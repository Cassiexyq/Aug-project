function browserFolder(path) {
	try {
		 var Message = "\请\选\择\文\件\夹";  // 选择框提示信息
		 var Shell = new ActiveXObject("Shell.Application");
		var Folder = Shell.BrowseForFolder(0, Message, 64, 17);// 起始目录为：我的电脑
		// var Folder = Shell.BrowseForFolder(0,Message,0); //起始目录为：桌面
       if (Folder != null) {
		             Folder = Folder.items();  // 返回 FolderItems 对象
		             Folder = Folder.item();  // 返回 Folder item 对象
		             Folder = Folder.Path;   // 返回路径
		             if (Folder.charAt(Folder.length - 1) != "\\") {
		                 Folder = Folder + "\\";
		             }
		        document.getElementById(path).value= Folder;
		    return Folder;
		    } 
	}
    catch (e) {
       alert(e.message); 
     }
}