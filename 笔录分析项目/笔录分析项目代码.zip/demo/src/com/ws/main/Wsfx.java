package com.ws.main;



public class Wsfx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileParse fileParse = new FileParse();
		fileParse.parse("F:\\File\\");
		System.out.println("success");
	}

}
