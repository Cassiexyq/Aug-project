package com.ws.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.rtf.RTFEditorKit;

import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.POIXMLDocument;
import org.apache.poi.POIXMLTextExtractor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import com.ws.model.Ws;
public class FileParse {
	
	String filename;  //�ļ���
	String content;  //�ļ�����
	String filefullpath;  //�ļ�ȫ·��
    String slfy;     //������Ժ
    String ay;  //����
    Date ktsj;  //��ͥʱ��
    String ktdd;  //��ͥ�ص�
    String spry;  //������Ա
    String sjy;  //���Ա
//    String ah;         //����
    String yg;    //ԭ��
    String bg;    //����
    Date sgfssjdate;  //�¹ʷ���ʱ��
    String sgfssj;
    String sgfsdd;  //�¹ʷ����ص�
    String sgjg;  //�¹ʾ���
    String sgzrrdqk;  //�¹������϶����
    String ysgclph;  //ԭ���¹ʳ����ƺ�
    String ysgclsyz;  //ԭ���¹ʳ���������
    String ysgcljsy;  //ԭ���¹ʳ�����ʻԱ
    String bsgclph;  //�����¹ʳ����ƺ�
    String bsgclsyz;  //�����¹ʳ���������
    String bsgcljsy;  //�����¹ʳ�����ʻԱ
    String sgcljqxbxgs;  //�¹ʳ�����ǿ�ձ��չ�˾
    String sgclsyszxbxgs;  //�¹ʳ�����ҵ�����ձ��չ�˾
    String syszxpcxe;  //��ҵ�������⳥�޶�
//    String sgqtpczrzt;  //�¹������⳥��������
    String ydfpckse;  //�ѵ渶�⳥������
    String dfr;  //�渶��
    String ylfse;  //ҽ�Ʒ�����
    String zysj;  //סԺʱ��
    String zyhsbzfse;  //סԺ��ʳ����������
    String hlq;  //������
    String hlfse;  //����������
    String yyq;  //Ӫ����
    String yyfse;  //Ӫ��������
    String wgq;  //����
    String wgfse;  //�󹤷�����
    String jtfse;  //��ͨ������
    String zsfse;  //ס�޷�����
    String zcdjjdjlsj;  //�²еȼ���������ʱ��
    String zcdjjdjl;  //�²еȼ���������
    String bfyrshfse;  //�����������������
    String cjpcjse;  //�м��⳥������
    String jsshfwj;  //�����𺦸�ο��
    String cjshfzjfse;  //�м�������߷�����


	
    /**
     * �������ݲ�д��excel
     * @param filefullPath  Ŀ¼·��
     */
    public List<Ws> parse(String filefullPath){
    	File file = new File(filefullPath);
//    	File[] files = file.listFiles();
    	String[] filenames = file.list();
//    	System.out.println(filenames.length);
    	
    	List<Ws> list = new ArrayList<Ws>();
    	
    	for(int i = 0; i < filenames.length; i++){
    		this.filefullpath  = filefullPath+filenames[i];
    		File file2 = new File(filefullpath);
//    		System.out.println(file2);
    		if(file2.isFile()){
    			Ws ws = new Ws();
    			System.out.println("��ʼ����  -��"+filenames[i]);
    			this.filename = getFileName(filenames[i]);
    			this.content = getContent(filefullpath);
//    			System.out.println(content);
                if(content!=null && content!=""){
//                	System.out.println(getSlfy());
//                	System.out.println(getAy());
//                	System.out.println(getYg());
//                	System.out.println(getBg());
//                	System.out.println(getSpry());
//                	System.out.println(getSjy());
//                	System.out.println(getKtsj());
//                	System.out.println(getKtdd());
//                	System.out.println(getZysj());
//                	System.out.println(getYlfse());
//                	System.out.println(getYyfse());
//                	System.out.println(getHlfse());
//                	System.out.println(getWgfse());
//                	System.out.println(getJtfse());
//                	System.out.println(getCjpcjse());
//                	System.out.println(getJsshfwj());
//                	System.out.println(getBfyrshfse());
//                	System.out.println(getCjshfzjfse());
//                	System.out.println(getZyhsbzfse());
//                	System.out.println(getYyq());
//                	System.out.println(getWgq());
//                	System.out.println(getHlq());
//                	System.out.println(getSgfssj());
//                	System.out.println(getSgfsdd());
//                	System.out.println(getSgjg());
//                	System.out.println(getSgzrrdqk());
//                	System.out.println(getBsgcljsy());
//                	System.out.println(getBsgclph());
//                	System.out.println(getBsgclsyz());
//                	System.out.println(getYsgclph());
//                	System.out.println(getYsgcljsy());
//                	System.out.println(getYsgclsyz());
//                	System.out.println(getZcdjjdjl());
//                	System.out.println(getZcdjjdjlsj());
//                	System.out.println(getSgcljqxbxgs());
//                	System.out.println(getSgclsyszxbxgs());
//                	System.out.println(getSyszxpcxe());
//                	System.out.println(getYdfpckse());
//                	System.out.println(getDfr());

                	ws.setFilename(this.filename);
                	ws.setSlfy(this.getSlfy());;
                	ws.setKtsj(this.getKtsj());
                	ws.setKtdd(this.getKtdd());
                	ws.setSjy(this.getSjy());
                	ws.setSpry(this.getSpry());
                	ws.setAy(this.getAy());
                	ws.setYg(this.getYg());
                	ws.setBg(this.getBg());
                	ws.setSgfssj(this.getSgfssj());
                	ws.setSgfsdd(this.getSgfsdd());
                	ws.setSgjg(this.getSgjg());
                	ws.setSgzrrdqk(this.getSgzrrdqk());
                	ws.setYsgclph(this.getYsgclph());
                	ws.setYsgcljsy(this.getYsgcljsy());
                	ws.setYsgclsyz(this.getYsgclsyz());
                	ws.setBsgclph(this.getBsgclph());
                	ws.setBsgcljsy(this.getBsgcljsy());
                	ws.setBsgclsyz(this.getBsgcljsy());
                	ws.setSgcljqxbxgs(this.getSgcljqxbxgs());
                	ws.setSgclsyszxbxgs(this.getSgclsyszxbxgs());
                	ws.setSyszxpcxe(this.getSyszxpcxe());
                	ws.setYdfpckse(this.getYdfpckse());
                	ws.setDfr(this.getDfr());
                	ws.setYlfse(this.getYlfse());
                	ws.setZysj(this.getZysj());
                	ws.setZyhsbzfse(this.getZyhsbzfse());
                	ws.setYyq(this.getYyq());
                	ws.setYyfse(this.getYyfse());
                	ws.setHlfse(this.getYyfse());
                	ws.setHlq(this.getHlq());
                	ws.setWgfse(this.getWgfse());
                	ws.setWgq(this.getWgq());
                	ws.setJsshfwj(this.getJsshfwj());
                	ws.setBfyrshfse(this.getBfyrshfse());
                	ws.setJtfse(this.getJtfse());
                	ws.setZsfse(this.getZsfse());
                    ws.setCjpcjse(this.getCjpcjse());
                    ws.setCjshfzjfse(this.getCjshfzjfse());
                	ws.setZcdjjdjlsj(this.getZcdjjdjlsj());
                	ws.setZcdjjdjl(this.getZcdjjdjl());
                	
                	System.out.println(this.filename+"�����ɹ�");
                	list.add(ws);
//                	save(wsList);
                }
                
                else{
                	System.out.println("no content");
                }
    		}
    		else{
    			System.out.println("Not File");
    		}
    	}
    	return list;
    }


    public void createFile(String FileFullPath){
    	File file = new File(FileFullPath);
    	try{
    		if(!file.exists()){
    			file.createNewFile();
    		}
    		
    	}catch(IOException e){
    		e.printStackTrace();
    	}
    }
    
    
    /**
     * ��ȡ�ļ����ĺ�׺
     * @return ���ش���ĺ�׺��
     */
    public String getSuffix(String fileFullPath){
        String suffix=null;
        int index = fileFullPath.lastIndexOf(".");
        suffix = fileFullPath.substring(index);
        return suffix;
    }

    /**
     * ��ò�����չ�����������ͱ�ʶ���ļ���
     * @param fileName ����չ�����ļ�ȫ��
     * @return ������չ�����ļ���
     */
    public String getFileName(String filepath){
        String filename = null;
        int index = filepath.lastIndexOf(".");
        filename = filepath.substring(0,index);
        return filename;
    }
    
	public String getContent(String filepath) {
		String suffix = getSuffix(filepath);
		String result = "";
		try{
			if(".doc".equals(suffix)){
				return getDocContentString(filepath);
			}else if(".docx".equals(suffix)){
				return getDocxContentString(filepath);
			}else if(".rtf".equals(suffix)){
				return getRtfContentString(filepath);
			}	
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return result;
	}
    

   public static String getDocContentString(String Filepath) throws Exception{
	   String result = "";
	   try{
		   WordExtractor wordExtractor = new WordExtractor(new FileInputStream(new File(Filepath)));
		   return wordExtractor.getText();
	   }catch(FileNotFoundException e){
		   e.printStackTrace();
	   }catch(IOException e){
		   e.printStackTrace();
	   }
	   return result;
   }
   
   public static String getDocxContentString(String Filepath) throws Exception{
	   String result = "";
	   try{
		   POIXMLTextExtractor exactor = new XWPFWordExtractor(POIXMLDocument.openPackage(Filepath));
		   return exactor.getText();
	   }catch(IOException e){
		   e.printStackTrace();
	   } 
	   return result;
   }
   
   public static String getRtfContentString(String Filepath) throws Exception{
	   String result = "";
	   try{
		   DefaultStyledDocument styleDoc = new DefaultStyledDocument();
		   InputStream is = new FileInputStream(Filepath);
		   new RTFEditorKit().read(is, styleDoc, 0);
		   return new String(styleDoc.getText(0, styleDoc.getLength()).getBytes("ISO8859_1"));
	   }catch (IOException e) {      
           e.printStackTrace();      
       } catch (BadLocationException e) {      
           e.printStackTrace();      
       }      
	   return result;
   }
   
	public String getFilefullpath() {
		return filefullpath;
	}
	
    /**
     * ���� ������Ժ �ֶ�
     * @return
     */
	public String getSlfy() {
        String slfy=null;
//        String regex = "����С�*?������Ժ";
        String regex = "(\n|\r\n|\\n|\\r\\n|).*?��.*?Ժ";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()){
            int indexStart = matcher.start();
            int indexEnd = matcher.end();
            slfy = content.substring(indexStart,indexEnd);
        }
//        slfy = slfy.replaceAll("\\s","");
        return slfy;
	}
	public String getAy() {

		String ay = null;
		String regex = "��.*?��.*?(\n|\r\n)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(content);
		if(match.find()){
			 int indexStart = match.start();
	         int indexEnd = match.end()-1; 
	         ay = content.substring(indexStart, indexEnd);
		}
        ay = ay.replaceAll("\\s","");
		ay = ay.replace("����","");
	    ay = ay.replace("��", "");
	    ay = ay.replace("\n","");
		return ay;
	}
	public Date getKtsj() {
		String ktsj = null;
//		String regex = "��ͥʱ�䣺[0-9]{4}��[0-9]{1,2}��[0-9]{1,2}��[��|��]��[0-9]{1,2}��[0-9]{2}";
		String regex = "(��ͥ|)ʱ.*?��.*?(\n|\r\n)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(content);
		if(match.find()){
			 int indexStart = match.start()+5;
	         int indexEnd = match.end()-1; 
	         ktsj = content.substring(indexStart, indexEnd);
	         int h = 0;
	         String n = "";
	         ktsj = ktsj.replace(":00","ʱ");
//	         System.out.println(ktsj);
        	 String regex2 = "��\\d+ʱ";
	        Pattern p = Pattern.compile(regex2);
	        Matcher m = p.matcher(ktsj);
	        if(m.find()){
	           int s  = m.start()+1;
	           int e = m.end()-1;
	           h = Integer.parseInt(ktsj.substring(s, e));
	        }
	        if(ktsj.contains("��")){
	        	h = h+12;
	        }
	        String regex3 = "\\d+��\\d+��\\d+��";
	        Pattern p2 = Pattern.compile(regex3);
	        Matcher m2 = p2.matcher(ktsj);
	        if(m2.find()){
	           int s2  = m2.start();
	           int e2 = m2.end();
	           n = ktsj.substring(s2, e2);
	        }
//	        System.out.println(n);
	        ktsj = n + h + "ʱ";
		}
//		 System.out.println(ktsj);
		Date k = null;
		DateFormat  format = new SimpleDateFormat("yyyy��MM��dd��HHʱ");
		try {
			k = format.parse(ktsj);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return k;
	}
	public String getKtdd() {
		String ktdd = null;
//		String regex = "(��ͥ|)��.*?�㡣*?(\n|\r\n)";
		String regex = "(��ͥ|)��.*?��.*?(\n|\r\n|\\s)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(content);
		if(match.find()){
			int indexStart = match.start();
			int indexEnd = match.end()-1;
			ktdd = content.substring(indexStart,indexEnd);
		}
		ktdd = ktdd.replaceAll("\\s","");
		ktdd = ktdd.replace("��ͥ","");
		ktdd = ktdd.replace("�ص�", "");
		ktdd = ktdd.replace("\n","");
		ktdd = ktdd.replace("��","");
		return ktdd;
	}
	public String getSpry() {
		String spry = null;
		String regex = "����(��|)Ա.*?(\n|\r\n|\\s)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(content);
		if(match.find()){
			 int indexStart = match.start();
	         int indexEnd = match.end()-1; 
	         spry = content.substring(indexStart, indexEnd);
		}
		spry = spry.replace("������Ա","");
		spry = spry.replace("����Ա","");
		spry = spry.replace("��","");
		return spry;
	}
	public String getSjy() {
		String sjy = null;
		String regex = "���Ա.*?(\n|\r\n| )";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(content);
		if(match.find()){
			 int indexStart = match.start()+4;
	         int indexEnd = match.end()-1; 
	         sjy = content.substring(indexStart, indexEnd);
		}
		return sjy;
	}

	public String getYg() {
        String yg = "";
        String regex = "\\s{1}(ԭ��|������|������|����ִ����).{1}.*?(,|��|��)";
//       String regex = "ԭ�� .*?(\n|\r\n|��)";
       Pattern pattern = Pattern.compile(regex);
       Matcher matcher = pattern.matcher(content);
       if(matcher.find()){
//           if(i == 4) break;
    	   int indexStart = matcher.start();
           int indexEnd = matcher.end()-1;
           yg = content.substring(indexStart,indexEnd);
         
           
       }

       yg = yg.replace("ԭ��","");
       yg = yg.replace("��", "");
       yg = yg.replaceAll("\n","");
       return yg;
	}
	public String getBg() {
		String bg = "";
		String regex = "\\s{1}(����|��������|��������|��ִ����|������ִ����).{1}.*?(��)";
	       Pattern pattern = Pattern.compile(regex);
	       Matcher matcher = pattern.matcher(content);
	       while(matcher.find()){
	           int indexStart = matcher.start();
	           int indexEnd = matcher.end()-1;
	           bg = bg + content.substring(indexStart,indexEnd)+"  ";
	           bg = bg.replace("����","");
		       bg = bg.replace("��", "");
		       bg = bg.replace("\n","");
		       bg = bg.replace("  ", "\r\n");
		       bg = bg.replace("���չ�˾", "");
	       }		
	       
		return bg;
	}
	public Date getSgfssj() {
		String sgfssj = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+30);
		String regex = "\\d+��\\d+��\\d+��(\\d+ʱ\\d+��|\\d+ʱ)(��|��)";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end()-1; 
            sgfssj = temp.substring(indexStart, indexEnd);
		}
		this.sgfssj = sgfssj;
//		System.out.println(sgfssj);
		Date k = null;
		if(sgfssj != null && sgfssj != ""){
			DateFormat  format = null;
			if(sgfssj.contains("��")){
				format = new SimpleDateFormat("yyyy��MM��dd��HHʱmm��");
			}
			else{
				format = new SimpleDateFormat("yyyy��MM��dd��HHʱ");
			}
		    
		    try {
			    k = format.parse(sgfssj);
		    } catch (ParseException e) {
			    // TODO Auto-generated catch block
			    e.printStackTrace();
		    }
		}
		return k;
	}
	public String getSgfsdd() {
		String sgfsdd = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+100);
		temp = temp.replaceAll("\\s","");
		temp = temp.replaceAll("\n", "");
		if(temp.contains("��")){
			index = temp.indexOf("��");
		}
		else {
			index = temp.indexOf("��");
		}
		temp = temp.substring(index);
//		System.out.println(temp);
		String regex = ".*?(��|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		while(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end()-1; 
            sgfsdd = temp.substring(indexStart, indexEnd);
            return sgfsdd;
		}
		
		return sgfsdd;
	}
	public String getSgjg() {
		String sgjg = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+300);
		String regex = "����.*?��ͨ�¹�";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end(); 
            sgjg = temp.substring(indexStart, indexEnd);
		}
		return sgjg;
	}
	public String getSgzrrdqk() {
		String sgzrrdqk = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+500);
		String regex = "(�¹ʾ������|�������).*?��";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end()-1; 
            sgzrrdqk = temp.substring(indexStart, indexEnd);
		}
		
		return sgzrrdqk;
	}
	public String getYsgclph() {
		String ysgclph = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+150);
//		System.out.println(temp);
		if(temp.contains("ԭ��")){
			index = temp.indexOf("ԭ��");
		}
		else{
			index = temp.indexOf("������");
		}
		temp = temp.substring(index,index+30);
//		System.out.println(temp);
		String regex = "��.*?(��|��)";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end(); 
    	    ysgclph = temp.substring(indexStart, indexEnd);
		}
		return ysgclph;
	}
	public String getYsgclsyz() {
		if(getYsgclph() == ""){
			return "";
		}
		return getYg();
	}
	public String getYsgcljsy() {
		String ysgcljsy = "";
		if(getYsgclph() == ""){
			return "";
		}
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+200);
//		if(temp.contains("ԭ��")){
//			index = temp.indexOf("ԭ��");
//		}
//		else{
//			index = temp.indexOf("������");
//		}
		String regex = "(ԭ��|������).*?��ʻ";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end()-2; 
    	    ysgcljsy = temp.substring(indexStart, indexEnd);
		}
		
		return ysgcljsy;
	}
	public String getBsgclph() {
		String bsgclph = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+100);
//		System.out.println(temp);
		index = temp.indexOf("����");
		temp = temp.substring(index,index+20);
//		System.out.println(temp);
		String regex = "��.*?��";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start();
    	    int indexEnd = match.end(); 
    	    bsgclph = temp.substring(indexStart, indexEnd);
		}
		return bsgclph;
	}
	public String getBsgclsyz() {
		String bsgclsyz = "";
		String ph = getBsgclph();
		if(ph.contains("��")){
			ph = ph.replace("��", "");
		}
		String temp = "";
		int index = content.indexOf(ph);
		temp = content.substring(index+100);
		if(temp.contains(ph)){
			int index2 = temp.indexOf(ph);
			temp = temp.substring(index2, index2+50);
//			System.out.println(temp);
			if(temp.contains("������")){
				int i = temp.indexOf("������");
				temp = temp.substring(i);
				String regex = ".*?��";
				Pattern p = Pattern.compile(regex);
				Matcher m = p.matcher(temp);
				if(m.find()){
					int s = m.start();
					int e = m.end()-1;
					bsgclsyz = temp.substring(s,e);
					return bsgclsyz;
				}
			}
			String regex2 = "��.*?����";
			Pattern p2 = Pattern.compile(regex2);
			Matcher m2 = p2.matcher(temp);
			if(m2.find()){
				int s2 = m2.start()+1;
				int e2 = m2.end()-2;
				bsgclsyz = temp.substring(s2,e2);
				if(bsgclsyz.contains("��")){
					return getBsgcljsy();
//					return r;
				}
				return bsgclsyz;
			}
		}
        
		return getBsgcljsy();
	}
	public String getBsgcljsy() {
		String bsgcljsy = "";
		String temp = "";
		int index = 0;
		if(content.contains("�����϶������")){
			index = content.indexOf("�����϶������");
		}else{
			index = content.indexOf("��ʵ�����ɣ�");
		}
		temp = content.substring(index,index+500);
		String regex = "����.*?��ʻ";
//		String regex="\\d+�ꡣ*?(����|��)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
//			System.out.println(temp);
			int indexStart = match.start()+2;
    	    int indexEnd = match.end()-2; 
    	    bsgcljsy = temp.substring(indexStart, indexEnd);
		}
		
		return bsgcljsy;
	}

	public String getSgcljqxbxgs() {
        String temp = "";
        String str = "";
        if(content.contains("�����ڱ�������")){
        	int index = content.indexOf("�����ڱ�������");
        	temp = content.substring(index-50,index+50);
//        	System.out.println(temp);
        	int index2 = temp.indexOf("��ǿ��");
        	str = temp.substring(index2-10, index2+10);
//        	System.out.println(str);
        	String regex = "��.*?��ǿ��";
        	Pattern pattern = Pattern.compile(regex);
    		Matcher match = pattern.matcher(str);
    		if(match.find()){
    			int indexStart = match.start()+1;
        	    int indexEnd = match.end()-3; 
        	    str = str.substring(indexStart, indexEnd);
//        	    System.out.println(str);
                if(str.contains("��˾")||str.contains("�ҹ�˾")||str.equals("")){
        			String re = "����.*?����(���|����)���";
        			Pattern p = Pattern.compile(re);
        			Matcher m = p.matcher(temp);
        			if(m.find()){
        				int Start = m.start();
                	    int End = m.end(); 
                	    str = temp.substring(Start, End);
//                	    System.out.println(str);
                	    String re3 = "����.*?(��|��)";
                	    Pattern p2 = Pattern.compile(re3);
                	    Matcher m2 = p2.matcher(str);
                	    if(m2.find()){
                	    	int s = m2.start();
                	    	int e = m2.end()-1;
                	    	str = str.substring(s, e);
                	    }
        			}
                }

    		}
    		
        }

        
		return str;
	}
	public String getSgclsyszxbxgs() {
        String temp = "";
        String str = "";
        if(content.contains("�����ڱ�������")){
        	int index = content.indexOf("�����ڱ�������");
        	temp = content.substring(index-50, index+70);
//        	System.out.println(temp);
        	if(content.contains("��ҵ��")||content.contains("��ҵ������")){
        		String regex = "��ҵ(������|��)";
        		Pattern pattern = Pattern.compile(regex);
        		Matcher matcher = pattern.matcher(temp);
        		if(matcher.find()){
        			int start = matcher.start()-20;
        			int end = matcher.end();
        			str = temp.substring(start, end);
//        			System.out.println(str);
        			String r = "��.*?��ҵ(��|������)";
        			Pattern p = Pattern.compile(r);
        			Matcher m = p.matcher(str);
        			if(m.find()){
        				int s = m.start();
        				int e = m.end();
        				str = str.substring(s, e);
//        				System.out.println(str);
        				if(!str.contains("��˾") && !str.contains("�ҹ�˾")){
                               return str;
                    	}
        			}
        		}
          	    String re3 = "����.*?(��|��)";
        	    Pattern p2 = Pattern.compile(re3);
        	    Matcher m2 = p2.matcher(temp);
        	    if(m2.find()){
        	    	int s2 = m2.start();
        	    	int e2 = m2.end()-1;
        	    	str = temp.substring(s2, e2);
        		}	
        	}
        }
    			
       return str;
	}
	public String getSyszxpcxe() {
		String syszxpcxe = "";
	    String regex = "(��ҵ��|��ҵ������).*?��";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(content);
		if(m.find()){
			int s = m.start();
			int e = m.end();
			syszxpcxe = content.substring(s, e);
			syszxpcxe = syszxpcxe.replace("��","");
		}
		return syszxpcxe;
	}

	public String getYdfpckse() {
		String ydfpckse = "";
		String temp = "";
		if(content.contains("�渶")){
			int index = content.indexOf("�渶");
			temp = content.substring(index, index+20);
			String regex = "�渶.*?Ԫ";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(temp);
			if(m.find()){
				int s = m.start();
				int e = m.end();
				ydfpckse =  temp.substring(s, e);
				String regex2 = "\\d+Ԫ";
				Pattern p2 = Pattern.compile(regex2);
				Matcher m2 = p2.matcher(ydfpckse);
				if(m2.find()){
					int s2 = m2.start();
					int e2 = m2.end();
					ydfpckse =  ydfpckse.substring(s2, e2);
				}
			}
		}

		return ydfpckse;
	}
	public String getDfr() {
		String dfr = "";
		String temp = "";
		if(content.contains("�渶")){
			int index = content.indexOf("�渶");
			temp = content.substring(index-10, index+20);
//			System.out.println(temp);
			String regex = "(��|֤��).*?�渶";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(temp);
			if(m.find()){
				int s = m.start();
				int e = m.end();
				dfr =  temp.substring(s, e);
			}
			dfr.replace("��","");
			dfr.replace("֤��", "");
		}
		return dfr;
	}
	public String getYlfse() {
		String ylfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+200);
			if(temp.contains("ҽҩ��") || temp.contains("ҽ�Ʒ�")){
				
				if(temp.contains("ҽҩ��")){
					index = temp.indexOf("ҽҩ��");
				}
				else{
					index = temp.indexOf("ҽ�Ʒ�");	
				}
				temp = temp.substring(index+3, index+20);
			}
		}
		
		else if(content.contains("ҽҩ��") || content.contains("ҽ�Ʒ�")){
			
			if(content.contains("ҽҩ��")){
				index = content.indexOf("ҽҩ��");
			}
			else{
				index = content.indexOf("ҽ�Ʒ�");	
			}
			temp = content.substring(index+3, index+20);
		}
		
//		System.out.println(temp);
		String regex = ".*?(��|��|Ԫ)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
			int start = match.start();
			int end = match.end();
			ylfse = temp.substring(start, end); 
		}
		
//        ylfse = ylfse.replaceAll("\\s", "");
//        ylfse = ylfse.replace("\n", "");
		return ylfse;
	}
	public String getZysj() {
		String zysj = "";
		if(content.contains("סԺ����")){
			int index = content.indexOf("סԺ����");
			String temp = content.substring(index-1, index+20);
//			System.out.println(temp);
			String regex = "\\d+(��|��)";
			Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(temp);
		    if(matcher.find()){
		    	int indexStart = matcher.start();
		        int indexEnd = matcher.end();
		        zysj = temp.substring(indexStart, indexEnd);
		    }
		}
		
		return zysj;
	}
	public String getZyhsbzfse() {
		String zyhsbzfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("סԺ��ʳ������")){
			if(content.contains("��Э������")){
				index = content.indexOf("��Э������");
				temp = content.substring(index, index+300);
		
			    if(temp.contains("סԺ��ʳ������")){
					index = temp.indexOf("סԺ��ʳ������");
					temp = temp.substring(index+7, index+20);
				}
			}
			else{
				index = content.indexOf("סԺ��ʳ������");	
				temp = content.substring(index+7, index+20);	
			}
//			System.out.println(temp);
			String regex = ".*?(��|��|Ԫ)";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(temp);
			if(match.find()){
				int start = match.start();
				int end = match.end();
				zyhsbzfse = temp.substring(start, end); 
			}
		}
			
		return zyhsbzfse;
	}
	public String getHlq() {
		String hlq = "";
		if(content.contains("������")){
//			int index = content.indexOf("������");
			String regex = "�����ڡ�*?\\d+(��|��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(content);
			if(matcher.find()){
				int start = matcher.start()+3;
				int end = matcher.end();
				hlq = content.substring(start,end);
				if(hlq != null && hlq != "") return hlq;
			}
		}
		String temp = content;
		while(temp.contains("������")){
            int index = temp.indexOf("������");
            String ttemp = temp.substring(index, index+100);
//            System.out.println(ttemp);
//            temp = temp.substring(index);
			String regex = "������.*?����[\\s\\S]*?(��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(ttemp);
			while(match.find()){
//				System.out.println(ttemp);
			    int indexStart = match.start();
			    int indexEnd = match.end();
			    hlq = ttemp.substring(indexStart, indexEnd);
			    if(hlq!=null && hlq!=""){
			    	String regex2 = "(��|����).*?\\d+(��|����|��)";
                    Pattern p = Pattern.compile(regex2);
                    Matcher m = p.matcher(hlq);
                    if(m.find()){
//                    	System.out.println("y");
                    	int s = m.start();
                    	int e = m.end();
                    	hlq = hlq.substring(s,e);
        			    if(hlq!=null && hlq!=""){
        			    	String regex3 = "\\d+(��|����|��)";
                            Pattern p2 = Pattern.compile(regex3);
                            Matcher m2 = p2.matcher(hlq);
                            if(m2.find()){
//                            	System.out.println("y");
                            	int s2 = m2.start();
                            	int e2 = m2.end();
                            	hlq = hlq.substring(s2,e2);
                            	return hlq;
                            }
        			    }
                    }
			    }
			    			    
			}
			temp = temp.substring(index+100);
			
		}

		return hlq;
	}
	public String getHlfse() {
		String hlfse = null;
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+200);
			if(temp.contains("������")){
				index = temp.indexOf("������");	
			}
			temp = temp.substring(index+3, index+20);
		}
		
		else if(content.contains("������")){
            index = content.indexOf("������");	
            temp = content.substring(index+3, index+20);
		}

//		System.out.println(temp);
		String regex = ".*?(��|��|Ԫ)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
			int start = match.start();
			int end = match.end();
			hlfse = temp.substring(start, end); 
		}
		
//        ylfse = ylfse.replaceAll("\\s", "");
//        hlfse = ylfse.replace("\n", "");
		
		return hlfse;
	}
	public String getYyq() {
		String yyq = "";
		if(content.contains("Ӫ����")){
//			int index = content.indexOf("������");
			String regex = "Ӫ���ڡ�*?\\d+(��|��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(content);
			if(matcher.find()){
				int start = matcher.start()+3;
				int end = matcher.end();
				yyq = content.substring(start,end);
				if(yyq != null && yyq != "") return yyq;
			}
		}
		String temp = content;
		while(temp.contains("Ӫ����")){
            int index = temp.indexOf("Ӫ����");
            String ttemp = temp.substring(index, index+100);
//            System.out.println(ttemp);
//            temp = temp.substring(index);
			String regex = "Ӫ����[\\s\\S]*?(����|����)[\\s\\S]*?(��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(ttemp);
			while(match.find()){
//				System.out.println(ttemp);
			    int indexStart = match.start();
			    int indexEnd = match.end();
			    yyq = ttemp.substring(indexStart, indexEnd);
//			    return yyq;
			    if(yyq!=null && yyq!=""){
			    	String regex2 = "(��|����|����).*?\\d+(��|����|��)";
                    Pattern p = Pattern.compile(regex2);
                    Matcher m = p.matcher(yyq);
                    if(m.find()){
//                    	System.out.println("y");
                    	int s = m.start();
                    	int e = m.end();
                    	yyq = yyq.substring(s,e);
                    	return yyq;

                    }
			    }
			    			    
			}
			temp = temp.substring(index+100);
			
		}

		return yyq;
	}
	public String getYyfse() {
		String yyfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+200);
			if(temp.contains("Ӫ����")){
				index = temp.indexOf("Ӫ����");
				temp = temp.substring(index+3, index+20);
			}
			
		}
		
		else if(content.contains("Ӫ����")){
            index = content.indexOf("Ӫ����");	
            temp = content.substring(index+3, index+20);
		}

//		System.out.println(temp);
		String regex = ".*?(��|��|Ԫ)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
			int start = match.start();
			int end = match.end();
			yyfse = temp.substring(start, end); 
		}
		return yyfse;
	}
	public String getWgq() {
		String wgq = "";
		if(content.contains("����")){
//			int index = content.indexOf("������");
			String regex = "���ڡ�*?\\d+(��|��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(content);
			if(matcher.find()){
				int start = matcher.start()+3;
				int end = matcher.end();
				wgq = content.substring(start,end);
				if(wgq != null && hlq != "") return wgq;
			}
		}
		String temp = content;
		while(temp.contains("�󹤷�")){
            int index = temp.indexOf("�󹤷�");
            String ttemp = temp.substring(index, index+150);
//            System.out.println(ttemp);
//            temp = temp.substring(index);
			String regex = "�󹤷�[^\\d].*?(���վ������ҵ��׼�����⳥|����)[\\s\\S]*?(��)";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(ttemp);
			while(match.find()){
//				System.out.println(ttemp);
			    int indexStart = match.start();
			    int indexEnd = match.end();
			    wgq = ttemp.substring(indexStart, indexEnd);
//			    return wgq;
			    if(wgq!=null && wgq!=""){
			    	String regex2 = "(��\\d+����|\\d+��|סԺ.*��ֹ)";
                    Pattern p = Pattern.compile(regex2);
                    Matcher m = p.matcher(wgq);
                    if(m.find()){
//                    	System.out.println("y");
                    	int s = m.start();
                    	int e = m.end();
                    	wgq = wgq.substring(s,e);
                    	return wgq;
                    }
			    }
			    			    
//			    temp = temp.substring(indexEnd);
			}
			temp = temp.substring(index+150);
			
		}

		return wgq;
	}
	public String getWgfse() {
		String wgf = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+200);
			if(temp.contains("�󹤷�")){
				index = temp.indexOf("�󹤷�");
				temp = temp.substring(index+3, index+20);
			}
			
		}
		
		else if(content.contains("�󹤷�")){
            index = content.indexOf("�󹤷�");	
            temp = content.substring(index+3, index+20);
		}

//		System.out.println(temp);
		String regex = ".*?(��|��|Ԫ)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
			int start = match.start();
			int end = match.end();
			wgf = temp.substring(start, end); 
		}
		return wgf;
	}
	public String getJtfse() {
		String jtfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+300);
			if(temp.contains("��ͨ��")){
				index = temp.indexOf("��ͨ��");	
				temp = temp.substring(index+3, index+20);
			}
			
		}
		
		else if(content.contains("��ͨ��")){
            index = content.indexOf("��ͨ��");	
            temp = content.substring(index+3, index+20);
		}

//		System.out.println(temp);
		String regex = ".*?(��|��|Ԫ)";
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(temp);
		if(match.find()){
			int start = match.start();
			int end = match.end();
			jtfse = temp.substring(start, end); 
		}
		return jtfse;
	}
	public String getZsfse() {
		String zsfse = "";
		if(content.contains("ס�޷�")){
			int index = content.indexOf("ס�޷�");
			String temp = content.substring(index, index+20);
			System.out.println(temp);
			String regex = ".*?(��|��|Ԫ)";
			Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(temp);
		    if(matcher.find()){
		    	int indexStart = matcher.start()+3;
		        int indexEnd = matcher.end();
		        zsfse = temp.substring(indexStart, indexEnd);
		    }
		}
		return zsfse;
	}
	public String getZcdjjdjlsj() {
		String zcdjjdjlsj = "";
		String temp = "";
		if(content.contains("��ʵ�����ɣ�")){
			int index = content.indexOf("��ʵ�����ɣ�");
			temp = content.substring(index, index+210);
			getSgfssj();
			if(temp.contains(this.sgfssj)){
				int index2 = temp.indexOf(this.sgfssj);
				temp = temp.substring(index2+100);
//				System.out.println(temp);
				String regex = "\\d+��\\d+��\\d+��";
				Pattern pattern = Pattern.compile(regex);
				Matcher match = pattern.matcher(temp);
				if(match.find()){
//					System.out.println(temp);
					int indexStart = match.start();
		    	    int indexEnd = match.end(); 
		    	    zcdjjdjlsj = temp.substring(indexStart, indexEnd);
				}
			}

		}
		return zcdjjdjlsj;
	}
	public String getZcdjjdjl() {
		String zcdjjdjl = "";
		String temp = "";
		if(content.contains("��ʵ�����ɣ�")){
			int index = content.indexOf("��ʵ�����ɣ�");
			temp = content.substring(index, index+300);
//			int index2 = content.indexOf(getSgfssj());
//			temp = content.substring(index2+30);
			String regex = "����.*?�˲�";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(temp);
			if(match.find()){
//				System.out.println(temp);
				int indexStart = match.start();
	    	    int indexEnd = match.end(); 
	    	    zcdjjdjl = temp.substring(indexStart, indexEnd);
	    	    return zcdjjdjl;
			}
		}
		if(content.contains("��Э�����£�")){
			int index = content.indexOf("��Э�����£�");
			temp = content.substring(index);
			String regex = "(����|����).*?�˲�";
			Pattern pattern = Pattern.compile(regex);
			Matcher match = pattern.matcher(temp);
			if(match.find()){
//				System.out.println(temp);
				int indexStart = match.start();
	    	    int indexEnd = match.end(); 
	    	    zcdjjdjl = temp.substring(indexStart, indexEnd);
	    	    return zcdjjdjl;
			}
		}
		return zcdjjdjl;
	}
	public String getBfyrshfse() {
		String bfyrshfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+300);
			if(temp.contains("�������������")){
				index = temp.indexOf("�������������");
				temp = temp.substring(index+7, index+20);
//				System.out.println(temp);
				String regex = ".*?(��|��|Ԫ)";
				Pattern pattern = Pattern.compile(regex);
				Matcher match = pattern.matcher(temp);
				if(match.find()){
					int start = match.start();
					int end = match.end();
					bfyrshfse = temp.substring(start, end); 
				}
			}
			
		}

		return bfyrshfse;
	}
	public String getCjpcjse() {
		String cjpcjse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+300);
			if(temp.contains("�м��⳥��")){
				index = temp.indexOf("�м��⳥��");	
				temp = temp.substring(index+5, index+20);
//				System.out.println(temp);
				String regex = ".*?(��|��|Ԫ)";
				Pattern pattern = Pattern.compile(regex);
				Matcher match = pattern.matcher(temp);
				if(match.find()){
					int start = match.start();
					int end = match.end();
					cjpcjse = temp.substring(start, end); 
				}
			}

		}

		return cjpcjse;
	}
	public String getJsshfwj() {
		String jsshfwj  = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+300);
			if(temp.contains("�����𺦸�ο��")){
				index = temp.indexOf("�����𺦸�ο��");	
				temp = temp.substring(index+7, index+20);
//				System.out.println(temp);
				String regex = ".*?(��|��|Ԫ)";
				Pattern pattern = Pattern.compile(regex);
				Matcher match = pattern.matcher(temp);
				if(match.find()){
					int start = match.start();
					int end = match.end();
					jsshfwj = temp.substring(start, end); 
				}
			}
			
		}

		return jsshfwj;
	}
	public String getCjshfzjfse() {
		String cjshfzjfse = "";
		int index = 0;
		String temp = "";
		if(content.contains("��Э������")){
			index = content.indexOf("��Э������");
			temp = content.substring(index, index+300);
			if(temp.contains("�м��������߷�")){
				index = temp.indexOf("�м��������߷�");	
				temp = temp.substring(index+7, index+20);
//				System.out.println(temp);
				String regex = ".*?(��|��|Ԫ)";
				Pattern pattern = Pattern.compile(regex);
				Matcher match = pattern.matcher(temp);
				if(match.find()){
					int start = match.start();
					int end = match.end();
					cjshfzjfse = temp.substring(start, end); 
				}
			}
			
		}

		return cjshfzjfse;
	}
  
}
