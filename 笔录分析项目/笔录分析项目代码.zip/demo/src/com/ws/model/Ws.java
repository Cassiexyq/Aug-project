package com.ws.model;

import java.util.Date;

public class Ws {
    String content;  //
    String slfy;     //������Ժ
    String ay;  //����
    java.util.Date ktsj;  //��ͥʱ��
    String ktdd;  //��ͥ�ص�
    String spry;  //������Ա
    String sjy;  //���Ա
    String ah;         //����
    String yg;    //ԭ��
    String bg;    //����
    java.util.Date sgfssj;  //�¹ʷ���ʱ��
    String sgfsdd;  //�¹ʷ����ص�
    String sgjg;  //�¹ʾ���
    String sgzrrdqk;  //�¹������϶����
    String ysgclph;  //ԭ���¹ʳ����ƺ�
    String ysgclsyz;  //ԭ���¹ʳ���������
    String ysgcljsy;  //ԭ���¹ʳ�����ʻԱ
    String bsgclph;  //�����¹ʳ����ƺ�
    String bsgclsyz;  //�����¹ʳ���������
    String bsgcljsy;  //�����¹ʳ�����ʻԱ
    String sgcljqxbxgs;  //�¹ʳ�����ǿ�ձ��չ�˾
    String sgclsyszxbxgs;  //�¹ʳ�����ҵ�����ձ��չ�˾
    String syszxpcxe;  //��ҵ�������⳥�޶�
//    String sgqtpczrzt;  //�¹������⳥��������
    String ydfpckse;  //�ѵ渶�⳥������
    String dfr;  //�渶��
    String ylfse;  //ҽ�Ʒ�����
    String zysj;  //סԺʱ��
    String zyhsbzfse;  //סԺ��ʳ����������
    String hlq;  //������
    String hlfse;  //����������
    String yyq;  //Ӫ����
    String yyfse;  //Ӫ��������
    String wgq;  //����
    String wgfse;  //�󹤷�����
    String jtfse;  //��ͨ������
    String zsfse;  //ס�޷�����
    String zcdjjdjlsj;  //�²еȼ���������ʱ��
    String zcdjjdjl;  //�²еȼ���������
    String bfyrshfse;  //�����������������
    String cjpcjse;  //�м��⳥������
    String jsshfwj;  //�����𺦸�ο��
    String cjshfzjfse;  //�м�������߷�����
//    String dchhlylcdjdyj;  //���к��������̶ȼ������
//    String dchhlfse;  //���к���������
    String count;
    String filename;
    
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSlfy() {
		return slfy;
	}
	public void setSlfy(String slfy) {
		this.slfy = slfy;
	}
	public String getAy() {
		return ay;
	}
	public void setAy(String ay) {
		this.ay = ay;
	}
	public java.util.Date getKtsj() {
		return ktsj;
	}
	public void setKtsj(java.util.Date date) {
		this.ktsj = date;
	}
	public String getKtdd() {
		return ktdd;
	}
	public void setKtdd(String ktdd) {
		this.ktdd = ktdd;
	}
	public String getSpry() {
		return spry;
	}
	public void setSpry(String spry) {
		this.spry = spry;
	}
	public String getSjy() {
		return sjy;
	}
	public void setSjy(String sjy) {
		this.sjy = sjy;
	}
	public String getAh() {
		return ah;
	}
	public void setAh(String ah) {
		this.ah = ah;
	}
	public String getYg() {
		return yg;
	}
	public void setYg(String yg) {
		this.yg = yg;
	}
	public String getBg() {
		return bg;
	}
	public void setBg(String bg) {
		this.bg = bg;
	}
	public java.util.Date getSgfssj() {
		return sgfssj;
	}
	public void setSgfssj(Date date) {
		this.sgfssj = date;
	}
	public String getSgfsdd() {
		return sgfsdd;
	}
	public void setSgfsdd(String sgfsdd) {
		this.sgfsdd = sgfsdd;
	}
	public String getSgjg() {
		return sgjg;
	}
	public void setSgjg(String sgjg) {
		this.sgjg = sgjg;
	}
	public String getSgzrrdqk() {
		return sgzrrdqk;
	}
	public void setSgzrrdqk(String sgzrrdqk) {
		this.sgzrrdqk = sgzrrdqk;
	}
	public String getYsgclph() {
		return ysgclph;
	}
	public void setYsgclph(String ysgclph) {
		this.ysgclph = ysgclph;
	}
	public String getYsgclsyz() {
		return ysgclsyz;
	}
	public void setYsgclsyz(String ysgclsyz) {
		this.ysgclsyz = ysgclsyz;
	}
	public String getYsgcljsy() {
		return ysgcljsy;
	}
	public void setYsgcljsy(String ysgcljsy) {
		this.ysgcljsy = ysgcljsy;
	}
	public String getBsgclph() {
		return bsgclph;
	}
	public void setBsgclph(String bsgclph) {
		this.bsgclph = bsgclph;
	}
	public String getBsgclsyz() {
		return bsgclsyz;
	}
	public void setBsgclsyz(String bsgclsyz) {
		this.bsgclsyz = bsgclsyz;
	}
	public String getBsgcljsy() {
		return bsgcljsy;
	}
	public void setBsgcljsy(String bsgcljsy) {
		this.bsgcljsy = bsgcljsy;
	}
	public String getSgcljqxbxgs() {
		return sgcljqxbxgs;
	}
	public void setSgcljqxbxgs(String sgcljqxbxgs) {
		this.sgcljqxbxgs = sgcljqxbxgs;
	}
	public String getSgclsyszxbxgs() {
		return sgclsyszxbxgs;
	}
	public void setSgclsyszxbxgs(String sgclsyszxbxgs) {
		this.sgclsyszxbxgs = sgclsyszxbxgs;
	}
	public String getSyszxpcxe() {
		return syszxpcxe;
	}
	public void setSyszxpcxe(String syszxpcxe) {
		this.syszxpcxe = syszxpcxe;
	}
//	public String getSgqtpczrzt() {
//		return sgqtpczrzt;
//	}
//	public void setSgqtpczrzt(String sgqtpczrzt) {
//		this.sgqtpczrzt = sgqtpczrzt;
//	}
	public String getYdfpckse() {
		return ydfpckse;
	}
	public void setYdfpckse(String ydfpckse) {
		this.ydfpckse = ydfpckse;
	}
	public String getDfr() {
		return dfr;
	}
	public void setDfr(String dfr) {
		this.dfr = dfr;
	}
	public String getYlfse() {
		return ylfse;
	}
	public void setYlfse(String ylfse) {
		this.ylfse = ylfse;
	}
	public String getZysj() {
		return zysj;
	}
	public void setZysj(String zysj) {
		this.zysj = zysj;
	}
	public String getZyhsbzfse() {
		return zyhsbzfse;
	}
	public void setZyhsbzfse(String zyhsbzfse) {
		this.zyhsbzfse = zyhsbzfse;
	}
	public String getHlq() {
		return hlq;
	}
	public void setHlq(String hlq) {
		this.hlq = hlq;
	}
	public String getHlfse() {
		return hlfse;
	}
	public void setHlfse(String hlfse) {
		this.hlfse = hlfse;
	}
	public String getYyq() {
		return yyq;
	}
	public void setYyq(String yyq) {
		this.yyq = yyq;
	}
	public String getYyfse() {
		return yyfse;
	}
	public void setYyfse(String yyfse) {
		this.yyfse = yyfse;
	}
	public String getWgq() {
		return wgq;
	}
	public void setWgq(String wgq) {
		this.wgq = wgq;
	}
	public String getWgfse() {
		return wgfse;
	}
	public void setWgfse(String wgfse) {
		this.wgfse = wgfse;
	}
	public String getJtfse() {
		return jtfse;
	}
	public void setJtfse(String jtfse) {
		this.jtfse = jtfse;
	}
	public String getZsfse() {
		return zsfse;
	}
	public void setZsfse(String zsfse) {
		this.zsfse = zsfse;
	}
	public String getZcdjjdjlsj() {
		return zcdjjdjlsj;
	}
	public void setZcdjjdjlsj(String zcdjjdjlsj) {
		this.zcdjjdjlsj = zcdjjdjlsj;
	}
	public String getZcdjjdjl() {
		return zcdjjdjl;
	}
	public void setZcdjjdjl(String zcdjjdjl) {
		this.zcdjjdjl = zcdjjdjl;
	}
	public String getBfyrshfse() {
		return bfyrshfse;
	}
	public void setBfyrshfse(String bfyrshfse) {
		this.bfyrshfse = bfyrshfse;
	}
	public String getCjpcjse() {
		return cjpcjse;
	}
	public void setCjpcjse(String cjpcjse) {
		this.cjpcjse = cjpcjse;
	}
	public String getJsshfwj() {
		return jsshfwj;
	}
	public void setJsshfwj(String jsshfwj) {
		this.jsshfwj = jsshfwj;
	}
	public String getCjshfzjfse() {
		return cjshfzjfse;
	}
	public void setCjshfzjfse(String cjshfzjfse) {
		this.cjshfzjfse = cjshfzjfse;
	}
//	public String getDchhlylcdjdyj() {
//		return dchhlylcdjdyj;
//	}
//	public void setDchhlylcdjdyj(String dchhlylcdjdyj) {
//		this.dchhlylcdjdyj = dchhlylcdjdyj;
//	}
//	public String getDchhlfse() {
//		return dchhlfse;
//	}
//	public void setDchhlfse(String dchhlfse) {
//		this.dchhlfse = dchhlfse;
//	}
    
}
