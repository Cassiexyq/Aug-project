package com.ws.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ws.main.ToDB;

public class ParseWs extends HttpServlet {

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

        doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//��servlet�ǿ��Դ�ҳ���ȡ�ļ��еĺ�˴��룬֧��IE��ActiveX�ؼ�,��Ϊ����ҳ�涼��Ҫ�ڹȸ������У����Զ�ע�͵�������

//		response.setContentType("text/html");
//		String filepath = request.getParameter("filepath");
//		System.out.println(filepath);
//		filepath = filepath.replaceAll("\\\\", "\\\\\\\\");
//		System.out.println(filepath);
//        ToDB to = new ToDB();
//        int count = to.StoDB(filepath);
//        System.out.println(count);
//        RequestDispatcher dis = request.getRequestDispatcher("index.jsp");
//        dis.forward(request, response);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
