package nju.software.cpwsqwjs.service.dataService;

import java.util.HashMap;

import nju.software.cpwsqwjs.service.model.WscpfxgcFdlxModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcZdlxModel;


public interface WsCpfxgcService {
		
	public int saveCpfxgc(WscpfxgcModel wscpfxgcModel,int ajxh);
	
	public void saveFdLxqj(WscpfxgcFdlxModel fdlx,String lxlx,int ajxh,int lxqjBh);
	
	public void saveZdLxqj(WscpfxgcZdlxModel zdlx,String lxlx,int ajxh,int lxqjBh);

	public void saveFlft(WscpfxgcFtModel model,int ajxh,int cpfxgcbh);
	
	public void saveCpfxgcBatch(WscpfxgcModel wscpfxgcModel,int ajxh);
}
