package nju.software.cpwsqwjs.main.ParseWsToXls;

import nju.software.cpwsqwjs.main.ParseWsToXls.FileParse;

/**
 * �������
 * Created by Hufk on 2017/07/28.
 */
public class Wsjx {
    public static void main(String[] args){
        FileParse fileParse = new FileParse();
        fileParse.parse("H:\\FileStation\\Engineering-Center\\file\\");
    }

}
