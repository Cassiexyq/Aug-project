package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * PubQtsscyrId entity. @author MyEclipse Persistence Tools
 */
public class PubQtsscyrId implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -4274507938380117724L;
	
	private Integer ajxh;
	private Integer qtsscyrbh;

	// Constructors

	/** default constructor */
	public PubQtsscyrId() {
	}

	/** full constructor */
	public PubQtsscyrId(Integer ajxh, Integer qtsscyrbh) {
		this.ajxh = ajxh;
		this.qtsscyrbh = qtsscyrbh;
	}

	// Property accessors

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "QTSSCYRBH", nullable = false)
	public Integer getQtsscyrbh() {
		return this.qtsscyrbh;
	}

	public void setQtsscyrbh(Integer qtsscyrbh) {
		this.qtsscyrbh = qtsscyrbh;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof PubQtsscyrId))
			return false;
		PubQtsscyrId castOther = (PubQtsscyrId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getQtsscyrbh() == castOther.getQtsscyrbh()) || (this
						.getQtsscyrbh() != null
						&& castOther.getQtsscyrbh() != null && this
						.getQtsscyrbh().equals(castOther.getQtsscyrbh())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getQtsscyrbh() == null ? 0 : this.getQtsscyrbh().hashCode());
		return result;
	}

}