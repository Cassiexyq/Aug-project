package nju.software.cpwsqwjs.service.model;

import java.util.List;

public class WsxszjdModel {
	private String rdss;
	private List<String> zjjl;
	public String getRdss() {
		return rdss;
	}
	public void setRdss(String rdss) {
		this.rdss = rdss;
	}
	public List<String> getZjjl() {
		return zjjl;
	}
	public void setZjjl(List<String> zjjl) {
		this.zjjl = zjjl;
	}
	
}
