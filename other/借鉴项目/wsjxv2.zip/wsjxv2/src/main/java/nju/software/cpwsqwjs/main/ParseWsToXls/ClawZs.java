package nju.software.cpwsqwjs.main.ParseWsToXls;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.main.other.Htcsrq;
import nju.software.cpwsqwjs.service.WsService;
import nju.software.cpwsqwjs.util.FileNameUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.*;
import java.util.List;

/**
 * Created by Hufk on 2017/07/27.
 */
public class ClawZs {
    private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml", "applicationContextDataSource.xml");
    static WsJbDao wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
    static Logger logger = Logger.getLogger(Htcsrq.class);
    static AjjbDao ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");

    static SqlDao sqlDao = (SqlDao) appContext.getBean("sqlDao");
    static WsService wsService=(WsService) appContext.getBean("wsService");

    public static void main(String[] args){
        try{
            File file = new File("H:\\court-2-record.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String fydm = null;     // ��ȡ��Ժ�������е������ַ�

            //�����������ڼ�¼
            File fileLarq = new File("H:\\ZsLarq.txt");
            fileLarq.createNewFile();
            BufferedWriter bufferedWriterLarq = new BufferedWriter(new FileWriter(fileLarq));

            //д�뵱����
            File fileDsr = new File("H:\\ZsDsr.txt");
            fileDsr.createNewFile();
            BufferedWriter bufferedWriterDsr = new BufferedWriter(new FileWriter(fileDsr));

            do{
                fydm = bufferedReader.readLine();

                //��������Ժ����
                String FYDM = null;     // �����ķ�Ժ����
                if (fydm!=null && fydm.contains("FYDM")){

                    int index = fydm.indexOf(":");
                    FYDM = fydm.substring(index+1);
                    System.out.println(FYDM);
                }

                if(FYDM!=null){
                    //������Ժ��ȡ����
                    DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());

                    //ѭ����ȡ���󰸺Ų�����
                    String ZSAH = null;
                    do{
                        String line = bufferedReader.readLine();
                        if (!line.equals("")){
                            int index = line.lastIndexOf(" ");
                            ZSAH = line.substring(index+1);
                            System.out.println(ZSAH+"===");
                            try{
                                List<List<String>> ajxh = sqlDao.callSql("select AJXH,AH,LARQ from PUB_AJ_JB where AH = '"+ZSAH+"'");
                                if(ajxh==null||ajxh.size()==0){
                                    continue;
                                }

                                for(int i=0; i<ajxh.size(); i++){
                                    WsJbDO wsJbDO=wsJbDao.getCpwsBbyajxh(Integer.parseInt(ajxh.get(i).get(0)));
                                    if(wsJbDO==null||wsJbDO.getWsnr()==null||wsJbDO.getWsmc()==null) {
                                        System.out.println(ajxh.get(i).get(0)+"-----");
                                        continue;
                                    }
                                    bufferedWriterLarq.write(ajxh.get(i).get(1) + " " +ajxh.get(i).get(2)+"\r\n");

                                    //��ѯ��������Ϣ
                                    List<List<String>> listDsr = sqlDao.callSql("select AJXH,DSRBH,DSRSSDW,DSRLB,DSRJC from DSR_JB where AJXH = " +ajxh.get(i).get(0));
                                    for (int k=0;k<listDsr.size();k++){
                                        //д��
                                        bufferedWriterDsr.write("ah#"+ajxh.get(i).get(1)+"#ajxh#"+listDsr.get(k).get(0)+"#dsrbh#"+listDsr.get(k).get(1)+"#dsrssdw#"+listDsr.get(k).get(2)+"#dsrlb#"+listDsr.get(k).get(3)+"#dsrjc#"+listDsr.get(k).get(4)+"\r\n");
                                    }

                                    byte[] wsnr=wsJbDO.getWsnr();
                                    String wsnrString= POIUtil.getContent(wsnr, wsJbDO.getWswjm());
                                    if(wsnrString==null||wsnrString.trim().equals("")){
                                        continue;
                                    }

                                    //write to doc
                                    FileUtil.createFile("H:\\FileStation\\Engineering-Center\\file\\f3\\"+ FileNameUtil.getFullName(wsJbDO.getWswjm(),ajxh.get(i).get(1),3), wsnr);
                                }

                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        } else{
                            break;
                        }
                    }while (ZSAH!=null);
                }
            }while (fydm != null);

            //�ر�
            bufferedReader.close();
            bufferedWriterDsr.flush();
            bufferedWriterDsr.close();
            bufferedWriterLarq.flush();
            bufferedWriterLarq.close();
        }catch(IOException e){
            e.printStackTrace();
        }

    }
}
