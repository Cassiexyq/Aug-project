package nju.software.cpwsqwjs.service;

public interface Ayservice {

	public String getAy(int ajxh);
}
