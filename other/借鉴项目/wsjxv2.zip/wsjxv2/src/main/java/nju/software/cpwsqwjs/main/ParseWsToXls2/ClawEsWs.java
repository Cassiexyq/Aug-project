package nju.software.cpwsqwjs.main.ParseWsToXls2;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.main.other.Htcsrq;
import nju.software.cpwsqwjs.service.WsService;
import nju.software.cpwsqwjs.util.FileNameUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;


/**
 * ��ȡ����
 * @author lr12
 *
 */
public class ClawEsWs {

    private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml", "applicationContextDataSource.xml");
    static WsJbDao wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
    static Logger logger = Logger.getLogger(Htcsrq.class);
    static AjjbDao ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");

    static SqlDao sqlDao = (SqlDao) appContext.getBean("sqlDao");
    static WsService wsService=(WsService) appContext.getBean("wsService");
    public static void main(String[] args){
        List<DataSourceEnum> list = DataSourceEnum.getFydmList();
        Iterator<DataSourceEnum> iterator = list.iterator();

        try{
//            File file = new File("H:\\court-record.txt");
//            file.createNewFile();
//            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file));
//            File fileLog = new File("H:\\court-noDocument.txt");
//            fileLog.createNewFile();
//            BufferedWriter bufferedWriterLog = new BufferedWriter(new FileWriter(fileLog));

            //д����������
            File fileLarq = new File("H:\\YsLarq.txt");
            fileLarq.createNewFile();
            BufferedWriter bufferedWriterLarq = new BufferedWriter(new FileWriter(fileLarq));

            //д�뵱����
            File fileDsr = new File("H:\\YsDsr.txt");
            fileDsr.createNewFile();
            BufferedWriter bufferedWriterDsr = new BufferedWriter(new FileWriter(fileDsr));

            while (iterator.hasNext()){
                DataSourceEnum dataSourceEnum = (DataSourceEnum)iterator.next();
                DataSourceRouter.routerTo(dataSourceEnum.getFydm());

                // write FYDM to TXT
//                bufferedWriter.write("FYDM:"+dataSourceEnum.getFydm()+"\r\n");
//                bufferedWriterLog.write("FYDM:"+dataSourceEnum.getFydm()+"\r\n");

                try {
                    List<List<String>> ajxh = sqlDao.callSql("select AJXH,AH,AJXZ,SPCX,LARQ from PUB_AJ_JB where AJXZ = '6' and SPCX= '2' and JARQ>'2013-12-31' AND JARQ<'2017-07-01'");
                    if(ajxh==null||ajxh.size()==0){
//                        bufferedWriter.write("\r\n");
//                        bufferedWriterLog.write("\r\n");
                        continue;
                    }

                    //return;

                    for (int i = 0; i < ajxh.size(); i++) {
                        WsJbDO wsJbDO=wsJbDao.getCpwsBbyajxh(Integer.parseInt(ajxh.get(i).get(0)));
                        if(wsJbDO==null||wsJbDO.getWsnr()==null||wsJbDO.getWsmc()==null) {

                            //д�롰�����޽᰸���顱��־
//                            bufferedWriterLog.write(ajxh.get(i).get(0) + " " + ajxh.get(i).get(1) + "\r\n");
                            continue;
                        }
//                        try{
//                            List<List<String>> list1 = sqlDao.callSql("select ESAH from . where AJXH="+ajxh.get(i).get(0) + " and ESAH<>''");
//                            if (list1.size()>0){
//                                //һ��������Ϣд��
//                                bufferedWriter.write(ajxh.get(i).get(0) + " " + ajxh.get(i).get(1) + " " + list1.get(0).get(0) +"\r\n");
//
//                            }
//                        }catch (Exception e){
//                            e.printStackTrace();
//                        }

                        bufferedWriterLarq.write(ajxh.get(i).get(1)+" "+ajxh.get(i).get(4) + "\r\n");
                        //bufferedWriter.write(ajxh.get(i).get(0) + " " + ajxh.get(i).get(1) +"\r\n");

                        //��ѯ��������Ϣ
                        List<List<String>> listDsr = sqlDao.callSql("select AJXH,DSRBH,DSRSSDW,DSRLB,DSRJC from DSR_JB where AJXH = " +ajxh.get(i).get(0));
                        for (int k=0;k<listDsr.size();k++){
                            //д��
                            bufferedWriterDsr.write("ah#"+ajxh.get(i).get(1)+"#ajxh#"+listDsr.get(k).get(0)+"#dsrbh#"+listDsr.get(k).get(1)+"#dsrssdw#"+listDsr.get(k).get(2)+"#dsrlb#"+listDsr.get(k).get(3)+"#dsrjc#"+listDsr.get(k).get(4)+"\r\n");
                        }

                        //��ѯԭ�󰸺�
                        List<List<String>> listYsah = sqlDao.callSql("select YSAH from MJZX_LA_SS where AJXH = " +ajxh.get(i).get(0));
                        String ysah ="";
                        if (listYsah.size()>0){
                            ysah = listYsah.get(0).get(0);
                        } else{
                            ysah = "no";
                        }


                        byte[] wsnr=wsJbDO.getWsnr();
                        String wsnrString= POIUtil.getContent(wsnr, wsJbDO.getWswjm());
                        if(wsnrString==null||wsnrString.trim().equals("")){
                            continue;
                        }

                        //write to doc
                        FileUtil.createFile("H:\\FileStation\\Engineering-Center\\file\\"+ FileNameUtil.getFullName(wsJbDO.getWswjm(),ajxh.get(i).get(1),ysah), wsnr);
                    }

                }
                catch (Exception e) {
                    e.printStackTrace();
                }
//                bufferedWriter.write("\r\n");
//                bufferedWriterLog.write("\r\n");
            }
            bufferedWriterDsr.flush();
            bufferedWriterDsr.close();
            bufferedWriterLarq.flush();
            bufferedWriterLarq.close();
//            bufferedWriter.flush();
//            bufferedWriter.close();
//            bufferedWriterLog.flush();
//            bufferedWriterLog.close();
        }catch (IOException e){
            e.printStackTrace();
        }


    }

}
