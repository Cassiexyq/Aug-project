package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;

import javax.persistence.Column;

public class DmbId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * �����
	 */
	private String lbbh;
	/**
	 * ������
	 */
	private String dmbh;
	
	@Column(name = "LBBH", length = 20, nullable = false)
	public String getLbbh() {
		return lbbh;
	}

	public void setLbbh(String lbbh) {
		this.lbbh = lbbh;
	}

	@Column(name = "DMBH", length = 20, nullable = false)
	public String getDmbh() {
		return dmbh;
	}

	public void setDmbh(String dmbh) {
		this.dmbh = dmbh;
	}

}
