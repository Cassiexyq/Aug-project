package nju.software.cpwsqwjs.main.other;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DsrGrDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.AjjbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrGrDO;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.service.CaseModelByWs;
import nju.software.cpwsqwjs.service.impl.BaseCaseModelByWs;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.StringUtil;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * �����������
 * 
 * @author lr12
 * 
 */
public class Htcsrq {
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	static WsJbDao wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
	static Logger logger = Logger.getLogger(Htcsrq.class);
	static AjjbDao ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");
	static DsrGrDao dsrGrDao = (DsrGrDao) appContext.getBean("dsrgrDao");
	static SqlDao sqlDao = (SqlDao) appContext.getBean("sqlDao");
	static FileUtil htnr = new FileUtil();
	static FileUtil htajxh = new FileUtil();

	public static void htcsnyByajxh(String fymc, String fydm, Integer ajxh,String ah) {

		AjjbDO ajjbDO = ajjbDao.findByAjxh(ajxh);
		if (ajjbDO == null)
			return;
		if (ajjbDO.getAjxz() == null)
			return;
		List<DsrGrDO> dsrGrDOs = dsrGrDao.getDsrGrsByAjxh(ajxh);
		if (dsrGrDOs == null || dsrGrDOs.size() == 0){
			htajxh.append(fymc+"\t"+fydm+"\t"+ajxh + "\t����Ϣ�����");
			return;
		}
		WsJbDO wsJbDO = wsJbDao.getCpwsBbyajxh(ajxh);
		if (wsJbDO == null || wsJbDO.getWsnr() == null
				|| wsJbDO.getWsnr().length == 0){
			htajxh.append(fymc+"\t"+fydm+"\t"+ajxh + "\t"+ah+"\t�����������");
			return;
		}
		boolean sfht = false;
		try {
			WsAnalyse wsAnalyse = new WsAnalyse(wsJbDO.getWsnr(),
					wsJbDO.getWswjm());
			System.out.println(wsAnalyse.getWsnr());
			CaseModelByWs caseModelByWs = new BaseCaseModelByWs();
			if(wsAnalyse.getSscyr()==null)
				return;
			List<WssscyrModel> wssscyrModels = caseModelByWs
					.jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk());
			if (wssscyrModels == null || wssscyrModels.size() == 0)
				return;
			for (int i = 0; i < dsrGrDOs.size(); i++) {
				if (dsrGrDOs.get(i).getXm() == null)
					continue;
				if (dsrGrDOs.get(i).getCsnyr() != null)
					continue;
				System.out.println(dsrGrDOs.get(i).getXm());
				Date csDate = jxwsCsny(dsrGrDOs.get(i).getXm().trim(),
						wssscyrModels);
				if (csDate != null) {
					sfht = true;
					dsrGrDOs.get(i).setCsnyr(csDate);
					dsrGrDao.updateDsrGr(dsrGrDOs.get(i));
					htnr.append(fymc+"\t"+fydm+"\t"+ajxh + "\t" + dsrGrDOs.get(i).getXm().trim()
							+ "\t"
							+ DateUtil.format(csDate, DateUtil.newFormat));
				}
				else{
					htajxh.append(fymc+"\t"+fydm+"\t"+ajxh +"\t"+ah+ "\t����ȱ�ٳ��������ջ���");;
				}
				
			}
			if (sfht) {
				htajxh.append(fymc+"\t"+fydm+"\t"+ajxh + "\t����ɹ�");
			} else {
				htajxh.append(fymc+"\t"+fydm+"\t"+ajxh + "\t����Ϣ�����");
			}
			//logger.error(wssscyrModels);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}
	}

	public static Date jxwsCsny(String xm, List<WssscyrModel> wssscyrModels) {
		for (int i = 0; i < wssscyrModels.size(); i++) {
			WssscyrModel wssscyrModel = wssscyrModels.get(i);
			if (wssscyrModel.getSscyr() == null)
				continue;
			if (xm.equals(StringUtil.trim(wssscyrModel.getSscyr()))) {
				if (wssscyrModel.getCsrq() == null)
					return null;
				String csrq = wssscyrModel.getCsrq();
				csrq = change(csrq);
				System.out.println(csrq);
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
						"yyyy-MM-dd");
				try {
					Date rq = simpleDateFormat.parse(csrq);

					return rq;
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return null;
	}

	public static String change(String str) {
		str = str.replace("��", "-");
		str = str.replace("��", "-");
		str = str.replace("��", "");
		return str;
	}

	public static void main(String[] args) {
	/*	htnr.setS("./htnr.txt");
		htajxh.setS("./htajxh.txt");*/
		/*for (DataSourceEnum dataSourceEnum : DataSourceEnum.values()) {
			if(dataSourceEnum==DataSourceEnum.DEFAULT||dataSourceEnum==DataSourceEnum.TEST)
				continue;
			DataSourceRouter.routerTo(dataSourceEnum.getFydm());
			try {
				List<List<String>> ajxh = sqlDao
						.callSql("select AJXH,AH from PUB_AJ_JB  where ((AJXZ = '6' ) or (AJXZ='7' and SPCX='B')) and JARQ <> null");
				for (int i = 0; i < ajxh.size(); i++) {
					htcsnyByajxh(dataSourceEnum.getFymc(),
							dataSourceEnum.getFydm(),
							Integer.parseInt(ajxh.get(i).get(0)),ajxh.get(i).get(1));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		}*/
		
		 /*DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		 htcsnyByajxh(DataSourceEnum.TJGY.getFydm(),DataSourceEnum.TJGY.getFymc(),49936,"(2006)һ�������ֵ�0285��");*/
	}
}
