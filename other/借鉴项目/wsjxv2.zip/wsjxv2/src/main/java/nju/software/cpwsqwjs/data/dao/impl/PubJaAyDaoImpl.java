package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.BaseHibernateDAO;
import nju.software.cpwsqwjs.data.dao.PubJaAyDao;
import nju.software.cpwsqwjs.data.dataobject.PubJaAy;

import org.apache.log4j.Logger;



/**
 * 
 * �᰸����DaoImpl
 * 
 * @author PengJL
 *
 */
public class PubJaAyDaoImpl extends BaseHibernateDAO implements PubJaAyDao {

	private static final Logger log = Logger.getLogger(PubJaAyDaoImpl.class);

	@Override
	public PubJaAy getJaAyDObyAjxh(int ajxh) {
		String hql = "from PubJaAy where ajxh =" + ajxh;
		@SuppressWarnings("unchecked")
		List<PubJaAy> res = this.getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getJaAyDO By Hql : " + hql);
		}
		return (res==null||res.size() == 0) ? new PubJaAy() : res.get(0);
	}

	@Override
	public void savePubJaAy(PubJaAy pubJaAy) {
		getMySession().saveOrUpdate(pubJaAy);

	}

	@Override
	public List<PubJaAy> getJaAysbyAjxh(int ajxh) {
		String hql = "from PubJaAy where ajxh =" + ajxh;
		List<PubJaAy> res = this.getHibernateTemplate().find(hql);
		return (res.size() == 0 || res == null) ? null : res;

	}

}