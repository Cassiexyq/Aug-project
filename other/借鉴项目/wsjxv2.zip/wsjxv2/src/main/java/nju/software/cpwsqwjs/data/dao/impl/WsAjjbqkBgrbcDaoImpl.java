package nju.software.cpwsqwjs.data.dao.impl;


import nju.software.cpwsqwjs.data.dao.WsAjjbqkBgrbcDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBgrbcDO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

public class WsAjjbqkBgrbcDaoImpl extends HibernateDaoSupport implements WsAjjbqkBgrbcDao {
    private static final Logger log = LoggerFactory.getLogger(WsAjjbqkBgrbcDaoImpl.class);
    @Override
    public WsAjjbqkBgrbcDO getByAjxh(int ajxh) {
        List<WsAjjbqkBgrbcDO>list = findByProperty("AJXH",ajxh);
        if(list==null)
            return null;
        else if(list.size()==0)
            return null;

        return list.get(0);
    }
    public List findByProperty(String propertyName, Object value) {
        log.debug("finding WsAjjbqkBgrbcDO with property: " + propertyName
                + ", value: " + value);
        try {
            String queryString = "from WsAjjbqkBgrbcDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            log.error("find by property name failed", re);
            throw re;
        }
    }

    @Override
    public void save(WsAjjbqkBgrbcDO wsAjjbqkBgrbcDO) {
        log.debug("saving wsAjjbqkBgrbcDO");
        try {
            getHibernateTemplate().saveOrUpdate(wsAjjbqkBgrbcDO);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }
	@Override
	public int getMaxbh() {
		// TODO Auto-generated method stub
		return 0;
	}
}
