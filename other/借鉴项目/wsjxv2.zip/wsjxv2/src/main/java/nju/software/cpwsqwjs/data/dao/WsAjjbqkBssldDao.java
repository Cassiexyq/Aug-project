package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBssldDO;


    public interface WsAjjbqkBssldDao {
    public WsAjjbqkBssldDO getByAjxh(int ajxh);
    public void save(WsAjjbqkBssldDO wsAjjbqkBssldDO);
    public int getMaxbh();
}
