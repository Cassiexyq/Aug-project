package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "XZWS_SSJL")
public class XzwsssjlDO implements Serializable {

	private int ajxh;
	private String ah;
	private String bgzyfzrsfdt;
	private String fzrxm;
	private String fzrsf;
	private String sfgksl;
	private String bgkslly;
	private String yglsct;
	@Id
	@Column(name = "AJXH", unique = true, nullable = false)
	public int getAjxh() {
		return ajxh;
	}

	public void setAjxh(int ajxh) {
		this.ajxh = ajxh;
	}
	@Column(name = "AH")
	public String getAh() {
		return ah;
	}

	public void setAh(String ah) {
		this.ah = ah;
	}
	@Column(name = "BGZYFZRSFDT")
	public String getBgzyfzrsfdt() {
		return bgzyfzrsfdt;
	}

	public void setBgzyfzrsfdt(String bgzyfzrsfdt) {
		this.bgzyfzrsfdt = bgzyfzrsfdt;
	}
	@Column(name = "FZRXM")
	public String getFzrxm() {
		return fzrxm;
	}

	public void setFzrxm(String fzrxm) {
		this.fzrxm = fzrxm;
	}
	@Column(name = "FZRSF")
	public String getFzrsf() {
		return fzrsf;
	}

	public void setFzrsf(String fzrsf) {
		this.fzrsf = fzrsf;
	}
	@Column(name = "SFGKSL")
	public String getSfgksl() {
		return sfgksl;
	}

	public void setSfgksl(String sfgksl) {
		this.sfgksl = sfgksl;
	}
	@Column(name = "BGKSLLY")
	public String getBgkslly() {
		return bgkslly;
	}

	public void setBgkslly(String bgkslly) {
		this.bgkslly = bgkslly;
	}
	@Column(name = "YGLSCT")
	public String getYglsct() {
		return yglsct;
	}

	public void setYglsct(String yglsct) {
		this.yglsct = yglsct;
	}


}

