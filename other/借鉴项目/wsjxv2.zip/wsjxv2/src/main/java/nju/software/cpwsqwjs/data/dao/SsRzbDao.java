package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.SsRzbDO;

public interface SsRzbDao {
	public void addSsRzb(SsRzbDO ssrzbDO);


	public int getMaxId();

}
