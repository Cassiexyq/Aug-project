/**
 * created by 2010-11-4
 */
package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.PubAydmbDao;
import nju.software.cpwsqwjs.data.dataobject.PubAydmb;
import nju.software.cpwsqwjs.util.StringUtil;



/**
 * @author byron
 * 
 */
public class PubAydmbDaoImpl extends HibernateDaoSupport
		implements PubAydmbDao {



	/*
	 * (non-Javadoc)
	 * 
	 * @see nju.edu.software.dao.PUB_AYDMBDao#loadAydm_5ByDmbh(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public int loadAydm_5ByDmbh(String dmbh) {
		List<PubAydmb> aydm_5 = getHibernateTemplate().find(
				"from PubAydmb where BBH = '05' and DMBH = ?", dmbh);
		if (aydm_5.isEmpty())
			return 0;
		else
			return aydm_5.get(0).getAydm_5();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see nju.edu.software.dao.PUB_AYDMBDao#loadDmbhByAydm_5(int)
	 */
	@SuppressWarnings("unchecked")
	public String loadDmbhByAydm_5(int aydm_5) {
		List<PubAydmb> dmbh = getHibernateTemplate().find(
				"from PubAydmb where BBH = '05' and AYDM_5 = ?", aydm_5);
		if (dmbh.isEmpty())
			return null;
		else
			return dmbh.get(0).getDmbh();
	}

	@SuppressWarnings("unchecked")
	@Override
	public int loadAydmByDmbhAndBbh(String dmbh, String bbh) {
		List<PubAydmb> aydm_5 = getHibernateTemplate().find(
				"from PubAydmb where BBH = ? and DMBH = ?", bbh, dmbh);
		if (aydm_5.isEmpty())
			return 0;
		else {
			if ("111".equals(bbh))
				return aydm_5.get(0).getAydm_11();
			else
				return aydm_5.get(0).getAydm_5();
		}
	}

	@Override
	public int loadAydmByDmbh(String dmbh) {
		@SuppressWarnings("unchecked")
		List<PubAydmb> aydm = getHibernateTemplate().find(
				"from PubAydmb where DMBH = ?", dmbh);
		if (aydm.isEmpty())
			return 0;
		else {
			PubAydmb ayDmb = aydm.get(0);
			dmbh = ayDmb.getDmbh();
			return ayDmb.getAydm_5();
		}
	}

	@Override
	public int loadMsAy(String dmbh) {
		String bbh = getMsBbh(dmbh);
		String hql = "from PubAydmb where BBH=? and DMBH=?";
		@SuppressWarnings("unchecked")
		List<PubAydmb> aydm = getHibernateTemplate().find(hql, bbh, dmbh);
		if (aydm.isEmpty())
			return 0;
		else {
			return aydm.get(0).getAydm_11();
		}
	}

	private String getMsBbh(String dmbh) {
		/*
		 * ���°���ʹ�������汾05��08��11 11�棬bbhΪ11 ������bhhΪGF
		 */
		if (!StringUtil.isBlank(dmbh)) {
			String bbh = dmbh.substring(0, 2);
			if (!"11".equals(bbh))
				return "GF";
		}
		return "11";
	}

	@Override
	public int loadAydm11ByDmbh(String dmbh) {

		String hql = "from PubAydmb where dmbh = '" + dmbh + "' ";
		@SuppressWarnings("unchecked")
		List<PubAydmb> aydm = getHibernateTemplate().find(hql);
		System.out.println(aydm);
		if (aydm.isEmpty())
			return 0;
		else {
			PubAydmb ay = aydm.get(0);
			return (ay.getAydm_11() != null) ? ay.getAydm_11() : 0;
		}
	}

	@Override
	public PubAydmb loadDmbhByAydm11(int aydm) {
		String hql = "from PubAydmb p where p.aydm_11 = " + aydm;
		@SuppressWarnings("unchecked")
		List<PubAydmb> pubaydm = getHibernateTemplate().find(hql);
		if (pubaydm.isEmpty())
			return null;
		else
			return pubaydm.get(0);
	}

	@Override
	public PubAydmb loadDmbhByAydm11AndBBH(int aydm, String BBH) {
		String hql = "from PubAydmb where aydm_11 = ? and BBH = ? ";
		@SuppressWarnings("unchecked")
		List<PubAydmb> pubaydm = getHibernateTemplate().find(hql, aydm, BBH);
		if (pubaydm.isEmpty())
			return null;
		else
			return pubaydm.get(0);
	}

}
