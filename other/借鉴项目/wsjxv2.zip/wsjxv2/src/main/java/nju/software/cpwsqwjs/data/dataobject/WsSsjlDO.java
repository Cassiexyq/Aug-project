package nju.software.cpwsqwjs.data.dataobject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WsssjlModel;
import nju.software.cpwsqwjs.service.model.WsssjlZkjlModel;

/**
 * WsSsjlDO entity. @author MyEclipse Persistence Tools
 * ���ϼ�¼
 */
@Entity
@Table(name = "WS_SSJL")
public class WsSsjlDO implements java.io.Serializable {

	private Integer ajxh;//�������
	private String ay;//����
	private String wzay;//��������
	private String ajly;//������Դ
	private String ajsj;//�����漰
	private String ktsl;//��ͥ����
	private String aydm;//���ɴ���
	private String ktrq;//��ͥ����(;)
	private String qsah;//ǰ�󰸺�(;)
	private String qsfy;//ǰ��Ժ
	private String ktslxx;//��ͥ������Ϣ
	private String bgkslyy;//����������ԭ��
	private String larq;//�������� 
	
	private String ysajsycx;//һ�󰸼����ó��� 
	private String jyzpt;//����ת��ͨ 
	private String ysajly;//һ�󰸼���Դ 
	private String slrq;//��������
	private String spzz;//������֯
	private String drsp;//��������
	private String sqcsrq;//���볷������
//	private HashMap<String,String> qxrxx;//ȱϯ����Ϣ(����)
//	private HashMap<String,String> ctrxx;//��ͥ����Ϣ(����)
	private String qsrq;//��������
	private String bgzyldct;//������Ҫ�쵼��ͥ
	private String xzxwzl;//������Ϊ����
	private String xzqqxwzl;//������Ȩ��Ϊ����
	
	private String jysyjycx;//�������ü��׳���
	private String msbfjxsl;//�������²��ּ�������
	private String ssxz;//��������
	private String jcy;//���Ա
	private String js;//���Ա��ɫ
//	private ArrayList<WsssjlZkjlModel> wsssjlZkjl;//�������ϼ�¼ָ�ؼ�¼
	private String qszay;//����������
	private String gsjg;//���߻���
	private String gsah;//���߰���
	private String slztqfdmsss;//���������𸽴���������
	private String jcyjyyqsl;//���Ժ������������
	private String snft;//���귨ͥ
	
	private String xzesqsah;//��������ǰ�󰸺�
	private String qsland;//ǰ���������
	private String qsfyjc;//ǰ��Ժ���
	private String fyjb;//ǰ��Ժ����
	private String qsahsxh;//ǰ�󰸺�˳���
	private String qscpsj;//ǰ�����ʱ��
	private String qswszl;//ǰ����������
	private String qsajyl;//ǰ�󰸼�����
	private String qsjafs;//ǰ��᰸��ʽ
	private String qssj;//ǰ����
	
	private String sshksfw;//���߻��߷�Χ
	private byte[] qspj;//ǰ���о�
	private String xsesqsah;//���¶���ǰ�󰸺�
	private String bzfymc;//��׼��Ժ����
	private String qsgsjg;//ԭ���߻���
	
	
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return ajxh;
	}
	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Column(name = "AY", length = 100)
	public String getAy() {
		return ay;
	}
	public void setAy(String ay) {
		this.ay = ay;
	}
	@Column(name = "WZAY", length = 100)
	public String getWzay() {
		return wzay;
	}
	public void setWzay(String wzay) {
		this.wzay = wzay;
	}
	@Column(name = "AJLY", length = 30)
	public String getAjly() {
		return ajly;
	}
	public void setAjly(String ajly) {
		this.ajly = ajly;
	}
	@Column(name = "AJSJ", length = 30)
	public String getAjsj() {
		return ajsj;
	}
	public void setAjsj(String ajsj) {
		this.ajsj = ajsj;
	}
	@Column(name = "KTSL", length = 10)
	public String getKtsl() {
		return ktsl;
	}
	public void setKtsl(String ktsl) {
		this.ktsl = ktsl;
	}
	@Column(name = "AYDM", length = 20)
	public String getAydm() {
		return aydm;
	}
	public void setAydm(String aydm) {
		this.aydm = aydm;
	}
	@Column(name = "KTRQ", length = 100)
	public String getKtrq() {
		return ktrq;
	}
	public void setKtrq(String ktrq) {
		this.ktrq = ktrq;
	}
	@Column(name = "QSAH", length = 255)
	public String getQsah() {
		return qsah;
	}
	public void setQsah(String qsah) {
		this.qsah = qsah;
	}
	@Column(name = "QSFY", length = 100)
	public String getQsfy() {
		return qsfy;
	}
	public void setQsfy(String qsfy) {
		this.qsfy = qsfy;
	}
	@Column(name = "KTSLXX", length = 20)
	public String getKtslxx() {
		return ktslxx;
	}
	public void setKtslxx(String ktslxx) {
		this.ktslxx = ktslxx;
	}
	@Column(name = "BGKSLYY", length = 20)
	public String getBgkslyy() {
		return bgkslyy;
	}
	public void setBgkslyy(String bgkslyy) {
		this.bgkslyy = bgkslyy;
	}
	@Column(name = "LARQ", length = 50)
	public String getLarq() {
		return larq;
	}
	public void setLarq(String larq) {
		this.larq = larq;
	}
	@Column(name = "YSAJSYCX", length = 20)
	public String getYsajsycx() {
		return ysajsycx;
	}
	public void setYsajsycx(String ysajsycx) {
		this.ysajsycx = ysajsycx;
	}
	@Column(name = "JYZPT", length = 10)
	public String getJyzpt() {
		return jyzpt;
	}
	public void setJyzpt(String jyzpt) {
		this.jyzpt = jyzpt;
	}
	@Column(name = "YSAJLY", length = 30)
	public String getYsajly() {
		return ysajly;
	}
	public void setYsajly(String ysajly) {
		this.ysajly = ysajly;
	}
	@Column(name = "SLRQ", length = 50)
	public String getSlrq() {
		return slrq;
	}
	public void setSlrq(String slrq) {
		this.slrq = slrq;
	}
	@Column(name = "SPZZ", length = 20)
	public String getSpzz() {
		return spzz;
	}
	public void setSpzz(String spzz) {
		this.spzz = spzz;
	}
	@Column(name = "DRSP", length = 10)
	public String getDrsp() {
		return drsp;
	}
	public void setDrsp(String drsp) {
		this.drsp = drsp;
	}
	@Column(name = "SQCSRQ", length = 50)
	public String getSqcsrq() {
		return sqcsrq;
	}
	public void setSqcsrq(String sqcsrq) {
		this.sqcsrq = sqcsrq;
	}
	@Column(name = "QSRQ", length = 50)
	public String getQsrq() {
		return qsrq;
	}
	public void setQsrq(String qsrq) {
		this.qsrq = qsrq;
	}
	@Column(name = "BGZYLDCT", length = 10)
	public String getBgzyldct() {
		return bgzyldct;
	}
	public void setBgzyldct(String bgzyldct) {
		this.bgzyldct = bgzyldct;
	}
	@Column(name = "XZXWZL", length = 20)
	public String getXzxwzl() {
		return xzxwzl;
	}
	public void setXzxwzl(String xzxwzl) {
		this.xzxwzl = xzxwzl;
	}
	@Column(name = "XZQQXWZL", length = 20)
	public String getXzqqxwzl() {
		return xzqqxwzl;
	}
	public void setXzqqxwzl(String xzqqxwzl) {
		this.xzqqxwzl = xzqqxwzl;
	}
	@Column(name = "JYSYJYCX", length = 10)
	public String getJysyjycx() {
		return jysyjycx;
	}
	public void setJysyjycx(String jysyjycx) {
		this.jysyjycx = jysyjycx;
	}
	@Column(name = "MSBFJXSL", length = 10)
	public String getMsbfjxsl() {
		return msbfjxsl;
	}
	public void setMsbfjxsl(String msbfjxsl) {
		this.msbfjxsl = msbfjxsl;
	}
	@Column(name = "SSXZ", length = 20)
	public String getSsxz() {
		return ssxz;
	}
	public void setSsxz(String ssxz) {
		this.ssxz = ssxz;
	}
	@Column(name = "JCY", length = 50)
	public String getJcy() {
		return jcy;
	}
	public void setJcy(String jcy) {
		this.jcy = jcy;
	}
	@Column(name = "JS", length = 20)
	public String getJs() {
		return js;
	}
	public void setJs(String js) {
		this.js = js;
	}
	@Column(name = "QSZAY", length = 100)
	public String getQszay() {
		return qszay;
	}
	public void setQszay(String qszay) {
		this.qszay = qszay;
	}
	@Column(name = "GSJG", length =100)
	public String getGsjg() {
		return gsjg;
	}
	public void setGsjg(String gsjg) {
		this.gsjg = gsjg;
	}
	@Column(name = "GSAH", length =100)
	public String getGsah() {
		return gsah;
	}
	public void setGsah(String gsah) {
		this.gsah = gsah;
	}
	@Column(name = "SLZTQFDMSSS", length =10)
	public String getSlztqfdmsss() {
		return slztqfdmsss;
	}
	public void setSlztqfdmsss(String slztqfdmsss) {
		this.slztqfdmsss = slztqfdmsss;
	}
	@Column(name = "JCYJYYQSL", length =10)
	public String getJcyjyyqsl() {
		return jcyjyyqsl;
	}
	public void setJcyjyyqsl(String jcyjyyqsl) {
		this.jcyjyyqsl = jcyjyyqsl;
	}
	@Column(name = "SNFT", length =10)
	public String getSnft() {
		return snft;
	}
	public void setSnft(String snft) {
		this.snft = snft;
	}
	@Column(name = "XZESQSAH", length =100)
	public String getXzesqsah() {
		return xzesqsah;
	}
	public void setXzesqsah(String xzesqsah) {
		this.xzesqsah = xzesqsah;
	}
	@Column(name = "QSLAND", length =20)
	public String getQsland() {
		return qsland;
	}
	public void setQsland(String qsland) {
		this.qsland = qsland;
	}
	@Column(name = "QSQSFYJC", length =10)
	public String getQsfyjc() {
		return qsfyjc;
	}
	public void setQsfyjc(String qsfyjc) {
		this.qsfyjc = qsfyjc;
	}
	@Column(name = "FYJB", length =10)
	public String getFyjb() {
		return fyjb;
	}
	public void setFyjb(String fyjb) {
		this.fyjb = fyjb;
	}
	@Column(name = "QSAHSXH", length =20)
	public String getQsahsxh() {
		return qsahsxh;
	}
	
	public void setQsahsxh(String qsahsxh) {
		this.qsahsxh = qsahsxh;
	}
	
	@Column(name = "QSCPSJ", length =50)
	public String getQscpsj() {
		return qscpsj;
	}
	public void setQscpsj(String qscpsj) {
		this.qscpsj = qscpsj;
	}
	@Column(name = "QSWSZL", length =50)
	public String getQswszl() {
		return qswszl;
	}
	public void setQswszl(String qswszl) {
		this.qswszl = qswszl;
	}
	@Column(name = "QSAJYL", length =100)
	public String getQsajyl() {
		return qsajyl;
	}
	public void setQsajyl(String qsajyl) {
		this.qsajyl = qsajyl;
	}
	@Column(name = "QSJAFS", length =50)
	public String getQsjafs() {
		return qsjafs;
	}
	public void setQsjafs(String qsjafs) {
		this.qsjafs = qsjafs;
	}
	@Column(name = "QSSJ", length =50)
	public String getQssj() {
		return qssj;
	}
	public void setQssj(String qssj) {
		this.qssj = qssj;
	}
	@Column(name = "SSHKFFW", length =100)
	public String getSshksfw() {
		return sshksfw;
	}
	public void setSshksfw(String sshksfw) {
		this.sshksfw = sshksfw;
	}
	@Column(name = "QSPJ")
	public byte[] getQspj() {
		return qspj;
	}
	public void setQspj(byte[] qspj) {
		this.qspj = qspj;
	}
	@Column(name = "XSESQSAH", length =100)
	public String getXsesqsah() {
		return xsesqsah;
	}
	public void setXsesqsah(String xsesqsah) {
		this.xsesqsah = xsesqsah;
	}
	@Column(name = "BZFYMC", length =100)
	public String getBzfymc() {
		return bzfymc;
	}
	public void setBzfymc(String bzfymc) {
		this.bzfymc = bzfymc;
	}
	@Column(name = "QSGSJG", length =100)
	public String getQsgsjg() {
		return qsgsjg;
	}
	public void setQsgsjg(String qsgsjg) {
		this.qsgsjg = qsgsjg;
	}
	 
	/**
	 * ��WsssjlModel��ȡ���ݣ�д��
	 * @param wsssjlModel
	 */
	public WsSsjlDO(WsssjlModel wsssjlModel) {
		// TODO Auto-generated constructor stub
		if(wsssjlModel.getAjly()!=null){
			this.ajly=wsssjlModel.getAjly();
		}
		if(wsssjlModel.getAjsj()!=null){
			this.ajsj=wsssjlModel.getAjsj();
		}
		if(wsssjlModel.getAy()!=null){
			this.ay=wsssjlModel.getAy();
		}
		if(wsssjlModel.getAydm()!=null){
			this.aydm=wsssjlModel.getAydm();
		}
		if(wsssjlModel.getBgkslyy()!=null){
			this.bgkslyy=wsssjlModel.getBgkslyy();
		}
		if(wsssjlModel.getBgzyldct()!=null){
			this.bgzyldct=wsssjlModel.getBgzyldct();
		}
		if(wsssjlModel.getBzfymc()!=null){
			this.bzfymc=wsssjlModel.getBzfymc();
		}
		if(wsssjlModel.getDrsp()!=null){
			this.drsp=wsssjlModel.getDrsp();
		}
		if(wsssjlModel.getFyjb()!=null){
			this.fyjb=wsssjlModel.getFyjb();
		}
		if(wsssjlModel.getGsah()!=null){
			this.gsah=wsssjlModel.getGsah();
		}
		if(wsssjlModel.getGsjg()!=null){
			this.gsjg=wsssjlModel.getGsjg();
		}
		if(wsssjlModel.getJcy()!=null){
			this.jcy=wsssjlModel.getJcy();
		}
		if(wsssjlModel.getJcyjyyqsl()!=null){
			this.jcyjyyqsl=wsssjlModel.getJcyjyyqsl();
		}
		if(wsssjlModel.getJs()!=null){
			this.js=wsssjlModel.getJs();
		}
		if(wsssjlModel.getJysyjycx()!=null){
			this.jysyjycx=wsssjlModel.getJysyjycx();
		}
		if(wsssjlModel.getJyzpt()!=null){
			this.jyzpt=wsssjlModel.getJyzpt();
		}
		if(wsssjlModel.getKtrq()!=null){
			String ktrq = null;
			for(String str : wsssjlModel.getKtrq()){
				ktrq = ktrq + str + ";";
			}
			this.ktrq = ktrq;
		}
		if(wsssjlModel.getKtsl()!=null){
			this.ktsl=wsssjlModel.getKtsl();
		}
		if(wsssjlModel.getKtslxx()!=null){
			this.ktslxx=wsssjlModel.getKtslxx();
		}
		if(wsssjlModel.getLarq()!=null){
			this.larq=wsssjlModel.getLarq();
		}
		if(wsssjlModel.getMsbfjxsl()!=null){
			this.msbfjxsl=wsssjlModel.getMsbfjxsl();
		}
		if(wsssjlModel.getQsah()!=null){
			String qsah = null;
			for(String str : wsssjlModel.getQsah()){
				qsah = qsah + str + ";";
			}
			this.qsah = qsah;
		}
		if(wsssjlModel.getQsahsxh()!=null){
			this.qsahsxh=wsssjlModel.getQsahsxh();
		}
		if(wsssjlModel.getQsajyl()!=null){
			this.qsajyl=wsssjlModel.getQsajyl();
		}
		if(wsssjlModel.getQscpsj()!=null){
			this.qscpsj=wsssjlModel.getQscpsj();
		}
		if(wsssjlModel.getQsfy()!=null){
			this.qsfy=wsssjlModel.getQsfy();
		}
		if(wsssjlModel.getQsfyjc()!=null){
			this.qsfyjc=wsssjlModel.getQsfyjc();
		}
		if(wsssjlModel.getQsgsjg()!=null){
			this.qsgsjg=wsssjlModel.getQsgsjg();
		}
		if(wsssjlModel.getQsjafs()!=null){
			this.qsjafs=wsssjlModel.getQsjafs();
		}
		if(wsssjlModel.getQsland()!=null){
			this.qsland=wsssjlModel.getQsland();
		}
		if(wsssjlModel.getQspj()!=null){
			try{
				this.qspj=wsssjlModel.getQspj().getBytes("UTF-8");
			}catch(UnsupportedEncodingException e){
				e.printStackTrace();
			}
		}
		if(wsssjlModel.getQsrq()!=null){
			this.qsrq=wsssjlModel.getQsrq();
		}
		if(wsssjlModel.getQssj()!=null){
			this.qssj=wsssjlModel.getQssj();
		}
		if(wsssjlModel.getQswszl()!=null){
			this.qswszl=wsssjlModel.getQswszl();
		}
		if(wsssjlModel.getQszay()!=null){
			this.qszay=wsssjlModel.getQszay();
		}
		if(wsssjlModel.getSlrq()!=null){
			this.slrq=wsssjlModel.getSlrq();
		}
		if(wsssjlModel.getSlztqfdmsss()!=null){
			this.slztqfdmsss=wsssjlModel.getSlztqfdmsss();
		}
		if(wsssjlModel.getSnft()!=null){
			this.snft=wsssjlModel.getSnft();
		}
		if(wsssjlModel.getSpzz()!=null){
			this.spzz=wsssjlModel.getSpzz();
		}
		if(wsssjlModel.getSqcsrq()!=null){
			this.sqcsrq=wsssjlModel.getSqcsrq();
		}
		if(wsssjlModel.getSshksfw()!=null){
			this.sshksfw=wsssjlModel.getSshksfw();
		}
		if(wsssjlModel.getSsxz()!=null){
			this.ssxz=wsssjlModel.getSsxz();
		}
		if(wsssjlModel.getWzay()!=null){
			this.wzay=wsssjlModel.getWzay();
		}
		if(wsssjlModel.getXsesqsah()!=null){
			this.xsesqsah=wsssjlModel.getXsesqsah();
		}
		if(wsssjlModel.getXzesqsah()!=null){
			this.xzesqsah=wsssjlModel.getXzesqsah();
		}
		if(wsssjlModel.getXzqqxwzl()!=null){
			this.xzqqxwzl=wsssjlModel.getXzqqxwzl();
		}
		if(wsssjlModel.getXzxwzl()!=null){
			this.xzxwzl=wsssjlModel.getXzxwzl();
		}
		if(wsssjlModel.getYsajly()!=null){
			this.ysajly=wsssjlModel.getYsajly();
		}
		if(wsssjlModel.getYsajsycx()!=null){
			this.ysajsycx=wsssjlModel.getYsajsycx();
		}
	}
	 

}