package nju.software.cpwsqwjs.test;

public class Test111 {

	
	public static void main(String[] args){
		String string="222,0.";
		String[] splitStrings=string.split("[,.]");
		System.out.println(splitStrings[1]);
	}
}
