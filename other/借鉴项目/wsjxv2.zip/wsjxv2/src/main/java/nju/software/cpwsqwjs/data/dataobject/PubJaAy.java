package nju.software.cpwsqwjs.data.dataobject;
// default package

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;


/**
 * PubJaAy entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="PUB_JA_AY"
)
@IdClass(value=PubJaAyPK.class)
public class PubJaAy  implements java.io.Serializable {


    // Fields    

	/**
	 * 
	 */
	private static final long serialVersionUID = 4752552514251472318L;
	 private Integer ajxh;
     private Integer jaaybh;
     private String ay;
     private String jaay;


    // Constructors

    /** default constructor */
    public PubJaAy() {
    }

  
	/** minimal constructor */
    public PubJaAy(Integer ajxh,Integer jaaybh) {
        this.ajxh = ajxh;
        this.jaaybh = jaaybh;
    }
    
    /** full constructor */
    public PubJaAy(Integer ajxh,Integer jaaybh, String ay, String jaay) {
    	this.ajxh = ajxh;
        this.jaaybh = jaaybh;
        this.ay = ay;
        this.jaay = jaay;
    }
    
    @Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return ajxh;
	}
	
	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name="JAAYBH", nullable=false)
	public Integer getJaaybh() {
		return jaaybh;
	}

   
    // Property accessors

	public void setJaaybh(Integer jaaybh) {
		this.jaaybh = jaaybh;
	}
	
    @Column(name="AY", length=10)
    public String getAy() {
        return this.ay;
    }
    
    public void setAy(String ay) {
        this.ay = ay;
    }
    
    @Column(name="JAAY", length=100)

    public String getJaay() {
        return this.jaay;
    }
    
    public void setJaay(String jaay) {
        this.jaay = jaay;
    }
	
}