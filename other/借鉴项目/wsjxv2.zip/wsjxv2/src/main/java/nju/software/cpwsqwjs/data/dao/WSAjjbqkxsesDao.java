package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WSAjjbqkxsesDO;

public interface WSAjjbqkxsesDao {
    public WSAjjbqkxsesDO getByAjxh(int ajxh);
    public void save(WSAjjbqkxsesDO wsAjjbqkxsesDO);
}
