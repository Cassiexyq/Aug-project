package nju.software.cpwsqwjs.business;

import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.handler.mseshandler.*;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSSscyrModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSSsjlModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MsysAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XSESCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XSESSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XsesAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XsesPjjgHandler;
import nju.software.cpwsqwjs.handler.xsyshandler.*;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESSscyrModelHandler;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSscyrModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XzysAjjbqkModelHandler;
import nju.software.cpwsqwjs.service.dataService.WsCpfxgcService;
import nju.software.cpwsqwjs.service.dataService.WsSpzzcyService;
import nju.software.cpwsqwjs.service.dataService.WsSsjlService;
import nju.software.cpwsqwjs.service.dataService.WsXspjjgfzService;
import nju.software.cpwsqwjs.service.dataService.WsajjbqkService;
import nju.software.cpwsqwjs.service.dataService.WsajjbxxService;
import nju.software.cpwsqwjs.service.dataService.WsdsrService;
import nju.software.cpwsqwjs.service.dataService.impl.WsCpfxgcServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsSpzzcyServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsSsjlServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsXspjjgfzServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsajjbqkServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsajjbxxServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsdsrServiceImpl;
import nju.software.cpwsqwjs.service.impl.BaseCaseModelByWs;
import nju.software.cpwsqwjs.service.model.*;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.util.AjlxEnum;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.util.XmlUtil;

import org.jdom.JDOMException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class WsManager {
	private BaseCaseModelByWs baseCaseModelByWs;
	private XmlUtil xmlUtil;
	private XsesPjjgHandler xsesPjjgHandler;
	private WsajjbxxService wsajjbxxService;
	private WsSpzzcyService wsSpzzcyService;
	private WsXspjjgfzService wsXspjjgfzService;
	private WsdsrService wsdsrService;
	private WsSsjlService wsSsjlService;
	private WsajjbqkService wsajjbqkService;
	private WsCpfxgcService wsCpfxgcService;
	public WsManager() {
		super();
		baseCaseModelByWs = new BaseCaseModelByWs();
		xmlUtil = new XmlUtil();
		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		xsesPjjgHandler = new XsesPjjgHandler();
		wsajjbxxService = new WsajjbxxServiceImpl();
		wsSpzzcyService = new WsSpzzcyServiceImpl();
		wsXspjjgfzService = new WsXspjjgfzServiceImpl();
		wsdsrService = new WsdsrServiceImpl();
		wsSsjlService = new WsSsjlServiceImpl();
		wsajjbqkService = new WsajjbqkServiceImpl();
		wsCpfxgcService = new WsCpfxgcServiceImpl();
	}
	
	public void saveData( WswsModel wswsModel,List<WssscyrModel> wssscyrModellist,WsssjlModel wsssjlModel,
			WsajjbqkModel wsajjbqkModel,WscpfxgcModel wscpfxgcModel,WscpjgModel wscpjgModel,XsPjjgModel xswscpjgModel
			,WswwModel wswwModel,
			AjlxEnum ajlx ){
			int ajxh=0;

			if(StringUtil.contains(ajlx.getAjlx(), "????")||StringUtil.contains(ajlx.getAjlx(), "????")){
				ajxh = wsajjbxxService.addAjjbxxFromWsAndCpjg(wswsModel, wscpjgModel, wswwModel);
			}else if(StringUtil.contains(ajlx.getAjlx(), "????")){
				ajxh = wsajjbxxService.addFromXsWsAndPjjg(wswsModel, xswscpjgModel, wswwModel);
			}
			System.out.println(ajxh);

			wsdsrService.addSscyr(wssscyrModellist, ajxh);
//			wsdsrService.addSscyrListBatch(wssscyrModellist, ajxh);
			

			wsSsjlService.saveSsjl(wsssjlModel, ajxh);

			if(StringUtil.contains(ajlx.getAjlx(), "????")||StringUtil.contains(ajlx.getAjlx(), "????")){
				wsajjbqkService.saveMsxzAjjbqk(ajxh, wsajjbqkModel);
			}else if(StringUtil.contains(ajlx.getAjlx(), "????")&&StringUtil.contains(ajlx.getAjlx(), "???")){
				wsajjbqkService.saveXsysAjjbqk(ajxh, wsajjbqkModel);
			}else if(StringUtil.contains(ajlx.getAjlx(), "????")&&StringUtil.contains(ajlx.getAjlx(), "????")){
				wsajjbqkService.saveXsesAjjbqk(ajxh, wsajjbqkModel);
			}

			wsCpfxgcService.saveCpfxgc(wscpfxgcModel, ajxh);

			if(StringUtil.contains(ajlx.getAjlx(), "????") && xswscpjgModel!=null){
				wsXspjjgfzService.saveXspjjg(ajxh, xswscpjgModel);
//				wsXspjjgfzService.savePjjgBacth(ajxh, xswscpjgModel);
			}
			
	}
	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws IOException
	 * @throws JDOMException
	 */
	public  void jxMses(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		WscpjgModel wscpjgModel = new WscpjgModel();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new SscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new SsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new CpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,wssscyrModellist,AjlxEnum.MSES);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new AjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel, wscpjgModel, null, wswwModel, AjlxEnum.MSES);
//		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,null,wscpfxgcModel,
//				wscpjgModel,null,wswwModel,outputpath,filename,inputpath,AjlxEnum.MSES);
	}

	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws JDOMException 
	 * @throws IOException 
	 */

	public void jxMsys(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		WscpjgModel wscpjgModel = new WscpjgModel();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new MSYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getSsjl(),wsnr,wsAnalyse);
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new MSYSSsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new MSYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,wssscyrModellist,AjlxEnum.MSYS);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new MsysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk(),wssscyrModellist);
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
//		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel, wscpjgModel, null, wswwModel, AjlxEnum.MSYS);
		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,null,wscpfxgcModel,
				wscpjgModel,null,wswwModel,outputpath,filename,inputpath,AjlxEnum.MSYS);
	}
	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	public void jxXzys(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		WscpjgModel wscpjgModel = new WscpjgModel();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new XZYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new XZYSSsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new XZYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,wssscyrModellist,AjlxEnum.XZYS);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new XzysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel, wscpjgModel, null, wswwModel, AjlxEnum.XZYS);
//		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,null,wscpfxgcModel,
//				wscpjgModel,null,wswwModel,outputpath,filename,inputpath,AjlxEnum.XZYS);
	}
	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	public void jxXsys(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		XsPjjgModel wscpjgModel = new XsPjjgModel();
		List<WsxszjdModel> zjdModellist=new ArrayList<WsxszjdModel>();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new XSYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl(),wsAnalyse.getWsnr());
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new XSYSSsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new XSYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc(),wssscyrModellist); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = new XSYSPjjgHandler().jxXspjjgModel(wsAnalyse, wssscyrModellist, AjlxEnum.XSYS);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new XsysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
		}
		if(wsajjbqkModel.getBssld()!=null){
			zjdModellist= new XsysZjdModelHandler().jxWsxszjdModel(wsajjbqkModel.getBssld());
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel, null,wscpjgModel,  wswwModel, AjlxEnum.XSYS);
//		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,zjdModellist,wscpfxgcModel,
//				null,wscpjgModel,wswwModel,outputpath,filename,inputpath,AjlxEnum.XSYS);
	}
	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	public void jxXzes(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		WscpjgModel wscpjgModel = new WscpjgModel();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();		
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new XZESSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new XZESSsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new XZESCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,wssscyrModellist,AjlxEnum.XZES);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new MsysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk(),wssscyrModellist);
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel,wscpjgModel,  null, wswwModel, AjlxEnum.XZES);
//		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,null,wscpfxgcModel,
//				wscpjgModel,null,wswwModel,outputpath,filename,inputpath,AjlxEnum.XZES);
	}
	/**
	 * @param wsAnalyse
	 * @param wsnr
	 * @param inputpath
	 * @param outputpath
	 * @param filename
	 * @throws JDOMException 
	 * @throws IOException 
	 */
	public void jxXses(WsAnalyse wsAnalyse,String wsnr,String inputpath,String outputpath,String filename) throws IOException, JDOMException{
		WsfdModel wsfdModel=new WsfdModel();
		WswsModel wswsModel=new WswsModel();
		WswwModel wswwModel=new WswwModel();
		WsssjlModel wsssjlModel=new WsssjlModel();
		List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
		XsPjjgModel wscpjgModel = new XsPjjgModel();
		List<WsxszjdModel> zjdModellist=new ArrayList<WsxszjdModel>();
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();		
		wsfdModel = baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
				wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		if(wsAnalyse.getSscyr()!=null){
			wssscyrModellist = new XZESSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getSsjl()!=null){
			wsssjlModel = new XSESSsjlModelHandler().jxWsssjlModel(wssscyrModellist,wsAnalyse.getSsjl());
		}
		if(wsAnalyse.getCpfxgc()!=null){
			wscpfxgcModel = new XSESCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc(),wssscyrModellist); 
		}
		if(wsAnalyse.getCpjg()!=null){
			wscpjgModel = xsesPjjgHandler.jxXspjjgModel(wsAnalyse,wssscyrModellist,AjlxEnum.XSES);
		}
		if(wsAnalyse.getAjjbqk()!=null){
			wsajjbqkModel = new XsesAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
		}
		if(wsajjbqkModel.getBssld()!=null){
			zjdModellist= new XsysZjdModelHandler().jxWsxszjdModel(wsajjbqkModel.getBssld());
		}
		if(wsAnalyse.getWw()!=null){
			wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
		}
		saveData(wswsModel, wssscyrModellist, wsssjlModel, wsajjbqkModel, wscpfxgcModel,null,wscpjgModel,   wswwModel, AjlxEnum.XSES);
//		xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,zjdModellist,wscpfxgcModel,
//				null,	wscpjgModel,wswwModel,outputpath,filename,inputpath,AjlxEnum.XSES);
	}


}