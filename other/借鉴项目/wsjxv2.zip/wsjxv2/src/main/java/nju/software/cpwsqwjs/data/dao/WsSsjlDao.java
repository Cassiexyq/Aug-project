package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsSsjlDO;
import nju.software.cpwsqwjs.service.model.WsssjlModel;

public interface WsSsjlDao {
	/**
	 * ���ݰ�����Ż�����ϼ�¼
	 * @param ajxh
	 * @return
	 */
	public WsSsjlDO getSsjlByAjxh(int ajxh);
	public Integer saveSsjlDo(WsSsjlDO wsSsjlDO);
	/**
	 * ��������
	 * @param ajxh
	 * @param wsssjlModel
	 */
	public void save(int ajxh, WsssjlModel wsssjlModel);
}
