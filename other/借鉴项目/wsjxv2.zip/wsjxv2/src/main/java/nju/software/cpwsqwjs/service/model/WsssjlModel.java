package nju.software.cpwsqwjs.service.model;

import java.util.ArrayList;
import java.util.HashMap;

public class WsssjlModel {
	private String ay;//����
	private String wzay;//��������
	private String ajly;//������Դ
	private String ajsj;//�����漰
	private String ktsl;//��ͥ����
	private String aydm;//���ɴ���
	private ArrayList<String> ktrq;//��ͥ����(;)
	private ArrayList<String> qsah;//ǰ�󰸺�(;)
	private String qsfy;//ǰ��Ժ
	private String ktslxx;//��ͥ������Ϣ
	private String bgkslyy;//����������ԭ��
	private String larq;//�������� 
	
	private String ysajsycx;//һ�󰸼����ó��� 
	private String jyzpt;//����ת��ͨ 
	private String ysajly;//һ�󰸼���Դ 
	private String slrq;//��������
	private String spzz;//������֯
	private String drsp;//��������
	private String sqcsrq;//���볷������
	private HashMap<String,String> qxrxx;//ȱϯ����Ϣ(����)
	private HashMap<String,String> ctrxx;//��ͥ����Ϣ(����)
	private String qsrq;//��������
	private String bgzyldct;//������Ҫ�쵼��ͥ
	private String xzxwzl;//������Ϊ����
	private String xzqqxwzl;//������Ȩ��Ϊ����
	
	private String jysyjycx;//�������ü��׳���
	private String msbfjxsl;//�������²��ּ�������
	private String ssxz;//��������
	private String jcy;//���Ա
	private String js;//���Ա��ɫ
	private ArrayList<WsssjlZkjlModel> wsssjlZkjl;//�������ϼ�¼ָ�ؼ�¼
	private String qszay;//����������
	private String gsjg;//���߻���
	private String gsah;//���߰���
	private String slztqfdmsss;//���������𸽴���������
	private String jcyjyyqsl;//���Ժ������������
	private String snft;//���귨ͥ
	
	private String xzesqsah;//��������ǰ�󰸺�
	private String qsland;//ǰ���������
	private String qsfyjc;//ǰ��Ժ���
	private String fyjb;//ǰ��Ժ����
	private String qsahsxh;//ǰ�󰸺�˳���
	private String qscpsj;//ǰ�����ʱ��
	private String qswszl;//ǰ����������
	private String qsajyl;//ǰ�󰸼�����
	private String qsjafs;//ǰ��᰸��ʽ
	private String qssj;//ǰ����
	
	private String sshksfw;//���߻��߷�Χ
	private String qspj;//ǰ���о�
	private String xsesqsah;//���¶���ǰ�󰸺�
	private String bzfymc;//��׼��Ժ����
	private String qsgsjg;//ԭ���߻���
	
	public String getAy() {
		return ay;
	}
	public void setAy(String ay) {
		this.ay = ay;
	}
	public String getWzay() {
		return wzay;
	}
	public void setWzay(String wzay) {
		this.wzay = wzay;
	}
	public String getAjly() {
		return ajly;
	}
	public void setAjly(String ajly) {
		this.ajly = ajly;
	}
	public String getAjsj() {
		return ajsj;
	}
	public void setAjsj(String ajsj) {
		this.ajsj = ajsj;
	}
	public String getKtsl() {
		return ktsl;
	}
	public void setKtsl(String ktsl) {
		this.ktsl = ktsl;
	}
	public String getAydm() {
		return aydm;
	}
	public void setAydm(String aydm) {
		this.aydm = aydm;
	}
	public ArrayList<String> getKtrq() {
		return ktrq;
	}
	public void setKtrq(ArrayList<String> ktrq) {
		this.ktrq = ktrq;
	}
	public ArrayList<String> getQsah() {
		return qsah;
	}
	public void setQsah(ArrayList<String> qsah) {
		this.qsah = qsah;
	}
	public String getQsfy() {
		return qsfy;
	}
	public void setQsfy(String qsfy) {
		this.qsfy = qsfy;
	}
	public String getKtslxx() {
		return ktslxx;
	}
	public void setKtslxx(String ktslxx) {
		this.ktslxx = ktslxx;
	}
	public String getBgkslyy() {
		return bgkslyy;
	}
	public void setBgkslyy(String bgkslyy) {
		this.bgkslyy = bgkslyy;
	}
	public String getLarq() {
		return larq;
	}
	public void setLarq(String larq) {
		this.larq = larq;
	}
	
	public String getYsajsycx() {
		return ysajsycx;
	}
	public void setYsajsycx(String ysajsycx) {
		this.ysajsycx = ysajsycx;
	}
	public String getJyzpt() {
		return jyzpt;
	}
	public void setJyzpt(String jyzpt) {
		this.jyzpt = jyzpt;
	}
	public String getYsajly() {
		return ysajly;
	}
	public void setYsajly(String ysajly) {
		this.ysajly = ysajly;
	}
	public String getSlrq() {
		return slrq;
	}
	public void setSlrq(String slrq) {
		this.slrq = slrq;
	}
	public String getSpzz() {
		return spzz;
	}
	public void setSpzz(String spzz) {
		this.spzz = spzz;
	}
	public String getDrsp() {
		return drsp;
	}
	public void setDrsp(String drsp) {
		this.drsp = drsp;
	}
	public String getSqcsrq() {
		return sqcsrq;
	}
	public void setSqcsrq(String sqcsrq) {
		this.sqcsrq = sqcsrq;
	}
	public HashMap<String, String> getQxrxx() {
		return qxrxx;
	}
	public void setQxrxx(HashMap<String, String> qxrxx) {
		this.qxrxx = qxrxx;
	}
	public HashMap<String, String> getCtrxx() {
		return ctrxx;
	}
	public void setCtrxx(HashMap<String, String> ctrxx) {
		this.ctrxx = ctrxx;
	}
	public String getXzxwzl() {
		return xzxwzl;
	}
	public void setXzxwzl(String xzxwzl) {
		this.xzxwzl = xzxwzl;
	}
	public String getXzqqxwzl() {
		return xzqqxwzl;
	}
	public void setXzqqxwzl(String xzqqxwzl) {
		this.xzqqxwzl = xzqqxwzl;
	}
	public String getBgzyldct() {
		return bgzyldct;
	}
	public void setBgzyldct(String bgzyldct) {
		this.bgzyldct = bgzyldct;
	}
	public String getQsrq() {
		return qsrq;
	}
	public void setQsrq(String qsrq) {
		this.qsrq = qsrq;
	}
	public String getSsxz() {
		return ssxz;
	}
	public void setSsxz(String ssxz) {
		this.ssxz = ssxz;
	}
	public String getQszay() {
		return qszay;
	}
	public void setQszay(String qszay) {
		this.qszay = qszay;
	}
	public String getGsjg() {
		return gsjg;
	}
	public void setGsjg(String gsjg) {
		this.gsjg = gsjg;
	}
	public String getGsah() {
		return gsah;
	}
	public void setGsah(String gsah) {
		this.gsah = gsah;
	}
	public String getJcyjyyqsl() {
		return jcyjyyqsl;
	}
	public void setJcyjyyqsl(String jcyjyyqsl) {
		this.jcyjyyqsl = jcyjyyqsl;
	}
	public String getSnft() {
		return snft;
	}
	public void setSnft(String snft) {
		this.snft = snft;
	}
	public String getJysyjycx() {
		return jysyjycx;
	}
	public void setJysyjycx(String jysyjycx) {
		this.jysyjycx = jysyjycx;
	}
	public ArrayList<WsssjlZkjlModel> getWsssjlZkjl() {
		return wsssjlZkjl;
	}
	public void setWsssjlZkjl(ArrayList<WsssjlZkjlModel> wsssjlZkjl) {
		this.wsssjlZkjl = wsssjlZkjl;
	}
	public String getSlztqfdmsss() {
		return slztqfdmsss;
	}
	public void setSlztqfdmsss(String slztqfdmsss) {
		this.slztqfdmsss = slztqfdmsss;
	}
	public String getJcy() {
		return jcy;
	}
	public void setJcy(String jcy) {
		this.jcy = jcy;
	}
	public String getJs() {
		return js;
	}
	public void setJs(String js) {
		this.js = js;
	}
	public String getQsfyjc() {
		return qsfyjc;
	}
	public void setQsfyjc(String qsfyjc) {
		this.qsfyjc = qsfyjc;
	}
	public String getQsahsxh() {
		return qsahsxh;
	}
	public void setQsahsxh(String qsahsxh) {
		this.qsahsxh = qsahsxh;
	}
	public String getXzesqsah() {
		return xzesqsah;
	}
	public void setXzesqsah(String xzesqsah) {
		this.xzesqsah = xzesqsah;
	}
	public String getQswszl() {
		return qswszl;
	}
	public void setQswszl(String qswszl) {
		this.qswszl = qswszl;
	}
	public String getQsjafs() {
		return qsjafs;
	}
	public void setQsjafs(String qsjafs) {
		this.qsjafs = qsjafs;
	}
	public String getQssj() {
		return qssj;
	}
	public void setQssj(String qssj) {
		this.qssj = qssj;
	}
	public String getMsbfjxsl() {
		return msbfjxsl;
	}
	public void setMsbfjxsl(String msbfjxsl) {
		this.msbfjxsl = msbfjxsl;
	}
	public String getQsland() {
		return qsland;
	}
	public void setQsland(String qsland) {
		this.qsland = qsland;
	}
	public String getFyjb() {
		return fyjb;
	}
	public void setFyjb(String fyjb) {
		this.fyjb = fyjb;
	}
	public String getQscpsj() {
		return qscpsj;
	}
	public void setQscpsj(String qscpsj) {
		this.qscpsj = qscpsj;
	}
	public String getQsajyl() {
		return qsajyl;
	}
	public void setQsajyl(String qsajyl) {
		this.qsajyl = qsajyl;
	}
	public String getSshksfw() {
		return sshksfw;
	}
	public void setSshksfw(String sshksfw) {
		this.sshksfw = sshksfw;
	}
	public String getQspj() {
		return qspj;
	}
	public void setQspj(String qspj) {
		this.qspj = qspj;
	}
	public String getXsesqsah() {
		return xsesqsah;
	}
	public void setXsesqsah(String xsesqsah) {
		this.xsesqsah = xsesqsah;
	}
	public String getBzfymc() {
		return bzfymc;
	}
	public void setBzfymc(String bzfymc) {
		this.bzfymc = bzfymc;
	}
	public String getQsgsjg() {
		return qsgsjg;
	}
	public void setQsgsjg(String qsgsjg) {
		this.qsgsjg = qsgsjg;
	}
}
