package nju.software.cpwsqwjs.service.impl;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dataobject.Dmb;
import nju.software.cpwsqwjs.service.DsrService;


/**
 * ������Service
 * 
 * @author DuWenjun
 * 
 */
public class DsrServiceImpl implements DsrService {

	
	private DmbDao dmbDao;
	private SqlDao sqlDao;

	

	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}



	public void setSqlDao(SqlDao sqlDao) {
		this.sqlDao = sqlDao;
	}



	/**
	 * ��ȡ�����˵���������
	 * 
	 * @param dsrlb
	 * @return
	 */
	private String getDsrLxmc(String dsrlb) {
		Dmb dmb = dmbDao.getDmbByLbbh("FBS0002-TM", dsrlb);
		if(dmb!=null)
		return dmb.getDmms();
		return "";
	}

	

	/**
	 * 
	 * ��ȡ���������ϵ�λ����
	 * 
	 * @param ajxz
	 * @param spcx
	 * @return
	 */
	public String getDsrssdwmc(String ajxz, String spcx, String dmbh) {
		String lbbh = "";
		String sql = "select SJXX from PUB_XTGL_XXXGL where NAME='���ϵ�λ'";
		try {
			List<String> list = sqlDao.callSqlSingle(sql);
			String lbbhString = list.get(0);
			String[] split = lbbhString.split(",");

			for (int i = 0; i < split.length; i++) {
				String ajxzString = split[i].substring(0, 1);
				String spcxString = split[i].substring(1, 2);

				if (ajxz.equals(ajxzString)) {
					if (spcx.equals(spcxString)) {
						lbbh = split[i].substring(2, split[i].length());
						break;
					} else if (spcxString.equals("*")) {
						lbbh = split[i].substring(2, split[i].length());
						break;
					}
				}
			}
			Dmb dmb = dmbDao.getDmbByLbbh(lbbh, dmbh);
			if(dmb!=null)
			return dmb.getDmms();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "";
	}

}
