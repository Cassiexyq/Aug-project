package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WsajjbqkModel;
import nju.software.cpwsqwjs.util.StringUtil;

/**
 * Created by mdw on 2017/1/4.
 *  
 * WSAjjbqkxsesDO entity. @author MyEclipse Persistence Tools
 * ����������� ���¶���
 */
@Entity
@Table(name = "WS_AJJBQKXSES")
public class WSAjjbqkxsesDO {
    private Integer ajxh;
    private String xsbssld;
    private String xsqssld;
    private String qscpyzypjjg;
    private String qscmssyzj;
    private String ssssbhyj;
    private String jcjgyj;

    @Id
    @Column(name = "AJXH", nullable = false)
    public Integer getAjxh() {
        return ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name = "XSBSSLD")
    public String getXsbssld() {
        return xsbssld;
    }

    public void setXsbssld(String xsbssld) {
        this.xsbssld = xsbssld;
    }
    @Column(name = "XSQSSLD")
    public String getXsqssld() {
        return xsqssld;
    }

    public void setXsqssld(String xsqssld) {
        this.xsqssld = xsqssld;
    }

    @Column(name = "QSCPYZYPJJG")
    public String getQscpyzypjjg() {
        return qscpyzypjjg;
    }

    public void setQscpyzypjjg(String qscpyzypjjg) {
        this.qscpyzypjjg = qscpyzypjjg;
    }
    @Column(name = "QSCMSSYZJ")
    public String getQscmssyzj() {
        return qscmssyzj;
    }

    public void setQscmssyzj(String qscmssyzj) {
        this.qscmssyzj = qscmssyzj;
    }

    @Column(name = "SSSSBHYJ")
    public String getSsssbhyj() {
        return ssssbhyj;
    }

    public void setSsssbhyj(String ssssbhyj) {
        this.ssssbhyj = ssssbhyj;
    }

    @Column(name = "JCJGYJ")
    public String getJcjgyj() {
        return jcjgyj;
    }

    public void setJcjgyj(String jcjgyj) {
        this.jcjgyj = jcjgyj;
    }
    
    public WSAjjbqkxsesDO(WsajjbqkModel model){
    	if(!StringUtil.isBlank(model.getXsbssld())){
    		this.xsbssld = model.getXsbssld();
    	}
    	if(!StringUtil.isBlank(model.getXsqssld())){
    		this.xsqssld = model.getXsqssld();
    	}
    	if(!StringUtil.isBlank(model.getQscpyzypjjg())){
    		this.qscpyzypjjg = model.getQscpyzypjjg();
    	}
    	if(!StringUtil.isBlank(model.getQscmssyzj())){
    		this.qscmssyzj = model.getQscmssyzj();
    	}
    	if(!StringUtil.isBlank(model.getSsssbhyj())){
    		this.ssssbhyj = model.getSsssbhyj();
    	}
    	if(!StringUtil.isBlank(model.getGsjgctyj())){
    		this.jcjgyj = model.getGsjgctyj();
    	}
    }
}
