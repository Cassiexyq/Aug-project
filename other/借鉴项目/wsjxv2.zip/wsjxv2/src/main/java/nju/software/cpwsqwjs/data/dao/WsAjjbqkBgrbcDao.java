package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBgrbcDO;

public interface WsAjjbqkBgrbcDao {
    public WsAjjbqkBgrbcDO getByAjxh(int ajxh);
    public void save(WsAjjbqkBgrbcDO wsAjjbqkBgrbcDO);
    public int getMaxbh();
}
