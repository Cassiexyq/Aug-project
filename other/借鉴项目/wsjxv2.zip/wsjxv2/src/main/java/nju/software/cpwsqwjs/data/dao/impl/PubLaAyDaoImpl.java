package nju.software.cpwsqwjs.data.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import nju.software.cpwsqwjs.data.dao.PubLaAyDao;
import nju.software.cpwsqwjs.data.dataobject.PubLaAy;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author lc
 *
 */
public class PubLaAyDaoImpl extends HibernateDaoSupport implements PubLaAyDao {
	private static final Logger log = Logger.getLogger(PubLaAyDaoImpl.class);
	
	/* (non-Javadoc)
	 * @see nju.software.ExecutionInterfaces.data.dao.Pub_LaAyDao#getLaAyDObyAjxh(int)
	 */

	public PubLaAy getLaAyDObyAjxh(int ajxh) {
		String hql = "from PubLaAy where ajxh ="+ajxh;
		@SuppressWarnings("unchecked")
		List<PubLaAy> res = this.getHibernateTemplate().find(hql);
	/*	if (log.isInfoEnabled()) {
			log.info("getLaAyDO By Hql : "+ hql);
		}*/
		return res.size()==0?new PubLaAy():res.get(0);
	}
	public List<PubLaAy> getLaAyDOsbyAjxh(int ajxh) {
		String hql = "from PubLaAy where ajxh ="+ajxh;
		@SuppressWarnings("unchecked")
		List<PubLaAy> res = this.getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getLaAyDO By Hql : "+ hql);
		}
		return res.size()==0?new ArrayList<PubLaAy>():res;
	}
	
	public List<PubLaAy> getLaAyDOAfterLarq(Date larq) {
		// TODO Auto-generated method stub
		String hql = "from PubLaAy where (larq >=?)  ";
		@SuppressWarnings("unchecked")
		List<PubLaAy> resDO = getHibernateTemplate().find(hql,larq);
		
		return resDO;
	
	}
}
