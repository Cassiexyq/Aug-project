package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDOId;

public interface WsXspjjgpfDao {
	
	public int save(WsXspjjgpfDO pf);

	public int getMaxPfbhByAjxhAndFzbh(int ajxh,int fzbh);
	
	public WsXspjjgpfDO finfById(WsXspjjgpfDOId id);
}
