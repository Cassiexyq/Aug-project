package nju.software.cpwsqwjs.service.dataService;

import java.util.List;

import nju.software.cpwsqwjs.service.model.xs.FjxModel;
import nju.software.cpwsqwjs.service.model.xs.PfModel;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.service.model.xs.XspjjgfzModel;

public interface WsXspjjgfzService {
	/**
	 * ���������о��������
	 * @param fzModel
	 * @param ajxh
	 * @return ����ķ�����
	 */
	public int saveFz(XspjjgfzModel fzModel,int ajxh);
	/**
	 * �������-�з�
	 * @param pf
	 * @param ajxh
	 * @param fzbh
	 * @param pflx
	 * @return
	 */
	public int savePf(PfModel pf,int ajxh,int fzbh,String pflx);
	
	public int saveFjx(FjxModel model,int ajxh,int fzbh,int pfbh);
	
	public void saveXspjjg(int ajxh,XsPjjgModel pjjgModel);
	
	public void saveFjxList(List<FjxModel> modelList,int ajxh,int fzbh,int pfbh);
	
	public void savePjjgBacth(int ajxh,XsPjjgModel pjjgModel);

}
