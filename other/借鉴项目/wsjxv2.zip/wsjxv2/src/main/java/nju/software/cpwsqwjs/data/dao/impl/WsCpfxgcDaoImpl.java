package nju.software.cpwsqwjs.data.dao.impl;

import java.util.Map;

import nju.software.cpwsqwjs.data.dao.WsCpfxgcDao;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcDO;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcFlftDO;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcLxqjDO;
import nju.software.cpwsqwjs.service.model.WscpfxgcFdlxModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcZdlxModel;
import nju.software.cpwsqwjs.util.StringUtil;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class WsCpfxgcDaoImpl extends HibernateDaoSupport implements WsCpfxgcDao{

	@Override
	public int saveCpfxgcDO(WsCpfxgcDO cpfxgcDO) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(cpfxgcDO);
			return cpfxgcDO.getAjxh();
		}catch(RuntimeException re){
			throw re;
		}
	}
	
	@Override
	public void save(int ajxh, WscpfxgcModel model) {
		// TODO Auto-generated method stub
		if(model!=null){
			Session s = this.getSessionFactory().openSession();
			Transaction tx = s.beginTransaction();
			WsCpfxgcDO cpfxgcDo = new WsCpfxgcDO(model);
			cpfxgcDo.setAjxh(ajxh);
			s.save(cpfxgcDo);
			int ftbh = 1;
			int lxqjBh = 1;
			if(model.getFtModellist()!=null){
				for(WscpfxgcFtModel ftModel : model.getFtModellist()){
					WsCpfxgcFlftDO flftDo = new WsCpfxgcFlftDO();
					flftDo.setAjxh(ajxh);
					flftDo.setFtbh(ftbh);
					flftDo.setFtmc(ftModel.getFlftmc());
					if(ftModel.getFtMap()!=null && !ftModel.getFtMap().isEmpty()){
						String tk = "";
						for(Map.Entry<String, String> entry : ftModel.getFtMap().entrySet()){
							if(entry.getKey()!=null){
								//�����������
								if(entry.getValue()!=null){
									tk = tk + "��" + entry.getKey() + "��" + entry.getValue() + ";";
								}
								//ֻ����Ŀû�п�Ŀ
								else{
									tk = tk + "��" + entry.getKey() + "��;"; 
								}
							}
						}
						if(tk.endsWith(";")){
							tk = tk.substring(0,tk.length()-1);
						}
						if(!StringUtil.isBlank(tk)){
							flftDo.setTk(tk);
						}
					}
					ftbh++;
					s.save(flftDo);
				}
			}
			
			if(model.getFdlxModel()!=null){
				for(WscpfxgcFdlxModel fdlxModel : model.getFdlxModel()){
					if(fdlxModel.getQj()!=null){
						WsCpfxgcLxqjDO lxqjDO = new WsCpfxgcLxqjDO();
						lxqjDO.setQj(fdlxModel.getQj());
						if(fdlxModel.getLxqjlb()!=null && !fdlxModel.getLxqjlb().isEmpty()){
							lxqjDO.setAjxh(ajxh);
							lxqjDO.setLxqjbh(lxqjBh);
							lxqjDO.setLxzl("�����������");
							String lxqjzl = "";
							for(String str : fdlxModel.getLxqjlb()){
								lxqjzl = lxqjzl + str + ";";
							}
							if(lxqjzl.endsWith(";")){
								lxqjzl = lxqjzl.substring(0,lxqjzl.length()-1);
							}
							if(!StringUtil.isBlank(lxqjzl)){
								lxqjDO.setLxqjzl(lxqjzl);
							}
							if(fdlxModel.getXgr()!=null && !fdlxModel.getXgr().isEmpty()){
								String xgs_str = "";
								for(String xgr : fdlxModel.getXgr()){
									xgs_str = xgs_str+xgr+";";
								}
								if(xgs_str.endsWith(";")){
									xgs_str = xgs_str.substring(0, xgs_str.length()-1);
								}
								if(!StringUtil.isBlank(xgs_str)){
									lxqjDO.setXgr(xgs_str);
								}
							}
						}
						lxqjBh++;
						s.save(lxqjDO);
					}
				}
			}
			if(model.getZdlxModel()!=null){
				for(WscpfxgcZdlxModel zdlxModel : model.getZdlxModel()){
					if(zdlxModel.getQj()!=null){
						WsCpfxgcLxqjDO lxqjDO = new WsCpfxgcLxqjDO();
						lxqjDO.setQj(zdlxModel.getQj());
						if(zdlxModel.getLxqjlb()!=null && !zdlxModel.getLxqjlb().isEmpty()){
							lxqjDO.setAjxh(ajxh);
							lxqjDO.setLxqjbh(lxqjBh);
							lxqjDO.setLxzl("�ö��������");
							String lxqjzl = "";
							for(String str : zdlxModel.getLxqjlb()){
								lxqjzl = lxqjzl + str + ";";
							}
							if(lxqjzl.endsWith(";")){
								lxqjzl = lxqjzl.substring(0,lxqjzl.length()-1);
							}
							if(!StringUtil.isBlank(lxqjzl)){
								lxqjDO.setLxqjzl(lxqjzl);
							}
							if(zdlxModel.getXgr()!=null &&  !zdlxModel.getXgr().isEmpty()){
								String xgs_str = "";
								for(String xgr : zdlxModel.getXgr()){
									xgs_str = xgs_str+xgr+";";
								}
								if(xgs_str.endsWith(";")){
									xgs_str = xgs_str.substring(0, xgs_str.length()-1);
								}
								if(!StringUtil.isBlank(xgs_str)){
									lxqjDO.setXgr(xgs_str);
								}
							}
						}
						lxqjBh++;
						s.save(lxqjDO);
					}
				}
			}
			tx.commit();
			s.close();
		}
	}

}
