package nju.software.cpwsqwjs.service;

import java.util.List;



public interface DsrService {

	public String getDsrssdwmc(String ajxz, String spcx, String dmbh);

}