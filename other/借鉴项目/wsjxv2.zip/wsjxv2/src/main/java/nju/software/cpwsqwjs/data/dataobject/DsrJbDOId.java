package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Id;

public class DsrJbDOId implements java.io.Serializable {
	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -8042897758133482224L;
	private Integer ajxh;
	private Integer dsrbh;
	// Constructors

	/** default constructor */
	public DsrJbDOId() {
	}

	/** minimal constructor */
	public DsrJbDOId(Integer ajxh, Integer dsrbh) {
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "DSRBH", nullable = false)
	public Integer getDsrbh() {
		return this.dsrbh;
	}

	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ajxh == null) ? 0 : ajxh.hashCode());
		result = prime * result + ((dsrbh == null) ? 0 : dsrbh.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DsrJbDOId other = (DsrJbDOId) obj;
		if (ajxh == null) {
			if (other.ajxh != null)
				return false;
		} else if (!ajxh.equals(other.ajxh))
			return false;
		if (dsrbh == null) {
			if (other.dsrbh != null)
				return false;
		} else if (!dsrbh.equals(other.dsrbh))
			return false;
		return true;
	}

}
