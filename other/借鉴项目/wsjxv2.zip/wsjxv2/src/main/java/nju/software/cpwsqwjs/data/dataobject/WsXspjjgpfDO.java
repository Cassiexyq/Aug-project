package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.xs.FjxModel;
import nju.software.cpwsqwjs.service.model.xs.PfModel;
import nju.software.cpwsqwjs.service.model.xs.Xszx;
import nju.software.cpwsqwjs.service.model.xs.ZmModel;

/**
 * WsXspjjgpfDO entity. @author MyEclipse Persistence Tools
 * �����о�����з�
 */
@Entity
@Table(name = "WS_XSPJJG_PF")
@IdClass(WsXspjjgpfDOId.class)
public class WsXspjjgpfDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer fzbh;//������
	private Integer pfbh;//�з����
	private String pflx;//�з�����
	private String zm;//����
	private String zmdm;//��������
	private String wzzm;//��������
	private String zxlb;//�������
	private String zxqx;//��������
	private String hxlb;//�������
	private String hbqx;//��������
	private String pjjglx;//�о��������
	private String yzszbf;//ԭ�����ﲢ��
	/** default constructor */
	public WsXspjjgpfDO() {
	}

	/** minimal constructor */
	public WsXspjjgpfDO(Integer ajxh, Integer fzbh,Integer pfbh) {
		this.ajxh = ajxh;
		this.fzbh = fzbh;
		this.pfbh = pfbh;
	}

	public WsXspjjgpfDO(Integer ajxh, Integer fzbh, Integer pfbh, String pflx,
			String zm, String zmdm, String wzzm, String zxlb, String zxqx,
			String hxlb, String hbqx, String pjjglx, String yzszbf) {
		super();
		this.ajxh = ajxh;
		this.fzbh = fzbh;
		this.pfbh = pfbh;
		this.pflx = pflx;
		this.zm = zm;
		this.zmdm = zmdm;
		this.wzzm = wzzm;
		this.zxlb = zxlb;
		this.zxqx = zxqx;
		this.hxlb = hxlb;
		this.hbqx = hbqx;
		this.pjjglx = pjjglx;
		this.yzszbf = yzszbf;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name = "FZBH", nullable = false)
	public Integer getFzbh() {
		return fzbh;
	}

	public void setFzbh(Integer fzbh) {
		this.fzbh = fzbh;
	}
	@Id
	@Column(name = "PFBH", nullable = false)
	public Integer getPfbh() {
		return pfbh;
	}

	public void setPfbh(Integer pfbh) {
		this.pfbh = pfbh;
	}
	@Column(name = "PFLX", length = 20)
	public String getPflx() {
		return pflx;
	}

	public void setPflx(String pflx) {
		this.pflx = pflx;
	}
	@Column(name = "ZM", length = 100)
	public String getZm() {
		return zm;
	}

	public void setZm(String zm) {
		this.zm = zm;
	}
	@Column(name = "ZMDM", length = 50)
	public String getZmdm() {
		return zmdm;
	}

	public void setZmdm(String zmdm) {
		this.zmdm = zmdm;
	}
	@Column(name = "WZZM", length = 100)
	public String getWzzm() {
		return wzzm;
	}

	public void setWzzm(String wzzm) {
		this.wzzm = wzzm;
	}
	@Column(name = "ZXLB", length = 20)
	public String getZxlb() {
		return zxlb;
	}

	public void setZxlb(String zxlb) {
		this.zxlb = zxlb;
	}
	@Column(name = "ZXXQ", length = 50)
	public String getZxqx() {
		return zxqx;
	}

	public void setZxqx(String zxqx) {
		this.zxqx = zxqx;
	}
	
	@Column(name = "HXLB", length = 20)
	public String getHxlb() {
		return hxlb;
	}

	public void setHxlb(String hxlb) {
		this.hxlb = hxlb;
	}
	@Column(name = "HXXQ", length = 50)
	public String getHbqx() {
		return hbqx;
	}

	public void setHbqx(String hbqx) {
		this.hbqx = hbqx;
	}
	@Column(name = "PJJGLX", length = 30)
	public String getPjjglx() {
		return pjjglx;
	}

	public void setPjjglx(String pjjglx) {
		this.pjjglx = pjjglx;
	}
	@Column(name = "YZSZBF", length = 2)
	public String getYzszbf() {
		return yzszbf;
	}

	public void setYzszbf(String yzszbf) {
		this.yzszbf = yzszbf;
	}
	
	public WsXspjjgpfDO(PfModel model,String pflx){
		this.pflx = pflx;
		if(model.getZm()!=null){
			if(model.getZm().getZm()!=null){
				this.zm = model.getZm().getZm();
			}
			if(model.getZm().getZmdm()!=null){
				this.zmdm = model.getZm().getZmdm();
			}
			if(model.getZm().getWzzm()!=null){
				this.wzzm = model.getZm().getWzzm();
			}
		}
		if(model.getZx()!=null){
			if(model.getZx().getZxlb()!=null){
				this.zxlb = model.getZx().getZxlb();
			}
			if(model.getZx().getZxxq()!=null){
				this.zxqx = model.getZx().getZxxq();
			}
		}
		if(model.getHx()!=null){
			if(model.getHx().getZxlb()!=null){
				this.zxlb = model.getHx().getZxlb();
			}
			if(model.getHx().getZxxq()!=null){
				this.zxqx = model.getHx().getZxxq();
			}
		}
		if(model.getPjjglx()!=null){
			this.pjjglx = model.getPjjglx();
		}
		if(model.getYzszbf()!=null){
			this.yzszbf = model.getYzszbf();
		}
	}
}