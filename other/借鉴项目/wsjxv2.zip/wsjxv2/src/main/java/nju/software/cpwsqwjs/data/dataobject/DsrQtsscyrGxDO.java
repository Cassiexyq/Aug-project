package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * DsrQtsscyrGxDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSR_QTSSCYR_GX")
@IdClass(DsrQtsscyrGxDOId.class)
public class DsrQtsscyrGxDO implements java.io.Serializable {

	// Fields

	//private DsrQtsscyrGxDOId id;
	private Integer ajxh;
	private Integer dsrbh;
	private Integer qtsscyrbh;

	// Constructors

	/** default constructor */
	public DsrQtsscyrGxDO() {
	}

	/** full constructor */
	public DsrQtsscyrGxDO(Integer ajxh, Integer dsrbh, Integer qtsscyrbh) {
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
		this.qtsscyrbh = qtsscyrbh;
	}

	// Property accessors
	@Column(name = "AJXH", nullable = false)
	@Id
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "DSRBH", nullable = false)
	@Id
	public Integer getDsrbh() {
		return this.dsrbh;
	}

	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}

	@Column(name = "QTSSCYRBH", nullable = false)
	@Id
	public Integer getQtsscyrbh() {
		return this.qtsscyrbh;
	}

	public void setQtsscyrbh(Integer qtsscyrbh) {
		this.qtsscyrbh = qtsscyrbh;
	}


}