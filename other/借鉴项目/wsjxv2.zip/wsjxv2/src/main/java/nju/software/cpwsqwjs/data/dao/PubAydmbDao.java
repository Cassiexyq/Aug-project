package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.PubAydmb;


/**
 * @author byron
 * 
 */
public interface PubAydmbDao {
	public String loadDmbhByAydm_5(int aydm_5);

	public int loadAydm_5ByDmbh(String dmbh);

	/**
	 * 11�����°��ɡ��⳥�����ع��������ʹ��
	 * 
	 * @param dmbh
	 * @return
	 */
	public int loadAydmByDmbh(String dmbh);

	public int loadAydmByDmbhAndBbh(String dmbh, String bbh);

	public int loadMsAy(String dmbh);

	public int loadAydm11ByDmbh(String dmbh);
	
	public PubAydmb loadDmbhByAydm11(int aydm);

	PubAydmb loadDmbhByAydm11AndBBH(int aydm, String BBH);
	
	

}
