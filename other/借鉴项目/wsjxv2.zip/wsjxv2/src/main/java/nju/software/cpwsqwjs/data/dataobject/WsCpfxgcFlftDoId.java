package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsCpfxgcFlftDoId entity. @author MyEclipse Persistence Tools
 */
public class WsCpfxgcFlftDoId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer ftbh;

	// Constructors

	/** default constructor */
	public WsCpfxgcFlftDoId() {
	}

	/** full constructor */
	public WsCpfxgcFlftDoId(Integer ajxh, Integer ftbh) {
		this.ajxh = ajxh;
		this.ftbh = ftbh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "FTBH", nullable = false)
	public Integer getFtbh() {
		return ftbh;
	}

	public void setFtbh(Integer ftbh) {
		this.ftbh = ftbh;
	}
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsCpfxgcFlftDoId))
			return false;
		WsCpfxgcFlftDoId castOther = (WsCpfxgcFlftDoId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getFtbh() == castOther.getFtbh()) || (this
						.getFtbh() != null && castOther.getFtbh() != null && this
						.getFtbh().equals(castOther.getFtbh())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getFtbh() == null ? 0 : this.getFtbh().hashCode());
		return result;
	}

}