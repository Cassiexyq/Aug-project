package nju.software.cpwsqwjs.data.dataobject;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.datamodel.WsajjbxxModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcFdlxModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcZdlxModel;
import nju.software.cpwsqwjs.service.model.WscpjgModel;
import nju.software.cpwsqwjs.service.model.WswsModel;

import com.sun.accessibility.internal.resources.accessibility;

/**
 * WsCpfxgcDO entity. @author MyEclipse Persistence Tools
 * ���з�������
 */
@Entity
@Table(name = "WS_CPFXGC")
public class WsCpfxgcDO implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	// Fields
	private Integer ajxh;//�������
	private String Jafslx;//�᰸��ʽ����
	private String xzpc;// �����⳥��������������
	private String ysajly;//һ�󰸼���Դ��һ�󰸼�����
	private String sfjgxzfy;//�Ƿ񾭹���������
	private String xzxwwfbj;//������ΪΥ������
	private String ktqsqchss;//��ͥǰ���볷��
	private String gtfz;// ��ͬ����
	private String bgrtyrzcx;//������ͬ���������
	// Constructors

	/** default constructor */
	public WsCpfxgcDO() {
	}

	/** minimal constructor */
	public WsCpfxgcDO(Integer ajxh) {
		this.ajxh = ajxh;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", unique = true, nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	@Column(name = "JAFSLX",length = 100)
	public String getJafslx() {
		return Jafslx;
	}

	public void setJafslx(String jafslx) {
		Jafslx = jafslx;
	}
	@Column(name = "XZPC",length = 10)
	public String getXzpc() {
		return xzpc;
	}

	public void setXzpc(String xzpc) {
		this.xzpc = xzpc;
	}
	@Column(name = "YSAJLY",length = 100)
	public String getYsajly() {
		return ysajly;
	}

	public void setYsajly(String ysajly) {
		this.ysajly = ysajly;
	}
	@Column(name = "SFJGXZFY",length = 10)
	public String getSfjgxzfy() {
		return sfjgxzfy;
	}

	public void setSfjgxzfy(String sfjgxzfy) {
		this.sfjgxzfy = sfjgxzfy;
	}
	@Column(name = "XZXWWFBJ",length = 10)
	public String getXzxwwfbj() {
		return xzxwwfbj;
	}

	public void setXzxwwfbj(String xzxwwfbj) {
		this.xzxwwfbj = xzxwwfbj;
	}
	@Column(name = "KTQSQCHSS",length = 10)
	public String getKtqsqchss() {
		return ktqsqchss;
	}

	public void setKtqsqchss(String ktqsqchss) {
		this.ktqsqchss = ktqsqchss;
	}
	@Column(name = "GTFZ",length = 10)
	public String getGtfz() {
		return gtfz;
	}

	public void setGtfz(String gtfz) {
		this.gtfz = gtfz;
	}
	@Column(name = "BGRTYRZCX",length = 10)
	public String getBgrtyrzcx() {
		return bgrtyrzcx;
	}
	public void setBgrtyrzcx(String bgrtyrzcx) {
		this.bgrtyrzcx = bgrtyrzcx;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * �Ӳ��з�������Model���
	 * @param wscpfxgcModel
	 */
	public WsCpfxgcDO(WscpfxgcModel wscpfxgcModel) {
		// TODO Auto-generated constructor stub
		if(wscpfxgcModel.getBgrtyrzcx()!=null){
			this.bgrtyrzcx = wscpfxgcModel.getBgrtyrzcx();
		}
		if(wscpfxgcModel.getGtfz()!=null){
			this.gtfz = wscpfxgcModel.getGtfz();
		}
		if(wscpfxgcModel.getJafslx()!=null){
			this.Jafslx = wscpfxgcModel.getJafslx();
		}
		if(wscpfxgcModel.getKtqsqchss()!=null){
			this.ktqsqchss = wscpfxgcModel.getKtqsqchss();
		}
		if(wscpfxgcModel.getSfjgxzfy()!=null){
			this.sfjgxzfy = wscpfxgcModel.getSfjgxzfy();
		}
		if(wscpfxgcModel.getXzpc()!=null){
			this.xzpc = wscpfxgcModel.getXzpc();
		}
		if(wscpfxgcModel.getXzxwwfbj()!=null){
			this.xzxwwfbj = wscpfxgcModel.getXzxwwfbj();
		}
		if(wscpfxgcModel.getYsajly()!=null){
			this.ysajly = wscpfxgcModel.getYsajly();
		}
	}


}