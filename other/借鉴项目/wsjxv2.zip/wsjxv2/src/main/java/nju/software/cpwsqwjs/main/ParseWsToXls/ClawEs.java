package nju.software.cpwsqwjs.main.ParseWsToXls;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.main.other.Htcsrq;
import nju.software.cpwsqwjs.service.WsService;
import nju.software.cpwsqwjs.util.FileNameUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.*;
import java.util.List;

/**
 * Created by Hufk on 2017/07/27.
 */
public class ClawEs {
    private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
            "applicationContext.xml", "applicationContextDataSource.xml");
    static WsJbDao wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
    static Logger logger = Logger.getLogger(Htcsrq.class);
    static AjjbDao ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");

    static SqlDao sqlDao = (SqlDao) appContext.getBean("sqlDao");
    static WsService wsService=(WsService) appContext.getBean("wsService");

    public static void main(String[] args){
        try{
            File file = new File("H:\\court-record.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String fydm = null;     // ��ȡ��Ժ�������е������ַ�

            //������Ϣ��¼
            File file2 = new File("H:\\court-2-record.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file2));

            //����δ�᰸��¼
            File file3 = new File("H:\\court-2-noDocument.txt");
            BufferedWriter bufferedWriterLog = new BufferedWriter(new FileWriter(file3));

            //�����������ڼ�¼
            File file4 = new File("H:\\EsLarq.txt");
            file4.createNewFile();
            BufferedWriter bufferedWriterLarq  = new BufferedWriter(new FileWriter(file4));

            //д�뵱����
            File fileDsr = new File("H:\\EsDsr.txt");
            fileDsr.createNewFile();
            BufferedWriter bufferedWriterDsr = new BufferedWriter(new FileWriter(fileDsr));

            int flag = 0;

            do{
                fydm = bufferedReader.readLine();
                //��������Ժ����
                String FYDM = null;     // �����ķ�Ժ����
                if (fydm!=null && fydm.contains("FYDM")){

                    int index = fydm.indexOf(":");
                    FYDM = fydm.substring(index+1);
                    System.out.println(FYDM);
                }

                if(FYDM!=null){
                    flag = 1;
                    if(FYDM.startsWith("120100")){
                        //������Ժ��ȡ����
                        DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
                    } else if(FYDM.startsWith("1201")){
                        //�����һ��Ժ��ȡ
                        DataSourceRouter.routerTo(DataSourceEnum.TJYZY.getFydm());
                    } else if(FYDM.startsWith("1202")){
                        //��������Ժ��ȡ
                        DataSourceRouter.routerTo(DataSourceEnum.TJEZY.getFydm());
                    }

                    //д�뷨Ժ���루FYDM��
                    bufferedWriter.write("FYDM:"+FYDM+"\r\n");
                    bufferedWriterLog.write("FYDM:"+FYDM+"\r\n");

                    //ѭ����ȡ���󰸺Ų�����
                    String ESAH = null;
                    String YSAH = null;
                    do{
                        String line = bufferedReader.readLine();
                        if (!line.equals("")){
                            int index = line.lastIndexOf(" ");
                            int indexFirst = line.indexOf(" ");
                            YSAH = line.substring(indexFirst+1,index);
                            ESAH = line.substring(index+1);
                            try{
                                List<List<String>> ajxh = sqlDao.callSql("select AJXH,AH,LARQ from PUB_AJ_JB where AH = '"+ESAH+"'");
                                if(ajxh==null||ajxh.size()==0){
                                    bufferedWriter.write("\r\n");
                                    bufferedWriterLog.write("\r\n");
                                    continue;
                                }

                                for(int i=0; i<ajxh.size(); i++){
                                    WsJbDO wsJbDO=wsJbDao.getCpwsBbyajxh(Integer.parseInt(ajxh.get(i).get(0)));
                                    if(wsJbDO==null||wsJbDO.getWsnr()==null||wsJbDO.getWsmc()==null) {

                                        //д�롰���󰸼��޽᰸���顱��־
                                        bufferedWriterLog.write(ajxh.get(i).get(0) + " " + ajxh.get(i).get(1) + "\r\n");
                                        continue;
                                    }

                                    //��ѯ������Ϣ��д����־
                                    try{
                                        List<List<String>> list1 = sqlDao.callSql("select ESAH from PUB_SSXX where AJXH="+ajxh.get(i).get(0) + " and ESAH<>''");
                                        if (list1.size()>0){
                                            //����������Ϣд��
                                            bufferedWriter.write(ajxh.get(i).get(0) + " " + YSAH + " " + ESAH + " " + list1.get(0).get(0) +"\r\n");
                                        }
                                    }catch (Exception e){
                                        e.printStackTrace();
                                    }

                                    //��ѯ��������Ϣ
                                    List<List<String>> listDsr = sqlDao.callSql("select AJXH,DSRBH,DSRSSDW,DSRLB,DSRJC from DSR_JB where AJXH = " +ajxh.get(i).get(0));
                                    for (int k=0;k<listDsr.size();k++){
                                        //д��
                                        bufferedWriterDsr.write("ah#"+ajxh.get(i).get(1)+"#ajxh#"+listDsr.get(k).get(0)+"#dsrbh#"+listDsr.get(k).get(1)+"#dsrssdw#"+listDsr.get(k).get(2)+"#dsrlb#"+listDsr.get(k).get(3)+"#dsrjc#"+listDsr.get(k).get(4)+"\r\n");
                                    }

                                    bufferedWriterLarq.write(ajxh.get(i).get(1)+" " +ajxh.get(i).get(2)+"\r\n");
                                    byte[] wsnr=wsJbDO.getWsnr();
                                    String wsnrString= POIUtil.getContent(wsnr, wsJbDO.getWswjm());
                                    if(wsnrString==null||wsnrString.trim().equals("")){
                                        continue;
                                    }

                                    //write to doc
                                    FileUtil.createFile("H:\\FileStation\\Engineering-Center\\file\\f2\\"+ FileNameUtil.getFullName(wsJbDO.getWswjm(),ajxh.get(i).get(1),2), wsnr);
                                }

                            }catch (Exception e){
                                e.printStackTrace();
                            }
                        } else{
                            break;
                        }
                    }while (ESAH!=null);
                }
                if(flag ==1){
                    bufferedWriter.write("\r\n");
                    bufferedWriterLog.write("\r\n");
                } else{
                    flag=0;
                }

            }while (fydm != null);

            //�ر�
            bufferedReader.close();
            bufferedWriterDsr.flush();
            bufferedWriterDsr.close();
            bufferedWriterLarq.flush();
            bufferedWriterLarq.close();
            bufferedWriter.close();
            bufferedWriterLog.close();
        }catch(IOException e){
            e.printStackTrace();
        }

    }
}
