package nju.software.cpwsqwjs.main.ParseWsToXls2;

import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import nju.software.cpwsqwjs.util.StringUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ��Ժ�����������Ҫ��.doc��.rtf
 * Created by Hufk on 2017/07/28.
 */
public class FileParse {
    class Ws{
        private String fileFullPath;    //һ������ȫ·��
        private String fileFullPathEs;  //��������ȫ·��
        private String fileFullPathZs;  //��������ȫ·��
        private String content;     //һ����������
        private String contentEs;   //������������
        private String contentZs;   //������������
        private String slfy;     //������Ժ
        private String ah;         //����
        private String ahTemp;      //��ʱһ�󰸺ţ���д���ļ�
        private String land ;     //�������
        private String spcx ;    //���г���
        private String ajxz;     //��������
        private String wszl;     //��������
        private String yg;         //ԭ��
        private String bg;         //����
        private String dsr;       //������
        private String larq;    //��������
        private String ay;      //����
        private String ygsc;    //ԭ���߳�
        private String bgbc;    //������
        private String cmss;    //������ʵ
        private String byrw;    //��Ժ��Ϊ
        private String pjjg;    //�о����
        private String esfy;    //����Ժ
        private String esah;    //���󰸺�
        private String esahTemp;    //��ʱ���󰸺ţ���д���ļ�
        private String ssr;     //������
        private String bssr;    //��������
        private String ysdsr;   //ԭ�������
        private String esland;  //�����������
        private String eslarq;  //������������
        private String ssrsc;   //�������߳�
        private String bssrbc;  //�������˱��
        private String escmss;  //���������ʵ
        private String esfyrw;  //����Ժ��Ϊ
        private String esfycpjg;    //����Ժ���н��
        private String zsfcfy;  //���󸴲鷨Ժ
        private String zsfcah;  //���󸴲鰸��
        //private String zsfcahTemp;  //��ʱ���󸴲鰸�ţ���д���ļ�
        private String zssqr;   //����������
        private String zsbsqr;  //����������
        private String ysdsr2;  //ԭ�������
        private String sqrzsqq; //��������������
        private String bsqrdbyj;    //�������˴�����
        private String zsfcfycm;    //���󸴲鷨Ժ����
        private String zsfcfyrw;    //���󸴲鷨Ժ��Ϊ
        private String zsfcfycpjg;  //���󸴲鷨Ժ���н��

        public String getFileFullPath() {
            return fileFullPath;
        }

        public void setFileFullPath(String fileFullPath) {
            this.fileFullPath = fileFullPath;
        }

        public String getFileFullPathEs() {
            return fileFullPathEs;
        }

        public void setFileFullPathEs(String fileFullPathEs) {
            this.fileFullPathEs = fileFullPathEs;
        }

        public String getFileFullPathZs() {
            return fileFullPathZs;
        }

        public void setFileFullPathZs(String fileFullPathZs) {
            this.fileFullPathZs = fileFullPathZs;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getContentEs() {
            return contentEs;
        }

        public void setContentEs(String contentEs) {
            this.contentEs = contentEs;
        }

        public String getContentZs() {
            return contentZs;
        }

        public void setContentZs(String contentZs) {
            this.contentZs = contentZs;
        }

        public String getSlfy() {
            return slfy;
        }

        public void setSlfy(String slfy) {
            this.slfy = slfy;
        }

        public String getAh() {
            return ah;
        }

        public void setAh(String ah) {
            this.ah = ah;
        }

        public String getLand() {
            return land;
        }

        public void setLand(String land) {
            this.land = land;
        }

        public String getSpcx() {
            return spcx;
        }

        public void setSpcx(String spcx) {
            this.spcx = spcx;
        }

        public String getAjxz() {
            return ajxz;
        }

        public void setAjxz(String ajxz) {
            this.ajxz = ajxz;
        }

        public String getWszl() {
            return wszl;
        }

        public void setWszl(String wszl) {
            this.wszl = wszl;
        }

        public String getYg() {
            return yg;
        }

        public void setYg(String yg) {
            this.yg = yg;
        }

        public String getBg() {
            return bg;
        }

        public void setBg(String bg) {
            this.bg = bg;
        }

        public String getDsr() {
            return dsr;
        }

        public void setDsr(String dsr) {
            this.dsr = dsr;
        }

        public String getLarq() {
            return larq;
        }

        public void setLarq(String larq) {
            this.larq = larq;
        }

        public String getAy() {
            return ay;
        }

        public void setAy(String ay) {
            this.ay = ay;
        }

        public String getYgsc() {
            return ygsc;
        }

        public void setYgsc(String ygsc) {
            this.ygsc = ygsc;
        }

        public String getBgbc() {
            return bgbc;
        }

        public void setBgbc(String bgbc) {
            this.bgbc = bgbc;
        }

        public String getCmss() {
            return cmss;
        }

        public void setCmss(String cmss) {
            this.cmss = cmss;
        }

        public String getByrw() {
            return byrw;
        }

        public void setByrw(String byrw) {
            this.byrw = byrw;
        }

        public String getPjjg() {
            return pjjg;
        }

        public void setPjjg(String pjjg) {
            this.pjjg = pjjg;
        }

        public String getEsfy() {
            return esfy;
        }

        public void setEsfy(String esfy) {
            this.esfy = esfy;
        }

        public String getEsah() {
            return esah;
        }

        public void setEsah(String esah) {
            this.esah = esah;
        }

        public String getSsr() {
            return ssr;
        }

        public void setSsr(String ssr) {
            this.ssr = ssr;
        }

        public String getBssr() {
            return bssr;
        }

        public void setBssr(String bssr) {
            this.bssr = bssr;
        }

        public String getYsdsr() {
            return ysdsr;
        }

        public void setYsdsr(String ysdsr) {
            this.ysdsr = ysdsr;
        }

        public String getEsland() {
            return esland;
        }

        public void setEsland(String esland) {
            this.esland = esland;
        }

        public String getEslarq() {
            return eslarq;
        }

        public void setEslarq(String eslarq) {
            this.eslarq = eslarq;
        }

        public String getSsrsc() {
            return ssrsc;
        }

        public void setSsrsc(String ssrsc) {
            this.ssrsc = ssrsc;
        }

        public String getBssrbc() {
            return bssrbc;
        }

        public void setBssrbc(String bssrbc) {
            this.bssrbc = bssrbc;
        }

        public String getEscmss() {
            return escmss;
        }

        public void setEscmss(String escmss) {
            this.escmss = escmss;
        }

        public String getEsfyrw() {
            return esfyrw;
        }

        public void setEsfyrw(String esfyrw) {
            this.esfyrw = esfyrw;
        }

        public String getEsfycpjg() {
            return esfycpjg;
        }

        public void setEsfycpjg(String esfycpjg) {
            this.esfycpjg = esfycpjg;
        }

        public String getZsfcfy() {
            return zsfcfy;
        }

        public void setZsfcfy(String zsfcfy) {
            this.zsfcfy = zsfcfy;
        }

        public String getZsfcah() {
            return zsfcah;
        }

        public void setZsfcah(String zsfcah) {
            this.zsfcah = zsfcah;
        }

        public String getZssqr() {
            return zssqr;
        }

        public void setZssqr(String zssqr) {
            this.zssqr = zssqr;
        }

        public String getZsbsqr() {
            return zsbsqr;
        }

        public void setZsbsqr(String zsbsqr) {
            this.zsbsqr = zsbsqr;
        }

        public String getYsdsr2() {
            return ysdsr2;
        }

        public void setYsdsr2(String ysdsr2) {
            this.ysdsr2 = ysdsr2;
        }

        public String getSqrzsqq() {
            return sqrzsqq;
        }

        public void setSqrzsqq(String sqrzsqq) {
            this.sqrzsqq = sqrzsqq;
        }

        public String getBsqrdbyj() {
            return bsqrdbyj;
        }

        public void setBsqrdbyj(String bsqrdbyj) {
            this.bsqrdbyj = bsqrdbyj;
        }

        public String getZsfcfycm() {
            return zsfcfycm;
        }

        public void setZsfcfycm(String zsfcfycm) {
            this.zsfcfycm = zsfcfycm;
        }

        public String getZsfcfyrw() {
            return zsfcfyrw;
        }

        public void setZsfcfyrw(String zsfcfyrw) {
            this.zsfcfyrw = zsfcfyrw;
        }

        public String getZsfcfycpjg() {
            return zsfcfycpjg;
        }

        public void setZsfcfycpjg(String zsfcfycpjg) {
            this.zsfcfycpjg = zsfcfycpjg;
        }
    }

    class Dsr{
        private String dw;  //��λ
        private String mc;  //����

        public String getDw() {
            return dw;
        }

        public void setDw(String dw) {
            this.dw = dw;
        }

        public String getMc() {
            return mc;
        }

        public void setMc(String mc) {
            this.mc = mc;
        }
    }

    private String fileFullPath;    //һ������ȫ·��
    private String fileFullPathEs;  //��������ȫ·��
    private String fileFullPathZs;  //��������ȫ·��
    private String content;     //һ����������
    private String contentNB;   //None blank
    private String contentEs;   //������������
    private String contentEsNB;
    private String contentZs;   //������������
    private String contentZsNB;

    private HashMap<String, String> yegl;   //һ��������
    private HashMap<String, String> ezgl;   //�����������

    private HashMap<String,String> ysLarq;  //һ����������
    private HashMap<String,String> esLarq;  //������������
    private HashMap<String,String> zsLarq;  //������������
    private HashMap<String,List<Dsr>> ysDsr;  //һ������
    private HashMap<String,List<Dsr>> esDsr;  //��������
    private HashMap<String,List<Dsr>> zsDsr;  //��������
    private List<Ws> wsList = new ArrayList<>();

    /**
     * �������ݲ�д��excel
     * @param fileFullPath  Ŀ¼·��
     */
    String testStr = "";
    public void parse(String fileFullPath) {
        ysLarq = parseLarq(ysLarq,"H:\\YsLarq.txt");
        esLarq = parseLarq(esLarq,"H:\\EsLarq.txt");
        zsLarq = parseLarq(zsLarq,"H:\\ZsLarq.txt");

        ysDsr = parseDsr(ysDsr,"H:\\YsDsr.txt");
        esDsr = parseDsr(esDsr,"H:\\EsDsr.txt");
        zsDsr = parseDsr(zsDsr,"H:\\ZsDsr.txt");

        yegl = getYegl();   //һ��������
        ezgl = getEzgl();   //�����������

        File file = new File(fileFullPath);
        String[] fileNames = file.list();
        int ii=0;
        for(int i=0;i<fileNames.length;i++){

            File file2 = new File(fileFullPath+fileNames[i]);
            if (file2.isFile()){
                this.fileFullPath = fileFullPath+fileNames[i];
                this.content = StringUtil.ToDBC(getContent(this.fileFullPath));    //һ����������
                contentNB = noneBlank(this.content);

                System.out.println(this.fileFullPath+"..."+(ii++));
                Ws ws = new Ws();
                ws.setSlfy(getSlfy());//������Ժ
                ws.setAh(getAh(fileNames[i]));         //����

                if(ws.getAh().equals("(2014)����ִ���ֵ�0006��")){
                    testStr = "(2014)����ִ���ֵ�0006��";
                    System.out.println(content);
                    System.out.println(contentNB);
                } else{
                    testStr= "";
                }
                ws.setLand(getLand(ws.getAh()));     //�������
                ws.setSpcx(getSpcx());    //���г���
                ws.setAjxz(getAjxz());    //��������
                ws.setWszl(getWszl());    //��������
                ws.setYg(getYg(ws.getAh()));        //ԭ��
                ws.setBg(getBg(ws.getAh()));        //����
                ws.setDsr(getDsr(ws.getAh()));      //������
                ws.setLarq(getLarq(ws.getAh()));   //��������
                ws.setAy(getAy());     //����
                ws.setYgsc(getYgsc());   //ԭ���߳�
                ws.setBgbc(getBgbc());   //������
                ws.setCmss(getCmss());   //������ʵ
                ws.setByrw(getByrw());   //��Ժ��Ϊ
                ws.setPjjg(getPjjg());   //�о����

                //����������Ϣ
                if(yegl.get(ws.getAh())!=null){

                    fileFullPathEs = getFileFullPath(yegl.get(ws.getAh()),2);
                    contentEs = getContent(fileFullPathEs);
                    this.contentEsNB = noneBlank(this.contentEs);
                    ws.setEsfy(getEsfy());    //����Ժ
                    ws.setEsah(getEsah(yegl.get(ws.getAh())));   //���󰸺�
                    ws.setSsr(getSsr(ws.getEsah()));     //������
                    ws.setBssr(getBssr(ws.getEsah()));    //��������
                    ws.setYsdsr(getYsdsr(ws.getAh()));   //ԭ�������
                    ws.setEsland(getEsland(ws.getEsah()));  //�����������
                    ws.setEslarq(getEslarq(ws.getEsah()));  //������������
                    ws.setSsrsc(getSsrsc());   //�������߳�
                    ws.setBssrbc(getBssrbc());  //�������˱��
                    ws.setEscmss(getEscmss());  //���������ʵ
                    ws.setEsfyrw(getEsfyrw());  //����Ժ��Ϊ
                    ws.setEsfycpjg(getEsfycpjg());    //����Ժ���н��

                    //����������Ϣ
                    if(ezgl.get(ws.getAh())!=null){
                        fileFullPathZs = getFileFullPath(ezgl.get(ws.getAh()),3);
                        contentZs = getContent(fileFullPathZs);
                        this.contentZsNB = noneBlank(contentZs);
                        ws.setZsfcfy(getZsfcfy());  //���󸴲鷨Ժ
                        ws.setZsfcah(getZsfcah(ezgl.get(ws.getAh())));  //���󸴲鰸��
                        ws.setZssqr(getZssqr(ws.getZsfcah()));   //����������
                        ws.setZsbsqr(getZsbsqr(ws.getZsfcah()));  //����������
                        ws.setYsdsr2(getYsdsr2(ws.getAh()));  //ԭ�������
                        ws.setSqrzsqq(getSqrzsqq()); //��������������
                        ws.setBsqrdbyj(getBsqrdbyj());    //�������˴�����
                        ws.setZsfcfycm(getZsfcfycm());    //���󸴲鷨Ժ����
                        ws.setZsfcfyrw(getZsfcfyrw());    //���󸴲鷨Ժ��Ϊ
                        ws.setZsfcfycpjg(getZsfcfycpjg());  //���󸴲鷨Ժ���н��
                    } else{
                        ws.setZsfcfy("");  //���󸴲鷨Ժ
                        ws.setZsfcah("");  //���󸴲鰸��
                        ws.setZssqr("");   //����������
                        ws.setZsbsqr("");  //����������
                        ws.setYsdsr2("");  //ԭ�������
                        ws.setSqrzsqq(""); //��������������
                        ws.setBsqrdbyj("");    //�������˴�����
                        ws.setZsfcfycm("");    //���󸴲鷨Ժ����
                        ws.setZsfcfyrw("");    //���󸴲鷨Ժ��Ϊ
                        ws.setZsfcfycpjg("");  //���󸴲鷨Ժ���н��
                    }

                } else{
                    ws.setEsfy("");    //����Ժ
                    ws.setEsah("");    //���󰸺�
                    ws.setSsr("");     //������
                    ws.setBssr("");    //��������
                    ws.setYsdsr("");   //ԭ�������
                    ws.setEsland("");  //�����������
                    ws.setEslarq("");  //������������
                    ws.setSsrsc("");   //�������߳�
                    ws.setBssrbc("");  //�������˱��
                    ws.setEscmss("");  //���������ʵ
                    ws.setEsfyrw("");  //����Ժ��Ϊ
                    ws.setEsfycpjg("");    //����Ժ���н��
                }
                wsList.add(ws);
            }
        }

        save2Xlsx(wsList);

    }

    /**
     * ������������
     * @param larq
     * @param filePath
     * @return
     */
    public HashMap<String,String> parseLarq(HashMap<String,String> larq,String filePath){
        larq = new HashMap<String,String>();
        File file = new File(filePath);
        try{
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = null;
            while ((line = bufferedReader.readLine())!=null){
                if (!line.equals("")){
                    int index1 = line.indexOf(" ");
                    int index2 = line.indexOf(" ",line.indexOf(" ")+1);
                    if (index1<index2){
                        continue;
                    }
                    larq.put(line.substring(0,index1),line.substring(index1+1,index2));
                }
            }
            bufferedReader.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return larq;
    }

    /**
     * ����������
     * @param dsrHashMap
     * @param filePath
     * @return
     */
    public HashMap<String,List<Dsr>> parseDsr(HashMap<String,List<Dsr>> dsrHashMap,String filePath){
        dsrHashMap = new HashMap<String,List<Dsr>>();
        File file = new File(filePath);
        try{
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = null;
            String ah = "";
            while ((line = bufferedReader.readLine())!=null){
                if (!line.equals("")){
                    //����������
                    int index1 = line.indexOf("ah#");
                    int index2 = line.indexOf("#ajxh#");
                    System.out.println(index1+"=="+index2);
                    String realAh = line.substring(index1+3,index2);

                    //�����������˵�λ
                    int index3 = line.indexOf("#dsrssdw#");
                    int index4 = line.indexOf("#dsrlb#");
                    String dsrDw = line.substring(index3+9,index4);

                    //����������������
                    int index5 = line.indexOf("#dsrjc#");
                    String dsrMc = line.substring(index5+7);

                    Dsr dsr = new Dsr();
                    dsr.setDw(dsrDw);
                    dsr.setMc(dsrMc);

                    if (realAh.equals(ah)){
                        dsrHashMap.get(ah).add(dsr);
                    }else {
                        List<Dsr> list = new ArrayList<Dsr>();
                        list.add(dsr);
                        dsrHashMap.put(realAh,list);
                    }

                    ah = realAh;

                }
            }
            bufferedReader.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return dsrHashMap;
    }

    /**
     * ��ȡ.doc��.rtf�ļ�����
     * @return  �ļ�����
     */
    public String getContent(String fileFullPath){
        String content=null;
        try{
            content = POIUtil.getContent(FileUtil.getContent(fileFullPath), getSuffix(fileFullPath));
        } catch (Exception e){
            e.printStackTrace();
        }
        getSuffix(fileFullPath);
        return content;
    }

    /**
     * ��ȡ�ļ����ĺ�׺
     * @return ���ش���ĺ�׺��
     */
    public String getSuffix(String fileFullPath){
        String suffix=null;
        int index = fileFullPath.lastIndexOf(".");
        suffix = fileFullPath.substring(index);
        return suffix;
    }

    /**
     * ��ò�����չ�����������ͱ�ʶ���ļ���
     * @param fileName ����չ�����ļ�ȫ��
     * @return ������չ�����ļ���
     */
    public String getFileName(String fileName){
        String filename = null;
        int index = fileName.lastIndexOf("-");
        filename = fileName.substring(0,index);
        return filename;
    }

    /**
     * ��� һ��Ͷ��󰸺� �Ĺ�����Ϣ��һ������
     * @return
     */
    public HashMap<String, String> getYegl(){
        HashMap<String, String> yegl = new HashMap<String, String>();
        try {
            File file = new File("H:\\FileStation\\Engineering-Center\\file\\f2\\");
            String[] fileList = file.list();

            for (int i=0;i<fileList.length;i++){

            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return yegl;
    }

    /**
     * ��� ��������󰸺� �Ĺ�����Ϣ�����ٹ���
     * @return
     */
    public HashMap<String, String> getEzgl(){
        HashMap<String, String> ezgl = new HashMap<String, String>();
        try {
            File file = new File("H:\\court-2-record.txt");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = bufferedReader.readLine())!=null){
                if (line.contains("��")){
                    int index1 = line.indexOf(" ");
                    int index2 = line.indexOf(" ",line.indexOf(" ")+1);
                    int index3 = line.lastIndexOf(" ");
                    String ysah = line.substring(index1+1,index2);
                    String zsah = line.substring(index3+1);
                    File file1 = new File(getFileFullPath(zsah,3));
                    if (!file1.exists()){
                        zsah = null;
                    }
                    ezgl.put(ysah,zsah);
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return ezgl;
    }

    private String noneBlank(String str){
        return str.replaceAll("\\s","");
    }

    public String getFileFullPath(String simpleName,int type){
        String rootDir = "H:\\FileStation\\Engineering-Center\\file\\";     //�ļ���Ŀ¼
        String fileFullPaht = null;
        String subDir = null ;      //��Ŀ¼

        if(type == 2){
            subDir = rootDir + "f2\\";
        }else if (type == 3){
            subDir = rootDir + "f3\\";
        }

        File file = new File(subDir + simpleName + "-" + type + ".doc");
        if (!file.exists()){
            file = new File(subDir + simpleName + "-" + type + ".rtf");
        }
        return file.getAbsolutePath();
    }

    /**
     * �����ݱ��浽xlsx
     * @param wsList
     */
    public void save2Xlsx(List<Ws> wsList){
        //���浽excel
        Iterator<Ws> iterator = wsList.iterator();
        String savePath = "H:\\������Ϣ���������о������-���.xlsx";
        File file = new File(savePath);
        if(file.exists()){
            try{
                System.out.println("����д��excel...");
                FileInputStream fileInputStream = new FileInputStream(savePath);
                XSSFWorkbook xssfWorkbook = new XSSFWorkbook(fileInputStream);
                Sheet sheet = xssfWorkbook.getSheetAt(0);
                int rows = sheet.getLastRowNum();    //��
                int i=rows;
                while (iterator.hasNext()){
                        Ws ws = (Ws)iterator.next();
                        Row row = sheet.createRow(i);
                        Cell cell01 = row.createCell(0);
                        Cell cell02 = row.createCell(1);
                        Cell cell03 = row.createCell(2);
                        Cell cell04 = row.createCell(3);
                        Cell cell05 = row.createCell(4);
                        Cell cell06 = row.createCell(5);
                        Cell cell07 = row.createCell(6);
                        Cell cell08 = row.createCell(7);
                        Cell cell09 = row.createCell(8);
                        Cell cell10 = row.createCell(9);
                        Cell cell11 = row.createCell(10);
                        Cell cell12 = row.createCell(11);
                        Cell cell13 = row.createCell(12);
                        Cell cell14 = row.createCell(13);
                        Cell cell15 = row.createCell(14);
                        Cell cell16 = row.createCell(15);
                        Cell cell17 = row.createCell(16);
                        Cell cell18 = row.createCell(17);
                        Cell cell19 = row.createCell(18);
                        Cell cell20 = row.createCell(19);
                        Cell cell21 = row.createCell(20);
                        Cell cell22 = row.createCell(21);
                        Cell cell23 = row.createCell(22);
                        Cell cell24 = row.createCell(23);
                        Cell cell25 = row.createCell(24);
                        Cell cell26 = row.createCell(25);
                        Cell cell27 = row.createCell(26);
                        Cell cell28 = row.createCell(27);
                        Cell cell29 = row.createCell(28);
                        Cell cell30 = row.createCell(29);
                        Cell cell31 = row.createCell(30);
                        Cell cell32 = row.createCell(31);
                        Cell cell33 = row.createCell(32);
                        Cell cell34 = row.createCell(33);
                        Cell cell35 = row.createCell(34);
                        Cell cell36 = row.createCell(35);
                        Cell cell37 = row.createCell(36);
                        Cell cell38 = row.createCell(37);

                        cell01.setCellValue(ws.getSlfy());
                        cell02.setCellValue(ws.getAh());
                        cell03.setCellValue(ws.getLand());
                        cell04.setCellValue(ws.getSpcx());
                        cell05.setCellValue(ws.getAjxz());
                        cell06.setCellValue(ws.getWszl());
                        cell07.setCellValue(ws.getYg());
                        cell08.setCellValue(ws.getBg());
                        cell09.setCellValue(ws.getDsr());
                        cell10.setCellValue(ws.getLarq());
                        cell11.setCellValue(ws.getAy());
                        cell12.setCellValue(ws.getYgsc());
                        cell13.setCellValue(ws.getBgbc());
                        cell14.setCellValue(ws.getCmss());
                        cell15.setCellValue(ws.getByrw());
                        cell16.setCellValue(ws.getPjjg());
                        cell17.setCellValue(ws.getEsfy());
                        cell18.setCellValue(ws.getEsah());
                        cell19.setCellValue(ws.getSsr());
                        cell20.setCellValue(ws.getBssr());
                        cell21.setCellValue(ws.getYsdsr());
                        cell22.setCellValue(ws.getEsland());
                        cell23.setCellValue(ws.getEslarq());
                        cell24.setCellValue(ws.getSsrsc());
                        cell25.setCellValue(ws.getBssrbc());
                        cell26.setCellValue(ws.getEscmss());
                        cell27.setCellValue(ws.getEsfyrw());
                        cell28.setCellValue(ws.getEsfycpjg());
                        cell29.setCellValue(ws.getZsfcfy());
                        cell30.setCellValue(ws.getZsfcah());
                        cell31.setCellValue(ws.getZssqr());
                        cell32.setCellValue(ws.getZsbsqr());
                        cell33.setCellValue(ws.getYsdsr2());
                        cell34.setCellValue(ws.getSqrzsqq());
                        cell35.setCellValue(ws.getBsqrdbyj());
                        cell36.setCellValue(ws.getZsfcfycm());
                        cell37.setCellValue(ws.getZsfcfyrw());
                        cell38.setCellValue(ws.getZsfcfycpjg());
                        i++;
                }
                FileOutputStream fileOutputStream = new FileOutputStream(savePath);
                xssfWorkbook.write(fileOutputStream);
                fileOutputStream.flush();
                fileOutputStream.close();
                fileInputStream.close();
                System.out.println("д�����.");
            } catch (IOException e){
                e.printStackTrace();
            }

        }else{
            System.out.println("xlsx�ļ������ڣ�");
        }
    }

    /**
     * ������һ��
     * @param date ���죬��ʽxxxx/xx/xx
     * @return
     */
    public String nextDay(String date){
        //������������δ�ض��ǺϷ��ģ����Բ����쳣
        try{
            int index1 = date.indexOf("/");
            int index2 = date.lastIndexOf("/");
            int year = Integer.parseInt(date.substring(0,index1));
            int month = Integer.parseInt(date.substring(index1+1,index2));
            int day = Integer.parseInt(date.substring(index2+1));
            int febDay;
            if(year%4==0&&year%100!=0 || year%400==0)
                febDay = 29;
            else
                febDay = 28;
            switch (month){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                    if(day<31)
                        return year+"/"+month+"/"+(day+1);
                    else
                        return year+"/"+(month+1)+"/"+"1";

                case 12:
                    if (day<31)
                        return year+"/"+month+"/"+(day+1);
                    else
                        return (year+1) +"/" + "1" +"/"+"1";
                case 2:
                    if (day<febDay)
                        return year+"/"+month+"/"+(day+1);
                    else
                        return year+"/"+3+"/"+"1";
                case 4:
                case 6:
                case 9:
                case 11:
                    if (day<30)
                        return year+"/"+month+"/"+(day+1);
                    else
                        return (year+1) +"/" + "1" +"/"+"1";
            }
            return "";

        }catch (Exception e){
            return "";
        }
    }

    /**
     * ȥ���ظ���ֵ����������list(i)��str���Ӽ���Ҳ������str��list(i)���Ӽ�
     * @param list
     * @param str
     * @return
     */
    public List<String> noDuplicate(List<String> list, String str){
        Iterator iterator = list.iterator();
        int flag = 1;
        while (iterator.hasNext()){
            String listi = (String)iterator.next();
            if (str.contains(listi) || listi.contains(str)){
                flag = 0;
            }
        }
        if(flag == 1 && str!="" && str!=null){
            list.add(str);
        }

        return list;
    }

    /**
     * ���� ������Ժ �ֶ�
     * @return
     */
    public String getSlfy(){
        String slfy=null;
        String regex = "(\n|\r\n|\\n|\\r\\n|).*?��.*?Ժ";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()){
            int indexStart = matcher.start();
            int indexEnd = matcher.end();
            slfy = content.substring(indexStart,indexEnd);
        }
        slfy = slfy.replaceAll("\\s","");
        return slfy;
    }

    /**
     * ��� ���� �ֶ�
     * @return
     */
    public String getAh(String filename){
        return getFileName(filename);
//        String ah = null;
//        String regex = "(\\(|��|��|\\[|��|��).*?(��|��|��).*?��";
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(contentNB);
//        if (matcher.find()){
//            int start = matcher.start();
//            int end = matcher.end();
//            ah = contentNB.substring(start,end);
//        }
//        System.out.println(this.fileFullPath+"11");
//        ah = ah.replaceAll("\\s","");
//        ah = ah.replace("���壩","");
//        ah = ah.replace("(��)","");
//        System.out.println(this.fileFullPath+"22");
        //return ah;
    }

    /**
     * ��� ������� �ֶ�
     * @return
     */
    public String getLand(String ah){
        if (ysLarq.containsKey(ah)){
            return ysLarq.get(ah).substring(0,4);
        } else{
            return "";
        }
//        String land = null;
//        String regex = "(\\(|��|��|\\[|��|��|2).*?(��|��|��).*?��";
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(content);
//        if (matcher.find()){
//            int start = matcher.start();
//            int end = matcher.end();
//            land = content.substring(start,end);
//        }
//        land = land.replaceAll("\\s","");
//        int index = land.indexOf("��");
//        if (index == -1){
//            index = land.indexOf("��");
//        }
//        if (index == -1){
//            index = land.indexOf("��");
//        }
//        land = land.substring(0,index);
//        land = land.replaceAll("\\D","");

//        int indexStart = contentNB.indexOf("(");
//        int indexEnd = contentNB.indexOf(")");
//        if(indexStart==-1 || indexStart>40){
//            indexStart = contentNB.indexOf("��");
//            indexEnd = contentNB.indexOf("��");
//        }
//        if(indexStart==-1  || indexStart>40){
//            indexStart = contentNB.indexOf("��");
//            indexEnd = contentNB.indexOf("��");
//        }
//        if(indexStart==-1 || indexStart>40){
//            indexStart = contentNB.indexOf("[");
//            indexEnd = contentNB.indexOf("]");
//        }
//        if(indexStart==-1 || indexStart>40){
//            indexStart = contentNB.indexOf("��");
//            indexEnd = contentNB.indexOf("��");
//        }
//        land = contentNB.substring(indexStart+1,indexEnd);

//        if(land.length()>4){
//            land = land.substring(0,4);
//        }
//        return land;
    }

    /**
     * ��� ���г��� �ֶ�
     * @return
     */
    public String getSpcx(){
        String spcx = null;
        int index = fileFullPath.lastIndexOf(".");
        String order = fileFullPath.substring(index-1,index);
        if (order.equals("1")){
            spcx = "һ��";
        } else if(order.equals("2")){
            spcx = "����";
        } else if(order.equals("3")){
            spcx = "����";
        }
        return spcx;
    }

    /**
     * ��� �������� �ֶ�
     * @return
     */
    public String getAjxz(){
        String ajxz = null;
        String regex = "����";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        ajxz = content.substring(indexStart,indexEnd);
        return ajxz;
    }

    /**
     * ��� �������� �ֶ�
     * @return
     */
    public String getWszl(){
        String wszl = null;
        String regex = "(�о���|�ö���)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentNB);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        wszl = contentNB.substring(indexStart,indexEnd);
        return wszl;
    }

    /**
     * ��� ԭ�� �ֶ�
     * @return
     */
    public String getYg(String ah){
        String yg = "";
        List<String> list = new ArrayList<String>();
        int end = content.indexOf("����");
        if (end==-1){
            end = content.indexOf("��������");
        }
        if (end==-1){
            end = content.indexOf("��������");
        }
        if (end==-1){
            end = content.indexOf("��ִ����");
        }
        if (end ==-1){
            end = content.indexOf("������ִ����");
        }

        if (end==-1){
            end = 100000;
        }
        String regex = "\\s{1}(ԭ��|������|������|����ִ����).{1}.*?(,|��|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;

        String tempStr="";
        while (matcher.find()){
            if(testStr.equals("(2014)����ִ���ֵ�0006��")){
                System.out.println("---------");
            }
            indexStart = matcher.start();
            if (indexStart > end){
                break;
            }
            indexEnd = matcher.end();
            String temp =content.substring(indexStart,indexEnd);
            if (temp.contains("������") || temp.contains("����") || temp.contains("֮��") || temp.contains("֮��") || temp.contains("֮ĸ") || temp.contains("֮�游") || temp.contains("֮��") || temp.contains("֮��") || temp.contains("֮Ů") || temp.contains("ǰ��") || temp.contains("ǰ��") || temp.contains("����") || temp.contains("����")){
                continue;
            }

            tempStr = content.substring(indexStart,indexEnd);

            //ȥ���ַ���
            tempStr = tempStr.replace("ԭ��","");
            tempStr = tempStr.replace("������","");
            tempStr = tempStr.replace("����ִ����","");
            tempStr = tempStr.replace("������","");
            tempStr = tempStr.replace("ִ����","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replace(":","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replace(":","");
            tempStr = tempStr.replace(",","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replace("�߳�","");
            tempStr = tempStr.replaceAll("\\s","");

            if(tempStr.contains("(") || tempStr.contains("��")){
                int index = tempStr.indexOf("(");
                if(index == -1){
                    index = tempStr.indexOf("��");
                }
                tempStr = tempStr.substring(0,index);
            }

            list = noDuplicate(list,tempStr);
        }

        //�����������ַ���
        int flag = 0;
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()){
            if (flag==1){
                yg = yg+"��\n";
            }
            String string = (String)iterator.next();
            yg = yg + string;
            flag = 1;
        }

        if (yg.equals("")){
            List<Dsr> dsrList = ysDsr.get(ah);
            if (dsrList==null){
                return yg;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                if(dsr.getDw().equals("11")){
                    yg = dsr.getMc();
                }
            }
        }

        return yg;
    }

    /**
     * ��� ���� �ֶ�
     * @return
     */
    public String getBg(String ah){
        String bg = "";

        int end = content.indexOf("ԭ��",content.indexOf("����"));
        int tempindex;
        if (end ==-1){
            end = content.indexOf("������",content.indexOf("��������")+4);
        }
        if (end ==-1){
            end = content.indexOf("������",content.indexOf("��������")+4);
        }
        if (end ==-1){
            tempindex = content.indexOf("��ִ����");
            if (tempindex == -1){
                tempindex = content.indexOf("������ִ����");
            }
            end = content.indexOf("����ִ����",tempindex+4);
        }
        String regex = "\\s{1}(����|��������|��������|��ִ����|������ִ����).{1}.*?(��|,|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        int flag=0;
        while (matcher.find()){
            indexStart = matcher.start();
            if (indexStart > end)
                break;
            indexEnd = matcher.end();
            String temp = content.substring(indexStart,indexEnd);
            if(flag==1){
                bg = bg + "��\n";
            }
            bg = bg + content.substring(indexStart,indexEnd).replaceAll("\\s","");
            if(bg.contains("(") || bg.contains("��")){
                int index = bg.indexOf("(");
                if(index == -1){
                    index = bg.indexOf("��");
                }
                bg = bg.substring(0,index);
            }
            flag =1 ;
        }

        //ȥ���ַ���
        bg = bg.replace("����","");
        bg = bg.replace("��ִ����","");
        bg = bg.replace("��������","");
        bg = bg.replace("��������","");
        bg = bg.replace("��","");
        bg = bg.replace("��","");
        bg = bg.replace(":","");
        bg = bg.replace(",","");
        bg = bg.replace("��","");

        if (bg.equals("")){
            List<Dsr> dsrList = ysDsr.get(ah);
            if (dsrList==null){
                return bg;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                if(dsr.getDw().equals("12")){
                    bg = dsr.getMc();
                }
            }
        }

        return bg;
    }

    /**
     * ��� ������ �ֶ�
     * @return
     */
    public String getDsr(String ah){
        String dsr = "";
        String regex = "\\s{1}������.*?(��|,|��|\\.)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        int flag = 0;
        int end = content.indexOf("�߳�");
        if (end == -1){
            end = content.indexOf("���");
        }
        if (end == -1){
            end = 100000;
        }
        while (matcher.find()){
            String tempStr;

            indexStart = matcher.start();
            if (indexStart > end){
                break;
            }
            indexEnd = matcher.end();
            tempStr = content.substring(indexStart,indexEnd);
            //ȥ���ַ���
            tempStr = tempStr.replace("������","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replace(":","");
            tempStr = tempStr.replace(",","");
            tempStr = tempStr.replace("��","");
            tempStr = tempStr.replaceAll("\\s","");
            if(tempStr.contains("(") || tempStr.contains("��")){
                int index = tempStr.indexOf("(");
                if(index == -1){
                    index = tempStr.indexOf("��");
                }
                tempStr = tempStr.substring(0,index);
            }
            if (tempStr.equals("") || tempStr.equals(null)){
                continue;
            }
            if(flag == 1){
                tempStr = "��\n" + tempStr;
            }

            dsr = dsr + tempStr;
            flag = 1;
        }

        if (dsr.equals("")){
            List<Dsr> dsrList = ysDsr.get(ah);
            if (dsrList==null){
                return dsr;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr11 = (Dsr)dsrIterator.next();
                if(dsr11.getDw().equals("13")){
                    dsr = dsr11.getMc();
                }
            }
        }

        return dsr;
    }

    /**
     * ��� �������� �ֶ�
     * @return
     */
    public String getLarq(String ah) {
        if (ysLarq.containsKey(ah)){
            return ysLarq.get(ah).replaceAll("-","/");
        } else {
            return "";
        }
//        String larq = "";
//        if(content.contains("��ͬ������")){
//            int index = content.indexOf("��ͬ������");
//            String temp = content.substring(index-30,index);
//            String regex = "[0-9������]";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(temp);
//            int indexStart = 0;
//            int indexEnd = 0;
//            while (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                larq = larq + temp.substring(indexStart,indexEnd);
//            }
//
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","");
//            larq = nextDay(larq);
//        }else if(content.contains("����������")){
//            int index = content.indexOf("����������");
//            String temp = content.substring(index-30,index);
//            String regex = "[0-9������]";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(temp);
//            int indexStart = 0;
//            int indexEnd = 0;
//            while (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                larq = larq + temp.substring(indexStart,indexEnd);
//            }
//
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","");
//        }else {
//            String regex = "��[0-9������]{9,12}.*?����";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(content);
//            int indexStart = 0;
//            int indexEnd = 0;
//            if (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                larq = larq + content.substring(indexStart,indexEnd);
//                String regex2 = "[0-9]{1,4}��[0-9]{1,2}��[0-9]{1,2}��";
//                Pattern pattern1 = Pattern.compile(regex2);
//                Matcher matcher1 = pattern1.matcher(larq);
//                if (matcher1.find()){
//                    indexStart = matcher1.start();
//                    indexEnd = matcher1.end();
//                    larq = larq.substring(indexStart,indexEnd);
//                }
//            }
//
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","/");
//            larq = larq.replace("��","");
//        }
//
//        //ȥ���ַ���
//        larq = larq.replace("��","");
//        larq = larq.replace("����","");
//        larq = larq.replace("��","");
//
//        return larq;
    }

    /**
     * ��� ���� �ֶ�
     * @return
     */
    public String getAy(){

        return "������Ϣ����";
    }

    /**
     * ��� ԭ���߳� �ֶ�
     * @return
     */
    public String getYgsc(){
        String ygsc = null;
        String regex = "ԭ��.*?�߳�.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        ygsc = content.substring(indexStart,indexEnd);

        //ȥ���ַ���
        ygsc = ygsc.replace("\n","");

        return ygsc;
    }

    /**
     * ��� ������ �ֶ�
     * @return
     */
    public String getBgbc(){
        String bgbc = null;
        String regex = "����.*?���.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        bgbc = content.substring(indexStart,indexEnd);

        //ȥ���ַ���
        bgbc = bgbc.replace("\n","");

        return bgbc;

    }

    /**
     * ��� ������ʵ �ֶ�
     * @return
     */
    public String getCmss(){
        String cmss = null;
        String regex = "��(��������|���|����).*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        cmss = content.substring(indexStart,indexEnd);

        //ȥ���ַ���
        cmss = cmss.replace("\n","");

        return cmss;
    }

    /**
     * ��� ��Ժ��Ϊ �ֶ�
     * @return
     */
    public String getByrw(){
        String byrw = null;
        String regex = "��Ժ(|����|���|������|�����)��Ϊ.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        byrw = content.substring(indexStart,indexEnd);

        //ȥ���ַ���
        byrw = byrw.replace("\n","");
        byrw = byrw.replace("�ö�����","");
        byrw = byrw.replace("�о�����","");
        byrw = byrw.replace("��","");
        byrw = byrw.replace(":","");

        return byrw;
    }

    /**
     * ��� �о���� �ֶ�
     * @return
     */
    public String getPjjg(){
        String pjjg = null;
        String regex = "(�о�|�ö�)����.*?(\n|\r\n).*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        pjjg = content.substring(indexStart,indexEnd);

        //ȥ���ַ���
        pjjg = pjjg.replace("\r\n","");
        pjjg = pjjg.replace(" ","");

        return pjjg;
    }

    /**
     * ��� ����Ժ �ֶ�
     * @return
     */
    public String getEsfy(){
        String esfy=null;
        String regex = "(\n|\r\n|\\n|\\r\\n|).*?��.*?Ժ";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()){
            int indexStart = matcher.start();
            int indexEnd = matcher.end();
            esfy = content.substring(indexStart,indexEnd);
        }
        esfy = esfy.replaceAll("\\s","");
        return esfy;
    }

    /**
     * ��� ���󰸺� �ֶ�
     * @return
     */
    public String getEsah(String filename) {
        return filename;
//        String esah = null;
//        String regex = "(\\(|��|��|\\[|��).*?��";
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(contentEs);
//        if (matcher.find()){
//            int start = matcher.start();
//            int end = matcher.end();
//            esah = contentEs.substring(start,end);
//        }
//        esah = esah.replaceAll("\\s","");

//        String esah = null;
//        int indeStart = contentEs.indexOf("(");
//        if(indeStart == -1 || indeStart > 30){
//            indeStart = contentEs.indexOf("��");
//        }
//        int indexEnd = contentEs.indexOf("��");
//        esah = contentEs.substring(indeStart,indexEnd+1);
       // return esah;
    }

    /**
     * ��� ������ �ֶ�
     * @return
     */
    public String getSsr(String esah) {
        String ssr = "";
        int flag = 0;
        String regex = "(\n|\r\n)������(��|\\().*?(|��).*?(,|��|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        while (matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
            String tempStr = contentEs.substring(indexStart,indexEnd);
            String tempStr2 = "";
            tempStr2 = tempStr.replace("������","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replace(":","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replace(",","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replaceAll("\\s","");
            if (tempStr2.equals("") || tempStr2.equals(null)){
                continue;
            }
            if (flag==1){
                ssr = ssr + "��\n";
            }
            flag = 1;
            ssr = ssr + tempStr2;
        }

        if (ssr.equals("")){
            List<Dsr> dsrList = new ArrayList<Dsr>();
            dsrList = ysDsr.get(esah);
            if (dsrList==null){
                return ssr;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                if(dsr.getDw().equals("24")){
                    ssr = dsr.getMc();
                }
            }
        }
        return ssr;
    }

    /**
     * ��� �������� �ֶ�
     * @return
     */
    public String getBssr(String esah) {
        String bssr = "";
        int flag = 0;
        String regex = "(\n|\r\n)��������(��|\\().*?(|��).*?(,|��|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        while (matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
            String tempStr = contentEs.substring(indexStart,indexEnd);
            String tempStr2 = "";

            tempStr2 = tempStr.replace("��������","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replace(":","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replace(",","");
            tempStr2 = tempStr2.replace("��","");
            tempStr2 = tempStr2.replaceAll("\\s","");
            if (tempStr2.equals("") || tempStr2.equals(null)){
                continue;
            }
            if (flag==1){
                bssr = bssr + "��\n";
            }
            flag = 1;
            bssr = bssr + tempStr2;
        }

        if (bssr.equals("")){
            List<Dsr> dsrList = new ArrayList<Dsr>();
            dsrList = ysDsr.get(esah);
            if (dsrList==null){
                return bssr;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                if(dsr.getDw().equals("25")){
                    bssr = dsr.getMc();
                }
            }
        }

        return bssr;
    }

    /**
     * ��� ԭ������� �ֶ�
     * @return
     */
    public String getYsdsr(String ah) {
        return getDsr(ah);
    }

    /**
     * ��� ����������� �ֶ�
     * @return
     */
    public String getEsland(String esah) {
        if(esLarq.containsKey(esah)){
            return esLarq.get(esah).substring(0,4);
        } else{
            return "";
        }

//        String esland = null;
//        String regex = "(\\(|��|��|\\[|��).*?(��|��).*?��";
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(contentEs);
//        if (matcher.find()){
//            int start = matcher.start();
//            int end = matcher.end();
//            esland = contentEs.substring(start,end);
//        }
//        esland = esland.replaceAll("\\s","");
//        int index = esland.indexOf("��");
//        if(index ==-1){
//            index = esland.indexOf("��");
//        }
//        esland = esland.substring(0,index);
//        esland = esland.replaceAll("\\D","");
//
//        if(esland.length()>4){
//            esland = esland.substring(0,4);
//        }
//        return esland;
    }

    /**
     * ��� ������������ �ֶ�
     * @return
     */
    public String getEslarq(String esah) {
        if (esLarq.containsKey(esah)){
            return esLarq.get(esah).replaceAll("-","/");
        } else {
            return "";
        }
//        String eslarq = "";
//        if(contentEs.contains("��ͬ������")){
//            int index = contentEs.indexOf("��ͬ������");
//            String temp = contentEs.substring(index-30,index);
//            String regex = "[0-9������]";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(temp);
//            int indexStart = 0;
//            int indexEnd = 0;
//            while (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                eslarq = eslarq + temp.substring(indexStart,indexEnd);
//            }
//
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","");
//            eslarq = nextDay(eslarq);
//        }else if(contentEs.contains("����������")){
//            int index = contentEs.indexOf("����������");
//            String temp = contentEs.substring(index-30,index);
//            String regex = "[0-9������]";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(temp);
//            int indexStart = 0;
//            int indexEnd = 0;
//            while (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                eslarq = eslarq + temp.substring(indexStart,indexEnd);
//            }
//
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","");
//        }else {
//            String regex = "��[0-9������]{9,12}.*?����";
//            Pattern pattern = Pattern.compile(regex);
//            Matcher matcher = pattern.matcher(contentEs);
//            int indexStart = 0;
//            int indexEnd = 0;
//            if (matcher.find()){
//                indexStart = matcher.start();
//                indexEnd = matcher.end();
//                eslarq = eslarq + contentEs.substring(indexStart,indexEnd);
//                String regex2 = "[0-9]{1,4}��[0-9]{1,2}��[0-9]{1,2}��";
//                Pattern pattern1 = Pattern.compile(regex2);
//                Matcher matcher1 = pattern1.matcher(eslarq);
//                if (matcher1.find()){
//                    indexStart = matcher1.start();
//                    indexEnd = matcher1.end();
//                    eslarq = eslarq.substring(indexStart,indexEnd);
//                }
//            }
//
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","/");
//            eslarq = eslarq.replace("��","");
//        }
//
//        //ȥ���ַ���
//        eslarq = eslarq.replace("��","");
//        eslarq = eslarq.replace("����","");
//        eslarq = eslarq.replace("��","");
//
//        return eslarq;
    }

    /**
     * ��� �������߳� �ֶ�
     * @return
     */
    public String getSsrsc() {
        String ssrsc = null;
        String regex = "������.*?�߳�.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        ssrsc = contentEs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        ssrsc = ssrsc.replace("\n","");

        return ssrsc;
    }

    /**
     * ��� �������˱�� �ֶ�
     * @return
     */
    public String getBssrbc() {
        String bssrbc = null;
        String regex = "��������.*?���.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        bssrbc = contentEs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        bssrbc = bssrbc.replace("\n","");

        return bssrbc;
    }

    /**
     * ��� ���������ʵ �ֶ�
     * @return
     */
    public String getEscmss() {
        String escmss = null;
        String regex = "(\n|\r\n).*?��Ժ.*?��ʵ.*?(ԭ��|һ��).*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        escmss = contentEs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        escmss = escmss.replaceAll("\\s","");
        if (escmss.equals("") || escmss.equals(null)){
            String cmss = null;
            String regex1 = "��(��������|���|����).*?(\n|\r\n)";
            Pattern pattern1 = Pattern.compile(regex1);
            Matcher matcher1 = pattern1.matcher(contentEs);
            int indexStart1 = 0;
            int indexEnd1 = 0;
            if(matcher1.find()){
                indexStart1 = matcher1.start();
                indexEnd1 = matcher1.end();
            }
            cmss = contentEs.substring(indexStart1,indexEnd1);

            //ȥ���ַ���
            cmss = cmss.replaceAll("\\s","");

            return cmss;
        }

        return escmss;
    }

    /**
     * ��� ����Ժ��Ϊ �ֶ�
     * @return
     */
    public String getEsfyrw() {
        String esfyrw = null;
        String regex = "��Ժ(|����|���|������|�����)��Ϊ.*?(��|\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        esfyrw = contentEs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        esfyrw = esfyrw.replace("\n","");

        return esfyrw;
    }

    /**
     * ��� ����Ժ���н�� �ֶ�
     * @return
     */
    public String getEsfycpjg() {
        String esfycpjg = null;
        String regex = "(�ö�����|�о�����).*?(\n|\r\n).*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentEs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        esfycpjg = contentEs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        esfycpjg = esfycpjg.replaceAll("\\s","");

        return esfycpjg;
    }

    /**
     * ��� ���󸴲鷨Ժ �ֶ�
     * @return
     */
    public String getZsfcfy() {
        String zsfcfy=null;
        String regex = "(\n|\r\n|\\n|\\r\\n|).*?��.*?Ժ";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        if (matcher.find()){
            int indexStart = matcher.start();
            int indexEnd = matcher.end();
            zsfcfy = contentZs.substring(indexStart,indexEnd);
        }
        zsfcfy = zsfcfy.replaceAll("\\s","");
        return zsfcfy;
    }

    /**
     * ��� ���󸴲鰸�� �ֶ�
     * @return
     */
    public String getZsfcah(String fileName) {
        return fileName;
    }

    /**
     * ��� ���������� �ֶ�
     * @return
     */
    public String getZssqr(String zsah) {
        String zsssr = "";
        int flag = 0;
        String regex = "���������ˣ�.*?(��|��).*?(��|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        int indexStart = 0;
        int indexEnd = 0;
        while (matcher.find()){
            if (flag==1){
                zsssr = zsssr + "��\n";
            }
            indexStart = matcher.start();
            indexEnd = matcher.end();
            String tempStr = contentZs.substring(indexStart,indexEnd);
            String tempStr2 = "";
            if (tempStr.contains("һ��ԭ�桢����������")){
                tempStr2 = tempStr.replace("����������","");
                tempStr2 = tempStr2.replace("��","");
                tempStr2 = tempStr2.replace("��","");
                tempStr2 = tempStr2.replace("��","");
            }
            flag = 1;
            zsssr = zsssr + tempStr2;
        }

        if (zsssr.equals("")){
            List<Dsr> dsrList = ysDsr.get(zsah);
            if (dsrList==null){
                return zsssr;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                int flag1 = 0;
                if(dsr.getDw().equals("5") || dsr.getDw().equals("6") || dsr.getDw().equals("8")){
                    if (flag1 ==1){
                        zsssr = zsssr + "��\n";
                    }
                    zsssr = zsssr + dsr.getMc();
                    flag1 = 1;
                }
            }
        }

        return zsssr;
    }

    /**
     * ��� ���������� �ֶ�
     * @return
     */
    public String getZsbsqr(String zsah) {
        String zsbsqr = "";
        int flag = 0;
        String regex = "�������ˣ�.*?(��|��).*?(��|��)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        int indexStart = 0;
        int indexEnd = 0;
        while (matcher.find()){
            if (flag==1){
                zsbsqr = zsbsqr + "��\n";
            }
            indexStart = matcher.start();
            indexEnd = matcher.end();
            String tempStr = contentZs.substring(indexStart,indexEnd);
            String tempStr2 = "";
            if (tempStr.contains("һ�󱻸桢����������")){
                tempStr2 = tempStr.replace("��������","");
                tempStr2 = tempStr2.replace("��","");
                tempStr2 = tempStr2.replace("��","");
                tempStr2 = tempStr2.replace("��","");
            }
            flag = 1;
            zsbsqr = zsbsqr + tempStr2;
        }

        if (zsbsqr.equals("")){
            List<Dsr> dsrList = ysDsr.get(zsah);
            if (dsrList==null){
                return zsbsqr;
            }
            Iterator<Dsr> dsrIterator = dsrList.iterator();
            while (dsrIterator.hasNext()){
                Dsr dsr = (Dsr)dsrIterator.next();
                if(dsr.getDw().equals("10")){
                    zsbsqr = dsr.getMc();
                }
            }
        }

        return zsbsqr;
    }

    /**
     * ��� ԭ������� �ֶ�
     * @return
     */
    public String getYsdsr2(String ah){
        return getDsr(ah);
    }

    /**
     * ��� �������������� �ֶ�
     * @return
     */
    public String getSqrzsqq() {
        String sqrzsqq = null;
        String regex = "(\n|\r\n).*?���������.*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        sqrzsqq = contentZs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        sqrzsqq = sqrzsqq.replace("\n","");

        return sqrzsqq;
    }

    /**
     * ��� �������˴����� �ֶ�
     * @return
     */
    public String getBsqrdbyj() {
        return "";
    }

    /**
     * ��� ���󸴲鷨Ժ���� �ֶ�
     * @return
     */
    public String getZsfcfycm() {
        return "";
    }

    /**
     * ��� ���󸴲鷨Ժ��Ϊ �ֶ�
     * @return
     */
    public String getZsfcfyrw() {
        String zsfcfyrw = null;
        String regex = "��Ժ��Ϊ.*?(��|\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        zsfcfyrw = contentZs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        zsfcfyrw = zsfcfyrw.replace("\n","");

        return zsfcfyrw;
    }

    /**
     * ��� ���󸴲鷨Ժ���н�� �ֶ�
     * @return
     */
    public String getZsfcfycpjg() {
        String zsfcfycpjg = null;
        String regex = "�ö�����.*?(\n|\r\n).*?(\n|\r\n)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(contentZs);
        int indexStart = 0;
        int indexEnd = 0;
        if(matcher.find()){
            indexStart = matcher.start();
            indexEnd = matcher.end();
        }
        zsfcfycpjg = contentZs.substring(indexStart,indexEnd);

        //ȥ���ַ���
        zsfcfycpjg = zsfcfycpjg.replace("\r\n","");

        return zsfcfycpjg;
    }
}
