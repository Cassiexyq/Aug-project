package nju.software.cpwsqwjs.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.handler.xzeshandler.XzesAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.AjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSscyrModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XzysAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.ZjdModelHandler;
import nju.software.cpwsqwjs.main.WsjxWordTxt;
import nju.software.cpwsqwjs.service.TestCpfxgcService;
import nju.software.cpwsqwjs.service.TestSsjlService;
import nju.software.cpwsqwjs.service.TestPjjgService;
import nju.software.cpwsqwjs.service.TestWwService;
import nju.software.cpwsqwjs.service.impl.BaseCaseModelByWs;
import nju.software.cpwsqwjs.service.impl.TestAjjbqkServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestCpfxgcServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestPjjgServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestSscyrServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestSsjlServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestWsServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestWwServiceImpl;
import nju.software.cpwsqwjs.service.impl.TestfdServiceImpl;
import nju.software.cpwsqwjs.service.model.TestModel;
import nju.software.cpwsqwjs.service.model.WsajjbqkModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;
import nju.software.cpwsqwjs.service.model.WscpjgModel;
import nju.software.cpwsqwjs.service.model.WsfdModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.service.model.WsssjlModel;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.service.model.WswwModel;
import nju.software.cpwsqwjs.util.AjlxEnum;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import nju.software.cpwsqwjs.util.XMLReader;
import nju.software.cpwsqwjs.util.XmlUtil;

import org.xml.sax.SAXException;

import com.google.common.collect.Multiset.Entry;

public class Test {
	public static List initTest(ArrayList<String> nodelist){
		List testModellist=new ArrayList<TestModel>();
		for(int i=0;i<nodelist.size();i++){
			String[]node = nodelist.get(i).split(",");
			TestModel testModel=new TestModel();
			testModel.setTestNode(node[0]);
			testModel.setCoNum(0);
			testModellist.add(testModel);
		}
		return testModellist;
	}
	public static String getQW(String filename,String path) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		String qw=null;
		String xpath_qw="//QW/@value";
		XMLReader xr=new XMLReader();
		qw=xr.getXMLNode(path+"\\"+filename, xpath_qw);
		return qw;
	}
	public static String format(String qw){
		char[]ws=qw.toCharArray();		
		for(int i=0;i<ws.length;i++){
			int temp=ws[i];
			if(temp==32){
					ws[i]=10;
			}

		}
		return String.valueOf(ws);
	}
	public static ArrayList<String> getNodelist(String filepath){
		File file = new File(filepath);
		String str = null;
		ArrayList<String> list = new ArrayList<String>();
		FileReader fr = null;
		if (file.exists()) {
			try {
				fr = new FileReader(file);
				BufferedReader bufr = new BufferedReader(fr);
				while ((str = bufr.readLine()) != null) {

					list.add(str);
				}
				bufr.close();
				fr.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			list = new ArrayList<String>();
		}
		return list;
	}
	/**
	 * ���Էֶ�
	 */
	public static List testFd(WsfdModel wsfdModel,String inputpath,String filename,List testModellist,ArrayList<String> nodelist,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();  
		TestfdServiceImpl ts=new TestfdServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel=(TestModel) testModellist.get(i);
			String[] node=nodelist.get(i).split(",");
			if(testModel.getTestNode().equals("����")){
				testModel=ts.testWs(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���ϲ�����")){
				testModel=ts.testSscyr(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���ϼ�¼")){
				testModel=ts.testSsjl(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����������")){
				testModel=ts.testAjjbqk(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���з�������")){
				testModel=ts.testCpfxgc(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���н��")){
				testModel=ts.testCpjg(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��β")){
				testModel=ts.testWw(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��¼")){
				testModel=ts.testFl(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
		}	
		return testModellist;
	}
	public static List testWs(WswsModel wswsModel,String inputpath,String filename,List testModellist,ArrayList<String> nodelist,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();  
		TestWsServiceImpl ts=new TestWsServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel=(TestModel) testModellist.get(i);
			String[] node=nodelist.get(i).split(",");
			if(testModel.getTestNode().equals("����������λ")){
				testModel=ts.testWszzdw(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���취Ժ")){
				testModel=ts.testJbfy(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����")){
				testModel=ts.testAh(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=ts.testWsmc(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�������")){
				testModel=ts.testLand(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��Ժ����")){
				testModel=ts.testFyjb(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����������ʡ��")){
				testModel=ts.testXzqhProv(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����������У�")){
				testModel=ts.testXzqhCity(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("��������")){
				testModel=ts.testAjxz(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("��������")){
				testModel=ts.testWszl(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("���г���")){
				testModel=ts.testSpcx(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=ts.testAjlx(testModel, wswsModel, inputpath, filename, specialpath, node);
				continue;
			}
		}	
		return testModellist;
	}
	public static List testSscyr(List<WssscyrModel> wssscyrModellist,WsfdModel wsfdModel,String inputpath,String filename,List testModellist,ArrayList<String> nodelist,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();  
		TestSscyrServiceImpl ts=new TestSscyrServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel=(TestModel) testModellist.get(i);
			String[] node=nodelist.get(i).split(",");
			if(testModel.getTestNode().equals("������")){
				testModel=ts.testSscyrqj(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���ϲ���������")){
				testModel=ts.testSscyrmc(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=ts.testSssf(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���ϵ�λ")){
				testModel=ts.testSsdw(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ԭ�����ϵ�λ")){
				testModel=ts.testYsssdw(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=ts.testCsrq(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����˵�ַ")){
				testModel=ts.testDsrdz(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("������ְ��")){
				testModel=ts.testDsrzw(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�Ա�")){
				testModel=ts.testXB(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����")){
				testModel=ts.testMZ(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��λ����")){
				testModel=ts.testDwxz(testModel, wssscyrModellist, inputpath, filename, specialpath, node);
				continue;
			}
		}	
		return testModellist;
	}

	public static List testSsjl(WsssjlModel wsssjlModel,String inputpath,String filename,List testModellist,ArrayList<String> nodelist,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();
		TestSsjlService testSsjlService = new TestSsjlServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel = (TestModel) testModellist.get(i);
			String[] node = nodelist.get(i).split(",");
			if(testModel.getTestNode().equals("���󰸼���Դ")){
				testModel=testSsjlService.testAjly(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����漰")){
				testModel=testSsjlService.testAjsj(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=testSsjlService.testLarq(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��ͥ����")){
				testModel=testSsjlService.testKtrq(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("��ͥ����")){
				testModel=testSsjlService.testKtsl(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��ͥ������Ϣ")){
				testModel=testSsjlService.testKtslxx(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����������ԭ��")){
				testModel=testSsjlService.testBgkslyy(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����")){
				testModel=testSsjlService.testAy(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=testSsjlService.testWzay(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���ɴ���")){
				testModel=testSsjlService.testAydm(testModel, wsssjlModel, inputpath, filename, specialpath, node);
			}
			if(testModel.getTestNode().equals("ǰ�󰸺�")){
				testModel=testSsjlService.testQsah(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ��Ժ")){
				testModel=testSsjlService.testQsfy(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("һ�󰸼����ó���")){
				testModel=testSsjlService.testYsajsycx(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("����ת��ͨ")){
				testModel=testSsjlService.testJyzpt(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("һ�󰸼���Դ")){
				testModel=testSsjlService.testYsajly(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("��������")){
				testModel=testSsjlService.testSlrq(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("������֯")){
				testModel=testSsjlService.testSpzz(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("���볷������")){
				testModel=testSsjlService.testSqcsrq(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}if(testModel.getTestNode().equals("��������")){
				testModel=testSsjlService.testDrsp(testModel, wsssjlModel, inputpath, filename, specialpath, node);
				continue;
			}
		}
		return testModellist;
	}
	public static List testAjjbqk(WsajjbqkModel wsajjbqkModel,String inputpath,String filename,List testModellist,ArrayList<String> nodeList,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();
		TestAjjbqkServiceImpl testAjjbqkServiceImpl = new TestAjjbqkServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel = (TestModel) testModellist.get(i);
			String[] node = nodeList.get(i).split(",");//���ƣ�//MC/@value
			if(testModel.getTestNode().equals("ǰ�����")){
				testModel=testAjjbqkServiceImpl.testQsdl(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�������")){
				testModel=testAjjbqkServiceImpl.testBsdl(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ��ԭ���߳ƶ�")){
				testModel=testAjjbqkServiceImpl.testQsygscd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ�󱻸��ƶ�")){
				testModel=testAjjbqkServiceImpl.testQsbgbcd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ�����߳ƶ�")){
				testModel=testAjjbqkServiceImpl.testQsfsscd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ��������")){
				testModel=testAjjbqkServiceImpl.testQssld(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ǰ���о���")){
				testModel=testAjjbqkServiceImpl.testQspjd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�������߳ƶ�")){
				testModel=testAjjbqkServiceImpl.testSsrscd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�������˱�ƶ�")){
				testModel=testAjjbqkServiceImpl.testBssrbcd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����������")){
				testModel=testAjjbqkServiceImpl.testBssld(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("ԭ���߳ƶ�")){
				testModel=testAjjbqkServiceImpl.testYgscd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����ƶ�")){
				testModel=testAjjbqkServiceImpl.testBgbcd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("������ʵ��")){
				testModel=testAjjbqkServiceImpl.testCmssd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("֤�ݶ�")){
				testModel=testAjjbqkServiceImpl.testZjd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����������")){
				testModel=testAjjbqkServiceImpl.testDsryjd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����߳ƶ�")){
				testModel=testAjjbqkServiceImpl.testFsscd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���߱�ƶ�")){
				testModel=testAjjbqkServiceImpl.testFsbcd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�������������")){
				testModel=testAjjbqkServiceImpl.testXzsszyd(testModel, wsajjbqkModel, inputpath, filename, specialpath, node);
				continue;
			}
		}
		return testModellist;
	}
	public static List testCpfxgc(List<WscpfxgcModel> wscpfxgcModellist,String inputpath,String filename,List testModellist,ArrayList<String> nodeList,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();
		TestCpfxgcService testcpfxgcService = new TestCpfxgcServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel = (TestModel) testModellist.get(i);
			String[] node = nodeList.get(i).split(",");//���ƣ�//MC/@value
//			if(testModel.getTestNode().equals("���ɷ���")){
//				testModel=testcpfxgcService.testFlft(testModel, wscpfxgcModellist, inputpath, filename, specialpath, node);
//				continue;
//			}
		}
		return testModellist;

	}
	public static List testWw(WswwModel wswwModel,String inputpath,String filename,List testModellist,ArrayList<String> nodeList,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();
		TestWwService testWwService = new TestWwServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel = (TestModel) testModellist.get(i);
			String[] node = nodeList.get(i).split(",");//���ƣ�//MC/@value
			if(testModel.getTestNode().equals("������Ա����")){
				testModel=testWwService.testSpryxm(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("������Ա��ɫ")){
				testModel=testWwService.testSpryjs(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����ʱ��")){
				testModel=testWwService.testCpsj(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�᰸���")){
				testModel=testWwService.testJand(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�᰸������")){
				testModel=testWwService.testJanyr(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�᰸����")){
				testModel=testWwService.testJany(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�᰸��")){
				testModel=testWwService.testJay(testModel, wswwModel, inputpath, filename, specialpath, node);
				continue;
			}
		}
		return testModellist;
	}

	public static List testCpjg(WsfdModel wsfdModel,WscpjgModel wscpjgModel,String inputpath,String filename,List testModellist,ArrayList<String> nodeList,String specialpath) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		FileUtil fileUtil = new FileUtil();
		TestPjjgService testPjjgService = new TestPjjgServiceImpl();
		for(int i=0;i<testModellist.size();i++){
			TestModel testModel = (TestModel) testModellist.get(i);
			String[] node = nodeList.get(i).split(",");//���ƣ�//MC/@value
			if(testModel.getTestNode().equals("�о����")){
				testModel=testPjjgService.testPjjg(testModel, wsfdModel, inputpath, filename, specialpath, node);
				continue;
			}

			if(testModel.getTestNode().equals("�᰸��ʽ")){
				testModel=testPjjgService.testJafs(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}

			if(testModel.getTestNode().equals("��������ԭ��")){
				testModel=testPjjgService.testMsesffcsyy(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�Ƿ񷢻�����")){
				testModel=testPjjgService.testSffhcs(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("����������")){
				testModel=testPjjgService.testAjslf(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�᰸����ܶ�")){
				testModel=testPjjgService.testJabdje(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("Ȩ����")){
				testModel=testPjjgService.testQlr(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("������")){
				testModel=testPjjgService.testYwr(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�о�ִ������")){
				testModel=testPjjgService.testPjzxqx(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��������")){
				testModel=testPjjgService.testCslx(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�����˼���")){
				testModel=testPjjgService.testCsrjh(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�о����γе���ʽ")){
				testModel=testPjjgService.testPjzrcdfs(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�о����")){
				testModel=testPjjgService.testPjje(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�о��������")){
				testModel=testPjjgService.testPjjelx(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("������Ϣ")){
				testModel=testPjjgService.testSsxx(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���Ϸѽ��")){
				testModel=testPjjgService.testSsfje(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���Ϸѳе���")){
				testModel=testPjjgService.testCdr(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("���Ϸѳе���ʽ")){
				testModel=testPjjgService.testCdfs(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("��Ͻ����")){
				testModel=testPjjgService.testGxyy(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			if(testModel.getTestNode().equals("�Ƿ�֧��ԭ����������")){
				testModel=testPjjgService.testSfzcygssqq(testModel, wscpjgModel, inputpath, filename, specialpath, node);
				continue;
			}
			
		}
		return testModellist;
	}
	public static void main(String[] args) throws Exception {
		//		for (DataSourceEnum dataSourceEnum : DataSourceEnum.values()) {
		//			DataSourceRouter.routerTo(dataSourceEnum.getFydm());
		//			inint("1990-1-19", "2016-02-27");
		//		}


		String  inputpath="C:\\Users\\lr12\\Desktop\\test";
//		String filepath="D:\\WS\\��������\\����ж���������Ժ\\����һ��";
		String specialpath="C:\\Users\\lr12\\Desktop\\test";

//		ArrayList<String> nodelist = getNodelist(filepath);

//		List testModellist=initTest(nodelist);
		File file=new File(inputpath);
		String filename[];
		filename=file.list();
        System.out.println(filename.length);
		for(int j=0;j<filename.length;j++)
		{
			System.out.println(filename[j]);
//			XmlUtil xmlUtil=new XmlUtil();
//			BaseCaseModelByWs baseCaseModelByWs = new BaseCaseModelByWs();
			String wsnr=POIUtil.getWqcGString(FileUtil.getContent(inputpath+"\\"+filename[j]), filename[j]);
			WsAnalyse wsAnalyse=new WsAnalyse( filename[j],wsnr);
			List<WssscyrModel> wssscyrModellist=new XZYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl());
			XZYSSsjlModelHandler xzysSsjlModelHandler=new XZYSSsjlModelHandler();
			WsssjlModel wsssjlModel=xzysSsjlModelHandler.jxWsssjlModel(wssscyrModellist, wsAnalyse.getSsjl());
			System.out.println(wsssjlModel.getBgzyldct());
			HashMap<String, String> hashMap=wsssjlModel.getCtrxx();
			for(java.util.Map.Entry<String,String> entry:hashMap.entrySet()){
				System.out.println(entry.getKey()+"==="+entry.getValue());
			}
			
			//wsnr=format(wsnr);
//			if(filename[j].endsWith("rtf")){
//				filename[j] = filename[j].replaceAll("rtf", "doc");
				
//				filename[j] = filename[j].replaceAll("rtf", "doc");
//			}
//			FileUtil.fileCopy(inputpath, filename[j], specialpath,	filename[j].replaceAll("rtf", "doc") );
//			String wsnr=WsjxWordTxt.fileSelection(inputpath,filename[j]);
//			WsAnalyse wsAnalyse = new WsAnalyse(filename[j],wsnr);
//			WsfdModel wsfdModel=new WsfdModel();
//			WswsModel wswsModel=new WswsModel();
//			WswwModel wswwModel=new WswwModel();
//			WsssjlModel wsssjlModel=new WsssjlModel();
//			List<WssscyrModel> wssscyrModellist= new ArrayList<WssscyrModel>();
//			WscpjgModel wscpjgModel = new WscpjgModel();
//			List<WscpfxgcModel> wscpfxgcModellist= new ArrayList<WscpfxgcModel>();
//			WsajjbqkModel wsajjbqkModel= new WsajjbqkModel();
//			List zjdModellist=new ArrayList<>();
//			wsfdModel=baseCaseModelByWs.jxWsfdModel(wsnr,wsAnalyse.getWs(), wsAnalyse.getSscyr(), wsAnalyse.getSsjl(),wsAnalyse.getAjjbqk(),
//					wsAnalyse.getCpfxgc(), wsAnalyse.getCpjg(), wsAnalyse.getWw(), wsAnalyse.getFl());
//			if(wsAnalyse.getWs()!=null){
//								wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
//							}
				//			if(wsAnalyse.getSscyr()!=null){
				//				wssscyrModellist = new SscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk()); 
				//			}
				//			if(wsAnalyse.getSsjl()!=null){
				//				wsssjlModel = new SsjlModelHandler().jxWsssjlModel(wsAnalyse.getSsjl());
				//			}
				//			if(wsAnalyse.getCpfxgc()!=null){
				//				wscpfxgcModellist = new CpfxgcModelHandler().jxWscpfxgcModelList(wsAnalyse.getCpfxgc()); 
				//			}
				//			if(wsAnalyse.getCpjg()!=null){
				//				wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,wssscyrModellist);
				//			}
//				if(wsAnalyse.getAjjbqk()!=null){
//					wsajjbqkModel = new AjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
//				}
//				if(wsajjbqkModel.getZjd()!=null){
//					zjdModellist= new ZjdModelHandler().jxZjdModellist(wsajjbqkModel.getZjd());
//				}
				//			if(wsAnalyse.getWw()!=null){
				//				wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
				//			}
				//			xmlUtil.BuildXMLDoc(wsfdModel, wswsModel,wssscyrModellist, wsAnalyse.getSscyr(),wsssjlModel,wsajjbqkModel,wscpfxgcModellist,
				//				wscpjgModel,wswwModel,outputpath,filename[j],inputpath);
				//			testModellist=testWs(wswsModel,inputpath,filename[j],testModellist,nodelist,specialpath);
				//			testModellist=testSscyr(wssscyrModellist,inputpath,filename[j],testModellist,nodelist,specialpath);
				//							testModellist=testFd(wsfdModel,inputpath,filename[j],testModellist,nodelist,specialpath);
				//			testModellist=testFd(wsfdModel,inputpath,filename[j],testModellist,nodelist,specialpath);
				//			testModellist=testCpjg(wsfdModel, wscpjgModel,inputpath, filename[j], testModellist, nodelist, specialpath);
				//			testModellist=testSsjl(wsssjlModel, inputpath, filename[j], testModellist, nodelist, specialpath);
//				testModellist=testAjjbqk(wsajjbqkModel, inputpath, filename[j], testModellist, nodelist, specialpath);
				//							System.out.println(wsAnalyse.getAjjbqk());
				//				System.out.println(wsajjbqkModel.getBssld());
			}

		
//		for(int i=0;i<testModellist.size();i++){
//			TestModel testModel=(TestModel) testModellist.get(i);
//			System.out.println("�ڵ����ƣ� "+testModel.getTestNode()+"  ��ȷ�ʣ�"+testModel.getCoNum()*100/filename.length+"%");
//		}
	}
}
