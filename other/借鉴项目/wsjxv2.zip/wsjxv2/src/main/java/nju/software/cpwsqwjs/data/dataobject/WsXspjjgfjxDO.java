package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.xs.FjxModel;

/**
 * WsXspjjgfjxDO entity. @author MyEclipse Persistence Tools
 * �����о���� ������
 */
@Entity
@Table(name = "WS_XSPJJG_FJX")
@IdClass(WsXspjjgfjxDOId.class)
public class WsXspjjgfjxDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer fjxbh;// �����̱��
	private Integer fzbh;//������
	private Integer pfbh;// �з����
	private String lb;//���
	private String se;//����
	private String bz;//��ע
	private String qx;//����
	/** default constructor */
	public WsXspjjgfjxDO() {
	}

	/** minimal constructor */
	public WsXspjjgfjxDO(Integer ajxh, Integer fjxbh) {
		this.ajxh = ajxh;
		this.fjxbh = fjxbh;
	}
	 
	public WsXspjjgfjxDO(Integer ajxh, Integer fjxbh, Integer fzbh,
			Integer pfbh, String lb, String se, String bz, String qx) {
		super();
		this.ajxh = ajxh;
		this.fjxbh = fjxbh;
		this.fzbh = fzbh;
		this.pfbh = pfbh;
		this.lb = lb;
		this.se = se;
		this.bz = bz;
		this.qx = qx;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name = "FJXBH", nullable = false)
	public Integer getFjxbh() {
		return fjxbh;
	}

	public void setFjxbh(Integer fjxbh) {
		this.fjxbh = fjxbh;
	}
	@Column(name = "FZBH")
	public Integer getFzbh() {
		return fzbh;
	}

	public void setFzbh(Integer fzbh) {
		this.fzbh = fzbh;
	}
	@Column(name = "PFBH")
	public Integer getPfbh() {
		return pfbh;
	}

	public void setPfbh(Integer pfbh) {
		this.pfbh = pfbh;
	}
	@Column(name = "LB", length = 	10)
	public String getLb() {
		return lb;
	}

	public void setLb(String lb) {
		this.lb = lb;
	}
	@Column(name = "SE", length = 30)
	public String getSe() {
		return se;
	}

	public void setSe(String se) {
		this.se = se;
	}
	@Column(name = "BZ", length = 10)
	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}
	@Column(name = "QX", length = 20)
	public String getQx() {
		return qx;
	}

	public void setQx(String qx) {
		this.qx = qx;
	}
	
	public WsXspjjgfjxDO(FjxModel model){
		if(model.getLb()!=null){
			this.lb = model.getLb();
		}
		if(model.getSe()!=null){
			this.se = model.getSe();
		}
		if(model.getBz()!=null){
			this.bz = model.getBz();
		}
		if(model.getQx()!=null){
			this.qx = model.getQx();
		}
	}

}