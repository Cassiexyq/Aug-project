package nju.software.cpwsqwjs.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;

import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class WsUtil {
	public static String getWsnrFromHtml(String filename) {
		return getWsnrFromHtml(filename, "UTF-8");
	}
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	static WsJbDao wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
	public static String getWsnrFromHtml(String filename, String charset) {
		File file = new File(filename);
		InputStreamReader ir;
		String wsnr = "";
		try {
			ir = new InputStreamReader(new FileInputStream(file), charset);
			BufferedReader br = new BufferedReader(ir);
			String str = "";
			while ((str = br.readLine()) != null) {
				wsnr += str;
			}
			ir.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return wsnr;
	}

	public static boolean createWsWord(byte[] data, String filename) {
		if (data != null && !StringUtil.isBlank(new String(data))) {
			File file = new File(filename);
			try {
				OutputStream out = new FileOutputStream(file);
				out.write(data);
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		/*String temp = getWsnrFromHtml("C:\\test\\html\\0066000000172981.html");
		String en_1 = Base64Util.getBASE64(temp.getBytes());
		System.out.println(en_1);
		System.out.println(new String(Base64Util.getFromBASE64(en_1)));
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println();
		try {
			String en_2 = Base64Util.getBASE64(temp.getBytes("UTF-8"));
			System.out.println(en_2);
			System.out.println(new String(Base64Util.getFromBASE64(en_2)));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		String fydm=DataSourceEnum.TJXQFY.getFydm();
		DataSourceRouter.routerTo(fydm);
	List<WsJbDO> list= wsJbDao.findByProperty("ajxh",48558 );
	  System.out.println(list.size());
	     System.out.println(list.get(0).getWswjm());
		 createWsWord(list.get(0).getWsnr(), "C:\\Users\\lr12\\Desktop\\nihao.doc");
	}

	public static boolean createWsHtml(byte[] data, String filename) {
		if (data != null && !StringUtil.isBlank(new String(data))) {
			File file = new File(filename);
			try {
				OutputStream out = new FileOutputStream(file);
				out.write(data);
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}
	
	public static boolean createWs(byte[] data, String filename) {
		if (data != null && !StringUtil.isBlank(new String(data))) {
			File file = new File(filename);
			try {
				OutputStream out = new FileOutputStream(file);
				out.write(data);
				out.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
		return false;
	}
}
