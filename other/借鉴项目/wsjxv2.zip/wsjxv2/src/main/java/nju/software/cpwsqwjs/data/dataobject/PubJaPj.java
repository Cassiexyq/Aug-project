package nju.software.cpwsqwjs.data.dataobject;

// default package

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * PubJaPj entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_JA_PJ")
public class PubJaPj implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1843807182958998522L;
	private Integer ajxh;
	private Date pjcdtjrq;
	private String bapjly;
	private String bacljg;
	private String pjyj;
	private Double pjrdajjz;
	private Double whjjss;
	private Date xprq;
	private String sfqxpj;
	private String sfgksp;
	private String bgkspyy;
	private String sfdtxp;
	private String pjsfsx;
	private String ysyy;
	private String ysfy;
	private Date ysrq;
	private String ysr;
	private Integer wc;
	private Integer gp;
	private Integer jz;
	private Integer jq;
	private Integer mx;
	private Integer wz;
	private Integer qt;
	private Integer sfhz;
	private Integer hz;
	private String sfjx;
	private Integer jxns;
	private Integer jxys;
	private String sfjs;
	private String sfjwzx;
	private Integer jwzxns;
	private Integer jwzxys;
	private Integer gpqtrs;
	private Integer cwsyflrs;
	private Integer lxbdrs;
	private Integer ssbqhzjbzrs;
	private Integer qtrs;
	private String sfeshsxshfh;
	private Date fhrq;
	private Integer sxbqzgyhzrs;
	private Date bqhzrq;
	private String eszsgpqk;
	private String bgkspyydm;
	private String yhzsxljzxzfgysryydm;
	private String bghcszl;
	private String xzjgfzrdtqk;//�������������˵�ͥ���

	// Constructors

	/** default constructor */
	public PubJaPj() {
	}

	/** minimal constructor */
	public PubJaPj(Integer ajxh) {
		this.ajxh = ajxh;
	}

	/** full constructor */
	public PubJaPj(Integer ajxh, Date pjcdtjrq, String bapjly, String bacljg,
			String pjyj, Double pjrdajjz, Double whjjss, Date xprq,
			String sfqxpj, String sfgksp, String bgkspyy, String sfdtxp,
			String pjsfsx, String ysyy, String ysfy, Date ysrq, String ysr,
			Integer wc, Integer gp, Integer jz, Integer jq, Integer mx,
			Integer wz, Integer qt, Integer sfhz, Integer hz, String sfjx,
			Integer jxns, Integer jxys, String sfjs, String sfjwzx,
			Integer jwzxns, Integer jwzxys, Integer gpqtrs, Integer cwsyflrs,
			Integer lxbdrs, Integer ssbqhzjbzrs, Integer qtrs,
			String sfeshsxshfh, Date fhrq, Integer sxbqzgyhzrs, Date bqhzrq,
			String eszsgpqk, String bgkspyydm, String yhzsxljzxzfgysryydm,
			String bghcszl) {
		super();
		this.ajxh = ajxh;
		this.pjcdtjrq = pjcdtjrq;
		this.bapjly = bapjly;
		this.bacljg = bacljg;
		this.pjyj = pjyj;
		this.pjrdajjz = pjrdajjz;
		this.whjjss = whjjss;
		this.xprq = xprq;
		this.sfqxpj = sfqxpj;
		this.sfgksp = sfgksp;
		this.bgkspyy = bgkspyy;
		this.sfdtxp = sfdtxp;
		this.pjsfsx = pjsfsx;
		this.ysyy = ysyy;
		this.ysfy = ysfy;
		this.ysrq = ysrq;
		this.ysr = ysr;
		this.wc = wc;
		this.gp = gp;
		this.jz = jz;
		this.jq = jq;
		this.mx = mx;
		this.wz = wz;
		this.qt = qt;
		this.sfhz = sfhz;
		this.hz = hz;
		this.sfjx = sfjx;
		this.jxns = jxns;
		this.jxys = jxys;
		this.sfjs = sfjs;
		this.sfjwzx = sfjwzx;
		this.jwzxns = jwzxns;
		this.jwzxys = jwzxys;
		this.gpqtrs = gpqtrs;
		this.cwsyflrs = cwsyflrs;
		this.lxbdrs = lxbdrs;
		this.ssbqhzjbzrs = ssbqhzjbzrs;
		this.qtrs = qtrs;
		this.sfeshsxshfh = sfeshsxshfh;
		this.fhrq = fhrq;
		this.sxbqzgyhzrs = sxbqzgyhzrs;
		this.bqhzrq = bqhzrq;
		this.eszsgpqk = eszsgpqk;
		this.bgkspyydm = bgkspyydm;
		this.yhzsxljzxzfgysryydm = yhzsxljzxzfgysryydm;
		this.bghcszl = bghcszl;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", unique = true, nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "PJCDTJRQ", length = 23)
	public Date getPjcdtjrq() {
		return this.pjcdtjrq;
	}

	public void setPjcdtjrq(Date pjcdtjrq) {
		this.pjcdtjrq = pjcdtjrq;
	}

	@Column(name = "BAPJLY")
	public String getBapjly() {
		return this.bapjly;
	}

	public void setBapjly(String bapjly) {
		this.bapjly = bapjly;
	}

	@Column(name = "BACLJG")
	public String getBacljg() {
		return this.bacljg;
	}

	public void setBacljg(String bacljg) {
		this.bacljg = bacljg;
	}

	@Column(name = "PJYJ")
	public String getPjyj() {
		return this.pjyj;
	}

	public void setPjyj(String pjyj) {
		this.pjyj = pjyj;
	}

	@Column(name = "PJRDAJJZ", scale = 4)
	public Double getPjrdajjz() {
		return this.pjrdajjz;
	}

	public void setPjrdajjz(Double pjrdajjz) {
		this.pjrdajjz = pjrdajjz;
	}

	@Column(name = "WHJJSS", scale = 4)
	public Double getWhjjss() {
		return this.whjjss;
	}

	public void setWhjjss(Double whjjss) {
		this.whjjss = whjjss;
	}

	@Column(name = "XPRQ", length = 23)
	public Date getXprq() {
		return this.xprq;
	}

	public void setXprq(Date xprq) {
		this.xprq = xprq;
	}

	@Column(name = "SFQXPJ", length = 1)
	public String getSfqxpj() {
		return this.sfqxpj;
	}

	public void setSfqxpj(String sfqxpj) {
		this.sfqxpj = sfqxpj;
	}

	@Column(name = "SFGKSP", length = 1)
	public String getSfgksp() {
		return this.sfgksp;
	}

	public void setSfgksp(String sfgksp) {
		this.sfgksp = sfgksp;
	}

	@Column(name = "BGKSPYY", length = 250)
	public String getBgkspyy() {
		return this.bgkspyy;
	}

	public void setBgkspyy(String bgkspyy) {
		this.bgkspyy = bgkspyy;
	}

	@Column(name = "SFDTXP", length = 1)
	public String getSfdtxp() {
		return this.sfdtxp;
	}

	public void setSfdtxp(String sfdtxp) {
		this.sfdtxp = sfdtxp;
	}

	@Column(name = "PJSFSX", length = 1)
	public String getPjsfsx() {
		return this.pjsfsx;
	}

	public void setPjsfsx(String pjsfsx) {
		this.pjsfsx = pjsfsx;
	}

	@Column(name = "YSYY", length = 250)
	public String getYsyy() {
		return this.ysyy;
	}

	public void setYsyy(String ysyy) {
		this.ysyy = ysyy;
	}

	@Column(name = "YSFY", length = 50)
	public String getYsfy() {
		return this.ysfy;
	}

	public void setYsfy(String ysfy) {
		this.ysfy = ysfy;
	}

	@Column(name = "YSRQ", length = 23)
	public Date getYsrq() {
		return this.ysrq;
	}

	public void setYsrq(Date ysrq) {
		this.ysrq = ysrq;
	}

	@Column(name = "YSR", length = 50)
	public String getYsr() {
		return this.ysr;
	}

	public void setYsr(String ysr) {
		this.ysr = ysr;
	}

	@Column(name = "WC")
	public Integer getWc() {
		return this.wc;
	}

	public void setWc(Integer wc) {
		this.wc = wc;
	}

	@Column(name = "GP")
	public Integer getGp() {
		return this.gp;
	}

	public void setGp(Integer gp) {
		this.gp = gp;
	}

	@Column(name = "JZ")
	public Integer getJz() {
		return this.jz;
	}

	public void setJz(Integer jz) {
		this.jz = jz;
	}

	@Column(name = "JQ")
	public Integer getJq() {
		return this.jq;
	}

	public void setJq(Integer jq) {
		this.jq = jq;
	}

	@Column(name = "MX")
	public Integer getMx() {
		return this.mx;
	}

	public void setMx(Integer mx) {
		this.mx = mx;
	}

	@Column(name = "WZ")
	public Integer getWz() {
		return this.wz;
	}

	public void setWz(Integer wz) {
		this.wz = wz;
	}

	@Column(name = "QT")
	public Integer getQt() {
		return this.qt;
	}

	public void setQt(Integer qt) {
		this.qt = qt;
	}

	@Column(name = "SFHZ")
	public Integer getSfhz() {
		return this.sfhz;
	}

	public void setSfhz(Integer sfhz) {
		this.sfhz = sfhz;
	}

	@Column(name = "HZ")
	public Integer getHz() {
		return this.hz;
	}

	public void setHz(Integer hz) {
		this.hz = hz;
	}

	@Column(name = "SFJX", length = 1)
	public String getSfjx() {
		return this.sfjx;
	}

	public void setSfjx(String sfjx) {
		this.sfjx = sfjx;
	}

	@Column(name = "JXNS")
	public Integer getJxns() {
		return this.jxns;
	}

	public void setJxns(Integer jxns) {
		this.jxns = jxns;
	}

	@Column(name = "JXYS")
	public Integer getJxys() {
		return this.jxys;
	}

	public void setJxys(Integer jxys) {
		this.jxys = jxys;
	}

	@Column(name = "SFJS", length = 1)
	public String getSfjs() {
		return this.sfjs;
	}

	public void setSfjs(String sfjs) {
		this.sfjs = sfjs;
	}

	@Column(name = "SFJWZX", length = 1)
	public String getSfjwzx() {
		return this.sfjwzx;
	}

	public void setSfjwzx(String sfjwzx) {
		this.sfjwzx = sfjwzx;
	}

	@Column(name = "JWZXNS")
	public Integer getJwzxns() {
		return this.jwzxns;
	}

	public void setJwzxns(Integer jwzxns) {
		this.jwzxns = jwzxns;
	}

	@Column(name = "JWZXYS")
	public Integer getJwzxys() {
		return this.jwzxys;
	}

	public void setJwzxys(Integer jwzxys) {
		this.jwzxys = jwzxys;
	}

	@Column(name = "GPQTRS")
	public Integer getGpqtrs() {
		return this.gpqtrs;
	}

	public void setGpqtrs(Integer gpqtrs) {
		this.gpqtrs = gpqtrs;
	}

	@Column(name = "CWSYFLRS")
	public Integer getCwsyflrs() {
		return this.cwsyflrs;
	}

	public void setCwsyflrs(Integer cwsyflrs) {
		this.cwsyflrs = cwsyflrs;
	}

	@Column(name = "LXBDRS")
	public Integer getLxbdrs() {
		return this.lxbdrs;
	}

	public void setLxbdrs(Integer lxbdrs) {
		this.lxbdrs = lxbdrs;
	}

	@Column(name = "SSBQHZJBZRS")
	public Integer getSsbqhzjbzrs() {
		return this.ssbqhzjbzrs;
	}

	public void setSsbqhzjbzrs(Integer ssbqhzjbzrs) {
		this.ssbqhzjbzrs = ssbqhzjbzrs;
	}

	@Column(name = "QTRS")
	public Integer getQtrs() {
		return this.qtrs;
	}

	public void setQtrs(Integer qtrs) {
		this.qtrs = qtrs;
	}

	@Column(name = "SFESHSXSHFH", length = 1)
	public String getSfeshsxshfh() {
		return this.sfeshsxshfh;
	}

	public void setSfeshsxshfh(String sfeshsxshfh) {
		this.sfeshsxshfh = sfeshsxshfh;
	}

	@Column(name = "FHRQ", length = 23)
	public Date getFhrq() {
		return this.fhrq;
	}

	public void setFhrq(Date fhrq) {
		this.fhrq = fhrq;
	}

	@Column(name = "SXBQZGYHZRS")
	public Integer getSxbqzgyhzrs() {
		return this.sxbqzgyhzrs;
	}

	public void setSxbqzgyhzrs(Integer sxbqzgyhzrs) {
		this.sxbqzgyhzrs = sxbqzgyhzrs;
	}

	@Column(name = "BQHZRQ", length = 23)
	public Date getBqhzrq() {
		return this.bqhzrq;
	}

	public void setBqhzrq(Date bqhzrq) {
		this.bqhzrq = bqhzrq;
	}

	@Column(name = "ESZSGPQK")
	public String getEszsgpqk() {
		return this.eszsgpqk;
	}

	public void setEszsgpqk(String eszsgpqk) {
		this.eszsgpqk = eszsgpqk;
	}

	@Column(name = "BGKSPYYDM", length = 10)
	public String getBgkspyydm() {
		return this.bgkspyydm;
	}

	public void setBgkspyydm(String bgkspyydm) {
		this.bgkspyydm = bgkspyydm;
	}

	@Column(name = "YHZSXLJZXZFGYSRYYDM", length = 10)
	public String getYhzsxljzxzfgysryydm() {
		return this.yhzsxljzxzfgysryydm;
	}

	public void setYhzsxljzxzfgysryydm(String yhzsxljzxzfgysryydm) {
		this.yhzsxljzxzfgysryydm = yhzsxljzxzfgysryydm;
	}

	@Column(name = "BGHCSZL")
	public String getBghcszl() {
		return bghcszl;
	}

	public void setBghcszl(String bghcszl) {
		this.bghcszl = bghcszl;
	}

	@Column(name="XZJGFZRDTQK")
	public String getXzjgfzrdtqk() {
		return xzjgfzrdtqk;
	}

	public void setXzjgfzrdtqk(String xzjgfzrdtqk) {
		this.xzjgfzrdtqk = xzjgfzrdtqk;
	}

}