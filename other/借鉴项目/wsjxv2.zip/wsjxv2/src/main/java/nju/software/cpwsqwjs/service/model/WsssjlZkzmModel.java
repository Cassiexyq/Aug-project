package nju.software.cpwsqwjs.service.model;

public class WsssjlZkzmModel {
	private String zkzm;
	private String wzzm;
	private String zmdm;
	public String getZkzm() {
		return zkzm;
	}
	public void setZkzm(String zkzm) {
		this.zkzm = zkzm;
	}
	public String getWzzm() {
		return wzzm;
	}
	public void setWzzm(String wzzm) {
		this.wzzm = wzzm;
	}
	public String getZmdm() {
		return zmdm;
	}
	public void setZmdm(String zmdm) {
		this.zmdm = zmdm;
	}
	
}
