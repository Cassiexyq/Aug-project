package nju.software.cpwsqwjs.data.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.StringUtil;

import org.hibernate.LockMode;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * A data access object (DAO) providing persistence and search support for
 * WsJbDO entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see nju.software.cpwsqwjs.data.dataobject.WsJbDO
 * @author MyEclipse Persistence Tools
 */

public class WsJbDao extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory.getLogger(WsJbDao.class);
	// property constants
	public static final String WSLB = "wslb";
	public static final String WSMC = "wsmc";
	public static final String ZFJ = "zfj";
	public static final String WSLBBH = "wslbbh";
	public static final String WSBH = "wsbh";
	public static final String WSYS = "wsys";
	public static final String WSJJ = "wsjj";
	public static final String ZZH = "zzh";
	public static final String WSWJM = "wswjm";
	public static final String WSAH = "wsah";
	public static final String WSZT = "wszt";
	public static final String SJJZ_FLAG = "sjjzFlag";
	public static final String ZS = "zs";

	protected void initDao() {
		// do nothing
	}

	public void save(WsJbDO transientInstance) {
		log.debug("saving WsJbDO instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(WsJbDO persistentInstance) {
		log.debug("deleting WsJbDO instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public WsJbDO findById(nju.software.cpwsqwjs.data.dataobject.WsJbDOId id) {
		log.debug("getting WsJbDO instance with id: " + id);
		try {
			WsJbDO instance = (WsJbDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsJbDO", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<WsJbDO> findByExample(WsJbDO instance) {
		log.debug("finding WsJbDO instance by example");
		try {
			List<WsJbDO> results = (List<WsJbDO>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding WsJbDO instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from WsJbDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List<WsJbDO> findByWslb(Object wslb) {
		return findByProperty(WSLB, wslb);
	}

	public List<WsJbDO> findByWsmc(Object wsmc) {
		return findByProperty(WSMC, wsmc);
	}

	public List<WsJbDO> findByZfj(Object zfj) {
		return findByProperty(ZFJ, zfj);
	}

	public List<WsJbDO> findByWslbbh(Object wslbbh) {
		return findByProperty(WSLBBH, wslbbh);
	}

	public List<WsJbDO> findByWsbh(Object wsbh) {
		return findByProperty(WSBH, wsbh);
	}

	public List<WsJbDO> findByWsys(Object wsys) {
		return findByProperty(WSYS, wsys);
	}

	public List<WsJbDO> findByWsjj(Object wsjj) {
		return findByProperty(WSJJ, wsjj);
	}

	public List<WsJbDO> findByZzh(Object zzh) {
		return findByProperty(ZZH, zzh);
	}

	public List<WsJbDO> findByWswjm(Object wswjm) {
		return findByProperty(WSWJM, wswjm);
	}

	public List<WsJbDO> findByWsah(Object wsah) {
		return findByProperty(WSAH, wsah);
	}

	public List<WsJbDO> findByWszt(Object wszt) {
		return findByProperty(WSZT, wszt);
	}

	public List<WsJbDO> findBySjjzFlag(Object sjjzFlag) {
		return findByProperty(SJJZ_FLAG, sjjzFlag);
	}

	public List<WsJbDO> findByZs(Object zs) {
		return findByProperty(ZS, zs);
	}

	public List findAll() {
		log.debug("finding all WsJbDO instances");
		try {
			String queryString = "from WsJbDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public WsJbDO merge(WsJbDO detachedInstance) {
		log.debug("merging WsJbDO instance");
		try {
			WsJbDO result = (WsJbDO) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(WsJbDO instance) {
		log.debug("attaching dirty WsJbDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(WsJbDO instance) {
		log.debug("attaching clean WsJbDO instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static WsJbDao getFromApplicationContext(ApplicationContext ctx) {
		return (WsJbDao) ctx.getBean("WsJbDODAO");
	}

	/**
	 * 
	 * @param beginDate
	 *            sql format yyyy/MM/dd HH:mm:ss
	 * @param endDate
	 *            sql format yyyy/MM/dd HH:mm:ss
	 * @param ajxhStart
	 * @param ajxhEnd
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<WsJbDO> getWs(String beginDate, String endDate, int ajxhStart,
			int ajxhEnd) {
		List<WsJbDO> wsList = new ArrayList<WsJbDO>();
		if (ajxhStart > ajxhEnd) {
			return wsList;
		}
		String hql = "";
		hql = "from WsJbDO where wswjm <> null and ajxh >" + ajxhStart
				+ " and ajxh < " + ajxhEnd + " ";
		if (!StringUtil.isBlank(beginDate)) {

			hql += " and scrq>='" + beginDate + "'";
		}
		if (!StringUtil.isBlank(endDate)) {

			hql += " and scrq<'" + endDate + "'";
		}
		hql += " and wsmc not like 'ԭ��%' and (sfjaws ='Y' or wsmc like'%�ö���%' or wsmc like'%�о���%' or wsmc like'%������%' or wsmc like '%������%')";
		System.out.println("+++" + hql);
		/*
		 * System.out.println("+++"+sql); ConnectionProvider cp = null;
		 * Connection connection = null; Statement statement = null; ResultSet
		 * resultSet = null;
		 * 
		 * try { cp = ((SessionFactoryImplementor) this
		 * .getSessionFactory()).getConnectionProvider(); connection =
		 * cp.getConnection(); statement = connection.createStatement();
		 * resultSet = statement.executeQuery(sql); int i=0;
		 * while(resultSet.next()) { i++; //
		 * System.out.println(">>>"+i+": "+resultSet.getString("WSWJM")); WsJbDO
		 * ws=new WsJbDO(); ws.setAjxh(resultSet.getInt("AJXH"));
		 * ws.setWsjbbh(resultSet.getInt("WSJBBH"));
		 * ws.setWslb(resultSet.getString("WSLB"));
		 * ws.setWsmc(resultSet.getString("WSMC"));
		 * ws.setZfj(resultSet.getString("ZFJ"));
		 * ws.setWslbbh(resultSet.getInt("WSLBBH"));
		 * ws.setWsbh(resultSet.getInt("WSBH"));
		 * ws.setWsys(resultSet.getInt("WSYS"));
		 * ws.setWsjj(resultSet.getString("WSJJ"));
		 * ws.setZzh(resultSet.getString("ZZH"));
		 * ws.setScrq(resultSet.getDate("SCRQ"));
		 * ws.setWswjm(resultSet.getString("WSWJM"));
		 * ws.setWsah(resultSet.getString("WSAH"));
		 * ws.setWszt(resultSet.getString("WSZT"));
		 * ws.setWsnr(resultSet.getBytes("WSNR"));
		 * ws.setSjjzFlag(resultSet.getString("SJJZ_FLAG"));
		 * ws.setZs(resultSet.getInt("ZS")); wsList.add(ws); }; //
		 * System.out.println(":~"+i+"������"); } catch (SQLException e) {
		 * log.error("Wrong sql:" + sql, e); }finally { try { if (resultSet !=
		 * null) resultSet.close(); if (statement != null) statement.close(); if
		 * (cp != null) cp.closeConnection(connection); } catch (SQLException e)
		 * { log.error("�ر����ݿ����ӳ�����",e); } }
		 */
		try {
			wsList = getHibernateTemplate().find(hql);
			if (wsList == null)
				wsList = new ArrayList<WsJbDO>();
		} catch (RuntimeException re) {
			log.error("getWs failed!", re);
		}

		return wsList;
	}

	public int getWsCount(String beginDate, String endDate) {
		String sql = "select  count(*) from PUB_WS_JB where PUB_WS_JB.WSWJM <> null ";

		if (!StringUtil.isBlank(beginDate)) {
			// sql+=" and DATEDIFF(ss, PUB_WS_JB.SCRQ,'"+beginDate+"') < 0 ";
			sql += " and PUB_WS_JB.SCRQ>='" + beginDate + "'";
		}
		if (!StringUtil.isBlank(endDate)) {
			// sql+=" and DATEDIFF(ss, PUB_WS_JB.SCRQ,'"+endDate+"') >= 0 ";
			sql += " and PUB_WS_JB.SCRQ<'" + endDate + "'";
		}
		sql += "and PUB_WS_JB.WSMC not like 'ԭ��%' and (PUB_WS_JB.SFJAWS='Y' or PUB_WS_JB.WSMC like'%�ö���%' or PUB_WS_JB.WSMC like'%�о���%' or PUB_WS_JB.WSMC like'%������%' or PUB_WS_JB.WSMC like '%������%')";

		System.out.println(sql);
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		int count = 0;
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();

			// System.out.println("=====================================B");
			connection = cp.getConnection();
			// System.out.println("=====================================A");
			statement = connection.createStatement();
			// System.out.println("=====================================C");
			resultSet = statement.executeQuery(sql);

			resultSet.next();
			count = resultSet.getInt(1);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);
			}
		}

		return count;
	}

	public int getMaxWsAjxh(String beginDate, String endDate) {
		String sql = "select  max(PUB_WS_JB.AJXH) from PUB_WS_JB where PUB_WS_JB.WSWJM <> null ";

		if (!StringUtil.isBlank(beginDate)) {

			sql += " and PUB_WS_JB.SCRQ>='" + beginDate + "'";
		}
		if (!StringUtil.isBlank(endDate)) {

			sql += " and PUB_WS_JB.SCRQ<'" + endDate + "'";
		}
		sql += "and PUB_WS_JB.WSMC not like 'ԭ��%' and (PUB_WS_JB.SFJAWS='Y' or PUB_WS_JB.WSMC like'%�ö���%' or PUB_WS_JB.WSMC like'%�о���%' or PUB_WS_JB.WSMC like'%������%' or PUB_WS_JB.WSMC like '%������%')";
		System.out.println(sql);
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		int count = 0;
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();
			connection = cp.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			resultSet.next();
			count = resultSet.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);
			}
		}

		return count;
	}

	public int getMinWsAjxh(String beginDate, String endDate) {
		String sql = "select  min(PUB_WS_JB.AJXH) from PUB_WS_JB where PUB_WS_JB.WSWJM <> null ";

		if (!StringUtil.isBlank(beginDate)) {
			sql += " and PUB_WS_JB.SCRQ>='" + beginDate + "'";
		}
		if (!StringUtil.isBlank(endDate)) {
			sql += " and PUB_WS_JB.SCRQ<'" + endDate + "'";
		}
		sql += "and PUB_WS_JB.WSMC not like 'ԭ��%' and (PUB_WS_JB.SFJAWS='Y' or PUB_WS_JB.WSMC like'%�ö���%' or PUB_WS_JB.WSMC like'%�о���%' or PUB_WS_JB.WSMC like'%������%' or PUB_WS_JB.WSMC like '%������%')";
		System.out.println(sql);
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		int count = 0;
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();
			connection = cp.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			resultSet.next();
			count = resultSet.getInt(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);
			}
		}

		return count;
	}

	@SuppressWarnings("unchecked")
	public byte[] getWsnrBytes(String wswjm) {
		List<WsJbDO> wsList = new ArrayList<WsJbDO>();
		byte[] b_wsnr = null;
		String hql = "from WsJbDO where wswjm = '" + wswjm + "'";
		try {
			wsList = getHibernateTemplate().find(hql);
			if (wsList == null) {
				wsList = new ArrayList<WsJbDO>();
				return null;
			}
		} catch (RuntimeException re) {
			log.error("getWsnr failed!", re);
		}
		System.out.println(wsList);
		b_wsnr = wsList.get(0).getWsnr();
		return b_wsnr;
	}

	public Date getWsMinDate() {
		String sql = "select  min(PUB_WS_JB.SCRQ) from PUB_WS_JB where PUB_WS_JB.WSWJM <> null ";

		sql += "and PUB_WS_JB.WSMC not like '%ԭ��' and (PUB_WS_JB.SFJAWS='Y' or PUB_WS_JB.WSMC like'%�ö���%' or PUB_WS_JB.WSMC like'%�о���%' or PUB_WS_JB.WSMC like'%������%' or PUB_WS_JB.WSMC like '%������%')";
		System.out.println(sql);
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		Date minDate = null;
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();
			connection = cp.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			resultSet.next();
			minDate = resultSet.getDate(1);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);
			}
		}

		return minDate;
	}
	@SuppressWarnings("unchecked")
	public WsJbDO getWsnrBytesbyajxh(Integer ajxh) {
		List<WsJbDO> wsList = new ArrayList<WsJbDO>();
		String hql = "from WsJbDO where ajxh = " + ajxh +" and sfjaws='Y'";
		try {
			wsList = getHibernateTemplate().find(hql);
			if (wsList == null||wsList.size()==0) {
			
				return null;
			}
		} catch (RuntimeException re) {
			log.error("getWsnr failed!", re);
			return null;
		}
	//	System.out.println(wsList);
		
		
		return wsList.get(0);
	}
	
	public WsJbDO getCpwsBbyajxh(Integer ajxh) {
		List<WsJbDO> wsList = new ArrayList<WsJbDO>();
		/**
		 * �����Ƿ�����������
		 */
		String hql = "from WsJbDO where ajxh = " + ajxh +" and sfjaws='Y' and wsmc not like '%ԭ��%' and wswjm  is not null";
		try {
			wsList = getHibernateTemplate().find(hql);
			if (wsList == null||wsList.size()==0) {
				/**
				 * ���Ÿ������������Ҳ�����������
				 */
			     hql="from WsJbDO where ajxh = " + ajxh +" and wswjm is not null and wsmc not like '%ԭ��%' and (wsmc like'%�ö���%' or wsmc like'%�о���%' or wsmc like'%������%' or wsmc like '%������%')";
			     wsList = getHibernateTemplate().find(hql);
			 	if (wsList == null||wsList.size()==0) {
			     return null;
			 	}
			 	return wsList.get(0);
			}
		} catch (RuntimeException re) {
			log.error("getWsnr failed!", re);
			return null;
		}
		finally{
//			System.out.println(hql);
		}
	//	System.out.println(wsList);
		
		
		return wsList.get(0);
	}
	
	@SuppressWarnings("unchecked")
	public List<WsJbDO> getWs(String ajxhs) {
		if(ajxhs == null){
			return null;
		}
		List<WsJbDO> wsList = new ArrayList<WsJbDO>();
		String hql = "";
		hql = "from WsJbDO where ajxh in ("+ajxhs+")";
		hql += " and wswjm <> null and wsmc not like 'ԭ��%' and sfjaws ='Y' and (wsmc like'%�ö���%' or wsmc like'%�о���%' or wsmc like'%������%' or wsmc like '%������%')";
		System.out.println("getWs hql:" + hql);
		try {
			wsList = getHibernateTemplate().find(hql);
			if (wsList == null)
				wsList = new ArrayList<WsJbDO>();
		} catch (RuntimeException re) {
			log.error("getWs failed!", re);
		}

		return wsList;
	}
	
}