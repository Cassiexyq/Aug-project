package nju.software.cpwsqwjs.service.model;

/**
 * �о���������Ϸѽ���࣬�������ϷѵĽ�����
 * @author ����
 *
 */
public class WsCpjgssfjeModel {
	private String value;
	private String category;
	
	public WsCpjgssfjeModel() {
		super();
	}
	public WsCpjgssfjeModel(String value, String category) {
		super();
		this.value = value;
		this.category = category;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	

}
