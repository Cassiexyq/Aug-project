package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * PubQtsscyr entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_QTSSCYR")
@IdClass(value=PubQtsscyrId.class)
public class PubQtsscyr implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 6930622198962849180L;
	
	private Integer ajxh;
	private Integer qtsscyrbh;
	private String qtsscyrlx;//�������ϲ��������� ί�д����� USR012-98 B�Ǹ�����
	private String ydsrgx;//�뵱���˹�ϵ ֱ���� USR005-98 3�޹�ϵ
	private String xm;
	private String xb;//1 �� 2 Ů 3���� 4δ��
	private Date csnyr;
	private String whcd;
	private String gzdw;
	private String zw;//ְ�� ��� GB12403-90  ��ʦ����
	private String zc;//1��ʦ 4������
	private String dh;
	private String yb;
	private String dz;
	private Date cysj;
	private String sfsfyz;

	// Constructors

	/** default constructor */
	public PubQtsscyr() {
	}

	/** minimal constructor */
	public PubQtsscyr(Integer ajxh, Integer qtsscyrbh) {
		this.ajxh = ajxh;
		this.qtsscyrbh = qtsscyrbh;
	}

	/** full constructor */
	public PubQtsscyr(Integer ajxh, Integer qtsscyrbh, String qtsscyrlx, String ydsrgx,
			String xm, String xb, Date csnyr, String whcd, String gzdw,
			String zw, String zc, String dh, String yb, String dz, Date cysj,
			String sfsfyz) {
		this.ajxh = ajxh;
		this.qtsscyrbh = qtsscyrbh;
		this.qtsscyrlx = qtsscyrlx;
		this.ydsrgx = ydsrgx;
		this.xm = xm;
		this.xb = xb;
		this.csnyr = csnyr;
		this.whcd = whcd;
		this.gzdw = gzdw;
		this.zw = zw;
		this.zc = zc;
		this.dh = dh;
		this.yb = yb;
		this.dz = dz;
		this.cysj = cysj;
		this.sfsfyz = sfsfyz;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "QTSSCYRBH", nullable = false)
	public Integer getQtsscyrbh() {
		return this.qtsscyrbh;
	}

	public void setQtsscyrbh(Integer qtsscyrbh) {
		this.qtsscyrbh = qtsscyrbh;
	}

	@Column(name = "QTSSCYRLX", length = 10)
	public String getQtsscyrlx() {
		return this.qtsscyrlx;
	}

	public void setQtsscyrlx(String qtsscyrlx) {
		this.qtsscyrlx = qtsscyrlx;
	}

	@Column(name = "YDSRGX", length = 10)
	public String getYdsrgx() {
		return this.ydsrgx;
	}

	public void setYdsrgx(String ydsrgx) {
		this.ydsrgx = ydsrgx;
	}

	@Column(name = "XM", length = 50)
	public String getXm() {
		return this.xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}

	@Column(name = "XB", length = 10)
	public String getXb() {
		return this.xb;
	}

	public void setXb(String xb) {
		this.xb = xb;
	}

	@Column(name = "CSNYR", length = 23)
	public Date getCsnyr() {
		return this.csnyr;
	}

	public void setCsnyr(Date csnyr) {
		this.csnyr = csnyr;
	}

	@Column(name = "WHCD", length = 10)
	public String getWhcd() {
		return this.whcd;
	}

	public void setWhcd(String whcd) {
		this.whcd = whcd;
	}

	@Column(name = "GZDW", length = 50)
	public String getGzdw() {
		return this.gzdw;
	}

	public void setGzdw(String gzdw) {
		this.gzdw = gzdw;
	}

	@Column(name = "ZW", length = 10)
	public String getZw() {
		return this.zw;
	}

	public void setZw(String zw) {
		this.zw = zw;
	}

	@Column(name = "ZC", length = 10)
	public String getZc() {
		return this.zc;
	}

	public void setZc(String zc) {
		this.zc = zc;
	}

	@Column(name = "DH", length = 20)
	public String getDh() {
		return this.dh;
	}

	public void setDh(String dh) {
		this.dh = dh;
	}

	@Column(name = "YB", length = 10)
	public String getYb() {
		return this.yb;
	}

	public void setYb(String yb) {
		this.yb = yb;
	}

	@Column(name = "DZ", length = 50)
	public String getDz() {
		return this.dz;
	}

	public void setDz(String dz) {
		this.dz = dz;
	}

	@Column(name = "CYSJ", length = 23)
	public Date getCysj() {
		return this.cysj;
	}

	public void setCysj(Date cysj) {
		this.cysj = cysj;
	}

	@Column(name = "SFSFYZ", length = 1)
	public String getSfsfyz() {
		return this.sfsfyz;
	}

	public void setSfsfyz(String sfsfyz) {
		this.sfsfyz = sfsfyz;
	}

}