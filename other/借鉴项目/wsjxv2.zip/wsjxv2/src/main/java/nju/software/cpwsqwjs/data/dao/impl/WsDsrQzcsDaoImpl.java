package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsDsrQzcsDao;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQzcsDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQzcsDOId;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by zhx on 2017/1/5.
 */
public class WsDsrQzcsDaoImpl extends HibernateDaoSupport implements WsDsrQzcsDao {

    @Override
    public WsDsrQzcsDO findByID(WsDsrQzcsDOId id) {
        try {
            WsDsrQzcsDO instance = (WsDsrQzcsDO) getHibernateTemplate().get(
                    "nju.software.cpwsqwjs.data.dataobject.WsDsrQzcsDO", id);
            return instance;
        } catch (RuntimeException re) {
            throw re;
        }
    }

    @Override
    public int getMaxQzcsbhByAjxh(int ajxh) {
        String hql="select max(qzcsbh) from WsDsrQzcsDO where ajxh="+ajxh;
        Session s=this.getSession();
        Query query = s.createQuery(hql);

        int maxQzcsbh=0;
        if (query.uniqueResult()!=null){
            maxQzcsbh=(int)query.uniqueResult();
        }
        this.releaseSession(s);
        return maxQzcsbh;
    }

    @Override
    public List<WsDsrQzcsDO> getDsrQzcsByAjxhDsrxh(int ajxh, int dsrbh) {
        return null;
    }

    @Override
    public WsDsrQzcsDO getDsrQzcsByQzcsbh(int ajxh, int qzcsbh) {
        return null;
    }

    @Override
    public int save(WsDsrQzcsDO wsDsrQzcsDO) {
        try{
            getHibernateTemplate().saveOrUpdate(wsDsrQzcsDO);
            return wsDsrQzcsDO.getQzcsbh();
        }catch (RuntimeException re){
            throw re;
        }
    }
}
