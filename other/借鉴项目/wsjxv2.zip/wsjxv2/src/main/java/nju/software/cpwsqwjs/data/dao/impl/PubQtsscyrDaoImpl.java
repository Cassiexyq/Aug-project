package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.PubQtsscyrDao;
import nju.software.cpwsqwjs.data.dataobject.PubQtsscyr;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class PubQtsscyrDaoImpl extends HibernateDaoSupport implements
		PubQtsscyrDao {
	private static final Logger log = Logger.getLogger(PubQtsscyrDaoImpl.class);

	@Override
	public List<PubQtsscyr> getPubQtsscyrsByAjxh(long ajxh) {
		String hql = "from PubQtsscyr where ajxh =" + ajxh;
		@SuppressWarnings("unchecked")
		List<PubQtsscyr> res = this.getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("PubQtsscyrDaoImpl By Hql : " + hql);
		}
		return res;
	}

	@Override
	public void savePubQtsscyr(PubQtsscyr pubQtsscyr) {

		try {
			getHibernateTemplate().save(pubQtsscyr);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean hasPubQtsscyrByAjxh_Xm(long ajxh, String xm) {
		String hql = "from PubQtsscyr where ajxh =" + ajxh +"and xm='"+xm+"'";
		@SuppressWarnings("unchecked")
		List<PubQtsscyr> res = this.getHibernateTemplate().find(hql);
		if(res!=null&&res.size()!=0)
			System.out.println("����ı���"+res.get(0).getXm());
		return res!=null?res.size()>0:false;
	}

}
