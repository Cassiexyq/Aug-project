package nju.software.cpwsqwjs.service.jtsg;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import nju.software.cpwsqwjs.service.model.PjjgnrModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.StringUtil;

public interface CpfxgcService {

	/**
	 * �ڲ��з��������У����ҽ�ͨ�¹ʹ�����
	 * @param cpfxgc
	 * @return
	 */
	public void getGcf(List<String> cpfxgc,List<WssscyrModel> wssscyrModellist);
	
	public  void setQlywr( List<String> cpfxgc,List<WssscyrModel> wssscyrModellist);
}
