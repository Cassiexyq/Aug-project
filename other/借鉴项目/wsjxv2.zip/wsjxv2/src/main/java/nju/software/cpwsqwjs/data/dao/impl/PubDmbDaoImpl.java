package nju.software.cpwsqwjs.data.dao.impl;

import java.util.ArrayList;
import java.util.List;



import nju.software.cpwsqwjs.data.dao.PubDmbDao;
import nju.software.cpwsqwjs.data.dataobject.PubDmb;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.googlecode.ehcache.annotations.Cacheable;

/**
 * �����DAO��ʵ��
 * 
 * @author byron
 * 
 */
public class PubDmbDaoImpl extends HibernateDaoSupport implements PubDmbDao {
	private static final Logger log = Logger.getLogger(PubDmbDaoImpl.class);

	@Override
	public PubDmb getDmByLbbhAndDmbh(String lbbh, String dmbh) {
		String hql = "from PubDmb where LBBH=? and dmbh=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, lbbh, dmbh);
		if (log.isInfoEnabled()) {
			log.info("getDmByDmbbh by sql: " + hql + " lbbh=" + lbbh + " dmbh"
					+ dmbh);
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}

	@Override
	public List<PubDmb> getJsFydmb() {
		String hql = "from PubDmb where LBBH=? and dmbh like ?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate()
				.find(hql, "FBZ0001-97", "32%");
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInJs by sql: " + hql);
		}
		return dmb;
	}

	@Override
	public List<PubDmb> getAllBm() {
		String hql = "from PubDmb where LBBH=? and bz=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, "USR206-99", "����");
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInJs by sql: " + hql);
		}
		return dmb;
	}

	@Override
	public PubDmb getFydmbByFybh(long fydm) {
		String hql = "from PubDmb where dmbh=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, fydm);
		if (log.isInfoEnabled()) {
			log.info("getDmByDmbbh by sql: " + hql + " dmbh" + fydm);
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}


	@SuppressWarnings("unchecked")
	@Override
	public PubDmb getDmbByBmbh(String bmbh) {
		String hql = "from PubDmb where LBBH=? and DMBH like ?";
		List<PubDmb> dmb = getHibernateTemplate().find(hql, "USR206-99", bmbh);
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}

	@Cacheable(cacheName = "PUB_DMB_CACHE")
	@Override
	public List<PubDmb> getAllBmByLbbh() {
		String hql = "from PubDmb where LBBH=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, "USR206-99");
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInJs by sql: " + hql);
		}
		return dmb;
	}

//	@Cacheable(cacheName = "PUB_DMB_CACHE")
	@Override
	public List<PubDmb> getTotalBm() {
		String hql = "from PubDmb where LBBH=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, "USR206-99");
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInJs by sql: " + hql);
		}
		return dmb;
	}

	@Override
	public List<PubDmb> getTotalBmWithOutCache() {
		String hql = "from PubDmb where LBBH=?";
		@SuppressWarnings("unchecked")
		List<PubDmb> dmb = getHibernateTemplate().find(hql, "USR206-99");
		if (dmb == null) {
			dmb = new ArrayList<PubDmb>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInJs by sql: " + hql);
		}
		return dmb;
	}

}
