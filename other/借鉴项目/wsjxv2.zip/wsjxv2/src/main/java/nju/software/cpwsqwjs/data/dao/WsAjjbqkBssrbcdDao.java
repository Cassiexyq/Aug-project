package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBssrbcdDO;

import java.util.List;

public interface WsAjjbqkBssrbcdDao {
    public WsAjjbqkBssrbcdDO getByAjxh(int ajxh);
    public void save(WsAjjbqkBssrbcdDO wsAjjbqkBssrbcdDO);
    public int getMaxbh();
}
