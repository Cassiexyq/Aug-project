package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;

import javax.persistence.Column;

/**
 * @author byron
 *
 */
public class PubAydmbPK implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5763096987881970681L;
	private String bbh;
	private String dmbh;
	
	/**
	 * 
	 */
	PubAydmbPK() {
		super();
	}
	
	/**
	 * @param bbh
	 * @param dmbh
	 */
	PubAydmbPK(String bbh, String dmbh) {
		super();
		this.bbh = bbh;
		this.dmbh = dmbh;
	}

	/**
	 * @return the bbh
	 */
	@Column(name="BBH",nullable=false)
	public String getBbh() {
		return bbh;
	}

	/**
	 * @param bbh the bbh to set
	 */
	public void setBbh(String bbh) {
		this.bbh = bbh;
	}

	/**
	 * @return the dmbh
	 */
	@Column(name="DMBH",nullable=false)
	public String getDmbh() {
		return dmbh;
	}

	/**
	 * @param dmbh the dmbh to set
	 */
	public void setDmbh(String dmbh) {
		this.dmbh = dmbh;
	}
	
	
}
