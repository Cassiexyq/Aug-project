package nju.software.cpwsqwjs.handler.msyshandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.service.impl.jtsg.CltbqkServiceImpl;
import nju.software.cpwsqwjs.service.jtsg.CltbqkService;
import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;

public class MSYSCpfxgcModelHandler {

	public WscpfxgcModel jxWscpfxgcModel(List<String> cpfxgc) {
		WscpfxgcModel wscpfxgcModel = new WscpfxgcModel();
		ArrayList<String> contentlist = WsAnalyse.getWholeContent(cpfxgc
				.get(cpfxgc.size() - 1));
		int index = 0;
		for (int i = 0; i < contentlist.size(); i++) {
			if (contentlist.get(i).contains("����")) {
				index = i;
				break;
			} else if (contentlist.get(i).contains("����")
					|| contentlist.get(i).contains("����")) {
				index = i;
			}
		}
		// ������������
		String ftString = "";// ����
		for (int j = index; j < contentlist.size(); j++) {
			ftString += contentlist.get(j);
		}
		String[] ftfz = ftString.split("��");
		ArrayList<WscpfxgcFtModel> ftModellist = new ArrayList<WscpfxgcFtModel>();
		wscpfxgcModel.setFtModellist(ftModellist);
		for (int j = 0; j < ftfz.length; j++) {
			String content = ftfz[j];
			if (content.indexOf("��") != -1) {
				WscpfxgcFtModel ftModel = new WscpfxgcFtModel();
				String flftmc = content.substring(0, content.indexOf("��"));
				ftModel.setFlftmc(flftmc);
				// System.out.println(flftmc);
				// ����������Ŀ����Ŀ
				String tmString[] = content.split("��");
				HashMap<String, String> ftMap = new HashMap<String, String>();// ����map<��Ŀ����Ŀ>
				List<String> tmlist = new ArrayList<String>();
				for (int i = 0; i < tmString.length - 1; i++) {
					if (!tmString[i + 1].contains("��")
							&& !tmString[i + 1].contains("��")
							&& tmString[i].contains("��")) {
						ftMap.put(tmString[i].substring(
								tmString[i].lastIndexOf("��") + 1,
								tmString[i].length()), "û�п�Ŀ");
					} else if (tmString[i].indexOf("��") > -1) {
						String tm = tmString[i].substring(
								tmString[i].lastIndexOf("��") + 1,
								tmString[i].length());
						String km = "";
						if (i < tmString.length - 1
								&& tmString[i + 1].contains("��")) {
							km = tmString[i + 1].substring(0,
									tmString[i + 1].lastIndexOf("��") + 1);
							ftMap.put(tm, km);
						}
						if (i < tmString.length - 1
								&& tmString[i + 1].contains("��")) {
							km = tmString[i + 1].substring(0,
									tmString[i + 1].lastIndexOf("��") + 1);
							ftMap.put(tm, km);
						}
					}
				}
				ftModel.setFtMap(ftMap);
				wscpfxgcModel.getFtModellist().add(ftModel);
			}
		}
		// �᰸��ʽ����
		String lastContent = contentlist.get(contentlist.size() - 1);
		if (lastContent != null) {
			int jaindex = lastContent.indexOf("����");
			if (jaindex != -1) {
				String jafslx = lastContent.substring(jaindex - 2, jaindex);
				wscpfxgcModel.setJafslx(jafslx);
			}
		}
		// ��������һ�󰸼���Դ
		String ysajly = null;
		for (int i = 0; i < contentlist.size(); i++) {
			if (contentlist.get(i).contains("������")
					|| contentlist.get(i).contains("�ٴ�����")
					|| contentlist.get(i).contains("��������")
					|| contentlist.get(i).contains("�ٴ�����")
					|| contentlist.get(i).contains("����")) {
				ysajly = "��������";
			}
		}
		wscpfxgcModel.setYsajly(ysajly);
		return wscpfxgcModel;
	}
}
