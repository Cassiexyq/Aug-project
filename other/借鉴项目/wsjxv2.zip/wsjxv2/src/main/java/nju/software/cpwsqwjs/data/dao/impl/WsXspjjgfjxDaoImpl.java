package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsXspjjgfjxDao;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfjxDO;

public class WsXspjjgfjxDaoImpl extends HibernateDaoSupport implements WsXspjjgfjxDao{

	@Override
	public int save(WsXspjjgfjxDO fix) {
		// TODO Auto-generated method stub
		try {
			getHibernateTemplate().saveOrUpdate(fix);
			return fix.getFjxbh();
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public int getMaxfjxbhByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(fjxbh) from WsXspjjgfjxDO where ajxh="+ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null) {
			maxbh =  (int) query.uniqueResult();
		}
		// �ͷ����ݿ�����
		this.releaseSession(s);
		return  maxbh;
	}

	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsXspjjgfjxDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public void saveFjxList(List<WsXspjjgfjxDO> doList) {
		// TODO Auto-generated method stub
		Session s = this.getSessionFactory().openSession();
		Transaction tx = s.beginTransaction();
		for(WsXspjjgfjxDO fjx:doList){
			s.save(fjx);
		}
		tx.commit();
		s.close();
	}
}
