package nju.software.cpwsqwjs.data.dao.impl;
import java.util.List;


import nju.software.cpwsqwjs.data.dao.PubJaPjDao;
import nju.software.cpwsqwjs.data.dataobject.PubJaPj;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.apache.log4j.Logger;
/*
YU
*/
public class PubJaPjDaoImpl extends HibernateDaoSupport  implements PubJaPjDao {

	private static final Logger log = Logger.getLogger(PubJaPjDaoImpl.class);
	
	@Override
	public PubJaPj getJaPjByAjxh(long ajxh) {
		String hql = "from PubJaPj where ajxh ="+ajxh;
		@SuppressWarnings("unchecked")
		List<PubJaPj> res = this.getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getJaPjDO By Hql : "+ hql);
		}
		return res.size()==0?new PubJaPj():res.get(0);
	}

}