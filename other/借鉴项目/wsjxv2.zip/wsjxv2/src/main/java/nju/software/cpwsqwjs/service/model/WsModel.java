package nju.software.cpwsqwjs.service.model;

import java.io.Serializable;
import java.util.Date;

import nju.software.cpwsqwjs.util.DateUtil;

public class WsModel implements Serializable {
	private Integer ajxh;
	private Integer wsjbbh;
	private String wslb;
	private String wsmc;
	/**
	 * ����
	 */
	private String zzh;
	private Date scrq;
	private String scrqStr;
	private String wswjm;
	//��ȡһ���ֵ�����ؼ�������
	private String wsnr;

	//�¼ӵ��������� �������ͣ������ͺͷ�Ժ
	private String ajlx;
	private String sjlx;
	private String fy;

	//��������
	private String laay;
	
	
	
	
	
	public String getLaay() {
		return laay;
	}
	public void setLaay(String laay) {
		this.laay = laay;
	}
	public String getFy() {
		return fy;
	}
	public void setFy(String fy) {
		this.fy = fy;
	}
	public String getSjlx() {
		return sjlx;
	}
	public void setSjlx(String sjlx) {
		this.sjlx = sjlx;
	}	

	public String getAjlx() {
		return ajlx;
	}
	public void setAjlx(String ajlx) {
		this.ajlx = ajlx;
	}
	public void setScrqStr(String scrqStr) {
		this.scrqStr = scrqStr;
	}
	public Integer getAjxh() {
		return ajxh;
	}
	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	public Integer getWsjbbh() {
		return wsjbbh;
	}
	public void setWsjbbh(Integer wsjbbh) {
		this.wsjbbh = wsjbbh;
	}
	public String getWslb() {
		return wslb;
	}
	public void setWslb(String wslb) {
		this.wslb = wslb;
	}
	public String getWsmc() {
		return wsmc;
	}
	public void setWsmc(String wsmc) {
		this.wsmc = wsmc;
	}
	public String getZzh() {
		return zzh;
	}
	public void setZzh(String zzh) {
		this.zzh = zzh;
	}
	public Date getScrq() {
		return scrq;
	}
	public void setScrq(Date scrq) {
		this.scrq = scrq;
		this.scrqStr=DateUtil.format(scrq, DateUtil.webFormat);
	}
	public String getScrqStr() {
		return scrqStr;
	}
	public String getWswjm() {
		return wswjm;
	}
	public void setWswjm(String wswjm) {
		this.wswjm = wswjm;
	}
	public String getWsnr() {
		return wsnr;
	}
	public void setWsnr(String wsnr) {
		this.wsnr = wsnr;
	}
}
