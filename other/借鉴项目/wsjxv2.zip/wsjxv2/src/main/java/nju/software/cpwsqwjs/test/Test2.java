package nju.software.cpwsqwjs.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.PubLaAyDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsCpfxgcDao;
import nju.software.cpwsqwjs.data.dao.WsCpfxgcFlftDao;
import nju.software.cpwsqwjs.data.dao.WsCpfxgcLxqjDao;
import nju.software.cpwsqwjs.data.dao.impl.PubLaAyDaoImpl;
import nju.software.cpwsqwjs.data.dao.impl.WsCpfxgcFlftDaoImpl;
import nju.software.cpwsqwjs.data.dataobject.PubLaAy;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.Ayservice;
import nju.software.cpwsqwjs.service.dataService.WsCpfxgcService;
import nju.software.cpwsqwjs.service.dataService.WsajjbxxService;
import nju.software.cpwsqwjs.service.dataService.impl.WsCpfxgcServiceImpl;
import nju.software.cpwsqwjs.service.dataService.impl.WsajjbxxServiceImpl;
import nju.software.cpwsqwjs.service.datamodel.WsajjbxxModel;
import nju.software.cpwsqwjs.service.impl.AyserviceImpl;

public class Test2 {
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	private static WsCpfxgcDao wsCpfxgcDao;
	private static WsCpfxgcFlftDao wsCpfxgcFlftDao;
	private static WsCpfxgcLxqjDao wsCpfxgcLxqjDao;
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsCpfxgcDao = (WsCpfxgcDao) appContext.getBean("wsCpfxgcDao");
		wsCpfxgcFlftDao = (WsCpfxgcFlftDao) appContext.getBean("wsCpfxgcFlftDao");
		wsCpfxgcLxqjDao = (WsCpfxgcLxqjDao) appContext.getBean("wsCpfxgcLxqjDao");
	}
	public static void main(String[] args){
//		PubLaAyDao dao = new PubLaAyDaoImpl();
//		List<PubLaAy> ay = dao.getLaAyDOsbyAjxh(82);
//		System.out.println(ay.size());
////		Ayservice ayservice = new AyserviceImpl();
////		String sy = ayservice.getAy(82);
////		System.out.println(sy);
		WsajjbxxService wsajjbxxService  = new WsajjbxxServiceImpl();
		WsajjbxxModel ajModel = wsajjbxxService.getAjjbxxModelByAh("(2000)���̼��ֵ�11��");
		System.out.println(ajModel.getAh());
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
//		int i = wsCpfxgcFlftDao.getMaxFtbhByajxh(69281);
//		System.out.println(i);
	}
}
