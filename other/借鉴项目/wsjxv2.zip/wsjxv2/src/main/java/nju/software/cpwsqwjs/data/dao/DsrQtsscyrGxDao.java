package nju.software.cpwsqwjs.data.dao;



import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.DsrQtsscyrGxDO;
import nju.software.cpwsqwjs.data.dataobject.DsrQtsscyrGxDOId;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;



/**
 * A data access object (DAO) providing persistence and search support for
 * DsrQtsscyrGxDO entities. Transaction control of the save(), update() and
 * delete() operations can directly support Spring container-managed
 * transactions or they can be augmented to handle user-managed Spring
 * transactions. Each of these methods provides additional information for how
 * to configure it for the desired type of transaction control.
 * 
 * @see software.tjspxt.data.dataobject.DsrQtsscyrGxDO
 * @author MyEclipse Persistence Tools
 */

public class DsrQtsscyrGxDao extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory
			.getLogger(DsrQtsscyrGxDao.class);

	// property constants

	protected void initDao() {
		// do nothing
	}

	public void save(DsrQtsscyrGxDO transientInstance) {
		log.debug("saving DsrQtsscyrGxDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(DsrQtsscyrGxDO persistentInstance) {
		log.debug("deleting DsrQtsscyrGxDO instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public DsrQtsscyrGxDO findById(
			DsrQtsscyrGxDOId id) {
		log.debug("getting DsrQtsscyrGxDO instance with id: " + id);
		try {
			DsrQtsscyrGxDO instance = (DsrQtsscyrGxDO) getHibernateTemplate()
					.get("software.tjspxt.data.dataobject.DsrQtsscyrGxDO", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<DsrQtsscyrGxDO> findByExample(DsrQtsscyrGxDO instance) {
		log.debug("finding DsrQtsscyrGxDO instance by example");
		try {
			List<DsrQtsscyrGxDO> results = (List<DsrQtsscyrGxDO>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding DsrQtsscyrGxDO instance with property: "
				+ propertyName + ", value: " + value);
		try {
			String queryString = "from DsrQtsscyrGxDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findAll() {
		log.debug("finding all DsrQtsscyrGxDO instances");
		try {
			String queryString = "from DsrQtsscyrGxDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public DsrQtsscyrGxDO merge(DsrQtsscyrGxDO detachedInstance) {
		log.debug("merging DsrQtsscyrGxDO instance");
		try {
			DsrQtsscyrGxDO result = (DsrQtsscyrGxDO) getHibernateTemplate()
					.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(DsrQtsscyrGxDO instance) {
		log.debug("attaching dirty DsrQtsscyrGxDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(DsrQtsscyrGxDO instance) {
		log.debug("attaching clean DsrQtsscyrGxDO instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static DsrQtsscyrGxDao getFromApplicationContext(
			ApplicationContext ctx) {
		return (DsrQtsscyrGxDao) ctx.getBean("DsrQtsscyrGxDODAO");
	}
	
	public void deleteByAjxhAndBh(int ajxh, int qtsscyrbh){
		String hql = "delete from DsrQtsscyrGxDO where ajxh = " + ajxh+" and qtsscyrbh = "+qtsscyrbh;
		
		Session s = this.getSession();
		Query query = s.createQuery(hql);
		query.executeUpdate();
		
		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);

	}
	//
	public int getMaxBhByAjxh(int ajxh)
	{
		String hql = "select max(qtsscyrbh) from DsrQtsscyrGxDO where ajxh = " + ajxh;
		
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Integer) query.uniqueResult();
		
		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		
		return maxbh;
	}
	public List<DsrQtsscyrGxDO> getDsrQtsscyrGxDOsByAjxh(int ajxh){
		String sqlString="from DsrQtsscyrGxDO where ajxh="+ajxh;
		List<DsrQtsscyrGxDO> list=null;
		try {
			list=getHibernateTemplate().find(sqlString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
}