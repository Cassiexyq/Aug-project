package nju.software.cpwsqwjs.service.jtsg;

import java.util.List;

import nju.software.cpwsqwjs.service.model.WssscyrModel;

public interface PjjgService {

	public boolean isPeichangIndexCorrect(String content,List<WssscyrModel> models);
}
