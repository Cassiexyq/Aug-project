package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WSAjjbqkxsesDao;
import nju.software.cpwsqwjs.data.dataobject.WSAjjbqkxsesDO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;


public class WSAjjbqkxsesDaoImpl extends HibernateDaoSupport implements WSAjjbqkxsesDao {
    private static final Logger log = LoggerFactory.getLogger(WSAjjbqkxsesDaoImpl.class);

    @Override
    public WSAjjbqkxsesDO getByAjxh(int ajxh) {
        List<WSAjjbqkxsesDO> list = findByProperty("AJXH", ajxh);
        if (list == null)
            return null;
        else if (list.size() == 0)
            return null;

        return list.get(0);
    }

    @Override
    public void save(WSAjjbqkxsesDO wsAjjbqkxsesDO) {
        log.debug("saving wsAjjbqkxsesDO");
        try {
            getHibernateTemplate().saveOrUpdate(wsAjjbqkxsesDO);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }


    public List findByProperty(String propertyName, Object value) {
        log.debug("finding WsAjjbqkxsysDO with property: " + propertyName
                + ", value: " + value);
        try {
            String queryString = "from WSAjjbqkxsesDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            log.error("find by property name failed", re);
            throw re;
        }
    }
}
