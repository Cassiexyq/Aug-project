package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkZjdDO;


public interface WsAjjbqkZjdDao {
    public WsAjjbqkZjdDO getByAjxh(int ajxh);
    public void save(WsAjjbqkZjdDO wsAjjbqkZjdDO);
    public int getMaxbh();
}
