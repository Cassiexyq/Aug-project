package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsSsjlZkzmDO;

public interface WsSsjlZkzmDao {
	public int save(WsSsjlZkzmDO zmDo);

	public int getMaxzmbhByajxh(int ajxh);
}
