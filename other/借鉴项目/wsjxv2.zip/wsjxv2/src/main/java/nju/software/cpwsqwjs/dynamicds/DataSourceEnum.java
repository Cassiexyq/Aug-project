package nju.software.cpwsqwjs.dynamicds;

import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.util.StringUtil;






/**
 */

/**
 * ���ԴEnum
 * 
 * @author zym
 * 
 */
public enum DataSourceEnum {
	/**
	 * ���п�
	 */
	DEFAULT("000000", "Default", "���п�"),
	/**
	 * ����
	 */
	TEST("test", "test", "����"),
	/**
	 * ��Ժ
	 */
	TJGY("120000 200", "Tjgy", "����и߼�����Ժ"),
	/**
	 * һ��Ժ
	 */
	TJYZY("120100 210", "Tjyzy", "��һ�м�����Ժ"),
	/**
	 * ����Ժ
	 */
	TJEZY("120200 220", "Tjezy", "�ڶ��м�����Ժ"),
	/**
	 * ��·
	 */
	TJTLFY("920103 132", "Tjtlfy", "��·"),
	/**
	 * ����
	 */
	TJHSFY("960200 230", "Tjhsfy", "����·�Ժ"),
	/**
	 * ��ƽ
	 */
	TJHPFY("120101 211", "Tjhpfy", "��ƽ������Ժ"),
	/**
	 * �Ͽ�
	 */
	TJNKFY("120104 212", "Tjnkfy", "�Ͽ�������Ժ"),
	/**
	 * �ӱ�
	 */
	TJHBFY("120105 213", "Tjhbfy", "�ӱ�������Ժ"),
	/**
	 * ����
	 */
	TJHQFY("120106 214", "Tjhqfy", "����������Ժ"),
	/**
	 * ����
	 */
	TJXQFY("120107 215", "Tjxqfy", "����������Ժ"),
	/**
	 * ����
	 */
	TJBCFY("120108 216", "Tjbcfy", "����������Ժ"),
	/**
	 * �Ӷ�
	 */
	TJHDFY("120202 221", "Tjhdfy", "�Ӷ�������Ժ"),

	/**
	 * ����
	 */
	TJHXFY("120203 222", "Tjhxfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJTGFY("120204 223", "Tjtgfy", "����������"),

	/**
	 * ����
	 */
	TJHGFY("120205 224", "Tjhgfy", "����������"),

	/**
	 * ���
	 */
	TJDGFY("120206 225", "Tjdgfy", "���������"),

	/**
	 * ����
	 */
	TJDLFY("120207 226", "Tjdlfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJJNFY("120208 227", "Tjjnfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJNHFY("120221 228", "Tjnhfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJWQFY("120222 217", "Tjwqfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJJHFY("120223 218", "Tjjhfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJBDFY("120224 219", "Tjbdfy", "����������Ժ"),

	/**
	 * ����
	 */
	TJJXFY("120225 21A", "Tjjxfy", "��������Ժ"),
	/**
	 * ������
	 */
	TJKFQFY("120241 229", "Tjkfqfy", "������������"),
	/**
	 * ����
	 */
	TJBHXQFY("120242 22A", "Tjbhxqfy", "������������Ժ");

	String fydm;

	String source;

	String fymc;

	/**
	 * @param fydm
	 * @param source
	 */
	private DataSourceEnum(String fydm, String source) {
		this.fydm = fydm;
		this.source = source;
	}

	/**
	 * @param fydm
	 * @param source
	 */
	private DataSourceEnum(String fydm, String source, String fy) {
		this.fydm = fydm;
		this.source = source;
		this.fymc = fy;
	}

	public static String getFydmBySource(String source) {
		for (DataSourceEnum src : DataSourceEnum.values()) {
			if (StringUtil.equals(source, src.getSource())) {
				return src.getFydm();
			}
		}
		return "";
	}

	public static List<DataSourceEnum> getFydmList() {
		List<DataSourceEnum> list = new ArrayList<DataSourceEnum>();
		for (DataSourceEnum src : DataSourceEnum.values()) {
			if (src.getFydm() == DataSourceEnum.DEFAULT.getFydm()
					|| src.getFydm() == DataSourceEnum.TEST.getFydm())
				continue;
			list.add(src);
		}
		return list;
	}

	public static String getFymcByFydm(String fydm) {
		for (DataSourceEnum src : DataSourceEnum.values()) {
			if (StringUtil.equals(fydm, src.getFydm())) {
				return src.getFymc();
			}
		}
		return "";
	}
	public static String getFydmByFymc(String fymc) {
	//	System.out.println(fymc+"1   ");
		for (DataSourceEnum src : DataSourceEnum.values()) {
			//System.out.println(src.getFymc()+"==");
			if (StringUtil.equals(fymc, src.getFymc())) {
				return src.getFydm();
			}
		}
		return "";
	}

	public static List<Court> getSubFy(String fydm) {
		List<Court> fydmList = new ArrayList<Court>();
		if (StringUtil.equals(TJGY.getFydm(), fydm)) {
			for (DataSourceEnum dataSource : DataSourceEnum.values()) {
				if (dataSource.getFydm().equals(
						DataSourceEnum.DEFAULT.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJGY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJYZY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJEZY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TEST.getFydm()))
					continue;
				fydmList.add(new Court(dataSource.getFydm(), dataSource
						.getFymc()));
			}
		} else if (StringUtil.equals(TJYZY.getFydm(), fydm)) {
			fydmList.add(new Court(TJHPFY.getFydm(), TJHPFY.getFymc()));
			fydmList.add(new Court(TJNKFY.getFydm(), TJNKFY.getFymc()));
			fydmList.add(new Court(TJHBFY.getFydm(), TJHBFY.getFymc()));
			fydmList.add(new Court(TJHQFY.getFydm(), TJHQFY.getFymc()));
			fydmList.add(new Court(TJXQFY.getFydm(), TJXQFY.getFymc()));
			fydmList.add(new Court(TJBCFY.getFydm(), TJBCFY.getFymc()));
			fydmList.add(new Court(TJWQFY.getFydm(), TJWQFY.getFymc()));
			fydmList.add(new Court(TJJHFY.getFydm(), TJJHFY.getFymc()));
			fydmList.add(new Court(TJBDFY.getFydm(), TJBDFY.getFymc()));
			fydmList.add(new Court(TJJXFY.getFydm(), TJJXFY.getFymc()));
		} else if (StringUtil.equals(TJEZY.getFydm(), fydm)) {
			fydmList.add(new Court(TJHDFY.getFydm(), TJHDFY.getFymc()));
			fydmList.add(new Court(TJHXFY.getFydm(), TJHXFY.getFymc()));
			fydmList.add(new Court(TJTGFY.getFydm(), TJTGFY.getFymc()));
			fydmList.add(new Court(TJHGFY.getFydm(), TJHGFY.getFymc()));
			fydmList.add(new Court(TJDGFY.getFydm(), TJDGFY.getFymc()));
			fydmList.add(new Court(TJDLFY.getFydm(), TJDLFY.getFymc()));
			fydmList.add(new Court(TJJNFY.getFydm(), TJJNFY.getFymc()));
			fydmList.add(new Court(TJNHFY.getFydm(), TJNHFY.getFymc()));
			fydmList.add(new Court(TJKFQFY.getFydm(), TJKFQFY.getFymc()));
			fydmList.add(new Court(TJBHXQFY.getFydm(), TJBHXQFY.getFymc()));
		}
		return fydmList;
	}

	public static List<String> getSubFydm(String fydm) {
		List<String> fydmList = new ArrayList<String>();
		if (StringUtil.equals(TJGY.getFydm(), fydm)) {
			for (DataSourceEnum dataSource : DataSourceEnum.values()) {
				if (dataSource.getFydm().equals(
						DataSourceEnum.DEFAULT.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJGY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJYZY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TJEZY.getFydm())
						|| dataSource.getFydm().equals(
								DataSourceEnum.TEST.getFydm()))
					continue;
				fydmList.add(dataSource.getFydm());
			}
		} else if (StringUtil.equals(TJYZY.getFydm(), fydm)) {
			fydmList.add(TJHPFY.getFydm());
			fydmList.add(TJNKFY.getFydm());
			fydmList.add(TJHBFY.getFydm());
			fydmList.add(TJHQFY.getFydm());
			fydmList.add(TJXQFY.getFydm());
			fydmList.add(TJBCFY.getFydm());
			fydmList.add(TJWQFY.getFydm());
			fydmList.add(TJJHFY.getFydm());
			fydmList.add(TJBDFY.getFydm());
			fydmList.add(TJJXFY.getFydm());
		} else if (StringUtil.equals(TJEZY.getFydm(), fydm)) {
			fydmList.add(TJHDFY.getFydm());
			fydmList.add(TJHXFY.getFydm());
			fydmList.add(TJTGFY.getFydm());
			fydmList.add(TJHGFY.getFydm());
			fydmList.add(TJDGFY.getFydm());
			fydmList.add(TJDLFY.getFydm());
			fydmList.add(TJJNFY.getFydm());
			fydmList.add(TJNHFY.getFydm());
			fydmList.add(TJKFQFY.getFydm());
			fydmList.add(TJBHXQFY.getFydm());
		} else {
			fydmList.add(fydm);
		}

		return fydmList;
	}

	/**
	 * @return the fydm
	 */
	public String getFydm() {
		return fydm;
	}

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	public String getFymc() {
		return fymc;
	}

}

