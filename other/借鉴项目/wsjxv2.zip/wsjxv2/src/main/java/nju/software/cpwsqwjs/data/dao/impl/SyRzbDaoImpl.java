package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.SyRzbDao;
import nju.software.cpwsqwjs.data.dataobject.SyRzbDO;

public class SyRzbDaoImpl extends HibernateDaoSupport implements SyRzbDao {
	private static Logger log = Logger.getLogger(SyRzbDaoImpl.class);

	
	public void addSyRzb(SyRzbDO s) {
		try {
			if (s == null) {
				throw new Exception("������־������Ϊ�գ�");
			} else {
				int id = getMaxId() + 1;
				s.setId(id);
				getHibernateTemplate().evict(s);
				getHibernateTemplate().save(s);
			}
			// ˢ��Session
			getSession().flush();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	
	public void updateSyRzb(SyRzbDO s) {
		try {
			if (s == null) {
				throw new Exception("������־������Ϊ�գ�");
			} else {
				getHibernateTemplate().update(s);
			}
			getSession().flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public int getMaxId() {
		String sql = "select max(id) from SyRzbDO";

		Integer maxxh = new Integer(0);
		try {
			Session s = this.getSession();
			Query query = s.createQuery(sql);

			if (query.uniqueResult() != null)
				maxxh = (Integer) query.uniqueResult();
			this.releaseSession(s);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Failed to get the max xh of SyRzbDO", e);
		}
		return maxxh;

	}

	
	public SyRzbDO getNewSyRzbDO() {
		// TODO Auto-generated method stub
		int id = getMaxId();
		String Hql = "from SyRzbDO where id=?";
		@SuppressWarnings("unchecked")
		List<SyRzbDO> list = getHibernateTemplate().find(Hql, id);
		if (list == null || list.size() == 0)
			return null;
		return list.get(0);
	}

	
}
