package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;

import javax.persistence.Column;

/**
 * @author yzj
 *
 */

public class PubJaAyPK implements Serializable{

	private static final long serialVersionUID = 1L;
	private Integer ajxh;
	private Integer jaaybh;
	
	public PubJaAyPK(){
		super();
	}
	
	
	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "AJXH")
	public Integer getAjxh() {
		return ajxh;
	}

	@Column (name = "JAAYBH")
	public Integer getJaaybh() {
		return jaaybh;
	}
	
	public void setJaaybh(Integer jaaybh) {
		this.jaaybh = jaaybh;
	}

	
	
	

}
