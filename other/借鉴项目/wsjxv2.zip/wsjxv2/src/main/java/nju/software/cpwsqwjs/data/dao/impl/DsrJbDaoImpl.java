package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;



import nju.software.cpwsqwjs.data.dao.BaseHibernateDAO;
import nju.software.cpwsqwjs.data.dao.DsrJbDao;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDO;

import org.apache.log4j.Logger;

/**
 * @author lc
 *
 */
public class DsrJbDaoImpl extends BaseHibernateDAO implements DsrJbDao {
	private static final Logger log = Logger.getLogger(DsrJbDaoImpl.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * nju.software.ExecutionInterfaces.data.dao.DsrJbDao#getDsrJbsByAjxh(int)
	 */
	@Override
	public List<DsrJbDO> getDsrJbsByAjxh(long ajxh) {
		String hql = "from DsrJbDO where ajxh = " + ajxh;
		@SuppressWarnings("unchecked")
		List<DsrJbDO> res = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDsrJbDO By Hql : " + hql);
		}
		return res.size() == 0 ? null : res;
	}

	@Override
	public int getMaxdsrbhByAjxh(Long ajxh) {
		Object result = getSession().createSQLQuery(
				"select max(DSRBH) from DSR_JB where AJXH = " + ajxh)
				.uniqueResult();
		return result == null ? 0 : (Integer) result;
	}

	@Override
	public List<DsrJbDO> getDsrJbsByAjxh_Ssdw_Dsrlb(long ajxh, String ssdw,
			String dsrlb) {
		String hql = "from DsrJbDO where ajxh = " + ajxh +" and dsrssdw='"+ssdw+"'"+" and dsrlb<>'"+dsrlb+"'";
		@SuppressWarnings("unchecked")
		List<DsrJbDO> res = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDsrJbDO By Hql : " + hql);
		}
		return res==null||res.size() == 0 ? null : res;
		
	}

	@Override
	public DsrJbDO findDsrJbDOByAjxh_dsrjc(long ajxh, String dsrjc) {
		String hql = "from DsrJbDO where ajxh = " + ajxh+" and dsrjc='"+dsrjc+"'";
		@SuppressWarnings("unchecked")
		List<DsrJbDO> res = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDsrJbDO By Hql : " + hql);
		}
		return res.size() == 0 ? null : res.get(0);
	}

}
