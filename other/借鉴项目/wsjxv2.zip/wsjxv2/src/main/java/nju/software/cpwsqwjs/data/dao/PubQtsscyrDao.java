package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.PubQtsscyr;



public interface PubQtsscyrDao {
	public List<PubQtsscyr> getPubQtsscyrsByAjxh(long ajxh);
	
	public void savePubQtsscyr(PubQtsscyr pubQtsscyr);

    public boolean hasPubQtsscyrByAjxh_Xm(long ajxh,String xm);
	
}


