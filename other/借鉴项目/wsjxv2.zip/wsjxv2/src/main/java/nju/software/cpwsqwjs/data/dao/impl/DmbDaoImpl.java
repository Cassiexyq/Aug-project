package nju.software.cpwsqwjs.data.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dataobject.Dmb;
import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.util.StringUtil;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.googlecode.ehcache.annotations.Cacheable;




public class DmbDaoImpl extends HibernateDaoSupport implements DmbDao {
	private static final Logger log = Logger.getLogger(DmbDaoImpl.class);
	
	@SuppressWarnings("unchecked")
	@Override
	@Cacheable(cacheName = "PUB_DMB_CACHE")
	public List<Dmb> getDmbListByLbbh(String lbbh) {
		String hql="from Dmb where lbbh=?";
		try{
			List<Dmb> result =getHibernateTemplate().find(hql,lbbh);
			return result==null?new ArrayList<Dmb>():result;
		}catch(RuntimeException re){
			log.error("getDmbListByLbbh failed with lbbh: "+lbbh);
			return new ArrayList<Dmb>();
		}
	}

    @Override
    @SuppressWarnings("unchecked")
    @Cacheable(cacheName = "PUB_DMB_CACHE")
    public Dmb getDmbByLbbh(String lbbh, String dmbh) {
        String hql = "from Dmb where lbbh = ? and dmbh = ? " ;
        List<Dmb> res = getHibernateTemplate().find(hql,lbbh,dmbh) ;
        for(Dmb dmb :res){
        	System.out.println("dmb="+dmb);
        }
        return res==null||res.isEmpty()?null:res.get(0);
    }
    
    @Override
    @Cacheable(cacheName = "PUB_DMB_CACHE")
    public List<Dmb> getDmbByGjjcAndXxxjc(String gjjc,String xxxjc,String ajxz,String spcx){
        String sql =  "select convert(varchar,xxx.SJXX) from PUB_XTGL_GJ_SJX_GXB gxb , PUB_XTGL_XXXGL xxx "+
                        "where gxb.GJBH = (select GJBH from PUB_XTGL_GJB where GJJC = :gjjc ) "
                        + "and gxb.XXXBH = xxx.XXXBH and xxx.XXXJC = :xxxjc " ; 
        Session session = getSession() ;
        String lbbhs = session.createSQLQuery(sql)
                .setString("gjjc", gjjc)
                .setString("xxxjc", xxxjc)
                .uniqueResult()
                .toString() ;
        List<Dmb> list =  Collections.emptyList() ;
        String lbbh = null ;
        if(!StringUtil.isBlank(lbbhs)&&!StringUtil.equals("-", lbbhs)){
            if(lbbhs.contains(",")){
                //���հ������ʺ����г�������
                String[] arr_lbbhs = lbbhs.split(",") ;
                for (String l : arr_lbbhs) {
                    if(StringUtil.isBlank(lbbh)&&l.startsWith(ajxz+spcx)){
                        lbbh = l.substring(2) ;
                    }
                    if(StringUtil.isBlank(lbbh)&&l.startsWith(ajxz+"*")){
                        lbbh = l.substring(2) ;
                    }
                    if(StringUtil.isBlank(lbbh)&&l.startsWith("*"+ajxz)){
                        lbbh = l.substring(2) ;
                    }
                }
            }else{
                lbbh = lbbhs ;
            }
        }
        if(!StringUtil.isBlank(lbbh)){
            list = this.getDmbListByLbbh(lbbh) ;
        }
        this.releaseSession(session);
        return list ;
    }


    /**
	 * ��������źʹ����Ż�ô�������
	 * 
	 * @param lbbh
	 * @param dmbh
	 * @return
	 */
	public DmbDO findByDmbhandLbbh(String lbbh, String dmbh) {
		String hql = "from DmbDO where lbbh='" + lbbh + "' and dmbh='" + dmbh
				+ "'";
		List<DmbDO> dmbDOs = new ArrayList<DmbDO>();
		dmbDOs = getHibernateTemplate().find(hql);
		return dmbDOs.size() == 0 ? new DmbDO() : dmbDOs.get(0);
	}

    

    @Override
    @SuppressWarnings("unchecked")
    public Dmb getXtqsdmByDmbh(String dmbh) {
        String hql = "from Dmb where lbbh = 'ϵͳȱʡ' and dmbh = ? " ;
        List<Dmb> res = getHibernateTemplate().find(hql,dmbh) ;
        return res==null||res.isEmpty()?null:res.get(0);
    }


}
