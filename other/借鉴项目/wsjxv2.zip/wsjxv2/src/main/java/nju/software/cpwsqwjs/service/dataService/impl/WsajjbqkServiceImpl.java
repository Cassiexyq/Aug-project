package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.WSAjjbqkxsesDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkBgrbcDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkBhrbhDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkBssldDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkBssrbcdDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkBszjdDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkCmssdDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkQssldDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkQszjdDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkZjdDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkmsxzDao;
import nju.software.cpwsqwjs.data.dao.WsAjjbqkxsysDao;
import nju.software.cpwsqwjs.data.dao.WsajjbxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WSAjjbqkxsesDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBgrbcDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBhrbhDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBssldDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBssrbcdDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBszjdDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkCmssdDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkQssldDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkQszjdDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkZjdDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkmsxzDO;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkxsysDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.WsajjbqkService;
import nju.software.cpwsqwjs.service.model.WsajjbqkModel;
import nju.software.cpwsqwjs.util.StringUtil;

public class WsajjbqkServiceImpl implements WsajjbqkService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static WsAjjbqkmsxzDao wsAjjbqkmsxzDao;
	private static WsAjjbqkxsysDao wsAjjbqkxsysDao;
	private static WSAjjbqkxsesDao wsAjjbqkxsesDao;
	private static WsAjjbqkQszjdDao wsAjjbqkQszjdDao;
	private static WsAjjbqkQssldDao wsAjjbqkQssldDao;
	private static WsAjjbqkBssrbcdDao wsAjjbqkBssrbcdDao;
	private static WsAjjbqkBssldDao wsAjjbqkBssldDao;
	private static WsAjjbqkBszjdDao wsAjjbqkBszjdDao;
	private static WsAjjbqkCmssdDao wsAjjbqkCmssdDao;
	private static WsAjjbqkZjdDao wsAjjbqkZjdDao;
	private static WsAjjbqkBgrbcDao wsAjjbqkBgrbcDao;
	 
	private static WsAjjbqkBhrbhDao wsAjjbqkBhrbhDao;
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsAjjbqkmsxzDao = (WsAjjbqkmsxzDao) appContext.getBean("wsAjjbqkmsxzDao");
		wsAjjbqkxsysDao = (WsAjjbqkxsysDao)appContext.getBean("wsAjjbqkxsysDao");
		wsAjjbqkxsesDao = (WSAjjbqkxsesDao)appContext.getBean("wsAjjbqkxsesDao");
		wsAjjbqkQszjdDao = (WsAjjbqkQszjdDao)appContext.getBean("wsAjjbqkQszjdDao");
		wsAjjbqkQssldDao = (WsAjjbqkQssldDao)appContext.getBean("wsAjjbqkQssldDao");
		wsAjjbqkBssrbcdDao =(WsAjjbqkBssrbcdDao)appContext.getBean("wsAjjbqkBssrbcdDao");
		wsAjjbqkBssldDao = (WsAjjbqkBssldDao)appContext.getBean("wsAjjbqkBssldDao");
		wsAjjbqkBszjdDao = (WsAjjbqkBszjdDao)appContext.getBean("wsAjjbqkBszjdDao");
		wsAjjbqkCmssdDao = (WsAjjbqkCmssdDao)appContext.getBean("wsAjjbqkCmssdDao");
		wsAjjbqkZjdDao = (WsAjjbqkZjdDao)appContext.getBean("wsAjjbqkZjdDao");
		wsAjjbqkBgrbcDao = (WsAjjbqkBgrbcDao)appContext.getBean("wsAjjbqkBgrbcDao");
		wsAjjbqkBhrbhDao = (WsAjjbqkBhrbhDao)appContext.getBean("wsAjjbqkBhrbhDao");
	}
	@Override
	public void saveMsxzAjjbqk(int ajxh, WsajjbqkModel ajjbqkModel) {
		// TODO Auto-generated method stub
		WsAjjbqkmsxzDO ajjbqmDo = new WsAjjbqkmsxzDO(ajjbqkModel);
		ajjbqmDo.setAjxh(ajxh);
		wsAjjbqkmsxzDao.save(ajjbqmDo);
		saveManyToOne(ajxh, ajjbqkModel);
	}

	@Override
	public void saveXsysAjjbqk(int ajxh, WsajjbqkModel ajjbqkModel) {
		// TODO Auto-generated method stub
		WsAjjbqkxsysDO ajjbqkDo = new WsAjjbqkxsysDO(ajjbqkModel);
		ajjbqkDo.setAjxh(ajxh);
		wsAjjbqkxsysDao.save(ajjbqkDo);
		saveManyToOne(ajxh, ajjbqkModel);
	}

	@Override
	public void saveXsesAjjbqk(int ajxh, WsajjbqkModel ajjbqkModel) {
		// TODO Auto-generated method stub
		WSAjjbqkxsesDO ajjbqkDo = new WSAjjbqkxsesDO(ajjbqkModel);
		ajjbqkDo.setAjxh(ajxh);
		wsAjjbqkxsesDao.save(ajjbqkDo);
		saveManyToOne(ajxh, ajjbqkModel);
	}

	@Override
	public void saveManyToOne(int ajxh, WsajjbqkModel model) {
		// TODO Auto-generated method stub
		//ǰ��֤�ݶ� ��������
		if(model.getQszjd()!=null && !model.getQszjd().isEmpty()){
			int maxbh = wsAjjbqkQszjdDao.getMaxbh()+1;
			for(String s:model.getQszjd()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkQszjdDO zjdDo = new WsAjjbqkQszjdDO(ajxh, maxbh, s);
					wsAjjbqkQszjdDao.save(zjdDo);
					maxbh++;
				}
			}
		}
	   //ǰ�������� ���¶��� ��������	 
		if(model.getQssld()!=null && !model.getQssld().isEmpty()){
			int maxbh = wsAjjbqkQssldDao.getMaxbh()+1;
			for(String s:model.getQssld()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkQssldDO sldDo = new WsAjjbqkQssldDO(ajxh, maxbh, s);
					wsAjjbqkQssldDao.save(sldDo);
					maxbh++;
				}
			}
		}
//		�������˱�ƶ� ���¶��� ��������
		if(model.getBssrbcd()!=null && !model.getBssrbcd().isEmpty()){
			int maxbh = wsAjjbqkBssrbcdDao.getMaxbh()+1;
			for(String s:model.getBssrbcd()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkBssrbcdDO wsdo = new WsAjjbqkBssrbcdDO(ajxh, maxbh, s);
					wsAjjbqkBssrbcdDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		���������� ���¶��� �������� ����һ��
		if(model.getBssld()!=null && !model.getBssld().isEmpty()){
			int maxbh = wsAjjbqkBssldDao.getMaxbh()+1;
			for(String s:model.getBssld()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkBssldDO wsdo = new WsAjjbqkBssldDO(ajxh, maxbh, s);
					wsAjjbqkBssldDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		����֤�ݶ� ��������
		if(model.getBszjd()!=null && !model.getBszjd().isEmpty()){
			int maxbh = wsAjjbqkBszjdDao.getMaxbh()+1;
			for(String s:model.getBszjd()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkBszjdDO wsdo = new WsAjjbqkBszjdDO(ajxh, maxbh, s);
					wsAjjbqkBszjdDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		 ������ʵ�� ����һ�� ����һ��
		if(model.getCmssd()!=null && !model.getCmssd().isEmpty()){
			int maxbh = wsAjjbqkCmssdDao.getMaxbh()+1;
			for(String s:model.getCmssd()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkCmssdDO wsdo = new WsAjjbqkCmssdDO(ajxh, maxbh, s);
					wsAjjbqkCmssdDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		 ֤�ݶ� ����һ�� ����һ�� ��������
		if(model.getZjd()!=null && !model.getZjd().isEmpty()){
			int maxbh = wsAjjbqkZjdDao.getMaxbh()+1;
			for(String s:model.getZjd()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkZjdDO wsdo = new WsAjjbqkZjdDO(ajxh, maxbh, s);
					wsAjjbqkZjdDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		�����˱�� ����һ��
		if(model.getBgrbc()!=null && !model.getBgrbc().isEmpty()){
			int maxbh = wsAjjbqkBgrbcDao.getMaxbh()+1;
			for(String s:model.getBgrbc()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkBgrbcDO wsdo = new WsAjjbqkBgrbcDO(ajxh, maxbh, s);
					wsAjjbqkBgrbcDao.save(wsdo);
					maxbh++;
				}
			}
		}
//		�绤�˱绤 ����һ��
		if(model.getBhrbh()!=null && !model.getBhrbh().isEmpty()){
			int maxbh = wsAjjbqkBhrbhDao.getMaxbh()+1;
			for(String s:model.getBhrbh()){
				if(!StringUtil.isBlank(s)){
					WsAjjbqkBhrbhDO wsdo = new WsAjjbqkBhrbhDO(ajxh, maxbh, s);
					wsAjjbqkBhrbhDao.save(wsdo);
					maxbh++;
				}
			}
		}
		
	}
	
	

}
