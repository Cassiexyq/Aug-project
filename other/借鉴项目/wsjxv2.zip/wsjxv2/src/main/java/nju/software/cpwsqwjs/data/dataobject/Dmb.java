package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * �����
 */
@Entity
@Table(name = "PUB_DMB")
@IdClass(DmbId.class)
public class Dmb implements Serializable {

	private static final long serialVersionUID = 3487352732449625181L;

	/**
	 * �����
	 */
	private String lbbh;
	/**
	 * ������
	 */
	private String dmbh;
	/**
	 * ��������
	 */
	private String dmms;
	/**
	 * ��ش���
	 */
	private String xgdm;
	/**
	 * ��ע
	 */
	private String bz;
	
	private String xgdm2;

	public Dmb() {
	}

	@Id
	@Column(name = "LBBH", length = 20, nullable = false)
	public String getLbbh() {
		return lbbh;
	}

	public void setLbbh(String lbbh) {
		this.lbbh = lbbh;
	}

	@Id
	@Column(name = "DMBH", length = 20, nullable = false)
	public String getDmbh() {
		return dmbh;
	}

	public void setDmbh(String dmbh) {
		this.dmbh = dmbh;
	}

	@Column(name = "DMMS", length = 250, nullable = false)
	public String getDmms() {
		return dmms;
	}

	public void setDmms(String dmms) {
		this.dmms = dmms;
	}

	@Column(name = "XGDM", length = 250)
	public String getXgdm() {
		return xgdm;
	}

	public void setXgdm(String xgdm) {
		this.xgdm = xgdm;
	}

	@Column(name = "BZ", length = 250)
	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	@Column(name = "XGDM2")
	public String getXgdm2() {
		return xgdm2;
	}

	public void setXgdm2(String xgdm2) {
		this.xgdm2 = xgdm2;
	}

}
