package nju.software.cpwsqwjs.data.dataobject;

import java.util.List;

import nju.software.cpwsqwjs.service.model.QkqkModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.StringUtil;

import javax.persistence.*;

/**
 * WsDsrQkDO entity. @author MyEclipse Persistence Tools
 * ������ǰ��
 */
@Entity
@Table(name = "WS_DSR_QK")
@IdClass(WsDsrQkDOId.class)
public class WsDsrQkDO implements java.io.Serializable {
	/**
	 * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private Integer ajxh;//�������
	private Integer qkbh;//ǰ�Ʊ��
	private Integer dsrbh;//�����˱��
	private String qklb;//ǰ�����
    private String cftime;//����ʱ��
    private String cfyy;//����ԭ��
    private String cfdw;//������λ
    private String cfxs;//������ʽ
    private String cfxq;//��������
    private String xmsfsj;//�����ͷ�����

	/** default constructor */
	public WsDsrQkDO() {
	}

	public WsDsrQkDO(Integer ajxh, Integer qkbh, Integer dsrbh, String qklb,
			String cftime, String cfyy, String cfdw, String cfxs, String cfxq,
			String xmsfsj) {
		super();
		this.ajxh = ajxh;
		this.qkbh = qkbh;
		this.dsrbh = dsrbh;
		this.qklb = qklb;
		this.cftime = cftime;
		this.cfyy = cfyy;
		this.cfdw = cfdw;
		this.cfxs = cfxs;
		this.cfxq = cfxq;
		this.xmsfsj = xmsfsj;
	}


	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "QKBH", nullable = false)
	public Integer getQkbh() {
		return qkbh;
	}

	public void setQkbh(Integer qkbh) {
		this.qkbh = qkbh;
	}
	@Column(name = "DSRBH")
	public Integer getDsrbh() {
		return this.dsrbh;
	}

	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}
	@Column(name = "QKLB",length = 50)
	public String getQklb() {
		return qklb;
	}
	public void setQklb(String qklb) {
		this.qklb = qklb;
	}

	@Column(name = "CFTIME",length = 50)
	public String getCftime() {
		return cftime;
	}

	public void setCftime(String cftime) {
		this.cftime = cftime;
	}

	@Column(name = "CFYY",length = 255)
	public String getCfyy() {
		return cfyy;
	}



	public void setCfyy(String cfyy) {
		this.cfyy = cfyy;
	}


	@Column(name = "SFDW",length = 200)
	public String getCfdw() {
		return cfdw;
	}



	public void setCfdw(String cfdw) {
		this.cfdw = cfdw;
	}


	@Column(name = "CFXS",length = 100)
	public String getCfxs() {
		return cfxs;
	}



	public void setCfxs(String cfxs) {
		this.cfxs = cfxs;
	}


	@Column(name = "CFRQ",length = 200)
	public String getCfxq() {
		return cfxq;
	}

	public void setCfxq(String cfxq) {
		this.cfxq = cfxq;
	}


	@Column(name = "XMSFSJ",length = 200)
	public String getXmsfsj() {
		return xmsfsj;
	}

	public void setXmsfsj(String xmsfsj) {
		this.xmsfsj = xmsfsj;
	}

	public WsDsrQkDO(QkqkModel qkqkModel){
         if (qkqkModel.getQklb()!=null&&!qkqkModel.getQklb().isEmpty()){
             this.qklb = qkqkModel.getQklb();
         }
         if (qkqkModel.getCfTime()!=null&&!qkqkModel.getCfTime().isEmpty()){
             this.cftime = qkqkModel.getCfTime();
         }
         if (qkqkModel.getCfxs()!=null&&!qkqkModel.getCfxs().isEmpty()){
             this.cfxs = qkqkModel.getCfxs();
         }
         if (qkqkModel.getCfdw()!=null&&!qkqkModel.getCfdw().isEmpty()){
             this.cfdw = qkqkModel.getCfdw();
         }
         if (qkqkModel.getXmsfTime()!=null&&!qkqkModel.getXmsfTime().isEmpty()){
             this.xmsfsj = qkqkModel.getXmsfTime();
         }
         if (qkqkModel.getCfReason()!=null&&!qkqkModel.getCfReason().isEmpty()){
             String qkReason_str="";
             for (String qkReason:qkqkModel.getCfReason()){
                 qkReason_str=qkReason_str+qkReason+";";
             }
             if (qkReason_str.endsWith(";")){
                 qkReason_str=qkReason_str.substring(0,qkReason_str.length()-1);
             }
             if (!StringUtil.isBlank(qkReason_str)){
                 this.cfyy = qkReason_str;
             }
         }
         if (qkqkModel.getCfxq()!=null&&!qkqkModel.getCfxq().isEmpty()){
             String cfxq_str="";
             for (String cfxq:qkqkModel.getCfxq()){
                 cfxq_str=cfxq_str+cfxq+";";
             }
             if (cfxq_str.endsWith(";")){
                 cfxq_str=cfxq_str.substring(0,cfxq_str.length()-1);
             }
             if (!StringUtil.isBlank(cfxq_str)){
                 this.cfxq = cfxq_str;
             }
         }
	}

}