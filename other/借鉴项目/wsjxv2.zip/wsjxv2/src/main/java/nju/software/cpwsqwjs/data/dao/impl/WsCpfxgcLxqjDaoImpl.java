package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.WsCpfxgcLxqjDao;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcLxqjDO;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcLxqjDOId;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class WsCpfxgcLxqjDaoImpl extends HibernateDaoSupport  implements  WsCpfxgcLxqjDao {

	public static final String LXQJZL="lxqjzl";//�����������
	public static final String XGR="xgr";//�����
	public static final String QJ="qj";//���
	
	@Override
	public WsCpfxgcLxqjDO findById(WsCpfxgcLxqjDOId id) {
		// TODO Auto-generated method stub
		try {
			WsCpfxgcLxqjDO instance = (WsCpfxgcLxqjDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsCpfxgcLxqjDO", id);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public int getMaxLxqjbhByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(lxqjbh) from WsCpfxgcLxqjDO where ajxh="+ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null) {
			maxbh =  (int) query.uniqueResult();
		}
		this.releaseSession(s);
		return  maxbh;
	}

	@Override
	public WsCpfxgcLxqjDO getCpfxgcLxqj(int ajxh, int lxqjbh) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int save(WsCpfxgcLxqjDO lxqjDO) {
		// TODO Auto-generated method stub
		try {
			getHibernateTemplate().saveOrUpdate(lxqjDO);
			return lxqjDO.getLxqjbh();
		} catch (RuntimeException re) {
			throw re;
		}
	}
	
	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsCpfxgcLxqjDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

}
