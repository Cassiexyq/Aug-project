package nju.software.cpwsqwjs.service.dataService.impl;

import nju.software.cpwsqwjs.data.dao.WsDsrDao;
import nju.software.cpwsqwjs.data.dao.WsDsrQkDao;
import nju.software.cpwsqwjs.data.dao.WsDsrQzcsDao;
import nju.software.cpwsqwjs.data.dataobject.WsDsrDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQkDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQzcsDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.WsdsrService;
import nju.software.cpwsqwjs.service.datamodel.WsdsrModel;
import nju.software.cpwsqwjs.service.model.QkqkModel;
import nju.software.cpwsqwjs.service.model.QzcsModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.MyBeanUtils;
import nju.software.cpwsqwjs.util.StringUtil;

import org.apache.bcel.generic.ARRAYLENGTH;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhx on 2016/12/29.
 */
public class WsdsrServiceImpl implements WsdsrService{

    private static ApplicationContext appContext=new org.springframework.context.support.ClassPathXmlApplicationContext(
            "applicationContext.xml","applicationContextDataSource.xml");

    private static WsDsrDao wsDsrDao;
    private static WsDsrQzcsDao wsDsrQzcsDao;
    private static WsDsrQkDao wsDsrQkDao;

    static{
//        DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
        wsDsrDao = (WsDsrDao)appContext.getBean("wsDsrDao");
        wsDsrQzcsDao = (WsDsrQzcsDao)appContext.getBean("wsDsrQzcsDao");
        wsDsrQkDao = (WsDsrQkDao)appContext.getBean("wsDsrQkDao");
    }

    @Override
    public WsdsrModel getDsrModelByDsrbh(int dsrbh) {
        List<WsDsrDO> dsrList=wsDsrDao.findByDsrbh(dsrbh);
        if (dsrList!=null&&dsrList.size()>0){
            WsDsrDO dsr=dsrList.get(0);
            WsdsrModel dsrModel=new WsdsrModel();
            try {
                MyBeanUtils.copyBean2Bean(dsrModel,dsr);
            }catch (Exception e){
                e.printStackTrace();
            }
            return dsrModel;
        }else {
            return null;
        }

    }

    @Override
    public int addDsr(WssscyrModel wssscyrModel,int ajxh) {
        WsDsrDO wsDsrDO = new WsDsrDO(wssscyrModel);
        int DsrbhMax=wsDsrDao.getMaxDsrbhByAjxh(ajxh);
        wsDsrDO.setAjxh(ajxh);
        //ǿ�ƴ�ʩ
        int QzcsbhMax=wsDsrQzcsDao.getMaxQzcsbhByAjxh(ajxh);
        if (wssscyrModel.getQzcsList()!=null&&!wssscyrModel.getQzcsList().isEmpty()){
            saveQzcs(wssscyrModel.getQzcsList(),ajxh,DsrbhMax,QzcsbhMax);
        }
        //ǰ�����
        int QkbhMax=wsDsrQkDao.getMaxQkbhByAjxh(ajxh);
        if (wssscyrModel.getQkqkList()!=null&&!wssscyrModel.getQkqkList().isEmpty()){
            saveQkqk(wssscyrModel.getQkqkList(),ajxh,DsrbhMax,QkbhMax);
        }
        wsDsrDO.setDsrbh(DsrbhMax+1);
        return wsDsrDao.addDsrDO(wsDsrDO);
    }

    public void saveQzcs(List<QzcsModel> qzcsModellist, int ajxh, int dsrbhMax,int qzcsbhMax) {
        for (QzcsModel qzcsModel:qzcsModellist){
            WsDsrQzcsDO wsDsrQzcsDO = new WsDsrQzcsDO();
            wsDsrQzcsDO.setAjxh(ajxh);
            wsDsrQzcsDO.setDsrbh(dsrbhMax);
            wsDsrQzcsDO.setQzcsbh(++qzcsbhMax);
            if (qzcsModel.getQzcsCategory()!=null&&!qzcsModel.getQzcsCategory().isEmpty()){
                wsDsrQzcsDO.setZl(qzcsModel.getQzcsCategory());
            }
            if (qzcsModel.getQzcsTime()!=null&&!qzcsModel.getQzcsTime().isEmpty()){
                wsDsrQzcsDO.setZxsj(qzcsModel.getQzcsTime());
            }
            if (qzcsModel.getQzcsDw()!=null&&!qzcsModel.getQzcsDw().isEmpty()){
                wsDsrQzcsDO.setDw(qzcsModel.getQzcsDw());
            }
            if (qzcsModel.getQscsReason()!=null&&!qzcsModel.getQscsReason().isEmpty()){
                String qzcsReason_str="";
                for (String qzcsReason:qzcsModel.getQscsReason()){
                    qzcsReason_str=qzcsReason_str+qzcsReason+";";
                }
                if (qzcsReason_str.endsWith(";")){
                    qzcsReason_str=qzcsReason_str.substring(0,qzcsReason_str.length()-1);
                }
                if (!StringUtil.isBlank(qzcsReason_str)){
                    wsDsrQzcsDO.setYy(qzcsReason_str);
                }
            }
            wsDsrQzcsDao.save(wsDsrQzcsDO);

        }
    }

    public void saveQkqk(List<QkqkModel> qzqkModellist, int ajxh, int dsrbhMax, int qkbhMax) {
        for (QkqkModel qkqkModel:qzqkModellist){
            WsDsrQkDO wsDsrQkDO = new WsDsrQkDO();
            wsDsrQkDO.setAjxh(ajxh);
            wsDsrQkDO.setDsrbh(dsrbhMax);
            wsDsrQkDO.setQkbh(++qkbhMax);
            if (qkqkModel.getQklb()!=null&&!qkqkModel.getQklb().isEmpty()){
                wsDsrQkDO.setQklb(qkqkModel.getQklb());
            }
            if (qkqkModel.getCfTime()!=null&&!qkqkModel.getCfTime().isEmpty()){
                wsDsrQkDO.setCftime(qkqkModel.getCfTime());
            }
            if (qkqkModel.getCfxs()!=null&&!qkqkModel.getCfxs().isEmpty()){
                wsDsrQkDO.setCfxs(qkqkModel.getCfxs());
            }
            if (qkqkModel.getCfdw()!=null&&!qkqkModel.getCfdw().isEmpty()){
                wsDsrQkDO.setCfdw(qkqkModel.getCfdw());
            }
            if (qkqkModel.getXmsfTime()!=null&&!qkqkModel.getXmsfTime().isEmpty()){
                wsDsrQkDO.setXmsfsj(qkqkModel.getXmsfTime());
            }
            if (qkqkModel.getCfReason()!=null&&!qkqkModel.getCfReason().isEmpty()){
                String qkReason_str="";
                for (String qkReason:qkqkModel.getCfReason()){
                    qkReason_str=qkReason_str+qkReason+";";
                }
                if (qkReason_str.endsWith(";")){
                    qkReason_str=qkReason_str.substring(0,qkReason_str.length()-1);
                }
                if (!StringUtil.isBlank(qkReason_str)){
                    wsDsrQkDO.setCfyy(qkReason_str);
                }
            }
            if (qkqkModel.getCfxq()!=null&&!qkqkModel.getCfxq().isEmpty()){
                String cfxq_str="";
                for (String cfxq:qkqkModel.getCfxq()){
                    cfxq_str=cfxq_str+cfxq+";";
                }
                if (cfxq_str.endsWith(";")){
                    cfxq_str=cfxq_str.substring(0,cfxq_str.length()-1);
                }
                if (!StringUtil.isBlank(cfxq_str)){
                    wsDsrQkDO.setCfyy(cfxq_str);
                }
            }
            wsDsrQkDao.save(wsDsrQkDO);
        }
    }


    @Override
    public void fromSscyrModel(WsDsrDO wsDsrDO, WssscyrModel wssscyrModel) {

    }

	@Override
	public void addSscyr(List<WssscyrModel> wssscyrModellist, int ajxh) {
		// TODO Auto-generated method stub
		if(wssscyrModellist!=null && wssscyrModellist.size()>0){
			int dsrbh = wsDsrDao.getMaxDsrbhByAjxh(ajxh)+1;
			for(WssscyrModel sscyr:wssscyrModellist){
				if(!StringUtil.isBlank(sscyr.getSscyr())){
					addDsr(sscyr, ajxh, dsrbh);
					dsrbh++;
				}
			}
		}
	}

	@Override
	public int addDsr(WssscyrModel wssscyrModel, int ajxh, int dsrbh) {
		// TODO Auto-generated method stub
		WsDsrDO wsDsrDO = new WsDsrDO(wssscyrModel);
        wsDsrDO.setAjxh(ajxh);
        //ǿ�ƴ�ʩ
        int QzcsbhMax=wsDsrQzcsDao.getMaxQzcsbhByAjxh(ajxh);
        if (wssscyrModel.getQzcsList()!=null&&!wssscyrModel.getQzcsList().isEmpty()){
            saveQzcs(wssscyrModel.getQzcsList(),ajxh,dsrbh,QzcsbhMax);
        }
        //ǰ�����
        int QkbhMax=wsDsrQkDao.getMaxQkbhByAjxh(ajxh);
        if (wssscyrModel.getQkqkList()!=null&&!wssscyrModel.getQkqkList().isEmpty()){
            saveQkqk(wssscyrModel.getQkqkList(),ajxh,dsrbh,QkbhMax);
        }
        wsDsrDO.setDsrbh(dsrbh);
        return wsDsrDao.addDsrDO(wsDsrDO);
	}

	@Override
	public void addSscyrList(List<WssscyrModel> wssscyrModellist, int ajxh) {
		// TODO Auto-generated method stub
		if(wssscyrModellist!=null && wssscyrModellist.size()>0){
			List<WsDsrDO> doList = new ArrayList<WsDsrDO>();
			for(WssscyrModel model:wssscyrModellist){
				WsDsrDO wsDsrDO = new WsDsrDO(model);
		        wsDsrDO.setAjxh(ajxh);
		        doList.add(wsDsrDO);
			}
		}
		
	}

	@Override
	public void addSscyrListBatch(List<WssscyrModel> wssscyrModellist, int ajxh) {
		// TODO Auto-generated method stub
		 int QzcsbhMax=wsDsrQzcsDao.getMaxQzcsbhByAjxh(ajxh)+1;
		 int QkbhMax=wsDsrQkDao.getMaxQkbhByAjxh(ajxh)+1;
		 wsDsrDao.addDsrBatch(wssscyrModellist, ajxh, QkbhMax, QzcsbhMax);
	}
}
