package nju.software.cpwsqwjs.data.dataobject;

import java.util.List;

import nju.software.cpwsqwjs.service.model.QzcsModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.StringUtil;

import javax.persistence.*;

/**
 * WsDsrQkDO entity. @author MyEclipse Persistence Tools
 * ������ǿ�ƴ�ʩ
 */
@Entity
@Table(name = "WS_DSR_QZCS")
@IdClass(WsDsrQzcsDOId.class)
public class WsDsrQzcsDO implements java.io.Serializable {
	/**
	 * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private Integer ajxh;//�������
	private Integer qzcsbh;//ǿ�ƴ�ʩ���
	private Integer dsrbh;//�����˱��
	private String zl;//ǿ�ƴ�ʩ����
    private String zxsj;//ǿ�ƴ�ʩִ��ʱ��
    private String dw;//ǿ�ƴ�ʩ��λ
    private String yy;//ǿ�ƴ�ʩԭ��
    private String sfdb;//�Ƿ����
    private String dbrq;//��������

	/** default constructor */
	public WsDsrQzcsDO() {
	}


	public WsDsrQzcsDO(Integer ajxh, Integer qzcsbh, Integer dsrbh, String zl,
			String zxsj, String dw, String yy, String sfdb, String dbrq) {
		super();
		this.ajxh = ajxh;
		this.qzcsbh = qzcsbh;
		this.dsrbh = dsrbh;
		this.zl = zl;
		this.zxsj = zxsj;
		this.dw = dw;
		this.yy = yy;
		this.sfdb = sfdb;
		this.dbrq = dbrq;
	}




	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "QZCSBH", nullable = false)
	public Integer getQzcsbh() {
		return qzcsbh;
	}


	public void setQzcsbh(Integer qzcsbh) {
		this.qzcsbh = qzcsbh;
	}

	@Column(name = "DSRBH" )
	public Integer getDsrbh() {
		return dsrbh;
	}


	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}

	@Column(name = "ZL" ,length=200)
	public String getZl() {
		return zl;
	}


	public void setZl(String zl) {
		this.zl = zl;
	}

	@Column(name = "ZXSJ" ,length=50)
	public String getZxsj() {
		return zxsj;
	}


	public void setZxsj(String zxsj) {
		this.zxsj = zxsj;
	}

	@Column(name = "DW" ,length=100)
	public String getDw() {
		return dw;
	}


	public void setDw(String dw) {
		this.dw = dw;
	}

	@Column(name = "YY" ,length=200)
	public String getYy() {
		return yy;
	}


	public void setYy(String yy) {
		this.yy = yy;
	}

	@Column(name = "SFDB" ,length=10)
	public String getSfdb() {
		return sfdb;
	}


	public void setSfdb(String sfdb) {
		this.sfdb = sfdb;
	}

	@Column(name = "DBRQ" ,length=50)
	public String getDbrq() {
		return dbrq;
	}


	public void setDbrq(String dbrq) {
		this.dbrq = dbrq;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public WsDsrQzcsDO(QzcsModel qzcsModel){
          if (qzcsModel.getQzcsCategory()!=null&&!qzcsModel.getQzcsCategory().isEmpty()){
             this.zl =  qzcsModel.getQzcsCategory() ;
          }
          if (qzcsModel.getQzcsTime()!=null&&!qzcsModel.getQzcsTime().isEmpty()){
              this.zxsj = qzcsModel.getQzcsTime();
          }
          if (qzcsModel.getQzcsDw()!=null&&!qzcsModel.getQzcsDw().isEmpty()){
              this.dw = qzcsModel.getQzcsDw();
          }
          if (qzcsModel.getQscsReason()!=null&&!qzcsModel.getQscsReason().isEmpty()){
              String qzcsReason_str="";
              for (String qzcsReason:qzcsModel.getQscsReason()){
                  qzcsReason_str=qzcsReason_str+qzcsReason+";";
              }
              if (qzcsReason_str.endsWith(";")){
                  qzcsReason_str=qzcsReason_str.substring(0,qzcsReason_str.length()-1);
              }
              if (!StringUtil.isBlank(qzcsReason_str)){
                  this.yy = qzcsReason_str;
              }
          }
	}
}