package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsAjjbqkZjdDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkZjdDO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by mdw on 2017/1/5.
 */
public class WsAjjbqkZjdDaoImpl extends HibernateDaoSupport implements WsAjjbqkZjdDao {
    private static final Logger log = LoggerFactory.getLogger(WsAjjbqkZjdDaoImpl.class);
    @Override
    public WsAjjbqkZjdDO getByAjxh(int ajxh) {
        List<WsAjjbqkZjdDO>list = findByProperty("AJXH",ajxh);
        if(list==null)
            return null;
        else if(list.size()==0)
            return null;

        return list.get(0);
    }
    public List findByProperty(String propertyName, Object value) {
        log.debug("finding WsAjjbqkZjdDO with property: " + propertyName
                + ", value: " + value);
        try {
            String queryString = "from WsAjjbqkZjdDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            log.error("find by property name failed", re);
            throw re;
        }
    }

    @Override
    public void save(WsAjjbqkZjdDO wsAjjbqkZjdDO) {
        log.debug("saving wsAjjbqkZjdDO");
        try {
            getHibernateTemplate().saveOrUpdate(wsAjjbqkZjdDO);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }

    }
	@Override
	public int getMaxbh() {
		// TODO Auto-generated method stub
		String hql = "select max(bh) from WsAjjbqkZjdDO";

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxAjxh = 0;
		if (query.uniqueResult() != null)
			maxAjxh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxAjxh;
	}
}
