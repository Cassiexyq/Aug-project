package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;
import org.apache.log4j.Logger;

import nju.software.cpwsqwjs.data.dao.BaseHibernateDAO;
import nju.software.cpwsqwjs.data.dao.XzwsssjlDao;
import nju.software.cpwsqwjs.data.dataobject.XzwsssjlDO;

public class XzwsssjlDaoImpl extends BaseHibernateDAO implements XzwsssjlDao {
	private static final Logger log = Logger.getLogger(XzwsssjlDaoImpl.class);
	@Override
	public List<XzwsssjlDO> getXzwsssjlByAjxh(int ajxh) {
		String hql = "from XzwsssjlDO where ajxh ="+ajxh;
		@SuppressWarnings("unchecked")
		List<XzwsssjlDO> res = this.getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getXzwsssjlDO By Hql : "+ hql);
		}
		if(res==null||res.size()==0)
			return null;
		return res;
	}

	@Override
	public void updateXzwsssjl(XzwsssjlDO xzDO) {
		
		try{
			getHibernateTemplate().update(xzDO);
		}
		catch (Exception e) {
		   e.printStackTrace();
		}
		
	}

	@Override
	public void saveXzwsssjl(XzwsssjlDO xzDO) {
		try{
			getHibernateTemplate().save(xzDO);
		}
		catch (Exception e) {
		   e.printStackTrace();
		}
		
	}

	@Override
	public void saveorupdateXzwsssjl(XzwsssjlDO xzDO) {
		try{
			getHibernateTemplate().saveOrUpdate(xzDO);
		}
		catch (Exception e) {
		   e.printStackTrace();
		}
	}
}

