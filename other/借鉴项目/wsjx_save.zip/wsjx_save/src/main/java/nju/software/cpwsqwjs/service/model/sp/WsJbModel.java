package nju.software.cpwsqwjs.service.model.sp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.util.StringUtil;




public class WsJbModel {
    private Integer ajxh;
    private Integer wsjbbh;
    private String wslb;//�������
    private String wsmc;//��������
    private String zfj;
    private Integer wslbbh;
    private Integer wsbh;
    private Integer wsys;
    private String wsjj;
    private String zzh;
    private Date scrq;
    private String wswjm;
    private String wsah;
    private String wszt;
    private byte[] wsnr;
    private String sjjzFlag;
    private String wsurl;
    private String sfjaws;
    
    public WsJbModel() {
		super();
	}

	public WsJbModel(WsJbDO wsJbDO)
    {
		this.ajxh = wsJbDO.getAjxh();
		this.wsjbbh = wsJbDO.getWsjbbh();
		this.wslb = wsJbDO.getWslb();
		this.wsmc = wsJbDO.getWsmc();
		this.zfj = wsJbDO.getZfj();
		this.wslbbh = wsJbDO.getWslbbh();
		this.wsbh = wsJbDO.getWsbh();
		this.wsys = wsJbDO.getWsys();
		this.wsjj = wsJbDO.getWsjj();
		this.zzh = wsJbDO.getZzh();
		this.scrq = wsJbDO.getScrq();
		this.wswjm = wsJbDO.getWswjm();
		this.wsah = wsJbDO.getWsah();
		this.wszt = wsJbDO.getWszt();
		this.wsnr = wsJbDO.getWsnr();
		this.sjjzFlag = wsJbDO.getSjjzFlag();
		if (StringUtil.isBlank(wsJbDO.getWsurl())) {
			this.wsurl= "N";
		}else {
			this.wsurl=wsJbDO.getWsurl();
		}
		this.sfjaws = wsJbDO.getSfjaws();
    }
    
    public static List<WsJbModel> convertDOsToModels(List<WsJbDO> wsJbDOs)
    {
    	List<WsJbModel> wsJbModels = new ArrayList<WsJbModel>();
    	for (WsJbDO wsJbDO : wsJbDOs) {
    		wsJbModels.add(new WsJbModel(wsJbDO));
		}
    	return wsJbModels;
    }
    
	public WsJbModel(Integer ajxh, Integer wsjbbh, String wslb, String wsmc,
			String zfj, Integer wslbbh, Integer wsbh, Integer wsys,
			String wsjj, String zzh, Date scrq, String wswjm, String wsah,
			String wszt, byte[] wsnr, String sjjzFlag,String sfjaws) {
		super();
		this.ajxh = ajxh;
		this.wsjbbh = wsjbbh;
		this.wslb = wslb;
		this.wsmc = wsmc;
		this.zfj = zfj;
		this.wslbbh = wslbbh;
		this.wsbh = wsbh;
		this.wsys = wsys;
		this.wsjj = wsjj;
		this.zzh = zzh;
		this.scrq = scrq;
		this.wswjm = wswjm;
		this.wsah = wsah;
		this.wszt = wszt;
		this.wsnr = wsnr;
		this.sjjzFlag = sjjzFlag;
		this.sfjaws = sfjaws;
	}
	public Integer getAjxh() {
		return ajxh;
	}
	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	public Integer getWsjbbh() {
		return wsjbbh;
	}
	public void setWsjbbh(Integer wsjbbh) {
		this.wsjbbh = wsjbbh;
	}
	public String getWslb() {
		return wslb;
	}
	public void setWslb(String wslb) {
		this.wslb = wslb;
	}
	public String getWsmc() {
		return wsmc;
	}
	public void setWsmc(String wsmc) {
		this.wsmc = wsmc;
	}
	public String getZfj() {
		return zfj;
	}
	public void setZfj(String zfj) {
		this.zfj = zfj;
	}
	public Integer getWslbbh() {
		return wslbbh;
	}
	public void setWslbbh(Integer wslbbh) {
		this.wslbbh = wslbbh;
	}
	public Integer getWsbh() {
		return wsbh;
	}
	public void setWsbh(Integer wsbh) {
		this.wsbh = wsbh;
	}
	public Integer getWsys() {
		return wsys;
	}
	public void setWsys(Integer wsys) {
		this.wsys = wsys;
	}
	public String getWsjj() {
		return wsjj;
	}
	public void setWsjj(String wsjj) {
		this.wsjj = wsjj;
	}
	public String getZzh() {
		return zzh;
	}
	public void setZzh(String zzh) {
		this.zzh = zzh;
	}
	public Date getScrq() {
		return scrq;
	}
	public void setScrq(Date scrq) {
		this.scrq = scrq;
	}
	public String getWswjm() {
		return wswjm;
	}
	public void setWswjm(String wswjm) {
		this.wswjm = wswjm;
	}
	public String getWsah() {
		return wsah;
	}
	public void setWsah(String wsah) {
		this.wsah = wsah;
	}
	public String getWszt() {
		return wszt;
	}
	public void setWszt(String wszt) {
		this.wszt = wszt;
	}
	public byte[] getWsnr() {
		return wsnr;
	}
	public void setWsnr(byte[] wsnr) {
		this.wsnr = wsnr;
	}
	public String getSjjzFlag() {
		return sjjzFlag;
	}
	public void setSjjzFlag(String sjjzFlag) {
		this.sjjzFlag = sjjzFlag;
	}

	public String getWsurl() {
		return wsurl;
	}

	public void setWsurl(String wsurl) {
		this.wsurl = wsurl;
	}

	public String getSfjaws() {
		return sfjaws;
	}

	public void setSfjaws(String sfjaws) {
		this.sfjaws = sfjaws;
	}
    
    

}
