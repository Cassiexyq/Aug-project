package nju.software.cpwsqwjs.data.dao;

import java.util.HashMap;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDO;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDoId;

public interface WsSsjlCtrDao {
	
	public void save(WsSsjlCtrDO ctrDo);
	
	public WsSsjlCtrDO findById(WsSsjlCtrDoId id);
	
	public List<WsSsjlCtrDO> findByajxh(int ajxh);

	public int getMaxCtrbhByAjxh(int ajxh);
}
