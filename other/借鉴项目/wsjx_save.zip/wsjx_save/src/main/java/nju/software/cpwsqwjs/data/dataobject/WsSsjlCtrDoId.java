package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsSsjlCtrDoId entity. @author MyEclipse Persistence Tools
 */
public class WsSsjlCtrDoId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer ctrbh;
	
	// Constructors

	/** default constructor */
	public WsSsjlCtrDoId() {
	}

	/** full constructor */
	public WsSsjlCtrDoId(Integer ajxh, Integer ctrbh ) {
		this.ajxh = ajxh;
		this.ctrbh = ctrbh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "CTRBH", nullable = false)
	public Integer getCtrbh() {
		return ctrbh;
	}

	public void setCtrbh(Integer ctrbh) {
		this.ctrbh = ctrbh;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsSsjlCtrDoId))
			return false;
		WsSsjlCtrDoId castOther = (WsSsjlCtrDoId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getCtrbh() == castOther.getCtrbh()) || (this
						.getCtrbh() != null && castOther.getCtrbh() != null && this
						.getCtrbh().equals(castOther.getCtrbh())));
	}


	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getCtrbh() == null ? 0 : this.getCtrbh().hashCode());
		return result;
	}

}