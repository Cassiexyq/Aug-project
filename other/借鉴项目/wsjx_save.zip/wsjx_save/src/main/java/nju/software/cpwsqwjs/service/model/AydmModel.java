package nju.software.cpwsqwjs.service.model;

import nju.software.cpwsqwjs.data.dataobject.AydmbDO;

public class AydmModel {

	private String aydmbh;//���ɴ�����
	private String aymc;//��������
	private String sjdm;//�ϼ�����
	private String sjmc;//�ϼ�����
	private String sm;//˵��
	private AydmModel sjay;
	private Integer ayjb;//���ɼ���
	
	public AydmModel() {
		super();
	}
	public AydmModel(String aydmbh, String aymc, String sjdm, String sjmc,
			String sm) {
		super();
		this.aydmbh = aydmbh;
		this.aymc = aymc;
		this.sjdm = sjdm;
		this.sjmc = sjmc;
		this.sm = sm;
	}
	public String getAydmbh() {
		return aydmbh;
	}
	public void setAydmbh(String aydmbh) {
		this.aydmbh = aydmbh;
	}
	public String getAymc() {
		return aymc;
	}
	public void setAymc(String aymc) {
		this.aymc = aymc;
	}
	public String getSjdm() {
		return sjdm;
	}
	public void setSjdm(String sjdm) {
		this.sjdm = sjdm;
	}
	public String getSjmc() {
		return sjmc;
	}
	public void setSjmc(String sjmc) {
		this.sjmc = sjmc;
	}
	public String getSm() {
		return sm;
	}
	public void setSm(String sm) {
		this.sm = sm;
	}
	public AydmModel(AydmbDO aydm){
		if(aydm!=null){
			if(aydm.getAydmbh()!=null){
				this.setAydmbh(aydm.getAydmbh());
			}
			if(aydm.getAymc()!=null){
				this.setAymc(aydm.getAymc());
			}
			if(aydm.getSjdm()!=null){
				this.setSjdm(aydm.getSjdm());
			}
			if(aydm.getSjmc()!=null){
				this.setSjmc(aydm.getSjmc());
			}
			if(aydm.getSm()!=null){
				this.setSm(aydm.getSm());
			}
			if(aydm.getAyjb()!=null){
				this.setAyjb(aydm.getAyjb());
			}
		}
	}
	public AydmModel getSjay() {
		return sjay;
	}
	public void setSjay(AydmModel sjay) {
		this.sjay = sjay;
	}
	public Integer getAyjb() {
		return ayjb;
	}
	public void setAyjb(Integer ayjb) {
		this.ayjb = ayjb;
	}
	
}
