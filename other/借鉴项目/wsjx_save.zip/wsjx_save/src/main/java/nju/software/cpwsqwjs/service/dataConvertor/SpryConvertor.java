package nju.software.cpwsqwjs.service.dataConvertor;

import nju.software.cpwsqwjs.data.dataobject.SpryDO;
import nju.software.cpwsqwjs.service.model.sp.SpryxxModel;
import nju.software.cpwsqwjs.util.StringUtil;


public class SpryConvertor {
	/**
	 * ��SpryDOת��ΪSpryxxModel
	 * @param spryxx
	 * @return
	 */
	public static SpryxxModel getSpryxxModelBySpryDO(SpryDO spryxx) {
		SpryxxModel model = new SpryxxModel();

		if (spryxx != null) {
			if (spryxx.getAjxh() != null)
				model.setAjxh(spryxx.getAjxh());
			if (StringUtil.equals(StringUtil.trim(spryxx.getFg()), "0"))
				model.setFg("���Ա");
			if(StringUtil.equals(StringUtil.trim(spryxx.getSfcbr()), "Y")){
				model.setFg("�а���");
			}
			if(StringUtil.equals(StringUtil.trim(spryxx.getSfrmpsy()), "Y")){
				model.setFg("��������Ա");
			}
			if(StringUtil.equals(StringUtil.trim(spryxx.getSfspz()), "Y")){
				model.setFg("���г�");
			}
			if(StringUtil.equals(StringUtil.trim(spryxx.getSfdlspy()), "Y")){
				model.setFg("��������Ա");
			}
//			�������N
			if(StringUtil.isBlank(model.getFg())){
				if(StringUtil.equals(StringUtil.trim(spryxx.getFg()), "1")){
					model.setFg("����Ա");
				}
			}
			if (spryxx.getSprybh() != null)
				model.setSprybh(spryxx.getSprybh());
			model.setXm(spryxx.getXm());
		}
		return model;
	}
}
