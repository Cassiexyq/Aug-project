package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.AydmbDO;

public interface AydmDao {

	public List<AydmbDO> getAll();
	
	public boolean save(AydmbDO aydm);
	
	public List<AydmbDO> findByProperty(String property,Object vaule);
	
	public AydmbDO findBySjdm(String vaule);
	public AydmbDO findByDmbh(String vaule);
}
