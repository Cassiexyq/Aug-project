package nju.software.cpwsqwjs.service.model;

import java.util.ArrayList;

public class WscpfxgcFdlxModel {
	private ArrayList<String> lxqjlb;//����������
	private String qj;//���
	private ArrayList<String> xgr;//�����
	public ArrayList<String> getLxqjlb() {
		return lxqjlb;
	}
	public void setLxqjlb(ArrayList<String> lxqjlb) {
		this.lxqjlb = lxqjlb;
	}
	public String getQj() {
		return qj;
	}
	public void setQj(String qj) {
		this.qj = qj;
	}
	public ArrayList<String> getXgr() {
		return xgr;
	}
	public void setXgr(ArrayList<String> xgr) {
		this.xgr = xgr;
	}
}
