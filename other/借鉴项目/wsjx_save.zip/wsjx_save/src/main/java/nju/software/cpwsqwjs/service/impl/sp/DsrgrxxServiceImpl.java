/**
 * 2014-5-18
 */
package nju.software.cpwsqwjs.service.impl.sp;

import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.DsrGrDao;
import nju.software.cpwsqwjs.data.dao.DsrJbDao;
import nju.software.cpwsqwjs.data.dao.XxxglDao;
import nju.software.cpwsqwjs.data.dataobject.AjjbDO;
import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrGrDO;
import nju.software.cpwsqwjs.data.dataobject.DsrGrDOId;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDOId;
import nju.software.cpwsqwjs.service.dataConvertor.DsrConvertor;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;
import nju.software.cpwsqwjs.service.sp.DmbService;
import nju.software.cpwsqwjs.service.sp.DsrgrxxService;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.StringUtil;
@Service
public class DsrgrxxServiceImpl implements DsrgrxxService {
	private   DsrGrDao dsrGrDao;
	private   DsrJbDao dsrJbDao;
	private   XxxService xxxSerrvice;
	private   DmbDao dmbDao;
	private   AjjbDao ajjbDao;
	
	
	/*private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static DsrGrDao dsrGrDao;
	private static DsrJbDao dsrJbDao;
	private static XxxService xxxSerrvice;
	private static DmbDao dmbDao;
	private static AjjbDao ajjbDao;
	static {
		dmbDao = (DmbDao) appContext.getBean("dmbDao");
		dsrGrDao = (DsrGrDao) appContext.getBean("dsrGrDao");
		dsrJbDao = (DsrJbDao) appContext.getBean("dsrJbDao");
		xxxSerrvice = new XxxServiceImpl();
		ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");
	}*/

	public void setDsrGrDao(DsrGrDao dsrGrDao) {
		this.dsrGrDao = dsrGrDao;
	}

	public void setDsrJbDao(DsrJbDao dsrJbDao) {
		this.dsrJbDao = dsrJbDao;
	}

	public void setXxxSerrvice(XxxService xxxSerrvice) {
		this.xxxSerrvice = xxxSerrvice;
	}

	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}

	public void setAjjbDao(AjjbDao ajjbDao) {
		this.ajjbDao = ajjbDao;
	}

	public List<DsrgrxxModel> getDsrgrxxByAjxh(long ajxh,AjjbxxModel ajModel) {
		// TODO Auto-generated method stub
		List<DsrGrDO> dsrGrDOs = dsrGrDao.findByProperty("ajxh", (int)ajxh);
		List<DsrJbDO> dsrJbDOs = dsrJbDao.findByProperty("ajxh", (int)ajxh);
		
		List<DsrgrxxModel> dsrgrModels = DsrConvertor.dsrgrDoListToModelList(dsrGrDOs, dsrJbDOs,dmbDao,xxxSerrvice,ajModel);
		return dsrgrModels;
	}

	@Override
	public boolean updateDsrssdw(int ajxh,int dsrbh, String ssdw) {
		// TODO Auto-generated method stub
		DsrJbDOId id = new DsrJbDOId(ajxh, dsrbh);
		DsrJbDO dsr = dsrJbDao.findById(id);
		if(dsr==null){
			return false;
		}
		
		AjjbDO ajjbDo = ajjbDao.findById(ajxh);	
		if(ajjbDo==null){
			return false;
		}
		
		AjjbxxModel ajjbxxModel = new AjjbxxModel(ajjbDo,true);
		String ssdw_lbbh = xxxSerrvice.getLbbhOld("dsrssdw", "DSR_JB", ajjbxxModel); 
		List<DmbDO> ssdwdmlist = dmbDao.getDmbbyDmms(ssdw_lbbh, ssdw);
		if(ssdwdmlist==null || ssdwdmlist.size()==0){
			return false;	
		}
		DmbDO ssdwdm = ssdwdmlist.get(0);
		String ssdwDmbh = ssdwdm.getDmbh();
		dsr.setDsrssdw(ssdwDmbh);
		dsrJbDao.save(dsr);
		return true;
	}

	@Override
	public boolean updateGrdsr(int ajxh, int dsrbh, String zd, String zdz) {
		// TODO Auto-generated method stub
		DsrGrDOId id = new DsrGrDOId(ajxh, dsrbh);
		DsrGrDO dsr = dsrGrDao.findById(id);
		if(dsr==null){
			return false;
		}
		if(StringUtil.equals(zd, "XB")){
			if(StringUtil.contains(zdz, "��")){
				dsr.setXb("1");
			}else if(StringUtil.contains(zdz, "Ů")){
				dsr.setXb("2");
			}else if(StringUtil.contains(zdz, "δ֪")){
				dsr.setXb("0");
			}else{
				dsr.setXb("9");
			}
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "CSNYR")){
			Date csnyr = DateUtil.parse(zdz, DateUtil.chineseDtFormat);
			dsr.setCsnyr(csnyr);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "MZ")){
			List<DmbDO> dmlist = dmbDao.getDmbbyDmms("FBZ0002-97", zdz);
			if(dmlist==null || dmlist.size()==0){
				return false;	
			}
			DmbDO dm = dmlist.get(0);
			String dmbh = dm.getDmbh();
			dsr.setMz(dmbh);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "WHCD")){
			List<DmbDO> dmlist = dmbDao.getDmbbyDmms("GB4658-84", zdz);
			if(dmlist==null || dmlist.size()==0){
				return false;	
			}
			DmbDO dm = dmlist.get(0);
			String dmbh = dm.getDmbh();
			dsr.setWhcd(dmbh);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "ZZMM")){
			List<DmbDO> dmlist = dmbDao.getDmbbyDmms("GB4762-84", zdz);
			if(dmlist==null || dmlist.size()==0){
				return false;	
			}
			DmbDO dm = dmlist.get(0);
			String dmbh = dm.getDmbh();
			dsr.setZzmm(dmbh);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "SSGJ")){
			List<DmbDO> dmlist = dmbDao.getDmbbyDmms("GB2659-86", zdz);
			if(dmlist==null || dmlist.size()==0){
				return false;	
			}
			DmbDO dm = dmlist.get(0);
			String dmbh = dm.getDmbh();
			dsr.setSsgj(dmbh);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "ZJLB")){
			List<DmbDO> dmlist = dmbDao.getDmbbyDmms("FBS0003-97", zdz);
			if(dmlist==null || dmlist.size()==0){
				return false;	
			}
			DmbDO dm = dmlist.get(0);
			String dmbh = dm.getDmbh();
			dsr.setZjlb(dmbh);
			dsrGrDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "SFZHM")){
			 dsr.setSfzhm(zdz);
			 dsrGrDao.save(dsr);
			 return true;
		}
		if(StringUtil.equals(zd, "DZ")){
			 dsr.setDz(zdz);
			 dsrGrDao.save(dsr);
			return true;
		}
		return false;
	}
	

}
