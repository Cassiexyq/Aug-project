package nju.software.cpwsqwjs.service.dataService;

import java.util.HashMap;

import nju.software.cpwsqwjs.service.model.WsssjlModel;
import nju.software.cpwsqwjs.service.model.WsssjlZkjlModel;

public interface WsSsjlService {
	
	public int saveSsjl(WsssjlModel wsssjlModel,int ajxh);
	
	public void saveCtrxx(HashMap<String,String> qxrxx,String ctlx,int ajxh,int startBh);

	public void saveZkjl(WsssjlZkjlModel model,int ajxh,int ssjlbh);
	
	public void saveSsjlBatch(WsssjlModel wsssjlModel,int ajxh);
}
