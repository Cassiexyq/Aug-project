package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * DsrMspcFjxxDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "DSR_MSPC_FJXX")
@IdClass(DsrMspcFjxxDOId.class)
public class DsrMspcFjxxDO implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer dsrbh;
	
	
	private Double zcze;
	private Double zwze;
	private Double yhzq;
	private Double sbse;
	private String ywdb;
	private String dbqk;
	private Double qrse;
	private String sfyy;
	private String yyclqk;

	// Constructors

	/** default constructor */
	public DsrMspcFjxxDO() {
	}

	/** minimal constructor */
	public DsrMspcFjxxDO(Integer ajxh, Integer dsrbh) {
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
	}

	/** full constructor */
	public DsrMspcFjxxDO(Integer ajxh, Integer dsrbh, Double zcze, Double zwze,
			Double yhzq, Double sbse, String ywdb, String dbqk, Double qrse,
			String sfyy, String yyclqk) {
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
		this.zcze = zcze;
		this.zwze = zwze;
		this.yhzq = yhzq;
		this.sbse = sbse;
		this.ywdb = ywdb;
		this.dbqk = dbqk;
		this.qrse = qrse;
		this.sfyy = sfyy;
		this.yyclqk = yyclqk;
	}

	// Property accessors
	@Column(name = "AJXH", nullable = false)
	@Id
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "DSRBH", nullable = false)
	@Id
	public Integer getDsrbh() {
		return this.dsrbh;
	}

	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}

	@Column(name = "ZCZE", scale = 4)
	public Double getZcze() {
		return this.zcze;
	}

	public void setZcze(Double zcze) {
		this.zcze = zcze;
	}

	@Column(name = "ZWZE", scale = 4)
	public Double getZwze() {
		return this.zwze;
	}

	public void setZwze(Double zwze) {
		this.zwze = zwze;
	}

	@Column(name = "YHZQ", scale = 4)
	public Double getYhzq() {
		return this.yhzq;
	}

	public void setYhzq(Double yhzq) {
		this.yhzq = yhzq;
	}

	@Column(name = "SBSE", scale = 4)
	public Double getSbse() {
		return this.sbse;
	}

	public void setSbse(Double sbse) {
		this.sbse = sbse;
	}

	@Column(name = "YWDB", length = 1)
	public String getYwdb() {
		return this.ywdb;
	}

	public void setYwdb(String ywdb) {
		this.ywdb = ywdb;
	}

	@Column(name = "DBQK", length = 250)
	public String getDbqk() {
		return this.dbqk;
	}

	public void setDbqk(String dbqk) {
		this.dbqk = dbqk;
	}

	@Column(name = "QRSE", scale = 4)
	public Double getQrse() {
		return this.qrse;
	}

	public void setQrse(Double qrse) {
		this.qrse = qrse;
	}

	@Column(name = "SFYY", length = 1)
	public String getSfyy() {
		return this.sfyy;
	}

	public void setSfyy(String sfyy) {
		this.sfyy = sfyy;
	}

	@Column(name = "YYCLQK")
	public String getYyclqk() {
		return this.yyclqk;
	}

	public void setYyclqk(String yyclqk) {
		this.yyclqk = yyclqk;
	}

}