package nju.software.cpwsqwjs.data.dataobject;

import nju.software.cpwsqwjs.service.model.WssscyrModel;

import javax.persistence.*;

/**
 * WsJbDO entity. @author MyEclipse Persistence Tools
 * ������
 */
@Entity
@Table(name = "WS_DSRB")
@IdClass(WsDsrDOId.class)
public class WsDsrDO implements java.io.Serializable {
	/**
	 * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private Integer ajxh;//�������
	private Integer dsrbh;//�����˱��
	private String ssdw;//���ϵ�λ
	private String ysssdw;//ԭ�����ϵ�λ
	private String dsrlb;//���������
	private String xm;//����
	private String xb;//�Ա�
 	private String mz;//����
 	private String gj; //����
	private String whcd;//�Ļ��̶�
	private String zjlx;//֤������
	private String zjhm;//֤������
 	private String zw; //ְ��
	private String dz;//��ַ
	private String sfzh;//�Ƿ��ٻ�
	private String tshy;//������ҵ
	private String jgdbr;//���ش�����
	private String dwxz;//��λ����
	private String xzflgxzt;//�������ɹ�ϵ����
	private String xzglfw;//����������Χ
	private String bglx;//��������
	private String zzjgdm;//��֯��������
	private String sfbhr;//�Ƿ񱻺���
	private String zrrsf;//��Ȼ������
	private String  hjszd;//�������ڵ�
	private String xjycs;//���Ѻ����
	private String xszrnl;//������������
	private String sfct;//�Ƿ��ͥ
	private String xw;//ѧλ
	private String zzmm;//������ò

	/** default constructor */
	public WsDsrDO() {
	}

	/** minimal constructor */
	public WsDsrDO(Integer ajxh, Integer dsrbh) {
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
	}

	public WsDsrDO(Integer ajxh, Integer dsrbh, String ssdw, String ysssdw,
			String dsrlb, String xm, String xb, String mz, String gj,
			String whcd, String zjlx, String zjhm, String zw, String dz,
			String sfzh, String tshy, String jgdbr, String dwxz,
			String xzflgxzt, String xzglfw, String bhlx, String zzjgdm,
			String sfbhr, String zrrsf, String hjszd, String xjycs,
			String xszrnl, String sfct, String xw) {
		super();
		this.ajxh = ajxh;
		this.dsrbh = dsrbh;
		this.ssdw = ssdw;
		this.ysssdw = ysssdw;
		this.dsrlb = dsrlb;
		this.xm = xm;
		this.xb = xb;
		this.mz = mz;
		this.gj = gj;
		this.whcd = whcd;
		this.zjlx = zjlx;
		this.zjhm = zjhm;
		this.zw = zw;
		this.dz = dz;
		this.sfzh = sfzh;
		this.tshy = tshy;
		this.jgdbr = jgdbr;
		this.dwxz = dwxz;
		this.xzflgxzt = xzflgxzt;
		this.xzglfw = xzglfw;
		this.bglx = bhlx;
		this.zzjgdm = zzjgdm;
		this.sfbhr = sfbhr;
		this.zrrsf = zrrsf;
		this.hjszd = hjszd;
		this.xjycs = xjycs;
		this.xszrnl = xszrnl;
		this.sfct = sfct;
		this.xw = xw;
	}

	/**
	 * ������������Ϣʱ��ʹ�����ϲ�����Model
	 * @param wssscyrModel
	 */
	public WsDsrDO(WssscyrModel wssscyrModel){
		if (wssscyrModel.getSsdw()!=null){
			this.ssdw=wssscyrModel.getSsdw();
		}
		if (wssscyrModel.getYsssdw()!=null){
			this.ysssdw=wssscyrModel.getYsssdw();
		}
		if (wssscyrModel.getDsrlb()!=null){
			this.dsrlb=wssscyrModel.getDsrlb();
		}
		if (wssscyrModel.getSscyr()!=null){
			this.xm=wssscyrModel.getSscyr();
		}
		if (wssscyrModel.getXb()!=null){
			this.xb=wssscyrModel.getXb();
		}
		if (wssscyrModel.getMz()!=null){
			this.mz=wssscyrModel.getMz();
		}
		if (wssscyrModel.getGj()!=null){
			this.gj=wssscyrModel.getGj();
		}
		if (wssscyrModel.getDsrwhcd()!=null){
			this.whcd=wssscyrModel.getDsrwhcd();
		}
		if (wssscyrModel.getZjlx()!=null){
			this.zjlx=wssscyrModel.getZjlx();
		}
		if (wssscyrModel.getZjhm()!=null){
			this.zjhm=wssscyrModel.getZjhm();
		}
		if (wssscyrModel.getDsrzw()!=null){
			this.zw=wssscyrModel.getDsrzw();
		}
		if (wssscyrModel.getDsrdz()!=null){
			this.dz=wssscyrModel.getDsrdz();
		}
		if (wssscyrModel.getDsrsfzh()!=null){
			this.sfzh=wssscyrModel.getDsrsfzh();
		}
		if (wssscyrModel.getTshy()!=null){
			this.tshy=wssscyrModel.getTshy();
		}
		if (wssscyrModel.getFddbr()!=null){
			this.jgdbr=wssscyrModel.getFddbr();
		}
		if (wssscyrModel.getGzdwxz()!=null){
			this.dwxz=wssscyrModel.getGzdwxz();
		}
		if (wssscyrModel.getXzfagxzt()!=null){
			this.xzflgxzt=wssscyrModel.getXzfagxzt();
		}
		if (wssscyrModel.getBglx()!=null){
			this.bglx=wssscyrModel.getBglx();
		}
		if (wssscyrModel.getZzjgdm()!=null){
			this.zzjgdm=wssscyrModel.getZzjgdm();
		}
		if (wssscyrModel.getIsBhr()!=null){
			this.sfbhr=wssscyrModel.getIsBhr();
		}
		if (wssscyrModel.getZrrsf()!=null){
			this.zrrsf=wssscyrModel.getZrrsf();
		}
		if (wssscyrModel.getHjd()!=null){
			this.hjszd=wssscyrModel.getHjd();
		}
		if (wssscyrModel.getXjycs()!=null){
			this.xjycs=wssscyrModel.getXjycs();
		}
		if (wssscyrModel.getXszrablity()!=null){
			this.xszrnl=wssscyrModel.getXszrablity();
		}
		if (wssscyrModel.getDtqk()!=null){
			this.sfct=wssscyrModel.getDtqk();
		}
		if (wssscyrModel.getDsrxw()!=null){
			this.xw=wssscyrModel.getDsrxw();
		}
		if (wssscyrModel.getZzmm()!=null){
			this.zzmm=wssscyrModel.getZzmm();
		}
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "DSRBH", nullable = false)
	public Integer getDsrbh() {
		return this.dsrbh;
	}

	public void setDsrbh(Integer dsrbh) {
		this.dsrbh = dsrbh;
	}
	@Column(name = "SSDW", length = 10)
	public String getSsdw() {
		return ssdw;
	}

	public void setSsdw(String ssdw) {
		this.ssdw = ssdw;
	}
	@Column(name = "YSSSDW", length = 10)
	public String getYsssdw() {
		return ysssdw;
	}

	public void setYsssdw(String ysssdw) {
		this.ysssdw = ysssdw;
	}
	@Column(name = "DSRLB", length = 10)
	public String getDsrlb() {
		return dsrlb;
	}

	public void setDsrlb(String dsrlb) {
		this.dsrlb = dsrlb;
	}
	@Column(name = "XM", length = 50)
	public String getXm() {
		return xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}
	@Column(name = "XB", length = 10)
	public String getXb() {
		return xb;
	}

	public void setXb(String xb) {
		this.xb = xb;
	}
	@Column(name = "MZ", length = 10)
	public String getMz() {
		return mz;
	}

	public void setMz(String mz) {
		this.mz = mz;
	}
	@Column(name = "GJ", length = 50)
	public String getGj() {
		return gj;
	}

	public void setGj(String gj) {
		this.gj = gj;
	}
	@Column(name = "WHCD", length = 10)
	public String getWhcd() {
		return whcd;
	}

	public void setWhcd(String whcd) {
		this.whcd = whcd;
	}
	@Column(name = "ZJLX", length = 10)
	public String getZjlx() {
		return zjlx;
	}

	public void setZjlx(String zjlx) {
		this.zjlx = zjlx;
	}
	@Column(name = "ZJHM", length = 50)
	public String getZjhm() {
		return zjhm;
	}

	public void setZjhm(String zjhm) {
		this.zjhm = zjhm;
	}
	@Column(name = "ZW", length = 10)
	public String getZw() {
		return zw;
	}

	public void setZw(String zw) {
		this.zw = zw;
	}
	@Column(name = "DZ", length = 200)
	public String getDz() {
		return dz;
	}

	public void setDz(String dz) {
		this.dz = dz;
	}
	@Column(name = "SFZH", length = 2)
	public String getSfzh() {
		return sfzh;
	}

	public void setSfzh(String sfzh) {
		this.sfzh = sfzh;
	}
	@Column(name = "TSHY", length = 20)
	public String getTshy() {
		return tshy;
	}

	public void setTshy(String tshy) {
		this.tshy = tshy;
	}
	@Column(name = "JGDBR", length = 20)
	public String getJgdbr() {
		return jgdbr;
	}

	public void setJgdbr(String jgdbr) {
		this.jgdbr = jgdbr;
	}
	@Column(name = "DWXZ", length = 20)
	public String getDwxz() {
		return dwxz;
	}

	public void setDwxz(String dwxz) {
		this.dwxz = dwxz;
	}
	@Column(name = "XZFLGXZT", length = 20)
	public String getXzflgxzt() {
		return xzflgxzt;
	}

	public void setXzflgxzt(String xzflgxzt) {
		this.xzflgxzt = xzflgxzt;
	}
	@Column(name = "XZGLFW", length = 20)
	public String getXzglfw() {
		return xzglfw;
	}

	public void setXzglfw(String xzglfw) {
		this.xzglfw = xzglfw;
	}
	@Column(name = "BGLX", length = 20)
	public String getBglx() {
		return bglx;
	}

	public void setBglx(String bglx) {
		this.bglx = bglx;
	}
	@Column(name = "ZZJGDM", length = 20)
	public String getZzjgdm() {
		return zzjgdm;
	}

	public void setZzjgdm(String zzjgdm) {
		this.zzjgdm = zzjgdm;
	}
	@Column(name = "SFBHR", length = 2)
	public String getSfbhr() {
		return sfbhr;
	}

	public void setSfbhr(String sfbhr) {
		this.sfbhr = sfbhr;
	}
	@Column(name = "ZRRSF", length = 10)
	public String getZrrsf() {
		return zrrsf;
	}

	public void setZrrsf(String zrrsf) {
		this.zrrsf = zrrsf;
	}
	@Column(name = "HJSZD", length = 200)
	public String getHjszd() {
		return hjszd;
	}

	public void setHjszd(String hjszd) {
		this.hjszd = hjszd;
	}
	@Column(name = "XJYCS", length = 100)
	public String getXjycs() {
		return xjycs;
	}

	public void setXjycs(String xjycs) {
		this.xjycs = xjycs;
	}
	@Column(name = "XSZRNL", length = 20)
	public String getXszrnl() {
		return xszrnl;
	}

	public void setXszrnl(String xszrnl) {
		this.xszrnl = xszrnl;
	}
	@Column(name = "SFCT", length = 10)
	public String getSfct() {
		return sfct;
	}

	public void setSfct(String sfct) {
		this.sfct = sfct;
	}
	@Column(name = "XW", length = 20)
	public String getXw() {
		return xw;
	}

	public void setXw(String xw) {
		this.xw = xw;
	}
	@Column(name = "ZZMM", length = 50)
	public String getZzmm() {
		return zzmm;
	}

	public void setZzmm(String zzmm) {
		this.zzmm = zzmm;
	}

}