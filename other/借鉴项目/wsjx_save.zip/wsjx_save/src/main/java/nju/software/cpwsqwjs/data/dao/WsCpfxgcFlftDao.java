package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcFlftDO;

public interface WsCpfxgcFlftDao {

	public int getMaxFtbhByajxh(int ajxh);

	public int saveFlft(WsCpfxgcFlftDO flftDO);

}
