package nju.software.cpwsqwjs.service.dataService;

import nju.software.cpwsqwjs.service.model.WsajjbqkModel;

public interface WsajjbqkService {

	/**
	 * �������� WS_AJJBQKMSXZ
	 * @param ajxh
	 * @param ajjbqkModel
	 */
	public void saveMsxzAjjbqk(int ajxh,WsajjbqkModel ajjbqkModel);
	/**
	 * ����һ�� WS_AJJBQKXSYS
	 * @param ajxh
	 * @param ajjbqkModel
	 */
	public void saveXsysAjjbqk(int ajxh,WsajjbqkModel ajjbqkModel);
	/**
	 * ���¶��� WS_AJJBQKXSYS
	 * @param ajxh
	 * @param ajjbqkModel
	 */
	public void saveXsesAjjbqk(int ajxh,WsajjbqkModel ajjbqkModel);
	
	public void saveManyToOne(int ajxh,WsajjbqkModel model);
}
