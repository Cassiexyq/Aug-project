package nju.software.cpwsqwjs.service.dataService;

import java.util.HashMap;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.service.model.FydmModel;

public interface FydmService {

	/**
	 * ���淨Ժ����
	 * @param modelList
	 */
	public void saveFydm(List<FydmModel> modelList);
	/**
	 * ���ݷ�Ժ���ƻ�÷�Ժ����
	 * @param fymc
	 */
	public FydmModel getFydmByFymc(String fymc);
	public FydmModel getFydmByCjm(String cjm);
	
	public List<FydmModel> getAllFydm();
	
	public WssxbDo setFy(WssxbDo wssx,String fycjm,String fymc,HashMap<String, FydmModel> map);
	
	public HashMap<String, FydmModel> getAll();
}
