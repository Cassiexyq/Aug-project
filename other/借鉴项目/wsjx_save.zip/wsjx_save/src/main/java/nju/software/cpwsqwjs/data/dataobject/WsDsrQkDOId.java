package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsDsrQkDOId entity. @author MyEclipse Persistence Tools
 */
public class WsDsrQkDOId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer qkbh;

	// Constructors

	/** default constructor */
	public WsDsrQkDOId() {
	}

	/** full constructor */
	public WsDsrQkDOId(Integer ajxh, Integer qkbh) {
		this.ajxh = ajxh;
		this.qkbh = qkbh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "QKBH", nullable = false)
	public Integer getQkbh() {
		return qkbh;
	}

	public void setQkbh(Integer qkbh) {
		this.qkbh = qkbh;
	}

	
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsDsrQkDOId))
			return false;
		WsDsrQkDOId castOther = (WsDsrQkDOId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getQkbh() == castOther.getQkbh()) || (this
						.getQkbh() != null && castOther.getQkbh() != null && this
						.getQkbh().equals(castOther.getQkbh())));
	}

	


	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getQkbh() == null ? 0 : this.getQkbh().hashCode());
		return result;
	}

}