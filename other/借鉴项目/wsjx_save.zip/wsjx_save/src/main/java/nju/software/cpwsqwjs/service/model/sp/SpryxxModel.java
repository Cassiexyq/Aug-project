package nju.software.cpwsqwjs.service.model.sp;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class SpryxxModel {
	
	private long ajxh;//�������
	private long sprybh;//������Ա���
	private String fg;//�ֹ�
	private String xm;//����

	public SpryxxModel(){}
	
	public SpryxxModel(long ajxh, long sprybh, String fg, String xm ) {
		super();
		this.ajxh = ajxh;
		this.sprybh = sprybh;
		this.fg = fg;
		this.xm = xm;
	}

	public long getAjxh() {
		return ajxh;
	}

	public void setAjxh(long ajxh) {
		this.ajxh = ajxh;
	}

	public long getSprybh() {
		return sprybh;
	}

	public void setSprybh(long sprybh) {
		this.sprybh = sprybh;
	}

	public String getFg() {
		return fg;
	}

	public void setFg(String fg) {
		this.fg = fg;
	}


	public String getXm() {
		return xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}


	public String toString(){
		return ToStringBuilder.reflectionToString(this);
	}
}

