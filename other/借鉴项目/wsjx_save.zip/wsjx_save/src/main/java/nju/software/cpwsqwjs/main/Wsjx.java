package nju.software.cpwsqwjs.main;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.business.WsManager;
import nju.software.cpwsqwjs.handler.mseshandler.WsModelHandler;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.util.FcUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.StringUtil;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by zhx on 2017/6/29.
 */
public class Wsjx {
    public static String  getWsnr(String path,String filename){
        String wsnr="";
        ArrayList<String> content=new ArrayList<String>();
        ArrayList<String> wsnrlist=new ArrayList<String>();
        FileUtil fileUtil = new FileUtil();
        FcUtil fcUtil=new FcUtil();
        fileUtil.setS(path+"\\"+filename);
        content=fileUtil.readFromFile();
        for(int i=0;i<content.size();i++){
            ArrayList<String> str=(ArrayList<String>) FcUtil.getWholeToken(content.get(i));
            if(str.size()>0){
                wsnrlist.add(content.get(i));
            }
        }
        for(int i=0;i<wsnrlist.size()-1;i++){
            wsnr+=wsnrlist.get(i)+"\n";
        }
        wsnr+=wsnrlist.get(wsnrlist.size()-1);
        return wsnr;
    }
    public static String fileSelection(String path,String filename) throws Exception{
        String wsnr=null;
        String str = filename.substring(filename.lastIndexOf(".")+1);
        if(str.contains("txt")){
            wsnr=getWsnr(path,filename);
        }else if(str.contains("doc")||str.contains("docx")||str.contains("DOC")){
            wsnr=FileUtil.readDoc(path, filename);
        }else if(str.contains("RTF")||str.contains("rtf") ){
            wsnr=FileUtil.readRtf(path, filename);
        }else{
            System.out.println("�ļ���Ϊ��"+filename+"\n��Ч�ļ�");
        }
        return wsnr;
    }

    public static void main(String[] args) throws Exception {
        String inputpath="/Users/zhx/Desktop/wsduty/test-input/";
        parseSingleWs(inputpath,"(2014)������ֵ�0845��-�����о��飨һ�����°������׳����ã�-3.doc");
    }

    public static void parseSingleWs(String inputpath,String filename) throws Exception{
        File file=new File(inputpath);
        String outputpath = file.getParent()+File.separator+"out";
        WsManager wsManager = new WsManager();
        try{
            System.out.println(filename);
            String wsnr=fileSelection(inputpath,filename);
            WsAnalyse wsAnalyse = new WsAnalyse(filename,wsnr);
            WswsModel wswsModel=new WswsModel();
            if(wsAnalyse.getWs()!=null){
                wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
            }
            String ajlx = wswsModel.getAjlx();
            if(StringUtil.contains(ajlx, "���¶���")){
                wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename);
            }else if(StringUtil.contains(ajlx, "����һ��")){
                wsManager.jxMsys(wsAnalyse,wsnr,inputpath,outputpath,filename);
            }else if(StringUtil.contains(ajlx, "����һ��")){
                wsManager.jxXzys(wsAnalyse,wsnr,inputpath,outputpath,filename);
            }else if(StringUtil.contains(ajlx, "����һ��")){
                wsManager.jxXsys(wsAnalyse, wsnr, inputpath, outputpath, filename);
            }else if(StringUtil.contains(ajlx, "��������")){
                wsManager.jxXzes(wsAnalyse, wsnr, inputpath, outputpath, filename);
            }else if(StringUtil.contains(ajlx, "���¶���")){
                wsManager.jxXses(wsAnalyse, wsnr, inputpath, outputpath, filename);
            }
        }catch(Exception e){
            System.out.println("�޷�����"+ filename);
            e.printStackTrace();
        }
    }

    public static void parseMulWs(String inputpath,String[] filenames) throws Exception {
        File file=new File(inputpath);
        String outputpath = file.getParent()+File.separator+"out";
        WsManager wsManager = new WsManager();
        for (String filename: filenames) {
            try{
                System.out.println(filename);
                String wsnr=fileSelection(inputpath,filename);
                WsAnalyse wsAnalyse = new WsAnalyse(filename,wsnr);
                WswsModel wswsModel=new WswsModel();
                if(wsAnalyse.getWs()!=null){
                    wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
                }
                String ajlx = wswsModel.getAjlx();
                if(StringUtil.contains(ajlx, "���¶���")){
                    wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename);
                }else if(StringUtil.contains(ajlx, "����һ��")){
                    wsManager.jxMsys(wsAnalyse,wsnr,inputpath,outputpath,filename);
                }else if(StringUtil.contains(ajlx, "����һ��")){
                    wsManager.jxXzys(wsAnalyse,wsnr,inputpath,outputpath,filename);
                }else if(StringUtil.contains(ajlx, "����һ��")){
                    wsManager.jxXsys(wsAnalyse, wsnr, inputpath, outputpath, filename);
                }else if(StringUtil.contains(ajlx, "��������")){
                    wsManager.jxXzes(wsAnalyse, wsnr, inputpath, outputpath, filename);
                }else if(StringUtil.contains(ajlx, "���¶���")){
                    wsManager.jxXses(wsAnalyse, wsnr, inputpath, outputpath, filename);
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
