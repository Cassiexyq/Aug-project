package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkQszjdDO;

public interface WsAjjbqkQszjdDao {
    public WsAjjbqkQszjdDO getByAjxh(int ajxh);
    public void save(WsAjjbqkQszjdDO wsAjjbqkQszjdDO);
    public int getMaxbh();
}
