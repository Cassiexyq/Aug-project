package nju.software.cpwsqwjs.data.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsssjlZkjlDao;
import nju.software.cpwsqwjs.data.dataobject.WsssjlzkjlDO;

public class WsssjlZkjlDaoImpl extends HibernateDaoSupport  implements WsssjlZkjlDao{

	@Override
	public void save(WsssjlzkjlDO zkjlDo) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(zkjlDo);
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public int getMaxZkjlbhByajxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(zkjlbh) from WsssjlzkjlDO where ajxh = "+ajxh;

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxbh;
	}

}
