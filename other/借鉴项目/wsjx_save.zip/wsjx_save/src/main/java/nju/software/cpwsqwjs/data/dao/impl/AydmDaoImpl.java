package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.AydmDao;
import nju.software.cpwsqwjs.data.dataobject.AydmbDO;
import nju.software.cpwsqwjs.data.dataobject.FydmDO;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class AydmDaoImpl extends HibernateDaoSupport implements AydmDao{

	@Override
	public List<AydmbDO> getAll() {
		// TODO Auto-generated method stub
		try {
			String queryString = "from AydmbDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public boolean save(AydmbDO aydm) {
		// TODO Auto-generated method stub
		 try{
	            getHibernateTemplate().saveOrUpdate(aydm);
		 }catch (RuntimeException re){
			 throw re;
		 }
		 return true;
	}

	@Override
	public List<AydmbDO>  findByProperty(String property, Object value) {
		// TODO Auto-generated method stub
		try {
			String queryString = "from AydmbDO as model where model."
					+ property + "= ?";
			return  getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public AydmbDO findBySjdm(String vaule) {
		// TODO Auto-generated method stub
		try {
			String queryString = "from AydmbDO as model where model.sjdm = '"+vaule+"'";
			List<AydmbDO> list = getHibernateTemplate().find(queryString);
			if(list.size()>0){
				return list.get(0);
			}else{
				return null;
			}
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public AydmbDO findByDmbh(String vaule) {
		// TODO Auto-generated method stub
		try {
			String queryString = "from AydmbDO as model where model.aydmbh = '"+vaule+"'";
			List<AydmbDO> list = getHibernateTemplate().find(queryString);
			if(list.size()>0){
				return list.get(0);
			}else{
				return null;
			}
		} catch (RuntimeException re) {
			throw re;
		}
	}

}
