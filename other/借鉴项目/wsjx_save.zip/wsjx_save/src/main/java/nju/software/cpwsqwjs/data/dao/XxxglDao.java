package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.XxxglDO;
import nju.software.cpwsqwjs.exception.BaseAppException;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


/**
 	* A data access object (DAO) providing persistence and search support for XxxglDO entities.
 			* Transaction control of the save(), update() and delete() operations 
		can directly support Spring container-managed transactions or they can be augmented	to handle user-managed Spring transactions. 
		Each of these methods provides additional information for how to configure it for the desired type of transaction control. 	
	 * @see software.tjspxt.data.dataobject.XxxglDO
  * @author MyEclipse Persistence Tools 
 */

public class XxxglDao extends HibernateDaoSupport  {
	     private static final Logger log = LoggerFactory.getLogger(XxxglDao.class);
		//property constants
	public static final String FYBH = "fybh";
	public static final String NAME = "name";
	public static final String SZB = "szb";
	public static final String SZL = "szl";
	public static final String DATATYPE = "datatype";
	public static final String XXXJC = "xxxjc";
	public static final String SJXX = "sjxx";



	protected void initDao() {
		//do nothing
	}
    
    public void save(XxxglDO transientInstance) {
        log.debug("saving XxxglDO instance");
        try {
            getHibernateTemplate().saveOrUpdate(transientInstance);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }
    
	public void delete(XxxglDO persistentInstance) {
        log.debug("deleting XxxglDO instance");
        try {
            getHibernateTemplate().delete(persistentInstance);
            log.debug("delete successful");
        } catch (RuntimeException re) {
            log.error("delete failed", re);
            throw re;
        }
    }
    
    public XxxglDO findById( java.lang.Integer id) {
        log.debug("getting XxxglDO instance with id: " + id);
        try {
            XxxglDO instance = (XxxglDO) getHibernateTemplate()
                    .get("software.tjspxt.data.dataobject.XxxglDO", id);
            return instance;
        } catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
    
    
    public List<XxxglDO> findByExample(XxxglDO instance) {
        log.debug("finding XxxglDO instance by example");
        try {
            List<XxxglDO> results = (List<XxxglDO>) getHibernateTemplate().findByExample(instance); 
            log.debug("find by example successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
            log.error("find by example failed", re);
            throw re;
        }
    }    
    
    public List findByProperty(String propertyName, Object value) {
      log.debug("finding XxxglDO instance with property: " + propertyName
            + ", value: " + value);
      try {
         String queryString = "from XxxglDO as model where model." 
         						+ propertyName + "= ?";
		 return getHibernateTemplate().find(queryString, value);
      } catch (RuntimeException re) {
         log.error("find by property name failed", re);
         throw re;
      }
	}

	public List<XxxglDO> findByFybh(Object fybh
	) {
		return findByProperty(FYBH, fybh
		);
	}
	
	public List<XxxglDO> findByName(Object name
	) {
		return findByProperty(NAME, name
		);
	}
	
	public List<XxxglDO> findBySzb(Object szb
	) {
		return findByProperty(SZB, szb
		);
	}
	
	public List<XxxglDO> findBySzl(Object szl
	) {
		return findByProperty(SZL, szl
		);
	}
	
	public List<XxxglDO> findByDatatype(Object datatype
	) {
		return findByProperty(DATATYPE, datatype
		);
	}
	
	public List<XxxglDO> findByXxxjc(Object xxxjc
	) {
		return findByProperty(XXXJC, xxxjc
		);
	}
	
	public List<XxxglDO> findBySjxx(Object sjxx
	) {
		return findByProperty(SJXX, sjxx
		);
	}
	

	public List findAll() {
		log.debug("finding all XxxglDO instances");
		try {
			String queryString = "from XxxglDO";
		 	return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
    public XxxglDO merge(XxxglDO detachedInstance) {
        log.debug("merging XxxglDO instance");
        try {
            XxxglDO result = (XxxglDO) getHibernateTemplate()
                    .merge(detachedInstance);
            log.debug("merge successful");
            return result;
        } catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }

    public void attachDirty(XxxglDO instance) {
        log.debug("attaching dirty XxxglDO instance");
        try {
            getHibernateTemplate().saveOrUpdate(instance);
            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }
    
    public void attachClean(XxxglDO instance) {
        log.debug("attaching clean XxxglDO instance");
        try {
            getHibernateTemplate().lock(instance, LockMode.NONE);
            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }

	public static XxxglDao getFromApplicationContext(ApplicationContext ctx) {
    	return (XxxglDao) ctx.getBean("xxxglDao");
	}
	
	
	
	
	
	
	public boolean addXxx(XxxglDO xxx) {
		try {
			if (xxx == null) {
				throw new BaseAppException("���ӵ���Ϣ�����Ϊ�գ�");
			} else {
				getHibernateTemplate().evict(xxx);    
				getHibernateTemplate().save(xxx);
				if(log.isInfoEnabled()){
					log.info("add a xxx with gjmc="+xxx.getName()+",table="+xxx.getSzb()+",column="+xxx.getSzl());
				}
			}
			//ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("������Ϣ��ʱ���ݿⷢ������");
		}
		
		return true;
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#deleteXxx(XxxglDO)
	 */
	public boolean deleteXxx(XxxglDO xxx) {
		try {
			if (xxx == null) {
				throw new BaseAppException("ɾ������Ϣ�����Ϊ�գ�");
			} else {
				getHibernateTemplate().delete(xxx);
				if(log.isInfoEnabled()){
					log.info("delete a xxx with gjmc="+xxx.getName()+",table="+xxx.getSzb()+",column="+xxx.getSzl());
				}
			}
			//ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("ɾ����Ϣ��ʱ���ݿⷢ������");
		}
		
		return true;
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#getXxxByGjbh(long)
	 */
	@SuppressWarnings("unchecked")
	public List<XxxglDO> getXxxByGjbh(long gjbh, long fybh) {
		String hql = "select new XxxglDO(b.xxxbh,b.fybh,b.name,b.szb,b.szl,b.datatype,b.xxxjc,b.sjxx) " +
				"from GjbDO a,XxxglDO b,GjSjxGxbDO c " +
				"where a.gjbh = c.gjbh and " +
				"c.xxxbh = b.xxxbh and " +
				"a.gjbh = "+gjbh + " and c.fybh=" + fybh;
		
		if(log.isInfoEnabled()){
			log.info("getGjListByXxxbh by sql: "+hql);
		}
		
		return getHibernateTemplate().find(hql);
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#getXxxList(long)
	 */
	@SuppressWarnings("unchecked")
	public List<XxxglDO> getXxxList(long fybh) {
		String hql = "from XxxglDO where fybh=" + fybh;
		
		List<XxxglDO> xxx = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled()){
			log.info("getXxxList by sql: "+hql);
		}
		return xxx;
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#getXxxByXxxbh(long)
	 */
	@SuppressWarnings("unchecked")
	public XxxglDO getXxxByXxxbh(long xxxbh) {
		String hql = "from XxxglDO where xxxbh=" + xxxbh;
		List<XxxglDO> xxx = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled()){
			log.info("getXxxByXxxbh by sql: "+hql);
		}
		return xxx.isEmpty() ? null : xxx.get(0);
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#getXxxByXxxmc(String, long)
	 */
	@SuppressWarnings("unchecked")
	public XxxglDO getXxxByXxxmc(String name, long fybh) {
		String hql = "from XxxglDO where name='" + name + "' and fybh=" + fybh;
		List<XxxglDO> xxx = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled()){
			log.info("getXxxByXxxmc by sql: "+hql);
		}
		return xxx.isEmpty() ? null : xxx.get(0);
	}
	
	@SuppressWarnings("unchecked")
	public XxxglDO getXxxByXxxmcAndDao(String xxxjc, String szb) {
		String hql = "from XxxglDO where xxxjc='" + xxxjc + "' and szb='" + szb+"'";
		List<XxxglDO> xxx = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled()){
			log.info("getXxxByXxxmc by sql: "+hql);
		}
		return xxx.isEmpty() ? null : xxx.get(0);
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#getMaxXxxbh()
	 */
	public long getMaxXxxbh() {
		String hql = "select max(xxxbh) from XxxglDO";
		
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		long maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Long) query.uniqueResult();

		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		
		return maxbh;
	}

	/* (non-Javadoc)
	 * @see  nju.software.appfoundation.data.dao.DmbDao#updateXxx(XxxglDO)
	 */
	public boolean updateXxx(XxxglDO xxx) {
		try {
			if (xxx == null) {
				throw new BaseAppException("���µ���Ϣ�����Ϊ�գ�");
			} else {
				getHibernateTemplate().update(xxx);
				if(log.isInfoEnabled()){
					log.info("update a xxx with gjmc="+xxx.getName()+",table="+xxx.getSzb()+",column="+xxx.getSzl());
				}
			}	
			//ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("������Ϣ��ʱ���ݿⷢ������");
		}
		
		return true;
	}

	/*
	 * (non-Javadoc)
	 * @see nju.software.appfoundation.data.dao.XxxglbDao#getXxxByTableAndColumn(java.lang.String, java.lang.String, long)
	 */
	@SuppressWarnings("unchecked")
	public XxxglDO getXxxByTableAndColumn(String szb, String szl, long fybh) {
		String hql = "from XxxglDO where szb='" + szb + "' and szl='" + szl + "' and fybh=" + fybh;
		List<XxxglDO> xxx = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled()){
			log.info("getXxxByXxxmc by sql: "+hql);
		}
		return xxx.isEmpty() ? null : xxx.get(0);
	}
}