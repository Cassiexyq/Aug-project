/**
 * 2014-5-19 17:01
 */
package nju.software.cpwsqwjs.service.sp;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;


/**
 * @author ruanhao
 *
 */
public interface DsrjgxxService {

	public List<DsrjgxxModel> getDsrjgxxByAjxh(long ajxh,AjjbxxModel aj);
	
	public boolean updateDsrdw(long ajxh, int dsrbh, String zd, String zdz);
}
