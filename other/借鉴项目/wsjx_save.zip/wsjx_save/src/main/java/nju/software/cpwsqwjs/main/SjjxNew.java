package nju.software.cpwsqwjs.main;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.business.WsManager;
import nju.software.cpwsqwjs.handler.mseshandler.WsModelHandler;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.util.XMLReader;
import org.xml.sax.SAXException;
public class SjjxNew {
	public static String getQW(String filename,String path) throws XPathExpressionException, ParserConfigurationException, SAXException, IOException{
		String qw=null;
		String xpath_qw="//QW/@value";
		XMLReader xr=new XMLReader();
		qw=xr.getXMLNode(path+"\\"+filename, xpath_qw);
		return qw;
	}
	public static String format(String qw){
		char[]ws=qw.toCharArray();		
		int index=0;
		for(int i=0;i<ws.length;i++){
			int temp=ws[i];
			if(temp==32){
				if(i-index>5){
					ws[i]=10;
				}
				index=i;
			}

		}
		return String.valueOf(ws);
	}
	public static void main(String[] args) throws Exception {
		String inputpath="C:\\Users\\super\\Desktop\\in";
		String outputpath="C:\\Users\\super\\Desktop\\output";

		File file=new File(inputpath);
		String filename[];
		filename=file.list();
		WsManager wsManager = new WsManager();
		for(int j=0;j<filename.length;j++)
		{
			System.out.println(filename[j]);
			String wsnr=getQW(filename[j],inputpath);
			wsnr=format(wsnr);
			WsAnalyse wsAnalyse = new WsAnalyse(filename[j],wsnr);
			WswsModel wswsModel=new WswsModel();
			if(wsAnalyse.getWs()!=null){
				wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			}
			String ajlx = wswsModel.getAjlx();
			if(StringUtil.contains(ajlx, "���¶���")){
				wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxMsys(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxXzys(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxXsys(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
			}else if(StringUtil.contains(ajlx, "��������")){
				wsManager.jxXzes(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
			}else if(StringUtil.contains(ajlx, "���¶���")){
				wsManager.jxXses(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
			}
		}
	}

}
