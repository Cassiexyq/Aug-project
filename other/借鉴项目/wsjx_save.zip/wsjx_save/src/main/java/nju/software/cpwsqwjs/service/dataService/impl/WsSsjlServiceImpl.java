package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.WsSsjlCtrDao;
import nju.software.cpwsqwjs.data.dao.WsSsjlDao;
import nju.software.cpwsqwjs.data.dao.WsSsjlZkzmDao;
import nju.software.cpwsqwjs.data.dao.WsssjlZkjlDao;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDO;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlDO;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlZkzmDO;
import nju.software.cpwsqwjs.data.dataobject.WsssjlzkjlDO;
import nju.software.cpwsqwjs.service.dataService.WsSsjlService;
import nju.software.cpwsqwjs.service.model.WsssjlModel;
import nju.software.cpwsqwjs.service.model.WsssjlZkjlModel;
import nju.software.cpwsqwjs.service.model.WsssjlZkzmModel;
import nju.software.cpwsqwjs.util.StringUtil;

public class WsSsjlServiceImpl implements WsSsjlService {

	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static WsSsjlDao wsSsjlDao;
	private static WsSsjlCtrDao wsSsjlCtrDao;
	private static WsssjlZkjlDao wsssjlzkjlDao;
	private static WsSsjlZkzmDao wsSsjlZkzmDao;
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsSsjlDao = (WsSsjlDao) appContext.getBean("wsSsjlDao");
		wsSsjlCtrDao = (WsSsjlCtrDao) appContext.getBean("wsSsjlCtrDao");
		wsssjlzkjlDao =(WsssjlZkjlDao)appContext.getBean("wsssjlzkjlDao");
		wsSsjlZkzmDao = (WsSsjlZkzmDao)appContext.getBean("wsSsjlZkzmDao");
	}
	
	@Override
	public int saveSsjl(WsssjlModel wsssjlModel,int ajxh) {
		// TODO Auto-generated method stub
		WsSsjlDO ssjlDO = new WsSsjlDO(wsssjlModel);
		ssjlDO.setAjxh(ajxh);
//		��ͥ����Ϣ
		if(wsssjlModel.getCtrxx()!=null && !wsssjlModel.getCtrxx().isEmpty()){
			saveCtrxx(wsssjlModel.getCtrxx(), "��ͥ", ajxh, 1);
		}
//		ȱϯ����Ϣ
		int maxCybh = wsSsjlCtrDao.getMaxCtrbhByAjxh(ajxh);
		if(wsssjlModel.getQxrxx()!=null && !wsssjlModel.getQxrxx().isEmpty()){
			saveCtrxx(wsssjlModel.getQxrxx(), "ȱϯ", ajxh, maxCybh+1);
		}
//		ָ�ؼ�¼
		if(wsssjlModel.getWsssjlZkjl()!=null && !wsssjlModel.getWsssjlZkjl().isEmpty()){
			int maxZkjlbh = wsssjlzkjlDao.getMaxZkjlbhByajxh(ajxh)+1;
			for(WsssjlZkjlModel zkjlModel:wsssjlModel.getWsssjlZkjl()){
				saveZkjl(zkjlModel, ajxh, maxZkjlbh);
				maxZkjlbh++;
			}
		}
		return wsSsjlDao.saveSsjlDo(ssjlDO);
	}
	@Override
	public void saveCtrxx(HashMap<String, String> qxrxx, String ctlx,int ajxh,int startBh) {
		// TODO Auto-generated method stub
		for(Map.Entry<String, String> entry:qxrxx.entrySet()){
			if(entry.getKey()!=null){
				WsSsjlCtrDO ctrDo = new WsSsjlCtrDO();
				ctrDo.setAjxh(ajxh);
				ctrDo.setCtrbh(startBh);
				ctrDo.setCtlx(ctlx);
				startBh++;
				ctrDo.setXm(entry.getKey());
				if(entry.getValue()!=null){
					ctrDo.setSssf(entry.getValue());
				}
				wsSsjlCtrDao.save(ctrDo);
			}
		}
	}
	@Override
	public void saveZkjl(WsssjlZkjlModel model, int ajxh, int zkjlbh) {
		// TODO Auto-generated method stub
		if(model.getXgr()!=null &&  !model.getXgr().isEmpty()){
			String xgs_str = "";
			for(String xgr:model.getXgr()){
				xgs_str = xgs_str+xgr+";";
			}
			if(xgs_str.endsWith(";")){
				xgs_str = xgs_str.substring(0, xgs_str.length()-1);
			}
			if(!StringUtil.isBlank(xgs_str)){
				WsssjlzkjlDO zkjlDo = new WsssjlzkjlDO();
				zkjlDo.setAjxh(ajxh);
				zkjlDo.setZkjlbh(zkjlbh);
				zkjlDo.setXgr(xgs_str);
				wsssjlzkjlDao.save(zkjlDo);
				if(model.getZkzmModelist()!=null && !model.getZkzmModelist().isEmpty()){
					int zmbh = wsSsjlZkzmDao.getMaxzmbhByajxh(ajxh)+1;
					for(WsssjlZkzmModel zmModel:model.getZkzmModelist() ){
						if(zmModel.getZkzm()!=null){
							WsSsjlZkzmDO zmDo = new WsSsjlZkzmDO(zmModel);
							zmDo.setAjxh(ajxh);
							zmDo.setZmbh(zmbh);
							zmDo.setZkjlbh(zkjlbh);
							wsSsjlZkzmDao.save(zmDo);
							zmbh++;
						}
					}
				}
			}
		}
	}
	@Override
	public void saveSsjlBatch(WsssjlModel wsssjlModel, int ajxh) {
		// TODO Auto-generated method stub
		wsSsjlDao.save(ajxh,wsssjlModel);
	}

}
