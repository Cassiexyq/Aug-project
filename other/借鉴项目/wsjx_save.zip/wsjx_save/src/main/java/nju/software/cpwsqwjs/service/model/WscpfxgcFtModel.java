package nju.software.cpwsqwjs.service.model;

import java.util.HashMap;

public class WscpfxgcFtModel {
	/**
	 * ���ɷ�������
	 */
	private String flftmc;
	/**
	 * ��������Map<��Ŀ����Ŀ>
	 */
	private HashMap<String,String> ftMap;
	public String getFlftmc() {
		return flftmc;
	}
	public void setFlftmc(String flftmc) {
		this.flftmc = flftmc;
	}
	public HashMap<String,String> getFtMap() {
		return ftMap;
	}
	public void setFtMap(HashMap<String,String> ftMap) {
		this.ftMap = ftMap;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		String ftStr = "";
		sb.append("��"+flftmc+"��");
		if(ftMap!=null){
			for(String key:ftMap.keySet()){
				if (key.length()<10){
					sb.append("��"+key+"��");
					if(!ftMap.get(key).equals("û�п�Ŀ")&&ftMap.get(key).length()<10){
						sb.append(ftMap.get(key));
					}else{
						sb.append("��");
					}
				}
			}
		}
		ftStr = sb.toString();
		if (ftStr.endsWith("��")){
			ftStr = ftStr.replace("��","");
		}
		ftStr = ftStr+";"+"\n";
		return ftStr;
	}
}
