package nju.software.cpwsqwjs.test;

import java.util.List;

import org.apache.xalan.xsltc.compiler.sym;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.AydmService;
import nju.software.cpwsqwjs.service.dataService.impl.AydmServiceImpl;
import nju.software.cpwsqwjs.service.impl.jtsg.CmssdpreServiceImpl;
import nju.software.cpwsqwjs.service.impl.jtsg.DsrbxgsServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.AjjbxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DmbServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrdwxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrgrxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrjgxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.LaayServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.SpryServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.WsJbServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.XxxServiceImpl;
import nju.software.cpwsqwjs.service.model.AydmModel;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;
import nju.software.cpwsqwjs.service.model.sp.LaayModel;
import nju.software.cpwsqwjs.service.model.sp.SpryxxModel;
import nju.software.cpwsqwjs.service.model.sp.WsJbModel;
import nju.software.cpwsqwjs.service.sp.Ajjbxxservice;
import nju.software.cpwsqwjs.service.sp.DmbService;
import nju.software.cpwsqwjs.service.sp.DsrdwxxService;
import nju.software.cpwsqwjs.service.sp.DsrgrxxService;
import nju.software.cpwsqwjs.service.sp.DsrjgxxService;
import nju.software.cpwsqwjs.service.sp.LaayService;
import nju.software.cpwsqwjs.service.sp.SpryService;
import nju.software.cpwsqwjs.service.sp.WsJbService;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.MoneyUtil;

public class Test3 {

	public static void main(String[] args){
		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
//		WsJbService wsJbService = new WsJbServiceImpl();
//		WsJbModel wsJbModel = wsJbService.getJaWsJbxxByAjxh(57421);
//		System.out.println(wsJbModel.getSfjaws());
//		System.out.println(wsJbModel.getWslb());
//		System.out.println(wsJbModel.getWsmc());
//				LaayService laayService = new LaayServiceImpl();
//		List<LaayModel> models= laayService.getLaayByAjxh(57421);
//		System.out.println(models.size());
		DmbService dmbService = new DmbServiceImpl();
		Ajjbxxservice ajjbxxservice = new AjjbxxServiceImpl();
		AjjbxxModel aj = ajjbxxservice.getAjjbxxByAjxh(1016);
		
		aj = ajjbxxservice.convertJafsFromDmToMs(aj );
		aj = ajjbxxservice.convertAjlyFromDmToMs(aj );
		aj = ajjbxxservice.setFymc(aj);
		
		XxxService xxxService = new XxxServiceImpl();
		
//		String lbbh = xxxService.getLbbhNew("dsrssdw", "DSR_JB", aj.getAjxz(), aj.getSpcx(), aj.getSpcxdz());
//		String lbbh = xxxService.getLbbhOld("dsrssdw", "DSR_JB", aj.getAjxz(), aj.getSpcx());
//		System.out.println("LBBH"+lbbh);
//		aj = ajjbxxservice.convertAjxzSpcxFromDmToMs(aj);
//		System.out.println("larq"+aj.getLarqStr());
//		System.out.println("ah"+aj.getAh());
//		System.out.println("spcx"+aj.getSpcx());
//		System.out.println("sycx"+aj.getSycx());
//		System.out.println("fymc"+aj.getFymc());
//		System.out.println("ajxz"+aj.getAjxz());
//		System.out.println("jafs"+aj.getJafs());
//		System.out.println("ajly"+aj.getAjly());
//		LaayService laayService = new LaayServiceImpl();
//		 List<LaayModel> list = laayService.getLaayByAjxh(57378);
//		 System.out.println(list.size());
//		SpryService service = new SpryServiceImpl();
//		List<SpryxxModel> lists = service.getSpryxxByAjxh(57378);
//		System.out.println(lists.size());
//		���Ը��˵�����
//		DsrgrxxService dsrgrxxService = new DsrgrxxServiceImpl();
//		List<DsrgrxxModel> models =dsrgrxxService.getDsrgrxxByAjxh(57378,aj);
//		System.out.println("���ϵ�λ��"+models.get(0).getDsrssdw());
//		System.out.println("������"+models.get(0).getXm());
//		System.out.println("�Ա�"+models.get(0).getXb());
//		System.out.println("���������գ�"+models.get(0).getCsnyr());
//		System.out.println("���壺"+models.get(0).getMz());
//		System.out.println("�������ң�"+models.get(0).getSsgj());
//		System.out.println("֤�����"+models.get(0).getZjlb());
//		System.out.println("����֤���룺"+models.get(0).getSfzhm());
//		System.out.println("��ַ��"+models.get(0).getDz());
//		���Ե�λ������
		DsrdwxxService dsrdwxxService = new DsrdwxxServiceImpl();
		List<DsrdwxxModel> model1 = dsrdwxxService.getDsrdwxxByAjxh(1071,aj);
		System.out.println("���ϵ�λ��"+model1.get(0).getDsrssdw());
		DsrjgxxService dsrjgxxService = new DsrjgxxServiceImpl();
		List<DsrjgxxModel> model2 = dsrjgxxService.getDsrjgxxByAjxh(1016,aj);
		System.out.println("���ϵ�λ��"+model2.get(0).getDsrssdw());
		} 
}
