package nju.software.cpwsqwjs.service.model;

import java.util.List;

import nju.software.cpwsqwjs.business.WsAnalyse;

public class XzzsWsjxModel {

	private WswsModel ws;
	private WscpfxgcModel cpfxgc;
	private WsajjbqkModel ajjbqk;
	private WsssjlModel ssjl;
	private WscpjgModel pjjg;
	private List<WssscyrModel> sscyr;
	
	private WsfdModel wsfdModel;
	public XzzsWsjxModel() {
		super();
	}
	

	public XzzsWsjxModel(WswsModel ws, WscpfxgcModel cpfxgc,
			WsajjbqkModel ajjbqk, WsssjlModel ssjl, WscpjgModel pjjg,
			List<WssscyrModel> sscyr, WsfdModel wsfdModel) {
		super();
		this.ws = ws;
		this.cpfxgc = cpfxgc;
		this.ajjbqk = ajjbqk;
		this.ssjl = ssjl;
		this.pjjg = pjjg;
		this.sscyr = sscyr;
		this.wsfdModel = wsfdModel;
	}


	public WswsModel getWs() {
		return ws;
	}
	public void setWs(WswsModel ws) {
		this.ws = ws;
	}
	public WscpfxgcModel getCpfxgc() {
		return cpfxgc;
	}
	public void setCpfxgc(WscpfxgcModel cpfxgc) {
		this.cpfxgc = cpfxgc;
	}
	public WsajjbqkModel getAjjbqk() {
		return ajjbqk;
	}
	public void setAjjbqk(WsajjbqkModel ajjbqk) {
		this.ajjbqk = ajjbqk;
	}
	public WsssjlModel getSsjl() {
		return ssjl;
	}
	public void setSsjl(WsssjlModel ssjl) {
		this.ssjl = ssjl;
	}
	public WscpjgModel getPjjg() {
		return pjjg;
	}
	public void setPjjg(WscpjgModel pjjg) {
		this.pjjg = pjjg;
	}
	public List<WssscyrModel> getSscyr() {
		return sscyr;
	}
	public void setSscyr(List<WssscyrModel> sscyr) {
		this.sscyr = sscyr;
	}

	public WsfdModel getWsfdModel() {
		return wsfdModel;
	}

	public void setWsfdModel(WsfdModel wsfdModel) {
		this.wsfdModel = wsfdModel;
	}
	
	
}
