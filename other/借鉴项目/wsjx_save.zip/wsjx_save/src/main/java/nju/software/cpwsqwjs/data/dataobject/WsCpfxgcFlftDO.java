package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WswwModel;

/**
 * WsCpfxgcFlftDO entity. @author MyEclipse Persistence Tools
 * ���з������� ���ɷ���
 */
@Entity
@Table(name = "WS_CPFXGC_FLFT")
@IdClass(WsCpfxgcFlftDoId.class)
public class WsCpfxgcFlftDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer ftbh;//�������
	private String ftmc;//����
	private String tk;//����
	/** default constructor */
	public WsCpfxgcFlftDO() {
	}

	/** minimal constructor */
	public WsCpfxgcFlftDO(Integer ajxh, Integer ftbh) {
		this.ajxh = ajxh;
		this.ftbh = ftbh;
	}

	public WsCpfxgcFlftDO(Integer ajxh, Integer ftbh, String ftmc, String tk) {
		super();
		this.ajxh = ajxh;
		this.ftbh = ftbh;
		this.ftmc = ftmc;
		this.tk = tk;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	@Id
	@Column(name = "FTBH", nullable = false)
	public Integer getFtbh() {
		return ftbh;
	}

	public void setFtbh(Integer ftbh) {
		this.ftbh = ftbh;
	}
	@Column(name = "FTMC", length = 200)
	public String getFtmc() {
		return ftmc;
	}

	public void setFtmc(String ftmc) {
		this.ftmc = ftmc;
	}
	@Column(name = "TK", length = 255)
	public String getTk() {
		return tk;
	}

	public void setTk(String tk) {
		this.tk = tk;
	}

	 
}