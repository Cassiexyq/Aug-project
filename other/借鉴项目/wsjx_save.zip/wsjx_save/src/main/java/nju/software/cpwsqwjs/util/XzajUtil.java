package nju.software.cpwsqwjs.util;

import java.util.ArrayList;
import java.util.StringTokenizer;

import nju.software.cpwsqwjs.service.model.sp.DmbModel;


/**
 * ���г������ƥ�乤����
 * @author byron
 *
 */
public class XzajUtil {
	public static boolean match(String bz, String ajxz, String spcx) {
		if (ajxz.startsWith("0")) {
			ajxz = ajxz.substring(1);
		}
		if (spcx.startsWith("0")) {
			spcx = spcx.substring(1);
		}
		
		if (bz.contains(";")) {
			StringTokenizer st = new StringTokenizer(bz,";");
			while (st.hasMoreTokens()) {
				String token = st.nextToken();
				if (token.equals(ajxz + spcx)) {
					return true;
				}
			}
			return false;
		} else {
			if (bz.equals(ajxz + spcx)) {
				return true;
			} else {
				/*if (bz.equals(ajxz + "*")) {
					return true;
				} else {
					return false;
				}*/
				return false;
			}
		}
	}
	
	/**
	 * 
	 * @param bz ���г�����ֵ���ش���  
	 * @param xgdm
	 * @return
	 */
	public static boolean matchNewSpcxdz(String bz, String xgdm) {
//		if (ajxz.startsWith("0")) {
//			ajxz = ajxz.substring(1);
//		}
//		if (spcx.startsWith("0")) {
//			spcx = spcx.substring(1);
//		}
		
		if (bz.contains(";")) {
			StringTokenizer st = new StringTokenizer(bz,";");
			while (st.hasMoreTokens()) {
				String token = st.nextToken();
				if (token.equals(xgdm)) {
					return true;
				}
			}
			return false;
		} else {
			if (bz.equals(xgdm)) {
				return true;
			} else {
				return false;
			}
		}
	}
	//����ŷ���get(1), num ����get(2)
	public static ArrayList<String> getLbbh(String xglbbh){
		
		ArrayList<String> result = new ArrayList<String>();
		
		String t_xglbbh = xglbbh.trim();
		int index = t_xglbbh.indexOf(',');
		String num2;
		String t_lbbh;
		if (index < 0) {
			num2 = "%";
			t_lbbh = t_xglbbh;
		} else {
			num2 = t_xglbbh.substring(index + 1, t_xglbbh.length());
			t_lbbh = t_xglbbh.substring(0, index);
		}
		if (t_lbbh.charAt(0) == '%')
			t_lbbh = t_lbbh.substring(1);
		if (t_lbbh.charAt(t_lbbh.length() - 1) == '%')
			t_lbbh = t_lbbh.substring(0, t_lbbh.length() - 1);
		
		result.add("");
		result.add(t_lbbh);
		result.add(num2);
		result.add("");
		result.add("");
		return result;
	}
	/**
	 * �°���12BFBS2015-QWQWQW,����12B��������
	 * @param lbbh
	 * @param dmbh ��Ҫƥ��������
	 * @return
	 */
	public static String getLbbhNew(String lbbh,String dmbh){
//		lbbh="1F1FBS2015-AJLY01,1F2FBS2015-AJLY02,2F1FBS2015-AJLY01,2F2FBS2015-AJLY02," +
//				"2F3FBS2015-AJLY03,2E0FBS2015-AJLY15,2F4FBS2015-AJLY04,2F5FBS2015-AJLY05,2F6FBS2015-AJLY06," +
//				"6E1FBS2015-AJLY01,6E2FBS2015-AJLY02,6E3FBS2015-AJLY05,7G1FBS2015-AJLY02," +
//				"7G2FBS2015-AJLY04,7G3FBS2015-AJLY05,110FBS2015-AJLY37,120FBS2015-AJLY38,131FBS2015-AJLY11," +
//				"132FBS2015-AJLY39,133FBS2015-AJLY17,134FBS2015-AJLY40,1B0FBS2015-AJLY07,141FBS2015-AJLY13," +
//				"142FBS2015-AJLY13,143FBS2015-AJLY13,1C1FBS2015-AJLY07,1C2FBS2015-AJLY08,1C3FBS2015-AJLY08," +
//				"1C4FBS2015-AJLY09,1D1FBS2015-AJLY10,1D2FBS2015-AJLY11,1D3FBS2015-AJLY12,1D4FBS2015-AJLY13," +
//				"1E1FBS2015-AJLY41,1E2FBS2015-AJLY42,1E3FBS2015-AJLY13,1Z0FBS2015-AJLY13,210FBS2015-AJLY43," +
//				"220FBS2015-AJLY44,231FBS2015-AJLY11,2Z0FBS2015-AJLY13,232FBS2015-AJLY16,233FBS2015-AJLY17,234FBS2015-AJLY45," +
//				"2D0FBS2015-AJLY14,241FBS2015-AJLY14,242FBS2015-AJLY08,243FBS2015-AJLY46,244FBS2015-AJLY08," +
//				"245FBS2015-AJLY47,246FBS2015-AJLY14,247FBS2015-AJLY08,248FBS2015-AJLY08,249FBS2015-AJLY08," +
//				"24AFBS2015-AJLY20,24BFBS2015-AJLY48,261FBS2015-AJLY20,262FBS2015-AJLY20,251FBS2015-AJLY20," +
//				"252FBS2015-AJLY49,271FBS2015-AJLY50,272FBS2015-AJLY15,273FBS2015-AJLY13,610FBS2015-AJLY51," +
//				"620FBS2015-AJLY44,631FBS2015-AJLY11,632FBS2015-AJLY16,633FBS2015-AJLY17,634FBS2015-AJLY45," +
//				"6D1FBS2015-AJLY08,6D2FBS2015-AJLY15,6Z0FBS2015-AJLY13,7B1FBS2015-AJLY51,7B2FBS2015-AJLY44," +
//				"7B3FBS2015-AJLY11,7B4FBS2015-AJLY16,7B5FBS2015-AJLY17,7B6FBS2015-AJLY45,7C1FBS2015-AJLY52," +
//				"7C2FBS2015-AJLY53,7C3FBS2015-AJLY54,7C4FBS2015-AJLY18,7C5FBS2015-AJLY55,7F0FBS2015-AJLY13," +
//				"7E1FBS2015-AJLY19,7E2FBS2015-AJLY19,7E3FBS2015-AJLY19,7E4FBS2015-AJLY19,7E5FBS2015-AJLY19," +
//				"7E6FBS2015-AJLY19,7F0FBS2015-AJLY13,B11FBS2015-AJLY20,B12FBS2015-AJLY20,B13FBS2015-AJLY20," +
//				"B14FBS2015-AJLY20,B15FBS2015-AJLY20,B16FBS2015-AJLY20,B17FBS2015-AJLY20,B18FBS2015-AJLY13," +
//				"B21FBS2015-AJLY21,B22FBS2015-AJLY21,B23FBS2015-AJLY21,B24FBS2015-AJLY22,B25FBS2015-AJLY23," +
//				"B26FBS2015-AJLY24,B27FBS2015-AJLY23,B28FBS2015-AJLY25,B29FBS2015-AJLY23,B31FBS2015-AJLY21," +
//				"B32FBS2015-AJLY21,B33FBS2015-AJLY26,B34FBS2015-AJLY22,B35FBS2015-AJLY23,B36FBS2015-AJLY24," +
//				"B37FBS2015-AJLY23,B38FBS2015-AJLY25,B39FBS2015-AJLY23,B41FBS2015-AJLY27,B42FBS2015-AJLY28," +
//				"B51FBS2015-AJLY28,B52FBS2015-AJLY29,C11FBS2015-AJLY30,C12FBS2015-AJLY31,C13FBS2015-AJLY13," +
//				"C21FBS2015-AJLY32,C22FBS2015-AJLY22,C23FBS2015-AJLY21,C31FBS2015-AJLY32,C32FBS2015-AJLY23," +
//				"C33FBS2015-AJLY21,C41FBS2015-AJLY27,C42FBS2015-AJLY33,C51FBS2015-AJLY34,C52FBS2015-AJLY35," +
//				"D11FBS2015-AJLY36,D12FBS2015-AJLY36,D20FBS2015-AJLY20,E10FBS2015-AJLY08,E20FBS2015-AJLY08," +
//				"E30FBS2015-AJLY08,E40FBS2015-AJLY08,8B1FBS2015-AJLY56,8B2FBS2015-AJLY19,8B3FBS2015-AJLY57," +
//				"8C1FBS2015-AJLY58,8C2FBS2015-AJLY59,8C3FBS2015-AJLY60,8C4FBS2015-AJLY13";
		String temp="";
		lbbh=StringUtil.NullToEmpty(lbbh);
		dmbh=StringUtil.NullToEmpty(dmbh);
		if(lbbh.equals("")){
			return "";
		}else{
			if (lbbh.contains(",")) {
				StringTokenizer st = new StringTokenizer(lbbh,",");
				while (st.hasMoreTokens()) {
					String token = st.nextToken();
					temp = token.substring(0, 3);
					if (temp.equals(dmbh)) {
						return token.substring(3,token.length());
					}
				}
			} else {
				temp = lbbh.substring(0, 3);
				if (temp.equals(dmbh)) {
					return lbbh.substring(3, lbbh.length());
				} 
			}
		}
		return "";
	}
	
	public static void setDmModel(DmbModel dmModel, ArrayList<String> result){
		String nextXgdm = dmModel.getXgdm();
		if (nextXgdm == null)
			result.set(0, "");
		else
			result.set(0, dmModel.getXgdm().trim());

		String nextBz = dmModel.getBz();
		if (nextBz == null)
			result.set(3, "");
		else
			result.set(3, dmModel.getBz().trim());

		String nextDmms = dmModel.getDmms();
		if (nextDmms == null)
			result.set(4, "");
		else
			result.set(4, dmModel.getDmms().trim());

	}
	
	public static boolean match(DmbModel dmModel, String spcx, String ajxz){
		if(!StringUtil.equals(spcx, "3")||StringUtil.equals(ajxz, "7"))
			return true;
		else{
			if(StringUtil.indexOf(dmModel.getDmms(), "��")==dmModel.getDmms().length()-1
					||StringUtil.contains(dmModel.getDmms(), "��")
					||StringUtil.indexOf(dmModel.getDmms(), "��")==dmModel.getDmms().length()-1
					||StringUtil.indexOf(dmModel.getDmms(), "��")==dmModel.getDmms().length()-1
					||StringUtil.indexOf(dmModel.getDmms(), "��")==dmModel.getDmms().length()-1)
				return true;
			else
				return false;
		}
		
	}
	
	public static boolean ajlyFilter(DmbModel dmModel){
		if(StringUtil.equals(dmModel.getDmbh(), "1000")
				||StringUtil.equals(dmModel.getDmbh(), "1200")
				||StringUtil.equals(dmModel.getDmbh(), "1230")
				||StringUtil.equals(dmModel.getDmbh(), "2000")
				||StringUtil.equals(dmModel.getDmbh(), "2200"))
			return false;
		if(dmModel.getDmms()=="���º���"||dmModel.getDmms()=="֪ʶ��Ȩ"||dmModel.getDmms()=="���º���")
			return false;
		return true;
	}
	
	public static boolean bycxdzFilter(DmbModel dmModel, String spcxdz) {
		if(StringUtil.equals(dmModel.getDmbh(), spcxdz)){
			return true;
		}
		if(StringUtil.contains(dmModel.getXgdm(), spcxdz))
			return true;
		return false;
	}
	public static String getLbbhByColumn(String ajxz, String spcx,String column_code) {
		if (!StringUtil.isBlank(ajxz))
			ajxz = StringUtil.trim(ajxz);
		if (!StringUtil.isBlank(spcx))
			spcx = StringUtil.trim(spcx);
		// ������Դ���⴦��
//		if (StringUtil.equals(tableName, "PUB_AJ_JB")
//				&& StringUtil.equals(columnName, "AJLY")) {
//			List<DmbModel> spcxs = spcxMap.get(ajxz);
//			for (DmbModel dm : spcxs) {
//				if (StringUtil.equals(dm.getDmbh(), spcx)) {
//					return StringUtil.replace(dm.getXgdm(), "%", "");
//				}
//			}
//		}


		String temp_ajxz = ajxz;
		if (temp_ajxz.equals("2") || temp_ajxz.equals("3")
				|| temp_ajxz.equals("4") || temp_ajxz.equals("5"))
			temp_ajxz = "2";

		// ��ñ�ע
//		String column_code = xxxService.getLbbhByTableAndColumn(tableName,
//				columnName, -1);

		if (StringUtil.indexOf(column_code, ",") < 0) {
			return column_code;
		}
		String temp_spcx = spcx;

		if (ajxz.equals("A") && spcx.equals("2")) {
			temp_ajxz = "A";
			temp_spcx = "2";
		}
		String toFind = column_code;
		int index = toFind.indexOf(temp_ajxz + temp_spcx);
		if (index > 0
				&& !StringUtil.equals(toFind.substring(index - 1, index), ",")) {
			index = -1;
		}
		if (index == -1) {
			index = toFind.indexOf(temp_ajxz + "*");
		}
		if (index == -1) {
			String errStr = "getCasecode() �޷�ƥ����ش��룡" + " temp_ajxz��"
					+ temp_ajxz + ",temp_spcx�� " + temp_spcx + ", sjxx:"
					+ toFind;
			return "";
		}

		String lbbh = "";

		int endIndex = toFind.indexOf(",", index);
		if (endIndex == -1) {
			lbbh = toFind.substring(index + 2, toFind.length());
		} else {
			lbbh = toFind.substring(index + 2, endIndex);
		}
		return lbbh;
	}
}
