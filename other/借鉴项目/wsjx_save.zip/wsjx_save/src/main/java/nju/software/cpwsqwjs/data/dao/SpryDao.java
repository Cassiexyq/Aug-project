package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.SpryDO;
import nju.software.cpwsqwjs.data.dataobject.SpryDOId;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


/**
 * A data access object (DAO) providing persistence and search support for
 * SpryDO entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see nju.software.cpwsqwjs.data.dataobject.SpryDO
 * @author MyEclipse Persistence Tools
 */

public class SpryDao extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory.getLogger(SpryDao.class);
	// property constants
	public static final String FG = "fg";
	public static final String SFCBR = "sfcbr";
	public static final String SFSPZ = "sfspz";
	public static final String SFDLSPY = "sfdlspy";
	public static final String SFRMPSY = "sfrmpsy";
	public static final String XM = "xm";

	protected void initDao() {
		// do nothing
	}

	public void save(SpryDO transientInstance) {
		log.debug("saving SpryDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(SpryDO persistentInstance) {
		log.debug("deleting SpryDO instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public SpryDO findById(SpryDOId id) {
		log.debug("getting SpryDO instance with id: " + id);
		try {
			SpryDO instance = (SpryDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.SpryDO", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<SpryDO> findByExample(SpryDO instance) {
		log.debug("finding SpryDO instance by example");
		try {
			List<SpryDO> results = (List<SpryDO>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding SpryDO instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from SpryDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List<SpryDO> findByFg(Object fg) {
		return findByProperty(FG, fg);
	}

	public List<SpryDO> findBySfcbr(Object sfcbr) {
		return findByProperty(SFCBR, sfcbr);
	}

	public List<SpryDO> findBySfspz(Object sfspz) {
		return findByProperty(SFSPZ, sfspz);
	}

	public List<SpryDO> findBySfdlspy(Object sfdlspy) {
		return findByProperty(SFDLSPY, sfdlspy);
	}

	public List<SpryDO> findBySfrmpsy(Object sfrmpsy) {
		return findByProperty(SFRMPSY, sfrmpsy);
	}

	public List<SpryDO> findByXm(Object xm) {
		return findByProperty(XM, xm);
	}

	public List findAll() {
		log.debug("finding all SpryDO instances");
		try {
			String queryString = "from SpryDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public SpryDO merge(SpryDO detachedInstance) {
		log.debug("merging SpryDO instance");
		try {
			SpryDO result = (SpryDO) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(SpryDO instance) {
		log.debug("attaching dirty SpryDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(SpryDO instance) {
		log.debug("attaching clean SpryDO instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static SpryDao getFromApplicationContext(ApplicationContext ctx) {
		return (SpryDao) ctx.getBean("spryDao");
	}
	
	public int add(SpryDO transientInstance) {
		log.debug("saving SpryDO instance");
		try {
			//session.beginTransaction();
			getHibernateTemplate().save(transientInstance);
			//session.getTransaction().commit();
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
		return transientInstance.getAjxh();
	}
	
	public List<SpryDO> getSpryByAjxh(Integer ajxh)
	{
		String hql = "from SpryDO where ajxh = " + ajxh;
		if(log.isInfoEnabled()){
			log.info("getAyDmListBySjdm by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}
	
	public SpryDO getSpryByAjxhAndSprybh(Integer ajxh , Integer sprybh)
	{
		String hql = "from SpryDO where ajxh = " + ajxh + " and SPRYBH = " + sprybh;
		if(log.isInfoEnabled()){
			log.info("getAyDmListBySjdm by sql: " + hql);
		}
		List<SpryDO> tempData = getHibernateTemplate().find(hql);
		return tempData.isEmpty() ? null : tempData.get(0);
	}
	
	public SpryDO getCbrByAjxh(Integer ajxh)
	{
		String hql = "from SpryDO where ajxh = " + ajxh + " and sfcbr = 'Y'";
		if(log.isInfoEnabled()){
			log.info("getAyDmListBySjdm by sql: " + hql);
		}
		List<SpryDO> tempData = getHibernateTemplate().find(hql);
		return tempData.isEmpty() ? null : tempData.get(0);
	}
	
	public Integer getMaxSprybhByAjxh(Integer ajxh) {
		String hql = "select max(sprybh) from SpryDO where ajxh=" + ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);
		Integer maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Integer)query.uniqueResult();
		// �ͷ����ݿ�����
		this.releaseSession(s);
		return maxbh;
	}
	
	public List<SpryDO> getSpryByAjxhAndNotSpzAndCpr(Integer ajxh)
	{
		String hql = "from SpryDO where ajxh = " +ajxh+ " and ( sfcbr <> 'Y' or sfcbr = null) AND  " +
				"( sfspz <> 'Y' or sfspz = null) AND  " +
				"( fg = '1' )";
		if(log.isInfoEnabled()){
			log.info("getSpryByAjxhAndEmpty by sql: " + hql);
		}
		List<SpryDO> tempData = getHibernateTemplate().find(hql);
		return tempData.size() == 0 ? null : tempData;
	}
	
	/**
	 * ���ݰ������ɾ��������������Ա��Ϣ
	 * @param ajxh �������
	 * @return �Ƿ�ɹ�ɾ��
	 */
	public boolean deleteSpryByAjxh(Integer ajxh)
	{
		String hql = "delete from SpryDO where ajxh = " +ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);
		if (log.isInfoEnabled()) {
			log.info("deleteSpryByAjxh with ajxhh = " + ajxh);
		}
		query.executeUpdate();
		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return true;
	}
}