package nju.software.cpwsqwjs.data.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.LaAyDO;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


/**
 * A data access object (DAO) providing persistence and search support for
 * LaAyDO entities. Transaction control of the save(), update() and delete()
 * operations can directly support Spring container-managed transactions or they
 * can be augmented to handle user-managed Spring transactions. Each of these
 * methods provides additional information for how to configure it for the
 * desired type of transaction control.
 * 
 * @see nju.software.cpwsqwjs.data.dataobject.LaAyDO
 * @author MyEclipse Persistence Tools
 */

public class LaAyDao extends HibernateDaoSupport {
	private static final Logger log = LoggerFactory.getLogger(LaAyDao.class);
	// property constants
	public static final String AY = "ay";
	public static final String LAAY = "laay";

	protected void initDao() {
		// do nothing
	}

	public void save(LaAyDO transientInstance) {
		log.debug("saving LaAyDO instance");
//		Session s = getSession();
		try {
			getHibernateTemplate().saveOrUpdate(transientInstance);
//			s.flush();
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}finally{
//			this.releaseSession(s);
		}
	}

	public void delete(LaAyDO persistentInstance) {
		log.debug("deleting LaAyDO instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public LaAyDO findById(nju.software.cpwsqwjs.data.dataobject.LaAyDOId id) {
		log.debug("getting LaAyDO instance with id: " + id);
		try {
			LaAyDO instance = (LaAyDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.LaAyDO", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<LaAyDO> findByExample(LaAyDO instance) {
		log.debug("finding LaAyDO instance by example");
		try {
			List<LaAyDO> results = (List<LaAyDO>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding LaAyDO instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from LaAyDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List<LaAyDO> findByAy(Object ay) {
		return findByProperty(AY, ay);
	}

	public List<LaAyDO> findByLaay(Object laay) {
		return findByProperty(LAAY, laay);
	}

	public List findAll() {
		log.debug("finding all LaAyDO instances");
		try {
			String queryString = "from LaAyDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public LaAyDO merge(LaAyDO detachedInstance) {
		log.debug("merging LaAyDO instance");
		try {
			LaAyDO result = (LaAyDO) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(LaAyDO instance) {
		log.debug("attaching dirty LaAyDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(LaAyDO instance) {
		log.debug("attaching clean LaAyDO instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}
	
	public synchronized long getMaxLaaybh(long ajxh) {
		String hql = "select max(laaybh) from LaAyDO where ajxh="+ajxh;
		
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Integer) query.uniqueResult();
		
		//�ͷ����ݿ�����
		this.releaseSession(s);
		
		return maxbh;
	}

	public static LaAyDao getFromApplicationContext(ApplicationContext ctx) {
		return (LaAyDao) ctx.getBean("LaAyDODAO");
	}
	
	/**
	 * �õ�ָ��������ŵİ�������
	 * @param ajxh �������
	 * @return �����б�
	 */
	public List<LaAyDO> getLaayListByAjxh(int ajxh)
	{
		String hql = "from LaAyDO where ajxh = "+ajxh ;
		if(log.isInfoEnabled())
			log.info("getLaayByAjxh by sql: " + hql);
		return getHibernateTemplate().find(hql);
	}
	
//	/**
//	 * ͨ��������źͽ᰸���ɱ�Ż�ȡ��������а��ɵ�����
//	 * @param ajxh
//	 * @param jaaybh ���ɱ��
//	 * @return ��������VO
//	 */
//	public AyXxbVO getWsbgJaayByAjxhAndLaaybh(long ajxh , long laaybh)
//	{
//		String sql = "SELECT B_AY.MC , PUB_LA_AY.AY FROM PUB_LA_AY LEFT JOIN PUB_AYDMB ON (PUB_AYDMB.DMBH=PUB_LA_AY.AY) , B_AY WHERE PUB_LA_AY.AJXH="+ajxh+" AND PUB_LA_AY.LAAYBH="+laaybh+" AND PUB_AYDMB.AYDM_5 = B_AY.DM";
//		ConnectionProvider cp = null;
//		Connection connection = null;
//		Statement statement = null;
//		ResultSet resultSet = null;
//		AyXxbVO laayXxbVO = null;
//		try {
//			cp = ((SessionFactoryImplementor) this
//					.getSessionFactory()).getConnectionProvider();
//			connection = cp.getConnection();
//			statement = connection.createStatement();
//			resultSet = statement.executeQuery(sql);
//			while (resultSet.next()) {
//				laayXxbVO = new AyXxbVO();
//				laayXxbVO.setAjxh(ajxh);
//				laayXxbVO.setAybh(laaybh);
//				laayXxbVO.setAydmbh(resultSet.getString("AY"));
//				laayXxbVO.setAyms(resultSet.getString("MC"));
//			}
//		} catch (SQLException e) {
//			log.error("Wrong sql:" + sql, e);
//		}finally {
//			try {
//				if (resultSet != null)
//					resultSet.close();
//				if (statement != null)
//					statement.close();
//				if (cp != null)
//					cp.closeConnection(connection);
//			} catch (SQLException e) {
//				log.error("�ر����ݿ����ӳ�����",e);
//			}
//		}
//		return laayXxbVO;
//	}
//	
//	/**
//	 * ͨ��������Ż�ȡ��������а��ɵ�����
//	 * @param ajxh
//	 * @return ������������
//	 */
//	public List<AyXxbVO> getWsbgJaayByAjxh(long ajxh)
//	{
//		String sql = "SELECT PUB_LA_AY.LAAY ,PUB_LA_AY.LAAYBH, PUB_LA_AY.AY FROM PUB_LA_AY WHERE PUB_LA_AY.AJXH="+ajxh;
//		ConnectionProvider cp = null;
//		Connection connection = null;
//		Statement statement = null;
//		ResultSet resultSet = null;
//		List<AyXxbVO> laayXxbVOs = new ArrayList<AyXxbVO>();
//		try {
//			cp = ((SessionFactoryImplementor) this
//					.getSessionFactory()).getConnectionProvider();
//			connection = cp.getConnection();
//			statement = connection.createStatement();
//			resultSet = statement.executeQuery(sql);
//			while (resultSet.next()) {
//				AyXxbVO laayXxbVO = new AyXxbVO();
//				laayXxbVO.setAjxh(ajxh);
//				laayXxbVO.setAybh(resultSet.getLong("LAAYBH"));
//				laayXxbVO.setAydmbh(resultSet.getString("AY"));
//				laayXxbVO.setAyms(resultSet.getString("LAAY"));
//				laayXxbVOs.add(laayXxbVO);
//			}
//		} catch (SQLException e) {
//			log.error("Wrong sql:" + sql, e);
//		}finally {
//			try {
//				if (resultSet != null)
//					resultSet.close();
//				if (statement != null)
//					statement.close();
//				if (cp != null)
//					cp.closeConnection(connection);
//			} catch (SQLException e) {
//				log.error("�ر����ݿ����ӳ�����",e);
//			}
//		}
//		return laayXxbVOs;
//	}
}