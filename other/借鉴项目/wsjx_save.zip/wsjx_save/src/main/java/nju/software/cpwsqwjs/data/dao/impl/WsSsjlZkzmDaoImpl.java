package nju.software.cpwsqwjs.data.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsSsjlZkzmDao;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlZkzmDO;

public class WsSsjlZkzmDaoImpl extends HibernateDaoSupport implements WsSsjlZkzmDao{

	@Override
	public int save(WsSsjlZkzmDO zmDo) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().save(zmDo);
			return zmDo.getZmbh();
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public int getMaxzmbhByajxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(zmbh) from WsSsjlZkzmDO where ajxh="+ajxh;

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxAjxh = 0;
		if (query.uniqueResult() != null)
			maxAjxh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxAjxh;
	}

}
