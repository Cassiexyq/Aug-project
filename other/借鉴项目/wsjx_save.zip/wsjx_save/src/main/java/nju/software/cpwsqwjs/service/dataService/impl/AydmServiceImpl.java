package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.AydmDao;
import nju.software.cpwsqwjs.data.dao.FydmDao;
import nju.software.cpwsqwjs.data.dataobject.AydmbDO;
import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.service.dataService.AydmService;
import nju.software.cpwsqwjs.service.model.AydmModel;
import nju.software.cpwsqwjs.util.StringUtil;

public class AydmServiceImpl implements AydmService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	private static AydmDao aydmDao;
	static{
		aydmDao = (AydmDao) appContext.getBean("aydmDao");
	}
	@Override
	public List<AydmModel> getAllAy() {
		// TODO Auto-generated method stub
		ArrayList<AydmModel> models = new ArrayList<AydmModel>();
		List<AydmbDO> list = aydmDao.getAll();
		for(AydmbDO dmDo:list){
			AydmModel model = new AydmModel(dmDo);
			models.add(model);
		}
		return models;
	}
	@Override
	public boolean save(AydmModel model) {
		// TODO Auto-generated method stub
		AydmbDO aydm = new AydmbDO(model);
		return aydmDao.save(aydm);
	}
	@Override
	public AydmModel getAydm(String property, String value) {
		// TODO Auto-generated method stub
		List<AydmbDO> list = aydmDao.findByProperty(property, value);
		if(list.size()>0){
			return new AydmModel(list.get(0));
		}
		return null;
	}
	@Override
	public AydmModel getAydmBySjdm(String value) {
		// TODO Auto-generated method stub
		AydmbDO dmDo = aydmDao.findBySjdm(value);
		if(dmDo!=null){
			AydmModel model = new AydmModel(dmDo);
			return model;
		}
		return null;
	}
	@Override
	public HashMap<String, AydmModel> getAll() {
		// TODO Auto-generated method stub
		List<AydmModel> models = this.getAllAy();
		HashMap<String, AydmModel> map = new HashMap<String, AydmModel>();
		for(AydmModel model:models){
			map.put(model.getAydmbh(), model);
		}
		return map;
	}
	@Override
	public void setAyjb(AydmModel model,HashMap<String, AydmModel> map) {
		// TODO Auto-generated method stub
		String aydm = model.getAydmbh();
		int count = 0;
		if(map.containsKey(aydm)){
			AydmModel ay1 = map.get(aydm);
			count++;
			if(ay1!=null && !StringUtil.isBlank(ay1.getSjdm()) && !StringUtil.equals("-", ay1.getSjdm())&&
					!StringUtil.equals("��", ay1.getSjdm())
					&& map.containsKey(ay1.getSjdm())){
				AydmModel ay2 = map.get(ay1.getSjdm());
				count++;
				if(ay2!=null && !StringUtil.isBlank(ay2.getSjdm()) && !StringUtil.equals("-", ay2.getSjdm())&&
						!StringUtil.equals("��", ay2.getSjdm())
						&& map.containsKey(ay2.getSjdm())){
					AydmModel ay3 = map.get(ay2.getSjdm());
					count++;
					if(ay3!=null && !StringUtil.isBlank(ay3.getSjdm()) && !StringUtil.equals("-", ay3.getSjdm())&&
							!StringUtil.equals("��", ay3.getSjdm())
							&& map.containsKey(ay3.getSjdm())){
						AydmModel ay4 = map.get(ay3.getSjdm());
						count++;
						if(ay4!=null && !StringUtil.isBlank(ay4.getSjdm()) && !StringUtil.equals("-", ay4.getSjdm())&&
								!StringUtil.equals("��", ay4.getSjdm())
								&& map.containsKey(ay4.getSjdm())){
							count++;
						}
					}
				}
			}
		}
		if(count>1){
			model.setAyjb(count-1);
			this.save(model);
		}
	}
	@Override
	public AydmModel getAydmByAydmbh(String value) {
		// TODO Auto-generated method stub
		AydmbDO dmDo = aydmDao.findByDmbh(value);
		if(dmDo!=null){
			AydmModel model = new AydmModel(dmDo);
			return model;
		}
		return null;
	}
	@Override
	public WssxbDo setAy(WssxbDo wssx, String aydm,
			HashMap<String, AydmModel> map) {
		// TODO Auto-generated method stub
		AydmModel ay = map.get(aydm);
		if(ay!=null){
			int ayjb = ay.getAyjb();
			wssx.setAycj(ayjb);
//			һ������
			if(ayjb==1){
				wssx.setYjaydm(aydm);
				wssx.setYjaymc(ay.getAymc());
				return wssx;
			}
//			��������
			if(ayjb==2){
				wssx.setEjaydm(aydm);
				wssx.setEjaymc(ay.getAymc());
				String sjdm = ay.getSjdm();
				if(!StringUtil.isBlank(sjdm)){
//					AydmbDO ay1 = aydmDao.findByDmbh(sjdm);
					AydmModel ay1 = map.get(sjdm);
					if(ay1!=null){
						wssx.setYjaydm(ay1.getAydmbh());
						wssx.setYjaymc(ay1.getAymc());
					}
				}
				return wssx;
			}
//			��������
			if(ayjb==3){
				wssx.setSjaydm(aydm);
				wssx.setSjaymc(ay.getAymc());
				String sjdm = ay.getSjdm();
				if(!StringUtil.isBlank(sjdm)){
//					AydmbDO ay2 = aydmDao.findByDmbh(sjdm);//��������
					AydmModel ay2 = map.get(sjdm);
					if(ay2!=null){
						wssx.setEjaydm(ay2.getAydmbh());
						wssx.setEjaymc(ay2.getAymc());
						String sjdm1 = ay2.getSjdm();
						if(!StringUtil.isBlank(sjdm)){
//							AydmbDO ay1 = aydmDao.findByDmbh(sjdm1);//һ������
							AydmModel ay1 = map.get(sjdm1);
							if(ay1!=null){
								wssx.setYjaydm(ay1.getAydmbh());
								wssx.setYjaymc(ay1.getAymc());
							}
						}
					}
				}
				return wssx;
			}
			
//			�ļ�����
			if(ayjb==4){
				wssx.setSijaydm(aydm);
				wssx.setSijaymc(ay.getAymc());
				String sjdm3 = ay.getSjdm();
				if(!StringUtil.isBlank(sjdm3)){
//					AydmbDO ay3 = aydmDao.findByDmbh(sjdm3);//��������
					AydmModel ay3 = map.get(sjdm3);
					if(ay3!=null){
						wssx.setSjaydm(ay3.getAydmbh());
						wssx.setSjaymc(ay3.getAymc());
						String sjdm2 = ay3.getSjdm();
						if(!StringUtil.isBlank(sjdm2)){
//							AydmbDO ay2 = aydmDao.findByDmbh(sjdm2);//2������
							AydmModel ay2 = map.get(sjdm2);
							if(ay2!=null){
								wssx.setEjaydm(ay2.getAydmbh());
								wssx.setEjaymc(ay2.getAymc());
								String  sjdm1 = ay2.getSjdm();
								if(!StringUtil.isBlank(sjdm1)){
//									AydmbDO ay1 = aydmDao.findByDmbh(sjdm1);//2������
									AydmModel ay1 = map.get(sjdm1);
									if(ay1!=null){
										wssx.setYjaydm(ay1.getAydmbh());
										wssx.setYjaymc(ay1.getAymc());
									}
								}
							}
						}
					}
				}
				return wssx;
			}
		}
		return wssx;
	}
	 

}
