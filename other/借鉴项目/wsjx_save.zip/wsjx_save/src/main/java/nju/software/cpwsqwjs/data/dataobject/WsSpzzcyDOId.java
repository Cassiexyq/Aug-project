package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsSpzzcyDOId entity. @author MyEclipse Persistence Tools
 */
public class WsSpzzcyDOId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer cybh;

	// Constructors

	/** default constructor */
	public WsSpzzcyDOId() {
	}

	/** full constructor */
	public WsSpzzcyDOId(Integer ajxh, Integer cybh) {
		this.ajxh = ajxh;
		this.cybh = cybh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "CYBH", nullable = false)
	public Integer getCybh() {
		return cybh;
	}

	public void setCybh(Integer cybh) {
		this.cybh = cybh;
	}
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsSpzzcyDOId))
			return false;
		WsSpzzcyDOId castOther = (WsSpzzcyDOId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getCybh() == castOther.getCybh()) || (this
						.getCybh() != null && castOther.getCybh() != null && this
						.getCybh().equals(castOther.getCybh())));
	}

	

	

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getCybh() == null ? 0 : this.getCybh().hashCode());
		return result;
	}

}