package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * LaAyDOId entity. @author MyEclipse Persistence Tools
 */

public class LaAyDOId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer laaybh;

	// Constructors

	/** default constructor */
	public LaAyDOId() {
	}

	/** full constructor */
	public LaAyDOId(Integer ajxh, Integer laaybh) {
		this.ajxh = ajxh;
		this.laaybh = laaybh;
	}

	// Property accessors

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "LAAYBH", nullable = false)
	public Integer getLaaybh() {
		return this.laaybh;
	}

	public void setLaaybh(Integer laaybh) {
		this.laaybh = laaybh;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof LaAyDOId))
			return false;
		LaAyDOId castOther = (LaAyDOId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getLaaybh() == castOther.getLaaybh()) || (this
						.getLaaybh() != null && castOther.getLaaybh() != null && this
						.getLaaybh().equals(castOther.getLaaybh())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getLaaybh() == null ? 0 : this.getLaaybh().hashCode());
		return result;
	}

}