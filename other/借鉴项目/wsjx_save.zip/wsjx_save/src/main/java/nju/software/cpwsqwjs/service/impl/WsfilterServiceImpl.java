package nju.software.cpwsqwjs.service.impl;

import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.WsfilterDAO;
import nju.software.cpwsqwjs.data.dataobject.WsfilterDO;
import nju.software.cpwsqwjs.service.WsfilterService;
import nju.software.cpwsqwjs.service.model.WsfilterModel;
import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationContext;

/**
 * Created by zhx on 2017/6/27.
 */
public class WsfilterServiceImpl implements WsfilterService{
    private static ApplicationContext appContext=new org.springframework.context.support.ClassPathXmlApplicationContext(
            "applicationContext.xml");
    private static WsfilterDAO wsfilterDAO;
    private static SqlDao sqlDao;

    static{
        //DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
        wsfilterDAO = (WsfilterDAO)appContext.getBean("wsfilterDAO");
        sqlDao = (SqlDao)appContext.getBean("sqlDao");
    }

    @Override
    public void saveWsfilter(WsfilterModel wsfilterModel) {
        WsfilterDO wsfilterDO = new WsfilterDO();
        long maxId = wsfilterDAO.getMaxId();
        System.out.println("maxid:"+maxId);
        BeanUtils.copyProperties(wsfilterModel,wsfilterDO);
        wsfilterDO.setId(++maxId);
        if (wsfilterDO.getByrw()==null){
            wsfilterDO.setByrw(" ");
        }
        if (wsfilterDO.getZw()==null){
            wsfilterDO.setZw(" ");
        }
        if (wsfilterDO.getFt()==null){
            wsfilterDO.setFt(" ");
        }
        //wsfilterDAO.save2(wsfilterDO);
        String sql = "insert into WS_FILTER (ID, AH, AJMC, AY, BYRW, CPRQ, FBRQ, FT, FYMC, SPCX, SPZ, WSBT, ZSAH, ZSFY, ZW) values ("+wsfilterDO.getId()+", '"+wsfilterDO.getAh()+"', '"+wsfilterDO.getAjmc()+"', '"+wsfilterDO.getAy()+"', '"+wsfilterDO.getByrw()+"', '"+wsfilterDO.getCprq()+"', '"+wsfilterDO.getFbrq()+"', '"+wsfilterDO.getFt()+"', '"+wsfilterDO.getFymc()+"', '"+wsfilterDO.getSpcx()+"', '"+wsfilterDO.getSpz()+"', '"+wsfilterDO.getWsbt()+"', '"+wsfilterDO.getZsah()+"', '"+wsfilterDO.getZsfy()+"', '"+wsfilterDO.getZw()+"')";
        try {
            sqlDao.excuteSql(sql);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
