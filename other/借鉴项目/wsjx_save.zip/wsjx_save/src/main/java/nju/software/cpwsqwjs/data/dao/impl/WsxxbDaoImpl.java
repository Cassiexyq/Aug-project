package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WssxbDo;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class WsxxbDaoImpl extends HibernateDaoSupport implements WsxxbDao{

	@Override
	public boolean save(WssxbDo wssx) {
		// TODO Auto-generated method stub
		 try{
	          getHibernateTemplate().saveOrUpdate(wssx);
		 }catch (RuntimeException re){
			 throw re;
		 }
		 return true;
	}

	@Override
	public int getMaxId() {
		// TODO Auto-generated method stub
		String hql = "select max(wsid) from WssxbDo";

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxid = 0;
		if (query.uniqueResult() != null)
			maxid = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxid;
	}

}
