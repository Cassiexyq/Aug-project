package nju.software.cpwsqwjs.service.dataService.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.FydmDao;
import nju.software.cpwsqwjs.data.dao.WsxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.service.dataService.WssxbService;
import nju.software.cpwsqwjs.util.XMLReader;

public class WssxbServiceImpl implements WssxbService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	private static WsxxbDao wsxxbDao;
	static{
		wsxxbDao = (WsxxbDao) appContext.getBean("wsxxbDao");
	}
	@Override
	public void save(WssxbDo wssx) {
		// TODO Auto-generated method stub
		wsxxbDao.save(wssx);
	}
	@Override
	public int getMaxid() {
		// TODO Auto-generated method stub
		return wsxxbDao.getMaxId();
	}

	 

}
