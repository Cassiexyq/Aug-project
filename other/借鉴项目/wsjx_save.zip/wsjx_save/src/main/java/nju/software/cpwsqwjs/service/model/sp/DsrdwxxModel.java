/**
 * 2014-5-19 17:03
 */
package nju.software.cpwsqwjs.service.model.sp;
public class DsrdwxxModel {

	long ajxh;
	long dsrbh;
	String dwlb;
	
	String dsrssdw;//���ϵ�λ
	String dsrlb;
	String sfssdbr;
	String dsrjc;
	String hpje;
	String qqpcje;
	
	String dwmc;//��λ����
	String dz;//��ַ
	String dh;
	String yb;
	String frxz;
	String fddbrxm;//��������������
	String dbrzw;
	String gyqygm;
	String lxdh;
	String djzlb;
	String djzh;
	String csnyr;
	String fddbrxb;
	String zzmm;
	String jb;
	String whcd;
	
	String zcze;
	String zwze;
	String yhzq;
	
	public long getAjxh() {
		return ajxh;
	}
	public void setAjxh(long ajxh) {
		this.ajxh = ajxh;
	}
	public long getDsrbh() {
		return dsrbh;
	}
	public void setDsrbh(long dsrbh) {
		this.dsrbh = dsrbh;
	}
	public String getDwlb() {
		return dwlb;
	}
	public void setDwlb(String dwlb) {
		this.dwlb = dwlb;
	}
	public String getDsrssdw() {
		return dsrssdw;
	}
	public void setDsrssdw(String dsrssdw) {
		this.dsrssdw = dsrssdw;
	}
	public String getDsrlb() {
		return dsrlb;
	}
	public void setDsrlb(String dsrlb) {
		this.dsrlb = dsrlb;
	}
	public String getSfssdbr() {
		return sfssdbr;
	}
	public void setSfssdbr(String sfssdbr) {
		this.sfssdbr = sfssdbr;
	}
	public String getDsrjc() {
		return dsrjc;
	}
	public void setDsrjc(String dsrjc) {
		this.dsrjc = dsrjc;
	}
	public String getHpje() {
		return hpje;
	}
	public void setHpje(String hpje) {
		this.hpje = hpje;
	}
	public String getQqpcje() {
		return qqpcje;
	}
	public void setQqpcje(String qqpcje) {
		this.qqpcje = qqpcje;
	}
	public String getDwmc() {
		return dwmc;
	}
	public void setDwmc(String dwmc) {
		this.dwmc = dwmc;
	}
	public String getDz() {
		return dz;
	}
	public void setDz(String dz) {
		this.dz = dz;
	}
	public String getDh() {
		return dh;
	}
	public void setDh(String dh) {
		this.dh = dh;
	}
	public String getYb() {
		return yb;
	}
	public void setYb(String yb) {
		this.yb = yb;
	}
	public String getFrxz() {
		return frxz;
	}
	public void setFrxz(String frxz) {
		this.frxz = frxz;
	}
	public String getFddbrxm() {
		return fddbrxm;
	}
	public void setFddbrxm(String fddbrxm) {
		this.fddbrxm = fddbrxm;
	}
	public String getDbrzw() {
		return dbrzw;
	}
	public void setDbrzw(String dbrzw) {
		this.dbrzw = dbrzw;
	}
	public String getGyqygm() {
		return gyqygm;
	}
	public void setGyqygm(String gyqygm) {
		this.gyqygm = gyqygm;
	}
	public String getLxdh() {
		return lxdh;
	}
	public void setLxdh(String lxdh) {
		this.lxdh = lxdh;
	}
	public String getDjzlb() {
		return djzlb;
	}
	public void setDjzlb(String djzlb) {
		this.djzlb = djzlb;
	}
	public String getDjzh() {
		return djzh;
	}
	public void setDjzh(String djzh) {
		this.djzh = djzh;
	}
	public String getCsnyr() {
		return csnyr;
	}
	public void setCsnyr(String csnyr) {
		this.csnyr = csnyr;
	}
	public String getZcze() {
		return zcze;
	}
	public void setZcze(String zcze) {
		this.zcze = zcze;
	}
	public String getZwze() {
		return zwze;
	}
	public void setZwze(String zwze) {
		this.zwze = zwze;
	}
	public String getYhzq() {
		return yhzq;
	}
	public void setYhzq(String yhzq) {
		this.yhzq = yhzq;
	}
	public String getFddbrxb() {
		return fddbrxb;
	}
	public void setFddbrxb(String fddbrxb) {
		this.fddbrxb = fddbrxb;
	}
	public String getZzmm() {
		return zzmm;
	}
	public void setZzmm(String zzmm) {
		this.zzmm = zzmm;
	}
	public String getJb() {
		return jb;
	}
	public void setJb(String jb) {
		this.jb = jb;
	}
	public String getWhcd() {
		return whcd;
	}
	public void setWhcd(String whcd) {
		this.whcd = whcd;
	}
	
	
}
