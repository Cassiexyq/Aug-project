package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WssxbDo;

public interface WsxxbDao {

	public int getMaxId();
	public boolean save(WssxbDo wssx);
}
