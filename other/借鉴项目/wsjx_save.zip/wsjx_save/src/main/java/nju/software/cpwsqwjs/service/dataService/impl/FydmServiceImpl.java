package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.cxf.binding.corba.wsdl.Array;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.FydmDao;
import nju.software.cpwsqwjs.data.dataobject.FydmDO;
import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.service.dataService.FydmService;
import nju.software.cpwsqwjs.service.model.FydmModel;
import nju.software.cpwsqwjs.util.StringUtil;

public class FydmServiceImpl implements FydmService{

	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	private static FydmDao fydmDao;
	static{
		fydmDao = (FydmDao) appContext.getBean("fydmDao");
	}
	@Override
	public void saveFydm(List<FydmModel> modelList) {
		// TODO Auto-generated method stub
		for(FydmModel model:modelList){
			FydmDO fydm = new FydmDO(model);
			fydmDao.save(fydm);
		}
	}
	@Override
	public FydmModel getFydmByFymc(String fymc) {
		// TODO Auto-generated method stub
		FydmDO dmDo = fydmDao.findByFymc(fymc);
		FydmModel model = new FydmModel(dmDo);
		return model;
	}
	@Override
	public List<FydmModel> getAllFydm() {
		// TODO Auto-generated method stub
		List<FydmModel> modelList = new ArrayList<FydmModel>();
		List<FydmDO> list = fydmDao.getAll();
		for(FydmDO dmDo:list){
			FydmModel model = new FydmModel(dmDo);
			modelList.add(model);
		}
		return modelList;
	}
	@Override
	public FydmModel getFydmByCjm(String cjm) {
		// TODO Auto-generated method stub
		FydmDO dmDo = fydmDao.findByCjm(cjm);
		FydmModel model = new FydmModel(dmDo);
		return model;
	}
	@Override
	public WssxbDo setFy(WssxbDo wssx, String fycjm,String fymc,HashMap<String, FydmModel> map) {
		// TODO Auto-generated method stub
		
		if(!StringUtil.isBlank(fycjm)&&fycjm.length()==3){
//			���㷨Ժ
			 if(fycjm.charAt(2)!='0'){
				 wssx.setJcymc(fymc);//���㷨Ժ
				 wssx.setFycj("���㷨Ժ");
				 FydmDO jcfy = fydmDao.findByCjm(fycjm);
				 if(jcfy!=null && jcfy.getSjfymc()!=null){
					 String zjfymc = jcfy.getSjfymc();
					 wssx.setZymc(zjfymc); 
					 FydmModel zcfy = map.get(zjfymc);
					 if(zcfy!=null && zcfy.getSjfymc()!=null){
						 wssx.setGymc(zcfy.getSjfymc());
					 }
				 }
				 return wssx;
			 }
//			zhong�㷨Ժ
			 if(fycjm.charAt(0)!='0'&&fycjm.charAt(1)!='0'&&fycjm.charAt(2)=='0'){
				 wssx.setZymc(fymc);
				 wssx.setFycj("�м���Ժ");
				 FydmDO zcfy = fydmDao.findByCjm(fycjm);
				 if(zcfy!=null && zcfy.getSjfymc()!=null){
					 String gjfymc = zcfy.getSjfymc();
					 wssx.setGymc(gjfymc); 
				 }
				 return wssx;
			 }
//			 G�㷨Ժ
			 if(fycjm.charAt(0)!='0'&&fycjm.charAt(1)=='0'&&fycjm.charAt(2)=='0'){
				 wssx.setGymc(fymc);
				 wssx.setFycj("�߼���Ժ");
				 return wssx;
			 }
			 if(fycjm.equals("000")){
				 wssx.setGymc(fymc);
				 wssx.setFycj("��߷�Ժ");
				 return wssx;
			 }
		}
		return wssx;
	}
	@Override
	public HashMap<String, FydmModel> getAll() {
		// TODO Auto-generated method stub
		HashMap<String, FydmModel> map = new HashMap<String, FydmModel>();
		List<FydmDO> list = fydmDao.getAll();
		for(FydmDO dmDo:list){
			FydmModel model = new FydmModel(dmDo);
			map.put(model.getFymc(), model);
		}
		return map;
	}

}
