package nju.software.cpwsqwjs.service.impl.sp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.SpryDao;
import nju.software.cpwsqwjs.data.dataobject.SpryDO;
import nju.software.cpwsqwjs.service.dataConvertor.SpryConvertor;
import nju.software.cpwsqwjs.service.model.sp.SpryxxModel;
import nju.software.cpwsqwjs.service.sp.SpryService;

public class SpryServiceImpl implements SpryService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static SpryDao spryDao;
	static {
		spryDao = (SpryDao) appContext.getBean("spryDao");
	} 
	
	@Override
	public List<SpryxxModel> getSpryxxByAjxh(long ajxh) {
		// TODO Auto-generated method stub
		List<SpryDO> SpryDOList = spryDao.getSpryByAjxh((int)ajxh);
		List<SpryxxModel> spryxxList = new ArrayList<SpryxxModel>();

		for (SpryDO SpryDO : SpryDOList) {
			SpryxxModel spryxxModel = SpryConvertor.getSpryxxModelBySpryDO(SpryDO);
			spryxxList.add(spryxxModel);
		}
		return spryxxList;
	}

}
