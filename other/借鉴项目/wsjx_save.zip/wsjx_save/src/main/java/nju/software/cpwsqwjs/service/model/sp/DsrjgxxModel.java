/**
 * 2014-5-21 16:00
 */
package nju.software.cpwsqwjs.service.model.sp;

/**
 * @author ruanhao
 *
 */
public class DsrjgxxModel {

	long ajxh;
	long dsrbh;
	String jglb;
	
	String dsrssdw;//���ϵ�λ
	String dsrlb;
	String sfssdbr;
	String dsrjc;
	String hpje;
	String qqpcje;
	
	String jgmc;//��������
	String dz;//��ַ
	String fddbrxm;//��������������
	String xzjgxz;//��������
	String yb;
	String sfpc;
	String dh;
	String sffy;
	String djzlb;
	String djzh;
	
	String zcze;
	String zwze;
	String yhzq;
	public long getAjxh() {
		return ajxh;
	}
	public void setAjxh(long ajxh) {
		this.ajxh = ajxh;
	}
	public long getDsrbh() {
		return dsrbh;
	}
	public void setDsrbh(long dsrbh) {
		this.dsrbh = dsrbh;
	}
	public String getJglb() {
		return jglb;
	}
	public void setJglb(String jglb) {
		this.jglb = jglb;
	}
	public String getDsrssdw() {
		return dsrssdw;
	}
	public void setDsrssdw(String dsrssdw) {
		this.dsrssdw = dsrssdw;
	}
	public String getDsrlb() {
		return dsrlb;
	}
	public void setDsrlb(String dsrlb) {
		this.dsrlb = dsrlb;
	}
	public String getSfssdbr() {
		return sfssdbr;
	}
	public void setSfssdbr(String sfssdbr) {
		this.sfssdbr = sfssdbr;
	}
	public String getDsrjc() {
		return dsrjc;
	}
	public void setDsrjc(String dsrjc) {
		this.dsrjc = dsrjc;
	}
	public String getHpje() {
		return hpje;
	}
	public void setHpje(String hpje) {
		this.hpje = hpje;
	}
	public String getQqpcje() {
		return qqpcje;
	}
	public void setQqpcje(String qqpcje) {
		this.qqpcje = qqpcje;
	}
	public String getJgmc() {
		return jgmc;
	}
	public void setJgmc(String jgmc) {
		this.jgmc = jgmc;
	}
	public String getDz() {
		return dz;
	}
	public void setDz(String dz) {
		this.dz = dz;
	}
	public String getFddbrxm() {
		return fddbrxm;
	}
	public void setFddbrxm(String fddbrxm) {
		this.fddbrxm = fddbrxm;
	}
	public String getXzjgxz() {
		return xzjgxz;
	}
	public void setXzjgxz(String xzjgxz) {
		this.xzjgxz = xzjgxz;
	}
	public String getYb() {
		return yb;
	}
	public void setYb(String yb) {
		this.yb = yb;
	}
	public String getSfpc() {
		return sfpc;
	}
	public void setSfpc(String sfpc) {
		this.sfpc = sfpc;
	}
	public String getDh() {
		return dh;
	}
	public void setDh(String dh) {
		this.dh = dh;
	}
	public String getSffy() {
		return sffy;
	}
	public void setSffy(String sffy) {
		this.sffy = sffy;
	}
	public String getDjzlb() {
		return djzlb;
	}
	public void setDjzlb(String djzlb) {
		this.djzlb = djzlb;
	}
	public String getDjzh() {
		return djzh;
	}
	public void setDjzh(String djzh) {
		this.djzh = djzh;
	}
	public String getZcze() {
		return zcze;
	}
	public void setZcze(String zcze) {
		this.zcze = zcze;
	}
	public String getZwze() {
		return zwze;
	}
	public void setZwze(String zwze) {
		this.zwze = zwze;
	}
	public String getYhzq() {
		return yhzq;
	}
	public void setYhzq(String yhzq) {
		this.yhzq = yhzq;
	}
	
}
