package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsDsrDO;
import nju.software.cpwsqwjs.service.model.WssscyrModel;

import java.util.List;

public interface WsDsrDao {
    /**
     * ���ݰ�����Ż�õ�������Ϣ
     * @param ajxh
     * @return
     */
    public WsDsrDO getDsrByAjxh(int ajxh);

    public List<WsDsrDO> findByAjxh(int ajxh);

    /**
     * ���ݵ����˱�Ż�õ�������Ϣ
     * @param dsrbh
     * @return
     */
    public WsDsrDO getDsrByDsrbh(int dsrbh);

    public List<WsDsrDO> findByDsrbh(int dsrbh);

    /**
     * ��õ�ǰ������˱��
     * @return
     */
    public Integer getMaxDsrbhByAjxh(int ajxh);

    public Integer addDsrDO(WsDsrDO wsDsrDO);
    
    public void addDsrDOList(List<WsDsrDO> wsDsrDO);
    
    public void addDsrBatch(List<WssscyrModel> wssscyrModellist, int ajxh,int maxQkbh,int maxQzcsbh);
}
