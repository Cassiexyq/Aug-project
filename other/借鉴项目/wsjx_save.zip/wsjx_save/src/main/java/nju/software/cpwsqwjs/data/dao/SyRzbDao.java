package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.SyRzbDO;

public interface SyRzbDao {
	public void addSyRzb(SyRzbDO syrzbDO);

	public void updateSyRzb(SyRzbDO syrzbDO);

	public int getMaxId();

	/*
	 * ��ȡ�������־
	 */
	public SyRzbDO getNewSyRzbDO();
}
