package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsSsjlZkzmDoId entity. @author MyEclipse Persistence Tools
 */
public class WsSsjlZkzmDoId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer zmbh;
	
	// Constructors

	/** default constructor */
	public WsSsjlZkzmDoId() {
	}

	/** full constructor */
	public WsSsjlZkzmDoId(Integer ajxh, Integer zmbh ) {
		this.ajxh = ajxh;
		this.zmbh = zmbh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	 
	@Column(name = "ZMBH", nullable = false)
	public Integer getZmbh() {
		return zmbh;
	}

	public void setZmbh(Integer zmbh) {
		this.zmbh = zmbh;
	}

	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsSsjlZkzmDoId))
			return false;
		WsSsjlZkzmDoId castOther = (WsSsjlZkzmDoId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getZmbh() == castOther.getZmbh()) || (this
						.getZmbh() != null && castOther.getZmbh() != null && this
						.getZmbh().equals(castOther.getZmbh())));
	}

	

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getZmbh() == null ? 0 : this.getZmbh().hashCode());
		return result;
	}

}