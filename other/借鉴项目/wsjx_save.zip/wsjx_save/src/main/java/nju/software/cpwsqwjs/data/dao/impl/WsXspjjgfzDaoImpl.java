package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsXspjjgfzDao;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfjxDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDOId;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDO;
import nju.software.cpwsqwjs.service.model.xs.FjxModel;
import nju.software.cpwsqwjs.service.model.xs.PfModel;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.service.model.xs.XspjjgfzModel;

public class WsXspjjgfzDaoImpl extends HibernateDaoSupport implements
		WsXspjjgfzDao {

	public static final String SSCYR = "sscyr";// ���ϲ�����
	public static final String PJJZM = "pjjzm";// �о�������
	public static final String ZMDM = "zmdm";// ��������
	public static final String WZZM = "wzzm";// ��������
	public static final String XQKSRQ = "xqksrq";// ���ڿ�ʼ����
	public static final String XQJSRQ = "xqjsrq";// ���ڽ�������
	public static final String XQZDBF = "xqzdbf";// �����۵ְ취
	public static final String MZHWZSF = "mzhwfsf";// ����������ͷ�
	public static final String SZBF = "szbf";// ���ﲢ��
	public static final String HBLX = " hblx";// �ϲ�����

	public WsXspjjgfzDO findById(WsXspjjgfzDOId id) {
		try {
			WsXspjjgfzDO instance = (WsXspjjgfzDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO", id);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public int getMaxFzbhByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(fzbh) from WsXspjjgfzDO where ajxh=" + ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null) {
			maxbh = (int) query.uniqueResult();
		}
		// �ͷ����ݿ�����
		this.releaseSession(s);
		return maxbh;
	}

	@Override
	public WsXspjjgfzDO getXsppjgFz(int ajxh, int fzbh) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int save(WsXspjjgfzDO fzDo) {
		// TODO Auto-generated method stub
		try {
			getHibernateTemplate().saveOrUpdate(fzDo);
			return fzDo.getFzbh();
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsXspjjgfzDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public void savePjjg(int ajxh, XsPjjgModel pjjgModel) {
		if (pjjgModel.getPjjgfzModels() != null) {
			int fzbh = this.getMaxFzbhByAjxh(ajxh) + 1;
			Session s = this.getSessionFactory().openSession();
			Transaction tx = s.beginTransaction();
			int i=0;//����ļ�¼��
			for (XspjjgfzModel fzModel : pjjgModel.getPjjgfzModels()) {
				// ����DO
				WsXspjjgfzDO fzDo = new WsXspjjgfzDO(fzModel);
				fzDo.setAjxh(ajxh);
				fzDo.setFzbh(fzbh);
				int maxPfbh = 1;
				int fjxbh = 1;
				if (fzModel.getDzpf() != null) {
					for (PfModel dzpf : fzModel.getDzpf()) {
						WsXspjjgpfDO pfDo = new WsXspjjgpfDO(dzpf, "�����з�");
						pfDo.setAjxh(ajxh);
						pfDo.setFzbh(fzbh);
						pfDo.setPfbh(maxPfbh);
						// �з��ĸ�����
						if (dzpf.getFjxList() != null && dzpf.getFjxList().size() > 0) {
							for (FjxModel fjx : dzpf.getFjxList()) {
								WsXspjjgfjxDO fjxDo = new WsXspjjgfjxDO(fjx);
								fjxDo.setAjxh(ajxh);
								fjxDo.setFzbh(fzbh);
								fjxDo.setPfbh(maxPfbh);
								fjxDo.setFjxbh(fjxbh);
								fjxbh = fjxbh++;
								s.save(fjxDo);
								i++;
							}
						}
//						�����з�
						maxPfbh=maxPfbh++;
						s.save(pfDo);
						i++;
					}
				}
				if(fzModel.getZxpf()!=null){
					WsXspjjgpfDO pfDo = new WsXspjjgpfDO(fzModel.getZxpf(), "ִ���з�");
					pfDo.setAjxh(ajxh);
					pfDo.setFzbh(fzbh);
					pfDo.setPfbh(maxPfbh);
					if(fzModel.getZxpf().getFjxList()!=null){
						for(FjxModel fjx:fzModel.getZxpf().getFjxList()){
							WsXspjjgfjxDO fjxDo = new WsXspjjgfjxDO(fjx);
							fjxDo.setAjxh(ajxh);
							fjxDo.setFzbh(fzbh);
							fjxDo.setFjxbh(fjxbh);
							fjxDo.setPfbh(maxPfbh);
							fjxbh=fjxbh ++;
							s.save(fjxDo);
							i++;
						}
					}
//					�����з�
					maxPfbh=maxPfbh++;
					s.save(pfDo);
					i++;
				}
			// �������
			++fzbh;
			s.save(fzDo);
			++i;
			if(i>50){
				s.flush();
				s.clear();
				i=0;
			}
			}
			tx.commit();
			s.close();
		}
	}
}
