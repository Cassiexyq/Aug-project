package nju.software.cpwsqwjs.service.impl;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.PubLaAyDao;
import nju.software.cpwsqwjs.data.dao.WsajjbxxbDao;
import nju.software.cpwsqwjs.data.dataobject.PubLaAy;
import nju.software.cpwsqwjs.data.dataobject.WsAjxxbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.Ayservice;

public class AyserviceImpl implements Ayservice{
	
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static PubLaAyDao pubLayyDao;
	private static WsajjbxxbDao wsajjbxxbDao;
	static {
		pubLayyDao = (PubLaAyDao) appContext.getBean("pubLayyDao");
		wsajjbxxbDao = (WsajjbxxbDao) appContext.getBean("wsajjbxxbDao");
	}

	@Override
	public String getAy(int ajxh) {
		// TODO Auto-generated method stub
//		PubLaAy ay =  pubLayyDao.getLaAyDObyAjxh(ajxh);
//		String ay_str = ay.getAy();
		WsAjxxbDO aj = wsajjbxxbDao.getAjjbxxByAjxh(ajxh);
		String ay_str = aj.getAh();
		return ay_str;
	}

}
