package nju.software.cpwsqwjs.vo;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.ValidateModel;

public class JYResult {
	
	private List<ValidateModel> wsResult;
	private List<List<ValidateModel>> dsrResult;
	
	public List<ValidateModel> getWsResult() {
		return wsResult;
	}
	public void setWsResult(List<ValidateModel> wsResult) {
		this.wsResult = wsResult;
	}
	
	public List<List<ValidateModel>> getDsrResult() {
		return dsrResult;
	}
	public void setDsrResult(List<List<ValidateModel>> dsrResult) {
		this.dsrResult = dsrResult;
	}
	
}
