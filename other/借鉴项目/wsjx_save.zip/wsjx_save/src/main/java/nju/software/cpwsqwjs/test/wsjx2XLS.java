package nju.software.cpwsqwjs.test;

import nju.software.cpwsqwjs.util.ExportUtil;
import nju.software.cpwsqwjs.util.FcUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by zhx on 2017/6/29.
 */
public class wsjx2XLS {
    public static String format(String qw){
        char[]ws=qw.toCharArray();
        int index=0;
        for(int i=0;i<ws.length;i++){
            int temp=ws[i];
            if(temp==32){
                if(i-index>5){
                    ws[i]=10;
                }
                index=i;
            }

        }
        return String.valueOf(ws);
    }
    public static String getWsnr(String path,String filename){
        String wsnr="";
        ArrayList<String> content=new ArrayList<String>();
        ArrayList<String> wsnrlist=new ArrayList<String>();
        FileUtil fileUtil = new FileUtil();
        FcUtil fcUtil=new FcUtil();
        String sep = File.separator;
        fileUtil.setS(path+sep+filename);
        content=fileUtil.readFromFile();
        if (content.size()==0){
            return null;
        }
        for(int i=0;i<content.size();i++){
            ArrayList<String> str=(ArrayList<String>) FcUtil.getWholeToken(content.get(i));
            if(str.size()>0){
                wsnrlist.add(content.get(i));
            }
        }
        for(int i=0;i<wsnrlist.size()-1;i++){
            wsnr+=wsnrlist.get(i)+"\n";
        }
        wsnr+=wsnrlist.get(wsnrlist.size()-1);
        return wsnr;
    }
    public static String fileSelection(String path,String filename) throws Exception{
        String wsnr=null;
        String str = filename.substring(filename.lastIndexOf(".")+1);
        if(str.contains("txt")){
            wsnr=getWsnr(path,filename);
        }
        else{
            wsnr = POIUtil.getContent(FileUtil.getContent(path+"\\"+filename), filename);
        }
        return wsnr;
    }
    public static void main(String[] args) throws Exception {
        //String inputpath="C:\\Users\\Admin\\Desktop\\��߲�������\\��߲�������\\��������2015\\cpws";
        //String filePath="C:\\Users\\Admin\\Desktop\\gy\\��������2015����һ������.xls";
        //String outputpath="C:\\Users\\Admin\\Desktop\\gy\\2015.xls";
        //String inputpath="/Users/zhx/Desktop/wsduty/test-input/";
        String inputpath="/Users/zhx/Desktop/wsduty/input-2016-2017/";
        String filePath = "/Users/zhx/Desktop/wsduty/����/2016��2017��.xls";
        String outputpath="/Users/zhx/Desktop/wsduty/out/2016-2017.xls";
        File file=new File(inputpath);
        String filename[];
        filename=file.list();
        XzwsService2015 service = new XzwsService2015();
        List<Xzws2015> models = new ArrayList<Xzws2015>();
        Map<String,Xzws2015> map=new HashMap<String,Xzws2015>();
        for(int j=0;j<filename.length;j++)
        {
            if(filename[j].endsWith(".DS_Store")){
                continue;
            }
            try{
                String wsnr=fileSelection(inputpath,filename[j]);
//				System.out.println(wsnr);
                System.out.println(filename[j]);

//                if(wsnr.contains("֪����") || wsnr.contains("��֪��")
//                        || wsnr.contains("�̱�����")){
//                    continue;
//                }
                if (wsnr==null){
                    continue;
                }
                Xzws2015 model = service.getModel(wsnr);
                model.setAh(filename[j].substring(0,filename[j].indexOf(".t")));
                models.add(model);
                map.put(filename[j].substring(0,filename[j].indexOf(".")), model);
            }catch(Exception e){
                System.out.println("�޷�����"+ filename[j]);
                e.printStackTrace();
            }
        }
        ExportUtil.exportNew2(map, filePath,outputpath);
//		ExportUtil.exportNew(models,outputpath);
    }
}
