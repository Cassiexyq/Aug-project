package nju.software.cpwsqwjs.service.impl.sp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.service.model.sp.DmbModel;
import nju.software.cpwsqwjs.service.sp.DmbService;
import nju.software.cpwsqwjs.util.StringUtil;
public class DmbServiceImpl implements DmbService{

	/*private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static DmbDao dmbDao;
	static {
		dmbDao = (DmbDao) appContext.getBean("dmbDao");
	}*/

	@Autowired
	private  DmbDao dmbDao;
	
	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}

	@Override
	public DmbModel getDmByLbbhAndDmbh(String lbbh, String dmbh, long fybh) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getLbbhByColumn(String ajxz, String spcx,String column_code) {
		if (!StringUtil.isBlank(ajxz))
			ajxz = StringUtil.trim(ajxz);
		if (!StringUtil.isBlank(spcx))
			spcx = StringUtil.trim(spcx);
		// ������Դ���⴦��
//		if (StringUtil.equals(tableName, "PUB_AJ_JB")
//				&& StringUtil.equals(columnName, "AJLY")) {
//			List<DmbModel> spcxs = spcxMap.get(ajxz);
//			for (DmbModel dm : spcxs) {
//				if (StringUtil.equals(dm.getDmbh(), spcx)) {
//					return StringUtil.replace(dm.getXgdm(), "%", "");
//				}
//			}
//		}


		String temp_ajxz = ajxz;
		if (temp_ajxz.equals("2") || temp_ajxz.equals("3")
				|| temp_ajxz.equals("4") || temp_ajxz.equals("5"))
			temp_ajxz = "2";

		// ��ñ�ע
//		String column_code = xxxService.getLbbhByTableAndColumn(tableName,
//				columnName, -1);

		if (StringUtil.indexOf(column_code, ",") < 0) {
			return column_code;
		}
		String temp_spcx = spcx;

		if (ajxz.equals("A") && spcx.equals("2")) {
			temp_ajxz = "A";
			temp_spcx = "2";
		}
		String toFind = column_code;
		int index = toFind.indexOf(temp_ajxz + temp_spcx);
		if (index > 0
				&& !StringUtil.equals(toFind.substring(index - 1, index), ",")) {
			index = -1;
		}
		if (index == -1) {
			index = toFind.indexOf(temp_ajxz + "*");
		}
		if (index == -1) {
			String errStr = "getCasecode() �޷�ƥ����ش��룡" + " temp_ajxz��"
					+ temp_ajxz + ",temp_spcx�� " + temp_spcx + ", sjxx:"
					+ toFind;
			return "";
		}

		String lbbh = "";

		int endIndex = toFind.indexOf(",", index);
		if (endIndex == -1) {
			lbbh = toFind.substring(index + 2, toFind.length());
		} else {
			lbbh = toFind.substring(index + 2, endIndex);
		}
		return lbbh;
	}



}
