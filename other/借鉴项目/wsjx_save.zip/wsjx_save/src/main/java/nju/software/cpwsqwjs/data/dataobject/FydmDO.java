package nju.software.cpwsqwjs.data.dataobject;

import nju.software.cpwsqwjs.service.model.FydmModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;

import javax.persistence.*;

/**
 * FydmDO entity. @author MyEclipse Persistence Tools
 * ��Ժ�����
 */
@Entity
@Table(name = "FYDMB") 
public class FydmDO implements java.io.Serializable {
	/**
	 * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private String fydm;//��Ժ����
	private String cjm;//�㼶��
	private String fymc;//��Ժ����
	private String sm;//˵��
	private String sjfymc;//�ϼ���Ժ����

	/** default constructor */
	public FydmDO() {
	}


	public FydmDO(String fydm, String cjm, String fymc, String sm) {
		super();
		this.fydm = fydm;
		this.cjm = cjm;
		this.fymc = fymc;
		this.sm = sm;
	}
	@Id
	@Column(name = "FYDM", nullable = false)
	public String getFydm() {
		return fydm;
	}

	public void setFydm(String fydm) {
		this.fydm = fydm;
	}
	@Column(name = "CJM")
	public String getCjm() {
		return cjm;
	}


	public void setCjm(String cjm) {
		this.cjm = cjm;
	}

	@Column(name = "FYMC", length = 50)
	public String getFymc() {
		return fymc;
	}


	public void setFymc(String fymc) {
		this.fymc = fymc;
	}

	@Column(name = "SM", length = 100)
	public String getSm() {
		return sm;
	}


	public void setSm(String sm) {
		this.sm = sm;
	}

	@Column(name = "SJFYMC", length = 50)
	public String getSjfymc() {
		return sjfymc;
	}


	public void setSjfymc(String sjfymc) {
		this.sjfymc = sjfymc;
	}
	
	public FydmDO(FydmModel model){
		if(model.getFydm()!=null){
			this.setFydm(model.getFydm());
		}
		if(model.getCjm()!=null){
			this.setCjm(model.getCjm());
		}
		if(model.getFymc()!=null){
			this.setFymc(model.getFymc());
		}
		if(model.getSjfymc()!=null){
			this.setSjfymc(model.getSjfymc());
		}
		if(model.getSm()!=null){
			this.setSm(model.getSm());
		}
	}

}