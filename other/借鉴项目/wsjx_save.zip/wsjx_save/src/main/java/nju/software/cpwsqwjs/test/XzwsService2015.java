package nju.software.cpwsqwjs.test;

import java.util.*;

import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.util.WwEnum;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.NlpAnalysis;

public class XzwsService2015 {

	public Xzws2015 getModel(String wsnr){
		Xzws2015 model = new Xzws2015();
		getZsfy(wsnr, model);
		getZsah(wsnr, model);
		getAy(wsnr, model);
		getByrw(wsnr, model);
		return model;
	}
	//������ɸѡ���ĵ�һ����ĳĳ�߼�����Ժ���ؼ���
	public void getZsfy(String wsnr,Xzws2015 model){
		String zsfy = "";
		int indexOfBF = wsnr.indexOf("����");
		if(indexOfBF>-1){
			String fyAll = wsnr.substring(indexOfBF+2);
			int indexOfFy = fyAll.indexOf("��Ժ");
			if(indexOfFy>-1 && indexOfFy<20){
				zsfy = fyAll.substring(0,indexOfFy+2);

			}
		}
		model.setZsfy(zsfy);
		// System.out.println("zsfy:"+zsfy);
	}

	public  void getZsah(String wsnr,Xzws2015 model){
		int indexOfBF = wsnr.indexOf("����");
		String ah = "";
		if(indexOfBF>-1){
			String fyAll = wsnr.substring(indexOfBF+2);
			int indexOfYear1 = fyAll.indexOf("��2");
			int indexOfYear2 = fyAll.indexOf("(2");
			int indexOfYear = indexOfYear1;
			if(indexOfYear1==-1){
				indexOfYear = indexOfYear2;
			}
			if(indexOfYear1!=-1 && indexOfYear2!=-1){
				indexOfYear = Math.min(indexOfYear1, indexOfYear2);
			}
			int indexOfHao = fyAll.indexOf("��");
			if(indexOfYear>-1 && indexOfHao>-1 && indexOfHao>indexOfYear && (indexOfHao-indexOfYear)<20){
				ah = fyAll.substring(indexOfYear, indexOfHao+1);

			}
		}
		model.setZsah(ah);
		// System.out.println(ah);
	}

	public void  getAy(String wsnr,Xzws2015 model ){
		int indexOfYA = wsnr.indexOf("һ��");
		String ay = "";
		if(indexOfYA>-1){
			String ayAll = wsnr.substring(0, indexOfYA);
			int indexOfKh = ayAll.lastIndexOf("��");
			if(indexOfKh!=-1 && indexOfYA-indexOfKh<20){
				ay = ayAll.substring(indexOfKh+1, indexOfYA);
			}
			if(ay.equals("")||ay.contains("��")){
				List<Term> parse =  NlpAnalysis.parse(ayAll).getTerms();
				String last = parse.get(0).getName();
				for(Term term:parse){
					if("nr".equals(term.getNatureStr()) || "nt".equals(term.getNatureStr())
							||"nw".equals(term.getNatureStr()) ){
						last = term.getName();
					}
				}
				int before = ayAll.lastIndexOf(last);
				if(before<indexOfYA){
					ay = ayAll.substring(before+last.length(), indexOfYA);
				}
			}
		}
		model.setAy(ay);
		//System.out.println("ay:"+ay);
	}
	/**
	 * ��Ժ��Ϊ�����ġ����г�
	 * @param wsnr
	 * @param model
	 */
	public void getByrw(String wsnr,Xzws2015 model){
		String byrw = "";
		String[] byrwList = {"��Ժ��Ϊ","��Ժ��������Ϊ","��Ժ�������Ϊ","���ֵ���","��Ժ�����Ϊ"};
		int start = -1;

		for(String s:byrwList){
			if(wsnr.indexOf(s)>-1){
				start = wsnr.indexOf(s);
				break;
			}
		}
		if(start!=-1){
			String byrwAll = wsnr.substring(start);
			String[] endList = {"�ö�����","�о�����","��������" };
			int end = -1;
			for(String s:endList){
				if(wsnr.indexOf(s)>-1){
					end = byrwAll.indexOf(s);
					break;
				}
			}
			if(end!=-1){
				byrw = byrwAll.substring(0, end);
				model.setByrw(byrw);
				//System.out.println(byrw);
				getFt(byrw,model);
				String cpjgAll = byrwAll.substring(end);
				cpjgAll=cpjgAll.replaceAll("[\\r]", "");
				cpjgAll=cpjgAll.replaceAll("��", "");
				cpjgAll=cpjgAll.replaceAll(" ", "");
				int indexOfSpz = cpjgAll.indexOf("���г�");
				if(indexOfSpz>-1){
					String cpjg = cpjgAll.substring(0, indexOfSpz);
					model.setZw(cpjg);
					//     System.out.println(cpjg);
					String ww = cpjgAll.substring(indexOfSpz);
					//�ҳ���β�������г��ĵ�һ����ɫ��index��ȡ���г��͸ý�ɫ�м������
					Set<Integer> wwRoleIndex = new TreeSet<>();
					List<String> wwList = WwEnum.getWwList();
					for (String wwrole: wwList) {
						if (ww.indexOf(wwrole)!=-1&&wwrole!="���г�"){
							wwRoleIndex.add(ww.indexOf(wwrole));
						}
					}
					String spz = ww.substring(3,(int)wwRoleIndex.toArray()[0]);
					//System.out.println("���г���"+spz);
					model.setSpz(spz);
//                    List<Term> parse =  NlpAnalysis.parse(ww).getTerms();
//                    boolean spz = false;
//                    for(Term term:parse){
//                        if("���г�".equals(term.getName())){
//                            spz = true;
//                        }
//                        if(spz && "nr".equals(term.getNatureStr())){
//                            model.setSpz(term.getName());
//                            System.out.println(term.getName());
//                            break;
//                        }
//                    }
				}
			}
		}
	}

	/**
	 * �ӱ�Ժ��Ϊ�н��������ɷ���
	 * @param byrw
	 * @param model
	 */
	public String getFt(String byrw,Xzws2015 model){
		String[] ftfz = byrw.split("��");
		ArrayList<WscpfxgcFtModel> ftModellist = new ArrayList<WscpfxgcFtModel>();
		for (int j = 0; j < ftfz.length; j++) {
			String content = ftfz[j];
			if (content.indexOf("��") != -1) {
				WscpfxgcFtModel ftModel = new WscpfxgcFtModel();
				String flftmc = content.substring(0, content.indexOf("��"));
				if (flftmc.endsWith("��Ҫ")||flftmc.endsWith("Э��")){
					continue;
				}
				ftModel.setFlftmc(flftmc);
				if (flftmc.endsWith("��")){
					continue;
				}
				// ����������Ŀ����Ŀ
				String tmString[] = content.split("��");
				HashMap<String, String> ftMap = new HashMap<String, String>();// ����map<��Ŀ����Ŀ>
				if(tmString.length==1){
					ftMap.put(tmString[0].substring(
							tmString[0].lastIndexOf("��") + 1), "û�п�Ŀ");
				}else{
					for (int i = 0; i < tmString.length - 1; i++) {
						if (!tmString[i + 1].contains("��")
								&& !tmString[i + 1].contains("��")
								&& tmString[i].contains("��")) {
							ftMap.put(tmString[i].substring(
									tmString[i].lastIndexOf("��") + 1,
									tmString[i].length()), "û�п�Ŀ");
						} else if ((tmString[i + 1].contains("��")
								|| tmString[i + 1].contains("��"))
								&& tmString[i].contains("��")) {
							String tm = "";
							if(tmString[i].lastIndexOf("��") >-1){
								if(tmString[i].lastIndexOf("��") > tmString[i].lastIndexOf("��")){
									tm = tmString[i].substring(
											tmString[i].lastIndexOf("��") + 1,
											tmString[i].length());
								}else{
									tm = tmString[i].substring(
											tmString[i].lastIndexOf("��") + 1,
											tmString[i].length());
								}
							}else{
								tm = tmString[i].substring(
										tmString[i].lastIndexOf("��") + 1,
										tmString[i].length());
							}
							String km = "";
							if (i < tmString.length - 1
									&& tmString[i + 1].contains("��")) {
								km = tmString[i + 1].substring(0,
										tmString[i + 1].lastIndexOf("��") + 1);
								ftMap.put(tm, km);
							}
							if (i < tmString.length - 1
									&& tmString[i + 1].contains("��")) {
								km = tmString[i + 1].substring(0,
										tmString[i + 1].lastIndexOf("��") + 1);
								ftMap.put(tm, km);
							}
						}
					}
				}
				ftModel.setFtMap(ftMap);
				ftModellist.add(ftModel);
			}
		}
		String ft = "";
		for (WscpfxgcFtModel ftmodel:ftModellist) {
			ft += ftmodel.toString();
		}
		model.setFt(ft);
		return ft;
	}
}
