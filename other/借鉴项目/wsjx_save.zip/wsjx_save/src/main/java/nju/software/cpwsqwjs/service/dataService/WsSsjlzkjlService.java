package nju.software.cpwsqwjs.service.dataService;

import nju.software.cpwsqwjs.service.model.WsssjlModel;

public interface WsSsjlzkjlService {
	
	public void saveZkjl(WsssjlModel ssjlModel);
}
