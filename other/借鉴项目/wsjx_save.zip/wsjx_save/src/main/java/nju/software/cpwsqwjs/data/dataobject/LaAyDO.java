package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;


/**
 * LaAyDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_LA_AY")
@IdClass(LaAyDOId.class)
public class LaAyDO implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer laaybh;
	private String ay;
	private String laay;

	// Constructors

	/** default constructor */
	public LaAyDO() {
	}

	/** minimal constructor */
	public LaAyDO(Integer ajxh,Integer laaybh) {
		this.ajxh=ajxh;
		this.laaybh=laaybh;
	}

	/** full constructor */
	public LaAyDO(LaAyDOId id, String ay, String laay) {
		this.ajxh=ajxh;
		this.laaybh=laaybh;
		this.ay = ay;
		this.laay = laay;
	}
	

	// Property accessors
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name = "LAAYBH", nullable = false)
	public Integer getLaaybh() {
		return this.laaybh;
	}

	public void setLaaybh(Integer laaybh) {
		this.laaybh = laaybh;
	}

	@Column(name = "AY", length = 10)
	public String getAy() {
		return this.ay;
	}

	public void setAy(String ay) {
		this.ay = ay;
	}

	@Column(name = "LAAY", length = 100)
	public String getLaay() {
		return this.laay;
	}

	public void setLaay(String laay) {
		this.laay = laay;
	}

}