package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * WssxbDo entity. @author MyEclipse Persistence Tools
 * �������Ա�
 */
@Entity
@Table(name = "WSXXB") 
public class WssxbDo implements Cloneable{

	private static final long serialVersionUID = 1L;
	// Fields
	private Integer wsid;//����id
	private String wsah;//���鰸��
	private String wsmc;//��������
	private String wslx;//��������
	private String xmlName;//xml�ļ���
	private String xmlPath;//xml·��
	private String docName;//doc�ļ���
	private String docPath;//doc·��
	private String ajlb;//����������µ�
	private Integer aycj;//���ɲ㼶 1234��
	private String yjaymc;//һ����������
	private String yjaydm;//һ�����ɴ���
	private String ejaymc;//������������
	private String ejaydm;//�������ɴ���
	private String sjaymc;//������������
	private String sjaydm;//�������ɴ���
	private String sijaymc;//�ļ���������
	private String sijaydm;//�ļ����ɴ���
	private String fycj;//��Ժ�㼶
	private String gymc;//��Ժ����
	private String zymc;//��Ժ����
	private String jcymc;//����Ժ����
	private String cprq;//��������
	private String cpnf;//�������
	private String spcx;//���г���
	private String spry;//������Ա
	private String yghzgsr;//ԭ����߹�����
	private String bg;//����
	private String ygsfct;//ԭ���Ƿ��ͥ
	private String bgsfct;//�����Ƿ��ͥ
	private String lsmc;//��������
	private String lsxm;//��ʦ����
	private String flyj;//��������
	
	
	public WssxbDo() {
		super();
	}
	
	
	public WssxbDo(Integer wsid, String wsah, String wsmc, String wslx,
			String xmlName, String xmlPath, String docName, String docPath,
			String ajlb, Integer aycj, String yjaymc, String yjaydm,
			String ejaymc, String ejaydm, String sjaymc, String sjaydm,
			String sijaymc, String sijaydm, String fycj, String gymc,
			String zymc, String jcymc, String cprq, String cpnf, String spcx,
			String spry, String yghzgsr, String bg, String ygsfct,
			String bgsfct, String lsmc, String lsxm, String flyj) {
		super();
		this.wsid = wsid;
		this.wsah = wsah;
		this.wsmc = wsmc;
		this.wslx = wslx;
		this.xmlName = xmlName;
		this.xmlPath = xmlPath;
		this.docName = docName;
		this.docPath = docPath;
		this.ajlb = ajlb;
		this.aycj = aycj;
		this.yjaymc = yjaymc;
		this.yjaydm = yjaydm;
		this.ejaymc = ejaymc;
		this.ejaydm = ejaydm;
		this.sjaymc = sjaymc;
		this.sjaydm = sjaydm;
		this.sijaymc = sijaymc;
		this.sijaydm = sijaydm;
		this.fycj = fycj;
		this.gymc = gymc;
		this.zymc = zymc;
		this.jcymc = jcymc;
		this.cprq = cprq;
		this.cpnf = cpnf;
		this.spcx = spcx;
		this.spry = spry;
		this.yghzgsr = yghzgsr;
		this.bg = bg;
		this.ygsfct = ygsfct;
		this.bgsfct = bgsfct;
		this.lsmc = lsmc;
		this.lsxm = lsxm;
		this.flyj = flyj;
	}
	
	@Id
	@Column(name = "WS_ID", unique = true, nullable = false)
	public Integer getWsid() {
		return wsid;
	}
	public void setWsid(Integer wsid) {
		this.wsid = wsid;
	}
	@Column(name = "WSAH", length = 100)
	public String getWsah() {
		return wsah;
	}
	public void setWsah(String wsah) {
		this.wsah = wsah;
	}
	@Column(name = "WSMC", length = 150)
	public String getWsmc() {
		return wsmc;
	}
	public void setWsmc(String wsmc) {
		this.wsmc = wsmc;
	}
	@Column(name = "WSLX", length = 20)
	public String getWslx() {
		return wslx;
	}
	public void setWslx(String wslx) {
		this.wslx = wslx;
	}
	@Column(name = "WS_XML_NAME", length = 50)
	public String getXmlName() {
		return xmlName;
	}
	public void setXmlName(String xmlName) {
		this.xmlName = xmlName;
	}
	@Column(name = "WS_XML_PATH", length = 255)
	public String getXmlPath() {
		return xmlPath;
	}
	public void setXmlPath(String xmlPath) {
		this.xmlPath = xmlPath;
	}
	@Column(name = "WS_DOC_NAME", length = 50)
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	@Column(name = "WS_DOC_PATH", length = 255)
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}
	@Column(name = "AJLB", length = 10)
	public String getAjlb() {
		return ajlb;
	}
	public void setAjlb(String ajlb) {
		this.ajlb = ajlb;
	}
	@Column(name = "AYCJ")
	public Integer getAycj() {
		return aycj;
	}
	public void setAycj(Integer aycj) {
		this.aycj = aycj;
	}
	@Column(name = "YJAYMC", length = 50)
	public String getYjaymc() {
		return yjaymc;
	}
	public void setYjaymc(String yjaymc) {
		this.yjaymc = yjaymc;
	}
	@Column(name = "YJAYDM", length = 10)
	public String getYjaydm() {
		return yjaydm;
	}
	public void setYjaydm(String yjaydm) {
		this.yjaydm = yjaydm;
	}
	@Column(name = "EJAYMC", length = 50)
	public String getEjaymc() {
		return ejaymc;
	}
	public void setEjaymc(String ejaymc) {
		this.ejaymc = ejaymc;
	}
	@Column(name = "EJAYDM", length = 10)
	public String getEjaydm() {
		return ejaydm;
	}
	public void setEjaydm(String ejaydm) {
		this.ejaydm = ejaydm;
	}
	@Column(name = "SJAYMC", length = 50)
	public String getSjaymc() {
		return sjaymc;
	}
	public void setSjaymc(String sjaymc) {
		this.sjaymc = sjaymc;
	}
	@Column(name = "SJAYDM", length = 10)
	public String getSjaydm() {
		return sjaydm;
	}
	public void setSjaydm(String sjaydm) {
		this.sjaydm = sjaydm;
	}
	@Column(name = "SiJAYMC", length = 50)
	public String getSijaymc() {
		return sijaymc;
	}
	public void setSijaymc(String sijaymc) {
		this.sijaymc = sijaymc;
	}
	@Column(name = "SiJAYDM", length = 10)
	public String getSijaydm() {
		return sijaydm;
	}
	public void setSijaydm(String sijaydm) {
		this.sijaydm = sijaydm;
	}
	@Column(name = "FYCJ", length = 10)
	public String getFycj() {
		return fycj;
	}
	public void setFycj(String fycj) {
		this.fycj = fycj;
	}
	@Column(name = "GYMC", length = 50)
	public String getGymc() {
		return gymc;
	}
	public void setGymc(String gymc) {
		this.gymc = gymc;
	}
	@Column(name = "ZYMC", length = 50)
	public String getZymc() {
		return zymc;
	}
	public void setZymc(String zymc) {
		this.zymc = zymc;
	}
	@Column(name = "JCYMC", length = 50)
	public String getJcymc() {
		return jcymc;
	}
	public void setJcymc(String jcymc) {
		this.jcymc = jcymc;
	}
	@Column(name = "CPRQ", length = 50)
	public String getCprq() {
		return cprq;
	}
	public void setCprq(String cprq) {
		this.cprq = cprq;
	}
	@Column(name = "CPNF", length = 20)
	public String getCpnf() {
		return cpnf;
	}
	public void setCpnf(String cpnf) {
		this.cpnf = cpnf;
	}
	@Column(name = "SPCX", length = 20)
	public String getSpcx() {
		return spcx;
	}
	public void setSpcx(String spcx) {
		this.spcx = spcx;
	}
	@Column(name = "SPRY", length =100)
	public String getSpry() {
		return spry;
	}
	public void setSpry(String spry) {
		this.spry = spry;
	}
	@Column(name = "YGHZGSR" )
	public String getYghzgsr() {
		return yghzgsr;
	}
	public void setYghzgsr(String yghzgsr) {
		this.yghzgsr = yghzgsr;
	}
	@Column(name = "BG" )
	public String getBg() {
		return bg;
	}
	public void setBg(String bg) {
		this.bg = bg;
	}
	@Column(name = "YGSFCT", length =10)
	public String getYgsfct() {
		return ygsfct;
	}
	public void setYgsfct(String ygsfct) {
		this.ygsfct = ygsfct;
	}
	@Column(name = "BGSFCT", length =10)
	public String getBgsfct() {
		return bgsfct;
	}
	public void setBgsfct(String bgsfct) {
		this.bgsfct = bgsfct;
	}
	@Column(name = "LSMC", length =100)
	public String getLsmc() {
		return lsmc;
	}
	public void setLsmc(String lsmc) {
		this.lsmc = lsmc;
	}
	@Column(name = "LSXM", length =50)
	public String getLsxm() {
		return lsxm;
	}
	public void setLsxm(String lsxm) {
		this.lsxm = lsxm;
	}
	@Column(name = "FLYJ" )
	public String getFlyj() {
		return flyj;
	}
	public void setFlyj(String flyj) {
		this.flyj = flyj;
	}
	
	public Object clone(){
		WssxbDo o=null;
		try{
			o=(WssxbDo)super.clone();
		}catch(CloneNotSupportedException e){
			System.out.println(e.toString());
		}
		return o;
	}
	
}
