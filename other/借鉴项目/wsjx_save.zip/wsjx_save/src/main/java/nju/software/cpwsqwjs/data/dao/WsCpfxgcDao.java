package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcDO;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;

public interface WsCpfxgcDao {

	public int saveCpfxgcDO(WsCpfxgcDO cpfxgcDO);

	public void save(int ajxh, WscpfxgcModel model);

}
