/**
 * 2014-5-19 17:01
 */
package nju.software.cpwsqwjs.service.sp;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;

public interface DsrdwxxService {

	public List<DsrdwxxModel> getDsrdwxxByAjxh(long ajxh,AjjbxxModel ajModel);
	
	public boolean updateDsrdw(long ajxh,int dsrbh,String zd,String zdz);
}
