package nju.software.cpwsqwjs.test;

import nju.software.cpwsqwjs.service.WsfilterService;
import nju.software.cpwsqwjs.service.impl.WsfilterServiceImpl;
import nju.software.cpwsqwjs.service.model.WsfilterModel;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhx on 2017/6/27.
 */
public class SaveWs {
    public static void main(String[] args) throws IOException {
        String path = "/Users/zhx/Desktop/wsduty/����/2016-2017ɸѡ(����).xls";
        save(path);

    }

    public static void save(String filePath) throws IOException{
        //��ʼ������ɸѡModel
        List<WsfilterModel> wsfilterModels = new ArrayList<>();
        //ȡ��excel�е���������
        File f = new File(filePath);
        InputStream inputStream = new FileInputStream(f);
        HSSFWorkbook xssfWorkbook = new HSSFWorkbook(inputStream);
        HSSFSheet sheet1 = xssfWorkbook.getSheetAt(0);
        //����
        for (int rowNum=2;rowNum<sheet1.getLastRowNum();rowNum++){
            HSSFRow row = sheet1.getRow(rowNum);

            WsfilterModel wsfilterModel = new WsfilterModel();
            wsfilterModel.setAh(row.getCell(0).getStringCellValue());
            wsfilterModel.setAjmc(row.getCell(1).getStringCellValue());
            wsfilterModel.setSpcx(row.getCell(2).getStringCellValue());
            wsfilterModel.setFymc(row.getCell(3).getStringCellValue());
            wsfilterModel.setWsbt(row.getCell(4).getStringCellValue());
            wsfilterModel.setCprq(row.getCell(5).getStringCellValue());
            wsfilterModel.setFbrq(row.getCell(6).getStringCellValue());
            wsfilterModel.setZsfy(row.getCell(7).getStringCellValue());
            wsfilterModel.setZsah(row.getCell(8).getStringCellValue());
            wsfilterModel.setSpz(row.getCell(9).getStringCellValue());
            wsfilterModel.setAy(row.getCell(10).getStringCellValue());
            wsfilterModel.setByrw(row.getCell(11).getStringCellValue());
            wsfilterModel.setZw(row.getCell(12).getStringCellValue());
            wsfilterModel.setFt(row.getCell(13).getStringCellValue());
            wsfilterModels.add(wsfilterModel);

        }
        WsfilterService wsfilterService = new WsfilterServiceImpl();
        //wsfilterService.saveWsfilter(wsfilterModels.get(0));
        //wsfilterService.saveWsfilter(wsfilterModels.get(1));
        for (WsfilterModel wsfilter:wsfilterModels) {
            wsfilterService.saveWsfilter(wsfilter);
        }
    }
}
