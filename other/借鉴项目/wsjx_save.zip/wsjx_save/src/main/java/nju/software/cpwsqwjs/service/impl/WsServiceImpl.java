package nju.software.cpwsqwjs.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.rtf.RTFEditorKit;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.SortedDocValuesField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TermRangeFilter;
import org.apache.lucene.search.TermRangeQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.BytesRef;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.usermodel.Range;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.InitializingBean;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.AjjbDO;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.WsService;
import nju.software.cpwsqwjs.service.model.SearchCondition;
import nju.software.cpwsqwjs.service.model.WsModel;
import nju.software.cpwsqwjs.service.model.convert.WsModelConvert;
import nju.software.cpwsqwjs.util.Constant;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import nju.software.cpwsqwjs.util.StringUtil;

public class WsServiceImpl implements WsService, InitializingBean {

	WsJbDao wsJbDao;
	AjjbDao ajjbDao;
	private static Logger log = Logger.getLogger(WsServiceImpl.class);

	// PubAjJbDao pubAjJbDao;
	// ������Ŀ
	public int getWsCount() {
		// TODO Auto-generated method stub
		List<WsJbDO> wss = wsJbDao.findByProperty("ajxh", 1559);
		int i = 0;
		for (WsJbDO do1 : wss) {
			String wjm = do1.getWswjm();
			byte[] nr = do1.getWsnr();
			if (StringUtil.isBlank(wjm) || nr == null || nr.length == 0)
				continue;
			try {
				System.out.println("!!!!!!!!\n"
						+ POIUtil.getContentString(nr, wjm));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			i++;
		}
		return i;
	}

	public List<WsModel> searchByCondition(SearchCondition condition)
			throws IOException {
		// TODO Auto-generated method stub
		List<WsModel> wsModels = new ArrayList<WsModel>();
		if (condition.isNull()) {
			return wsModels;
		}
		BooleanQuery query = new BooleanQuery();
		// ����
		String ah = condition.getAh();
		if (!StringUtil.isBlank(ah)) {
			List<AjjbDO> ajdos = ajjbDao.findByAh(ah);
			if (ajdos != null && ajdos.size() > 0) {
				AjjbDO do1 = ajdos.get(0);
				// �������
				Term term_ajxh = new Term("ajxh", String.valueOf(do1.getAjxh()));
				TermQuery tQuery_ajxh = new TermQuery(term_ajxh);
				BooleanClause clause_ajxh = new BooleanClause(tQuery_ajxh,
						BooleanClause.Occur.MUST);
				query.add(clause_ajxh);
			} else {
				return wsModels;
			}

		}
		// ��������
		String scrqks = condition.getScrqks();
		String scrqjs = condition.getScrqjs();
		if (!(StringUtil.isBlank(scrqks) && StringUtil.isBlank(scrqjs))) {
			if (StringUtil.isBlank(scrqks)) {
				scrqks = "1970-01-01";
			} else {
				scrqks = DateUtil.format(
						DateUtil.parse(scrqks, DateUtil.webFormat),
						DateUtil.webFormat);
				if (scrqks == null) {
					scrqks = "1970-01-01";
				}
			}
			if (StringUtil.isBlank(scrqjs)) {
				scrqjs = DateUtil.format(new Date(), DateUtil.webFormat);
			} else {
				scrqjs = DateUtil.format(
						DateUtil.parse(scrqjs, DateUtil.webFormat),
						DateUtil.webFormat);
				if (scrqjs == null) {
					scrqks = DateUtil.format(new Date(), DateUtil.webFormat);
				}
			}

			TermRangeQuery scrqQuery = TermRangeQuery.newStringRange("scrq",
					scrqks, scrqjs, true, true);
			BooleanClause scrqClause = new BooleanClause(scrqQuery, Occur.MUST);
			query.add(scrqClause);
		}

		// �������
		String wslb = condition.getWslb();
		if (!StringUtil.isBlank(wslb)) {
			List<String> wslbTokens = getTokens(wslb);
			BooleanClause clause_wslb = new BooleanClause(getBoolQuery("wslb",
					wslbTokens), BooleanClause.Occur.MUST);
			query.add(clause_wslb);
		}

		// ����
		String zz = condition.getZz();
		if (!StringUtil.isBlank(zz)) {
			// ����
			Term term_zz = new Term("zz", zz);
			TermQuery tQuery_zz = new TermQuery(term_zz);
			BooleanClause clause_zz = new BooleanClause(tQuery_zz,
					BooleanClause.Occur.MUST);
			query.add(clause_zz);
		}

		// ��������
		String wsnr = condition.getWsnr();
		if (!StringUtil.isBlank(wsnr)) {
			List<String> wsnrTokens = getTokens(wsnr);
			BooleanClause clause_wsnr = new BooleanClause(getBoolQuery("wsnr",
					wsnrTokens), BooleanClause.Occur.MUST);
			query.add(clause_wsnr);
		}

		File indexDir = new File(Constant.IndexPath);
		IndexReader reader = DirectoryReader.open(FSDirectory.open(indexDir
				.toPath()));
		IndexSearcher searcher = new IndexSearcher(reader);
		ScoreDoc[] scoreDocs = searcher.search(query, 1000).scoreDocs;
		System.out.println("��������:" + scoreDocs.length + "��");
		for (int i = 0; i < scoreDocs.length; i++) {
			int doc1 = scoreDocs[i].doc;
			Document document = searcher.doc(doc1);
			wsModels.add(WsModelConvert.documentToModel(document));
		}
		reader.close();
		return wsModels;
	}

	// ��ȡ�ִʽ��
	public List<String> getTokens(String keyword) {
		// TODO Auto-generated method stub
		List<String> tokens = new ArrayList<String>();
		if (StringUtil.isBlank(keyword)) {
			return tokens;
		}
		String text = keyword;
		// �����ִʶ���

		// �����ִ�����

		try {

			Analyzer anal = Constant.Analyzer;
			StringReader reader = new StringReader(text);
			// �ִ�
			TokenStream ts = anal.tokenStream("", reader);
			ts.reset();
			CharTermAttribute term = ts.getAttribute(CharTermAttribute.class);

			while (ts.incrementToken()) {
				tokens.add(term.toString());
				// System.out.print(term.toString()+"|");
			}
			reader.close();
			ts.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tokens.clear();
			tokens.add(keyword);
		}

		return tokens;
	}

	private BooleanQuery getBoolQuery(String field, List<String> keywords) {
		BooleanQuery query = new BooleanQuery();
		for (String keyword : keywords) {
			Term term = new Term(field, keyword);
			TermQuery tQuery = new TermQuery(term);
			BooleanClause clause = new BooleanClause(tQuery,
					BooleanClause.Occur.MUST);
			query.add(clause);
		}
		return query;
	}

	public void setWsJbDao(WsJbDao wsJbDao) {
		this.wsJbDao = wsJbDao;
	}

	public void setAjjbDao(AjjbDao ajjbDao) {
		this.ajjbDao = ajjbDao;
	}

	
//	public byte[] getWsByWjm(String wjm) {
//		// TODO Auto-generated method stub
//		byte[] wsnr = null;
//		wsnr = wsJbDao.getWsnrBytes(wjm);
//		if (wsnr == null)
//			System.out.println("wsnr null!!!");
//		return wsnr;
//	}

	
	public List<WsModel> search(String keyword, String search_way, int page,
			int pageNum, HttpServletRequest request) {
		List<WsModel> wss = new ArrayList<WsModel>();
		switch (search_way) {
		case Constant.QuanWen:
			try {
				wss = searchByKeyword(keyword, page, pageNum, request);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case Constant.AnJianXuHao:
			try {
				wss = searchByAjxh(keyword);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case Constant.WenjianMing:
			try {
				wss = searchByWjm(keyword);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case Constant.WenShuJiBiaoBianHao:
			try {
				wss = searchByWsjbbh(keyword);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case Constant.WenShuNeiRong:
			try {
				wss = searchByWsnr(keyword);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case Constant.ZuoZhe:
			try {
				wss = searchByZz(keyword);
			} catch (IOException | ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			System.out.println("error search way");
		}
		return wss;
	}

	private String getGlString(Query query, String content) {
		try {
			Highlighter highlighter = new Highlighter(new SimpleHTMLFormatter(
					"", ""), new QueryScorer(query));
			Fragmenter fragmenter = new SimpleFragmenter(Constant.WsnrLength);

			highlighter.setTextFragmenter(fragmenter);
			try {
				// System.out.println(content);
				return highlighter.getBestFragment(Constant.Analyzer,
						Constant.Index_Wsnr, content);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (InvalidTokenOffsetsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// ��ø�����query
	private BooleanQuery getGlQuery(boolean isJqss, String keyword) {
		BooleanQuery query = new BooleanQuery();
		List<String> tokens = getTokens(keyword);
		if (!isJqss) {
			// ��������
			BooleanClause clause_wsnr = new BooleanClause(getBoolQuery(
					Constant.Index_Wsnr, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_wsnr);
		} else {
			// ��������
			BooleanClause clause_wsnr = new BooleanClause(getJqcx(keyword,
					Constant.Index_Wsnr), BooleanClause.Occur.SHOULD);
			query.add(clause_wsnr);

		}

		return query;
	}

	public List<WsModel> searchByKeyword(String keyword, int page, int pageNum,
			HttpServletRequest request) throws IOException, ParseException {

		// ִ��������boolean
		BooleanQuery query = new BooleanQuery();
		HttpSession session = request.getSession();
		boolean isjqss = (boolean) session.getAttribute("isJqss");
		// ��������
		BooleanQuery gl = new BooleanQuery();
		BooleanClause gl_clause = new BooleanClause(
				getGlQuery(isjqss, keyword), BooleanClause.Occur.MUST);
		gl.add(gl_clause);

		BooleanClause clause = new BooleanClause(conditionSearch(keyword,
				isjqss), BooleanClause.Occur.MUST);
		query.add(clause);
		BooleanClause clause_wsnr = new BooleanClause(getBoolOrQuery(
				Constant.Index_Wsnr, getTokens(keyword)),
				BooleanClause.Occur.SHOULD);
		gl.add(clause_wsnr);
		File indexDir = new File(Constant.IndexPath);
		IndexReader reader = DirectoryReader.open(FSDirectory.open(indexDir
				.toPath()));
		IndexSearcher searcher = new IndexSearcher(reader);
		TopDocs hits = null;
		ScoreDoc[] scoreDocs = null;

		log.info("����ǰ");
		hits = searcher.search(query, page * pageNum);
		session.setAttribute("count", hits.totalHits + "");
		scoreDocs = hits.scoreDocs;
		System.out.println("��������:" + scoreDocs.length + "��");
		List<WsModel> wss = new ArrayList<WsModel>();
		for (int i = (page - 1) * pageNum; i < scoreDocs.length; i++) {

			int doc1 = scoreDocs[i].doc;
			Document document = searcher.doc(doc1);
			WsModel wsModel = WsModelConvert.documentToModel(document);
			Query glQuery = gl.rewrite(reader);
			String str = getGlString(glQuery, wsModel.getWsnr());
			if (str != null && str.length() != 0)
				wsModel.setWsnr(str);
			else {
				if (wsModel.getWsnr().length() > Constant.WsnrLength)
					wsModel.setWsnr(wsModel.getWsnr().substring(0,
							Constant.WsnrLength));

			}
			wss.add(wsModel);
		}

		log.info("������");
		reader.close();
		return wss;
	}

	
	public List<WsModel> searchByZz(String keyword) throws IOException,
			ParseException {
		// TODO Auto-generated method stub
		return singleSearch(Constant.Index_Zz, keyword);
	}

	
	public List<WsModel> searchByWjm(String keyword) throws IOException,
			ParseException {
		// TODO Auto-generated method stub
		return singleSearch(Constant.Index_Wswjm, keyword);
	}

	
	public List<WsModel> searchByAjxh(String keyword) throws IOException,
			ParseException {
		// TODO Auto-generated method stub
		return singleSearch(Constant.Index_Ajxh, keyword);
	}

	
	public List<WsModel> searchByWsjbbh(String keyword) throws IOException,
			ParseException {
		// TODO Auto-generated method stub
		return singleSearch(Constant.Index_Wsjbbh, keyword);
	}

	
	public List<WsModel> searchByWsnr(String keyword) throws IOException,
			ParseException {
		// TODO Auto-generated method stub
		return singleSearch(Constant.Index_Wsnr, keyword);
	}

	private List<WsModel> singleSearch(String index_tag, String keyword)
			throws IOException, ParseException {
		Term term = new Term(index_tag, keyword);
		Query query = null;

		/*
		 * if(index_tag.equals(Constant.Index_Zz)){ BooleanQuery bquery_zz=new
		 * BooleanQuery(); List<String> tokens_zz=getTokens(keyword);
		 * bquery_zz=getBoolQuery(Constant.Index_Zz, tokens_zz); //Term
		 * term_b_zz=new Term(Constant.Index_Zz, keyword); //TermQuery
		 * tQuery_zz=new TermQuery(term_b_zz); BooleanClause clause_zz=new
		 * BooleanClause(bquery_zz, BooleanClause.Occur.SHOULD);
		 * bquery_zz.add(clause_zz); query=bquery_zz; }else
		 * if(index_tag.equals(Constant.Index_Wswjm)){ BooleanQuery
		 * bquery_wjm=new BooleanQuery(); Term term_b_wjm=new
		 * Term(Constant.Index_Wswjm, keyword); TermQuery tQuery_wjm=new
		 * TermQuery(term_b_wjm); BooleanClause clause_wjm=new
		 * BooleanClause(tQuery_wjm, BooleanClause.Occur.SHOULD);
		 * bquery_wjm.add(clause_wjm); List<String>
		 * tokens_wjm=getTokens(keyword);
		 * bquery_wjm=getBoolQuery(Constant.Index_Wswjm, tokens_wjm);
		 * BooleanClause clause_wjm=new BooleanClause(bquery_wjm,
		 * BooleanClause.Occur.SHOULD); bquery_wjm.add(clause_wjm);
		 * query=bquery_wjm; }else{ FuzzyQuery fquery=new FuzzyQuery(term);
		 * query=fquery; }
		 */
		TermQuery tquery = new TermQuery(term);
		// FuzzyQuery fquery=new FuzzyQuery(term);
		query = tquery;

		File indexDir = new File(Constant.IndexPath);
		IndexReader reader = DirectoryReader.open(FSDirectory.open(indexDir
				.toPath()));
		IndexSearcher searcher = new IndexSearcher(reader);
		ScoreDoc[] scoreDocs = searcher.search(query,
				Constant.SingleSearchLength).scoreDocs;
		System.out.println("��������:" + scoreDocs.length + "��");
		List<WsModel> wss = new ArrayList<WsModel>();
		for (int i = 0; i < scoreDocs.length; i++) {
			int doc1 = scoreDocs[i].doc;
			Document document = searcher.doc(doc1);
			wss.add(WsModelConvert.documentToModel(document));
		}
		reader.close();
		return wss;
	}

	private BooleanQuery getJqcx(String keyword, String field) {
		BooleanQuery query = new BooleanQuery();
		keyword = keyword.trim();
		String[] split = keyword.split(" ");
		ArrayList<String> list = new ArrayList<String>();
		for (int i = 0; i < split.length; i++) {
			if (!split[i].equals(""))
				list.add(split[i]);
		}
		for (String str : list) {
			PhraseQuery temp = new PhraseQuery();
			List<String> tokens = getTokens(str);
			for (int i = 0; i < tokens.size(); i++) {
				temp.add(new Term(field, tokens.get(i)));
			}

			BooleanClause clause_tj = new BooleanClause(temp,
					BooleanClause.Occur.MUST);
			query.add(clause_tj);
		}
		return query;

	}

	public List<WsModel> searchBySx(String keyword, List<String> fy,
			List<String> sjs, List<String> ajlxs, List<String> wjlxs,
			Date begin, Date end, int page, int pageNum,
			HttpServletRequest request) {

		log.info("ɸѡǰ");
		HttpSession session = request.getSession();
		List<String> tokens = new ArrayList<String>();
		BooleanQuery query = new BooleanQuery();
		BooleanClause clause_con = null;
		boolean isjqss= (boolean) session.getAttribute("isJqss");
	
	 

		clause_con = new BooleanClause(conditionSearch(keyword, isjqss),
				BooleanClause.Occur.MUST);
		// ֻ�Թؼ��ʶ�����ɸѡ�ʸ���
		BooleanQuery gl = new BooleanQuery();
		BooleanClause gl_clause = new BooleanClause(
				getGlQuery(isjqss, keyword), BooleanClause.Occur.MUST);
		gl.add(gl_clause);
		query.add(clause_con);
		//�Է�Ժ����ɸѡ
		if (fy != null && fy.size() != 0) {

			BooleanClause clause_fy = new BooleanClause(getBoolOrQuery(
					Constant.Index_Fy, fy), BooleanClause.Occur.MUST);
			query.add(clause_fy);
			tokens.clear();
		}
		//�����г������ɸѡ
		if (sjs.size() != 0) {

			BooleanClause clause_sj = new BooleanClause(getBoolOrQuery(
					Constant.Index_Sj, sjs), BooleanClause.Occur.MUST);

			query.add(clause_sj);
		}
		//���ļ����ͽ���ɸѡ
		if (wjlxs.size() != 0) {
			tokens.clear();
			BooleanQuery temp = new BooleanQuery();
			for (int index = 0; index < wjlxs.size(); index++) {
				tokens = getTokens(wjlxs.get(index));
				BooleanClause clause_wjlx = new BooleanClause(getBoolQuery(
						Constant.Index_Wsmc, tokens),
						BooleanClause.Occur.SHOULD);
				temp.add(clause_wjlx);
			}
			BooleanClause clause = new BooleanClause(temp,
					BooleanClause.Occur.MUST);

			query.add(clause);
		}
		//�԰������ͽ���ɸѡ
		if (ajlxs.size() != 0) {

			BooleanClause clause_ajlx = new BooleanClause(getBoolOrQuery(
					Constant.Index_Ajlx, ajlxs), BooleanClause.Occur.MUST);

			query.add(clause_ajlx);
		}
		File indexDir = new File(Constant.IndexPath);
		IndexReader reader = null;
		try {
			reader = DirectoryReader.open(FSDirectory.open(indexDir.toPath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		IndexSearcher searcher = new IndexSearcher(reader);

		ScoreDoc[] scoreDocs = null;
		TopDocs hits = null;

		try {
	
			if (begin != null && end != null) {
				BytesRef beginbyte = new BytesRef(DateUtil.format(begin,
						DateUtil.webFormat));
				BytesRef endbyte = new BytesRef(DateUtil.format(end,
						DateUtil.webFormat));
				Filter filter = new TermRangeFilter(Constant.Index_Scrq,
						beginbyte, endbyte, true, true);
				hits = searcher.search(query, filter, page * pageNum);

			} else {
				hits = searcher.search(query, page * pageNum);
			}
		
				session.setAttribute("count", hits.totalHits + "");

		} catch (IOException e) {
			e.printStackTrace();
		}
		scoreDocs = hits.scoreDocs;
		log.info("ɸѡ��");
		List<WsModel> wsModels = new ArrayList<WsModel>();
		if (scoreDocs == null || scoreDocs.length == 0)
			return wsModels;
		System.out.println("��������:" + scoreDocs.length + "��");
		/*
		 * ת����wsmodel
		 * 
		 */
		for (int i = (page - 1) * pageNum; i < scoreDocs.length; i++) {
			int doc1 = scoreDocs[i].doc;
			Document document = null;
			try {
				document = searcher.doc(doc1);
			} catch (IOException e) {
				e.printStackTrace();
			}
			WsModel wsModel = WsModelConvert.documentToModel(document);
			
			/*
			 * ������ȡ��һ�ΰ����ؼ���
			 */
			Query glQuery = null;
			try {
				glQuery = gl.rewrite(reader);
			} catch (IOException e) {
				log.info(e);
				e.printStackTrace();
			}
			String str = getGlString(glQuery, wsModel.getWsnr());
			if (str != null && str.length() != 0)
				wsModel.setWsnr(str);
			else {
				if (wsModel.getWsnr().length() > Constant.WsnrLength)
					wsModel.setWsnr(wsModel.getWsnr().substring(0,
							Constant.WsnrLength));
			}
			wsModels.add(wsModel);

		}

		try {
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return wsModels;
	}

	private BooleanQuery getBoolOrQuery(String field, List<String> condition) {
		BooleanQuery query = new BooleanQuery();
		for (String keyword : condition) {
			// System.out.println(keyword + "======" + field);
			List<String> tokensList = getTokens(keyword);
			BooleanClause clause = new BooleanClause(getBoolQuery(field,
					tokensList), BooleanClause.Occur.SHOULD);
			query.add(clause);
		}
		return query;
	}

	public BooleanQuery conditionSearch(String keyword, boolean isJqss) {
		BooleanQuery query = new BooleanQuery();

		List<String> tokens = getTokens(keyword);
		for (String str : tokens) {
			System.out.println("test========" + str);
		}
		if (!isJqss) {
			// ����
			BooleanClause clause_zz = new BooleanClause(getBoolQuery(
					Constant.Index_Zz, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_zz);
			// �ļ���
			BooleanClause clause_wjm = new BooleanClause(getBoolQuery(
					Constant.Index_Wswjm, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_wjm);
			// �������
			BooleanClause clause_wslb = new BooleanClause(getBoolQuery(
					Constant.Index_Wslb, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_wslb);
			// ��������
			BooleanClause clause_wsmc = new BooleanClause(getBoolQuery(
					Constant.Index_Wsmc, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_wsmc);
			// ��������
			BooleanClause clause_wsnr = new BooleanClause(getBoolQuery(
					Constant.Index_Wsnr, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_wsnr);
			// ��Ժ����
			BooleanClause clause_fy = new BooleanClause(getBoolQuery(
					Constant.Index_Fy, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_fy);
		} else {
			BooleanClause clause_zz = new BooleanClause(getBoolQuery(
					Constant.Index_Zz, tokens), BooleanClause.Occur.SHOULD);
			query.add(clause_zz);
			// �ļ���
			BooleanClause clause_wjm = new BooleanClause(getJqcx(keyword,
					Constant.Index_Wswjm), BooleanClause.Occur.SHOULD);
			query.add(clause_wjm);
			// �������
			BooleanClause clause_wslb = new BooleanClause(getJqcx(keyword,
					Constant.Index_Wslb), BooleanClause.Occur.SHOULD);
			query.add(clause_wslb);
			// ��������
			BooleanClause clause_wsmc = new BooleanClause(getJqcx(keyword,
					Constant.Index_Wsmc), BooleanClause.Occur.SHOULD);
			query.add(clause_wsmc);
			// ��������
			BooleanClause clause_wsnr = new BooleanClause(getJqcx(keyword,
					Constant.Index_Wsnr), BooleanClause.Occur.SHOULD);
			query.add(clause_wsnr);
			// ��Ժ����
			BooleanClause clause_fy = new BooleanClause(getJqcx(keyword,
					Constant.Index_Fy), BooleanClause.Occur.SHOULD);
			query.add(clause_fy);
		}

		return query;
	}

	
	public String convertToText(byte[] ws, String suffix) {
		// TODO Auto-generated method stub
		suffix = suffix.toLowerCase();
		try {
			InputStream in = new ByteArrayInputStream(ws);
			String text = ""; // ��ת������
			int index=suffix.lastIndexOf(".");
			if(index==-1)
				return "";
			suffix=suffix.substring(index+1, suffix.length());
			if (suffix.equals("rtf")) {
				// ��ȡrtf�ĵ� text
				RTFEditorKit rtf = new RTFEditorKit();
				DefaultStyledDocument dsd = new DefaultStyledDocument();
				rtf.read(in, dsd, 0);
				text = new String(dsd.getText(0, dsd.getLength()).getBytes(
						"ISO8859_1"), "GBK");
			}
			if (suffix.equals("doc")) {
				// ����doc�ĵ� text
				HWPFDocument document = new HWPFDocument(in);
				Range rang = document.getRange();
				text = rang.text();
			}
			else if(suffix.equals("docx")){
				try {
					XWPFDocument xwpf = new XWPFDocument(in);
					XWPFWordExtractor extractor=new XWPFWordExtractor(xwpf);
					text= extractor.getText();
				}  catch (Exception e) {
		            log.info(e);
				}
	
			}
			// ȥ�����з� �Լ��ո�
			text = text.replaceAll("\r", "</br>");
			text = text.replaceAll("\n", "</br>");
			text = text.replaceAll("[ ]+", "&nbsp;");
			text = "<h1><strong><center>" + text + "</h1>";
			String temp = text.replaceFirst("</br>",
					"</center></strong></h1><h1><center><strong>");
			String temp1 = temp
					.replaceFirst("</br>",
							"</strong></center></h1><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");

			// temp=text.replaceFirst("</br>", "</h2>");

			text = temp1.replaceAll("</br>",
					"</h3><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
			//System.out.println(text);
			// System.out.println(text);
			return text;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			// log.error("�����ѯ���ݸ�ʽת������", e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			// log.error("�����ѯ���ݸ�ʽת������", e);
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			// log.error("�����ѯ���ݸ�ʽת������", e);
		} catch (Exception e) {
			// log.error("�����ѯ���ݸ�ʽת������", e);
		}
		return null;

	}

	
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub

	}

}
