package nju.software.cpwsqwjs.service.impl.sp;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.LaAyDao;
import nju.software.cpwsqwjs.data.dataobject.LaAyDO;
import nju.software.cpwsqwjs.service.model.sp.LaayModel;
import nju.software.cpwsqwjs.service.sp.LaayService;

public class LaayServiceImpl implements LaayService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static LaAyDao laAyDao;
	static {
		laAyDao = (LaAyDao) appContext.getBean("laAyDao");
	}
	@Override
	public List<LaayModel> getLaayByAjxh(long ajxh) {
		List<LaAyDO> laAyDOs = laAyDao.findByProperty("ajxh", (int)ajxh);
		List<LaayModel> laayModels = LaayModel.laayDoListToModelList(laAyDOs);
		return laayModels;
	}

}
