package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.WsXspjjgfjxDao;
import nju.software.cpwsqwjs.data.dao.WsXspjjgfzDao;
import nju.software.cpwsqwjs.data.dao.WsXspjjgpfDao;
import nju.software.cpwsqwjs.data.dao.WsajjbxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfjxDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.WsXspjjgfzService;
import nju.software.cpwsqwjs.service.model.xs.FjxModel;
import nju.software.cpwsqwjs.service.model.xs.PfModel;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.service.model.xs.XspjjgfzModel;
import nju.software.cpwsqwjs.service.model.xs.ZmModel;

public class WsXspjjgfzServiceImpl implements WsXspjjgfzService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static WsXspjjgfzDao wsXspjjgfzDao;
	private static WsXspjjgpfDao wsXspjjgpfDao;
	private static WsXspjjgfjxDao wsXspjjgfjxDao;
	static {
		wsXspjjgfzDao = (WsXspjjgfzDao) appContext.getBean("wsXspjjgfzDao");
		wsXspjjgpfDao = (WsXspjjgpfDao)appContext.getBean("wsXspjjgpfDao");
		wsXspjjgfjxDao = (WsXspjjgfjxDao)appContext.getBean("wsXspjjgfjxDao");
	}

	@Override
	public int saveFz(XspjjgfzModel fzModel,int ajxh) {
		// TODO Auto-generated method stub
		WsXspjjgfzDO fzDo = new WsXspjjgfzDO(fzModel);
		fzDo.setAjxh(ajxh);
		int fzbh = wsXspjjgfzDao.getMaxFzbhByAjxh(ajxh)+1;
		fzDo.setFzbh(fzbh);
		wsXspjjgfzDao.save(fzDo);
		return fzbh;
	}

	@Override
	public int savePf(PfModel pf, int ajxh, int fzbh,String pflx) {
		// TODO Auto-generated method stub
		WsXspjjgpfDO pfDo = new WsXspjjgpfDO(pf, pflx);
		pfDo.setAjxh(ajxh);
		pfDo.setFzbh(fzbh);
		int maxPfbh = wsXspjjgpfDao.getMaxPfbhByAjxhAndFzbh(ajxh, fzbh)+1;
		pfDo.setPfbh(maxPfbh);
		return wsXspjjgpfDao.save(pfDo);
	}

	@Override
	public int saveFjx(FjxModel model, int ajxh,int fzbh,int pfbh) {
		// TODO Auto-generated method stub
		WsXspjjgfjxDO fjxDo = new WsXspjjgfjxDO(model);
		fjxDo.setAjxh(ajxh);
		fjxDo.setFzbh(fzbh);
		int fjxbh = wsXspjjgfjxDao.getMaxfjxbhByAjxh(ajxh)+1; 
		fjxDo.setFjxbh(fjxbh);
		return wsXspjjgfjxDao.save(fjxDo);
	}

	@Override
	public void saveXspjjg(int ajxh,XsPjjgModel pjjgModel) {
		// TODO Auto-generated method stub
		if(pjjgModel.getPjjgfzModels()!=null){
			for(XspjjgfzModel fzModel:pjjgModel.getPjjgfzModels()){
				int fzbh = saveFz(fzModel, ajxh);
				if(fzModel.getDzpf()!=null){
					for(PfModel dzpf:fzModel.getDzpf()){
						int pfbh = savePf(dzpf, ajxh, fzbh, "�����з�");
						if(dzpf.getFjxList()!=null && dzpf.getFjxList().size()>0){
							for(FjxModel fjx:dzpf.getFjxList()){
								saveFjx(fjx, ajxh, fzbh, pfbh);
							}
						}
					}
				}
				if(fzModel.getZxpf()!=null){
					int pfbh = savePf(fzModel.getZxpf(), ajxh, fzbh, "ִ���з�");
					if(fzModel.getZxpf().getFjxList()!=null){
						for(FjxModel fjx:fzModel.getZxpf().getFjxList()){
							saveFjx(fjx, ajxh, fzbh, pfbh);
						}
					}
				}
			}
		}
	}

	@Override
	public void saveFjxList(List<FjxModel> modelList, int ajxh, int fzbh,
			int pfbh) {
		// TODO Auto-generated method stub
		List<WsXspjjgfjxDO> fjxDoList = new ArrayList<WsXspjjgfjxDO>();
		int fjxbh = wsXspjjgfjxDao.getMaxfjxbhByAjxh(ajxh)+1; 
		for(FjxModel model:modelList){
			WsXspjjgfjxDO fjxDo = new WsXspjjgfjxDO(model);
			fjxDo.setAjxh(ajxh);
			fjxDo.setFzbh(fzbh);
			fjxDo.setFjxbh(fjxbh);
			fjxbh++;
			fjxDoList.add(fjxDo);
		}
		wsXspjjgfjxDao.saveFjxList(fjxDoList);
	}

	@Override
	public void savePjjgBacth(int ajxh, XsPjjgModel pjjgModel) {
		// TODO Auto-generated method stub
		 wsXspjjgfzDao.savePjjg(ajxh, pjjgModel);
	}

}
