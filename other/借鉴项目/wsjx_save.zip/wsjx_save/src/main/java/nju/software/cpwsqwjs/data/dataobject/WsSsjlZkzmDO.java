package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WsssjlZkzmModel;

/**
 * WsssjlzkjlDO entity. @author MyEclipse Persistence Tools
 * ���ϼ�¼ ָ������
 */
@Entity
@Table(name = "WS_SSJL_ZKJL_ZM")
@IdClass(WsSsjlZkzmDoId.class)
public class WsSsjlZkzmDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer zmbh;// �������
	private Integer zkjlbh;//ָ�ؼ�¼���
	private String zm;
	private String zmdm;
	private String wzzm;
	/** default constructor */
	public WsSsjlZkzmDO() {
	}

	/** minimal constructor */
	public WsSsjlZkzmDO(Integer ajxh, Integer zmbh) {
		this.ajxh = ajxh;
		this.zmbh = zmbh;
	}

	public WsSsjlZkzmDO(Integer ajxh, Integer zmbh, Integer zkjlbh, String zm,
			String zmdm, String wzzm) {
		super();
		this.ajxh = ajxh;
		this.zmbh = zmbh;
		this.zkjlbh = zkjlbh;
		this.zm = zm;
		this.zmdm = zmdm;
		this.wzzm = wzzm;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	@Id
	@Column(name = "ZMBH", nullable = false)
	public Integer getZmbh() {
		return zmbh;
	}

	public void setZmbh(Integer zmbh) {
		this.zmbh = zmbh;
	}
	@Column(name = "ZKJLBH")
	public Integer getZkjlbh() {
		return zkjlbh;
	}

	public void setZkjlbh(Integer zkjlbh) {
		this.zkjlbh = zkjlbh;
	}
	@Column(name = "ZM", length = 100)
	public String getZm() {
		return zm;
	}

	public void setZm(String zm) {
		this.zm = zm;
	}
	@Column(name = "ZMDM", length = 50)
	public String getZmdm() {
		return zmdm;
	}

	public void setZmdm(String zmdm) {
		this.zmdm = zmdm;
	}
	@Column(name = "WZZM", length = 100)
	public String getWzzm() {
		return wzzm;
	}

	public void setWzzm(String wzzm) {
		this.wzzm = wzzm;
	}

	public WsSsjlZkzmDO(WsssjlZkzmModel zmModel){
		if(zmModel.getZkzm()!=null){
			this.zm = zmModel.getZkzm();
		}
		if(zmModel.getWzzm()!=null){
			this.wzzm = zmModel.getWzzm();
		}
		if(zmModel.getZmdm()!=null){
			this.zmdm = zmModel.getZmdm();
		}
	}
	 
}