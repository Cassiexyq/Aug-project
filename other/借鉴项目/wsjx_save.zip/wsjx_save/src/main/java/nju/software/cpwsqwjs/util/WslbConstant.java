package nju.software.cpwsqwjs.util;

public class WslbConstant {
	public static String wslb_tsbll="ͥ���¼��";
	
}
