package nju.software.cpwsqwjs.controller;

import java.io.UnsupportedEncodingException;

import nju.software.cpwsqwjs.service.impl.sp.AjjbxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrdwxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrgrxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrjgxxServiceImpl;
import nju.software.cpwsqwjs.service.sp.Ajjbxxservice;
import nju.software.cpwsqwjs.service.sp.DsrdwxxService;
import nju.software.cpwsqwjs.service.sp.DsrgrxxService;
import nju.software.cpwsqwjs.service.sp.DsrjgxxService;
import nju.software.cpwsqwjs.util.JdjcEnum;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.vo.JYResult;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value="/")
public class HtController {
	
	@Autowired
	Ajjbxxservice ajjbxxservice ;
	@Autowired
	DsrgrxxService dsrgrxxservice ;
	@Autowired
	DsrdwxxService dsrdwxxservice ;
	@Autowired
	DsrjgxxService dsrjgxxservice ;
	
	public void setAjjbxxservice(Ajjbxxservice ajjbxxservice) {
		this.ajjbxxservice = ajjbxxservice;
	}

	public void setDsrgrxxservice(DsrgrxxService dsrgrxxservice) {
		this.dsrgrxxservice = dsrgrxxservice;
	}

	public void setDsrdwxxservice(DsrdwxxService dsrdwxxservice) {
		this.dsrdwxxservice = dsrdwxxservice;
	}

	public void setDsrjgxxservice(DsrjgxxService dsrjgxxservice) {
		this.dsrjgxxservice = dsrjgxxservice;
	}

	@ResponseBody
	@RequestMapping(value="/ht")
	public boolean ht(long ajxh,String jdmc,String jdbz,String wszd) throws UnsupportedEncodingException{
		String szbszl = JdjcEnum.getSzbAndSzlByJdmc(jdmc);
		if(!StringUtil.isBlank(szbszl)){
			String[] res = szbszl.split(";");
			String szb = res[0];
			String szl = res[1];
			if(StringUtil.equals(szb, "PUB_AJ_JB")){
				return ajjbxxservice.updateAj(ajxh, szl, wszd);
			}else if(StringUtil.equals(szb, "DSR_JB")){
				int dsrbh = Integer.parseInt(jdbz);
				return dsrgrxxservice.updateDsrssdw((int)ajxh, dsrbh, wszd);
			}else if(StringUtil.equals(szb, "DSR_GR")){
				int dsrbh = Integer.parseInt(jdbz);
				return dsrgrxxservice.updateGrdsr((int)ajxh, dsrbh, szl, wszd);
			}else if(StringUtil.equals(szb, "DSR_DW")){
				int dsrbh = Integer.parseInt(jdbz);
				return dsrdwxxservice.updateDsrdw(ajxh, dsrbh, szl, wszd);
			}else if(StringUtil.equals(szb, "DSR_XP_JG")){
				int dsrbh = Integer.parseInt(jdbz);
				return dsrjgxxservice.updateDsrdw(ajxh, dsrbh,szl, wszd);
			}
		} 
		return false;
	}
}
