package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.xs.PfModel;
import nju.software.cpwsqwjs.service.model.xs.XspjjgfzModel;
import nju.software.cpwsqwjs.service.model.xs.ZmModel;

/**
 * WsXspjjgfzDO entity. @author MyEclipse Persistence Tools
 * �����о���� ����
 */
@Entity
@Table(name = "WS_XSPJJGFZ")
@IdClass(WsXspjjgfzDOId.class)
public class WsXspjjgfzDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer fzbh;//������
	private String sscyr;// ���ϲ�����
	private String pjjzm;// �о�������
	private String zmdm;//��������
	private String wzzm;//��������
	private String xqksrq;//���ڿ�ʼ����
	private String xqjsrq;//���ڽ�������
	private String xqzdbf;//�����۵ְ취
	private String mzhwfsf;//����������ͷ�
	private String szbf;//���ﲢ��
	private String hblx;//�ϲ�����
	/** default constructor */
	public WsXspjjgfzDO() {
	}

	/** minimal constructor */
	public WsXspjjgfzDO(Integer ajxh, Integer fzbh) {
		this.ajxh = ajxh;
		this.fzbh = fzbh;
	}
	 
	public WsXspjjgfzDO(Integer ajxh, Integer fzbh, String sscyr, String pjjzm,
			String zmdm, String wzzm, String xqksrq, String xqjsrq,
			String xqzdbf, String mzhwfsf, String szbf, String hblx) {
		super();
		this.ajxh = ajxh;
		this.fzbh = fzbh;
		this.sscyr = sscyr;
		this.pjjzm = pjjzm;
		this.zmdm = zmdm;
		this.wzzm = wzzm;
		this.xqksrq = xqksrq;
		this.xqjsrq = xqjsrq;
		this.xqzdbf = xqzdbf;
		this.mzhwfsf = mzhwfsf;
		this.szbf = szbf;
		this.hblx = hblx;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name = "FZBH", nullable = false)
	public Integer getFzbh() {
		return fzbh;
	}

	public void setFzbh(Integer fzbh) {
		this.fzbh = fzbh;
	}
	@Column(name = "SSCYR", length = 50)
	public String getSscyr() {
		return sscyr;
	}

	public void setSscyr(String sscyr) {
		this.sscyr = sscyr;
	}
	@Column(name = "PJZZM", length = 50)
	public String getPjjzm() {
		return pjjzm;
	}

	public void setPjjzm(String pjjzm) {
		this.pjjzm = pjjzm;
	}
	@Column(name = "ZMDM", length = 50)
	public String getZmdm() {
		return zmdm;
	}

	public void setZmdm(String zmdm) {
		this.zmdm = zmdm;
	}
	@Column(name = "WZZM", length = 50)
	public String getWzzm() {
		return wzzm;
	}

	public void setWzzm(String wzzm) {
		this.wzzm = wzzm;
	}
	@Column(name = "XQKSRQ", length = 20)
	public String getXqksrq() {
		return xqksrq;
	}

	public void setXqksrq(String xqksrq) {
		this.xqksrq = xqksrq;
	}
	@Column(name = "XQJSRQ", length = 20)
	public String getXqjsrq() {
		return xqjsrq;
	}

	public void setXqjsrq(String xqjsrq) {
		this.xqjsrq = xqjsrq;
	}
	@Column(name = "XQZDBF", length = 20)
	public String getXqzdbf() {
		return xqzdbf;
	}

	public void setXqzdbf(String xqzdbf) {
		this.xqzdbf = xqzdbf;
	}
	@Column(name = "MZHWZSF", length = 2)
	public String getMzhwfsf() {
		return mzhwfsf;
	}

	public void setMzhwfsf(String mzhwfsf) {
		this.mzhwfsf = mzhwfsf;
	}
	@Column(name = "SZBF", length = 2)
	public String getSzbf() {
		return szbf;
	}

	public void setSzbf(String szbf) {
		this.szbf = szbf;
	}
	@Column(name = "HBLX", length = 2)
	public String getHblx() {
		return hblx;
	}

	public void setHblx(String hblx) {
		this.hblx = hblx;
	}

	public WsXspjjgfzDO(XspjjgfzModel model){
		if(model.getSscyr()!=null){
			this.sscyr = model.getSscyr();
		}
		if(model.getPjzzm()!=null){
			ZmModel zm = model.getPjzzm();
			if(zm.getZm()!=null){
				this.pjjzm = zm.getZm();
			}
			if(zm.getWzzm()!=null){
				this.wzzm = zm.getWzzm();
			}
			if(zm.getZmdm()!=null){
				this.zmdm = zm.getZmdm();
			}
		}
		if(model.getXqksrq()!=null){
			this.setXqksrq(model.getXqksrq());
		}
		if(model.getXqjsrq()!=null){
			this.xqjsrq = model.getXqjsrq();
		}
		if(model.getXqzdbf()!=null){
			this.xqzdbf = model.getXqzdbf();
		}
		if(model.getMzhwzsf()!=null){
			this.mzhwfsf = model.getMzhwzsf();
		}
		if(model.getSzbf()!=null){
			this.szbf = model.getSzbf();
		}
		if(model.getHblx()!=null){
			this.hblx = model.getHblx();
		}
	}
}