package nju.software.cpwsqwjs.data.dao.impl;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsSsjlCtrDao;
import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDO;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDO;
import nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDoId;

public class WsSsjlCtrDaoImpl extends HibernateDaoSupport implements WsSsjlCtrDao {

	@Override
	public void save(WsSsjlCtrDO ctrDo) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(ctrDo);
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public WsSsjlCtrDO findById(WsSsjlCtrDoId id) {
		// TODO Auto-generated method stub
		try {
			WsSsjlCtrDO instance = (WsSsjlCtrDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsSsjlCtrDO", id);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}
	
	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsSpzzcyDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List<WsSsjlCtrDO> findByajxh(int ajxh) {
		// TODO Auto-generated method stub
		return findByProperty("ajxh", ajxh);
	}

	@Override
	public int getMaxCtrbhByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(cybh) from WsSpzzcyDO where ajxh = "+ajxh;

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxCybh = 0;
		if (query.uniqueResult() != null)
			maxCybh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxCybh;
	}
	
	 
	 

}
