package nju.software.cpwsqwjs.service.impl.sp;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.XxxglDao;
import nju.software.cpwsqwjs.data.dataobject.AjjbDO;
import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.data.dataobject.XxxglDO;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DmbModel;
import nju.software.cpwsqwjs.service.sp.Ajjbxxservice;
import nju.software.cpwsqwjs.service.sp.DmbService;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.DmUtil;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.util.XzajUtil;
@Service
public class AjjbxxServiceImpl implements Ajjbxxservice {

//	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
//			"applicationContext.xml", "applicationContextDataSource.xml");
//
//	private static AjjbDao ajjbDao;
//	private static DmbDao dmbDao;
//	private static XxxglDao xxxglDao;
//	static {
//		dmbDao = (DmbDao) appContext.getBean("dmbDao");
//		ajjbDao = (AjjbDao) appContext.getBean("ajjbDao");
//		xxxglDao = (XxxglDao) appContext.getBean("xxxglDao");
//	}
	@Autowired
	private  AjjbDao ajjbDao;
	@Autowired
	private  DmbDao dmbDao;
	@Autowired
	private  XxxglDao xxxglDao;
	
	public void setAjjbDao(AjjbDao ajjbDao) {
		this.ajjbDao = ajjbDao;
	}

	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}

	public void setXxxglDao(XxxglDao xxxglDao) {
		this.xxxglDao = xxxglDao;
	}

	@Override
	public AjjbxxModel getWsAjjbxxByAjxh(long ajxh) {
		// TODO Auto-generated method stub
		AjjbxxModel  aj = this.getAjjbxxByAjxh(ajxh);
		if(aj==null) return null;
		aj = this.convertJafsFromDmToMs(aj);//�᰸��ʽ
		aj= this.convertAjlyFromDmToMs(aj);//������Դ
		aj = this.setFymc(aj);//��Ժ����
		aj = this.convertSycx(aj);//���ó���
		aj = this.convertAjxzSpcxFromDmToMs(aj);//�������� ���г���
		return aj;
	}
	
	@Override
	public AjjbxxModel getAjjbxxByAjxh(long ajxh) {
		// TODO Auto-generated method stub
		AjjbDO ajjbDo = ajjbDao.findById((int)ajxh);	
		if (ajjbDo == null){
			return null;
		}
		AjjbxxModel ajjbxxModel = new AjjbxxModel(ajjbDo);
		return ajjbxxModel;
	}

	@Override
	public AjjbxxModel convertJafsFromDmToMs(AjjbxxModel ajjbxxModel) {
		// TODO Auto-generated method stub
//		�ж����¾ɰ���
		String ajxz = StringUtil.trim(ajjbxxModel.getAjxz());
		String spcx = StringUtil.trim(ajjbxxModel.getSpcx());
		String spcxdz = StringUtil.trim(ajjbxxModel.getSpcxdz());
		Date lasj = ajjbxxModel.getLarq();
		if(DateUtil.getYear(lasj)>=2016){
			String spcxlbbh = "";
			if (ajxz != null) {
				spcxlbbh = DmUtil.getSpcxLbbhByAjxz(ajxz); 
			}
			String lbbhxgdm = ajxz+spcx+spcxdz;
			DmbDO spcxDm = dmbDao.findById(spcxlbbh, spcx); 
			if(!(spcxDm.getXgdm2()!=null && !StringUtil.isBlank(spcxDm.getXgdm2()))){//������С��
				lbbhxgdm = ajxz+spcx+"0";
			}
			XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao("jafs", "PUB_AJ_JB");
			String jafslbbh = xxx.getSjxx2016();
		    jafslbbh = XzajUtil.getLbbhNew(jafslbbh, lbbhxgdm);
		    DmbDO jafsDm = dmbDao.findById(jafslbbh, ajjbxxModel.getJafs());
		    if(jafsDm!=null && !StringUtil.isBlank(jafsDm.getDmms())){
				ajjbxxModel.setJafs(jafsDm.getDmms());
			}
		}else{
			if (ajxz.startsWith("0")) {
				ajxz = ajxz.substring(1);
			}
			if (spcx.startsWith("0")) {
				spcx = spcx.substring(1);
			}
			XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao("jafs", "PUB_AJ_JB");
			String lbbh = xxx.getSjxx();
			if (xxx.getSjxx().contains(",")) {
				lbbh = XzajUtil.getLbbhByColumn(ajxz, spcx,lbbh);
				DmbDO jafsDm = dmbDao.findById(lbbh,ajjbxxModel.getJafs());
				if(jafsDm!=null && !StringUtil.isBlank(jafsDm.getDmms())){
					ajjbxxModel.setJafs(jafsDm.getDmms());
				}
			}
		}
		return ajjbxxModel;
	}

	@Override
	public AjjbxxModel convertAjlyFromDmToMs(AjjbxxModel ajjbxxModel ) {
		// TODO Auto-generated method stub
//		�ж����¾ɰ���
		String ajxz = StringUtil.trim(ajjbxxModel.getAjxz());
		String spcx = StringUtil.trim(ajjbxxModel.getSpcx());
		String spcxdz = StringUtil.trim(ajjbxxModel.getSpcxdz());
		Date lasj = ajjbxxModel.getLarq();
//		2016֮��İ���
		if(DateUtil.getYear(lasj)>=2016){
			String spcxlbbh = "";
			if (ajxz != null) {
				spcxlbbh = DmUtil.getSpcxLbbhByAjxz(ajxz); 
			}
			String lbbhxgdm = ajxz+spcx+spcxdz;
			DmbDO spcxDm = dmbDao.findById(spcxlbbh, spcx); 
			if(!(spcxDm.getXgdm2()!=null && !StringUtil.isBlank(spcxDm.getXgdm2()))){//������С��
				lbbhxgdm = ajxz+spcx+"0";
			}
			XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao("ajly", "PUB_AJ_JB");
			String ajlylbbh = xxx.getSjxx2016();
			ajlylbbh = XzajUtil.getLbbhNew(ajlylbbh, lbbhxgdm);
		    DmbDO ajlyDm = dmbDao.findById(ajlylbbh, ajjbxxModel.getAjly());
		    if(ajlyDm!=null && !StringUtil.isBlank(ajlyDm.getDmms())){
				ajjbxxModel.setAjly(ajlyDm.getDmms());
			}
		}else{
			if (ajxz.startsWith("0")) {
				ajxz = ajxz.substring(1);
			}
			if (spcx.startsWith("0")) {
				spcx = spcx.substring(1);
			}
			XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao("ajly", "PUB_AJ_JB");
			String lbbh = xxx.getSjxx();
			if (xxx.getSjxx().contains(",")) {
				lbbh = XzajUtil.getLbbhByColumn(ajxz, spcx,lbbh);
				DmbDO ajlyDm = dmbDao.findById(lbbh,ajjbxxModel.getAjly());
				if(ajlyDm!=null && !StringUtil.isBlank(ajlyDm.getDmms())){
					ajjbxxModel.setAjly(ajlyDm.getDmms());
				}
			}
		}
		return ajjbxxModel;
	}

	@Override
	public AjjbxxModel convertAjxzSpcxFromDmToMs(AjjbxxModel ajjbxxModel) {
		// TODO Auto-generated method stub
		String ajxz = ajjbxxModel.getAjxz();
		String spcx = ajjbxxModel.getSpcx();
//		��������
		DmbDO ajxzDm = dmbDao.findById("FBS0021-97",ajxz);
		if(ajxzDm!=null && !StringUtil.isBlank(ajxzDm.getDmms())){
//			ajjbxxModel.setAjxz(ajxzDm.getDmms());
			ajjbxxModel.setAjxzStr(ajxzDm.getDmms());
		}else{
			return ajjbxxModel;
		}

		String spcx_lbbh="";
		if(!StringUtil.isBlank(ajxzDm.getXgdm())){
			spcx_lbbh = ajxzDm.getXgdm();
			DmbDO spcxDm = dmbDao.findById(spcx_lbbh,spcx);
			if(spcxDm!=null && !StringUtil.isBlank(spcxDm.getDmms())){
				ajjbxxModel.setSpcx(spcxDm.getDmms());
				ajjbxxModel.setSpcxStr(spcxDm.getDmms());
			}
		}
		return ajjbxxModel;
	}

	@Override
	public AjjbxxModel setFymc(AjjbxxModel ajjbxxModel) {
		// TODO Auto-generated method stub
		DmbDO fymcDm = dmbDao.findById("ϵͳȱʡ","��Ժ����");
		if(fymcDm!=null && !StringUtil.isBlank(fymcDm.getDmms())){
			ajjbxxModel.setFymc(fymcDm.getDmms());
		}
		return ajjbxxModel;
	}

	@Override
	public AjjbxxModel convertSycx(AjjbxxModel ajjbxxModel) {
		// TODO Auto-generated method stub
		if(StringUtil.equals(ajjbxxModel.getSycx(), "1")){
			ajjbxxModel.setSycx("����");
		}else if(StringUtil.equals(ajjbxxModel.getSycx(), "2")){
			ajjbxxModel.setSycx("��ͨ");
		}else if(StringUtil.equals(ajjbxxModel.getSycx(), "3")){
			ajjbxxModel.setSycx("�ٲ�");
		} 
		return ajjbxxModel;
	}

	@Override
	public boolean updateAj(long ajxh, String zd, String zdz) {
		// TODO Auto-generated method stub
		AjjbDO ajjb = ajjbDao.findById((int)ajxh);
		if(StringUtil.equals(zd, "AH")){
			ajjb.setAh(zdz);
		}else if(StringUtil.equals(zd, "LARQ")){
			Date larq = DateUtil.parse(zdz, DateUtil.chineseDtFormat);
			ajjb.setLarq(larq);
		}
		return ajjbDao.save(ajjb);
	}

}
