package nju.software.cpwsqwjs.service.dataService.impl;

import nju.software.cpwsqwjs.service.dataService.WsSsjlzkjlService;
import nju.software.cpwsqwjs.service.model.WsssjlModel;

public class WsSsjlzkjlServiceImpl implements WsSsjlzkjlService {

	@Override
	public void saveZkjl(WsssjlModel ssjlModel) {
		// TODO Auto-generated method stub

	}

}
