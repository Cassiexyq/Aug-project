package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dataobject.WsDsrDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQkDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQzcsDO;

import org.apache.cxf.service.invoker.SessionFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsDsrDao;
import nju.software.cpwsqwjs.service.model.QkqkModel;
import nju.software.cpwsqwjs.service.model.QzcsModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.util.StringUtil;

import java.util.List;


public class WsDsrDaoImpl extends HibernateDaoSupport implements WsDsrDao{

    public static final String SSDW="ssdw";//���ϵ�λ
    public static final String YSSSDW="ysssdw";//ԭ�����ϵ�λ
    public static final String DSRLB="dsrlb";//���������
    public static final String XM="xm";//����
    public static final String XB="xb";//�Ա�
    public static final String MZ="mz";//����
    public static final String GJ="gj"; //����
    public static final String WHCD="whcd";//�Ļ��̶�
    public static final String ZJLX="zjlx";//֤������
    public static final String ZZHM="zjhm";//֤������
    public static final String ZW="zw"; //ְ��
    public static final String DZ="dz";//��ַ
    public static final String SFZH="sfzh";//�Ƿ��ٻ�
    public static final String TSHY="tshy";//������ҵ
    public static final String JGDBR="jgdbr";//���ش�����
    public static final String DWXZ="dwxz";//��λ����
    public static final String XZFLGXZT="xzflgxzt";//�������ɹ�ϵ����
    public static final String XZGLFW="xzglfw";//����������Χ
    public static final String BGLX="bglx";//��������
    public static final String ZZJGDM="zzjgdm";//��֯��������
    public static final String SFBHR="sfbhr";//�Ƿ񱻺���
    public static final String ZRRSF="zrrsf";//��Ȼ������
    public static final String HJSZD="hjszd";//�������ڵ�
    public static final String XJYCS="xjycs";//���Ѻ����
    public static final String XSZRNL="xszrnl";//������������
    public static final String SFCT="sfct";//�Ƿ��ͥ
    public static final String XW="xw";//ѧλ
    public static final String ZZMM="zzmm";//������ò

    @Override
    public WsDsrDO getDsrByAjxh(int ajxh) {
        try {
            WsDsrDO instance = (WsDsrDO)getHibernateTemplate().get(
                    "nju.software.cpwsqwjs.data.dataobject.WsDsrDO", ajxh);
            return instance;
        }catch (RuntimeException re){
            throw re;
        }
    }

    @Override
    public List<WsDsrDO> findByAjxh(int ajxh) {
        return findByProperty("ajxh", ajxh);
    }

    @Override
    public WsDsrDO getDsrByDsrbh(int dsrbh) {
        try{
            WsDsrDO instance = (WsDsrDO)getHibernateTemplate().get(
                    "nju.software.cpwsqwjs.data.dataobject.WsDsrDO", dsrbh);
            return instance;
        }catch (RuntimeException re){
            throw re;
        }
    }

    public List findByProperty(String propertyName, Object value) {
        try {
            String queryString = "from WsDsrDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            throw re;
        }
    }

    @Override
    public List<WsDsrDO> findByDsrbh(int dsrbh) {
        return findByProperty("dsrbh", dsrbh);
    }

    @Override
    public Integer getMaxDsrbhByAjxh(int ajxh) {
        String hql = "select max(dsrbh) from WsDsrDO where ajxh ="+ajxh;

        Session s = this.getSession();
        Query query = s.createQuery(hql);

        int maxDsrbh = 0;
        if (query.uniqueResult() != null)
            maxDsrbh = (Integer) query.uniqueResult();

        this.releaseSession(s);
        return maxDsrbh;
    }

    @Override
    public Integer addDsrDO(WsDsrDO wsDsrDO) {
        try{
            getHibernateTemplate().saveOrUpdate(wsDsrDO);
            return wsDsrDO.getDsrbh();
        }catch (RuntimeException re){
            throw re;
        }
    }

	@Override
	public void addDsrDOList(List<WsDsrDO> wsDsrDOList) {
		// TODO Auto-generated method stub
		Session s = this.getSessionFactory().openSession();
		Transaction tx = s.beginTransaction();
		for(WsDsrDO dsrDO:wsDsrDOList){
			s.saveOrUpdate(dsrDO);
		}
		tx.commit();
		s.close();
	}

	@Override
	public void addDsrBatch(List<WssscyrModel> wssscyrModellist, int ajxh,int maxQkbh,int maxQzcsbh) {
		// TODO Auto-generated method stub
		int dsrbh = this.getMaxDsrbhByAjxh(ajxh)+1;
		if(wssscyrModellist!=null && wssscyrModellist.size()>0){
			
			Session s = this.getSessionFactory().openSession();
			Transaction tx = s.beginTransaction();
			int i=0;//��Ǽ�¼����
			for(WssscyrModel sscyr:wssscyrModellist){
				if(!StringUtil.isBlank(sscyr.getSscyr())){
					WsDsrDO wsDsrDO = new WsDsrDO(sscyr);
			        wsDsrDO.setAjxh(ajxh);
			        wsDsrDO.setDsrbh(dsrbh);
			        
			        if (sscyr.getQzcsList()!=null&&!sscyr.getQzcsList().isEmpty()){
			        	 for (QzcsModel qzcsModel:sscyr.getQzcsList()){
			                 WsDsrQzcsDO wsDsrQzcsDO = new WsDsrQzcsDO(qzcsModel);
			                 wsDsrQzcsDO.setAjxh(ajxh);
			                 wsDsrQzcsDO.setDsrbh(dsrbh);
			                 wsDsrQzcsDO.setQzcsbh(maxQzcsbh);
			                 s.save(wsDsrQzcsDO);
			                 maxQzcsbh++;
			                 i++;
			             }
			        }
			        
			        if (sscyr.getQkqkList()!=null&&!sscyr.getQkqkList().isEmpty()){
			        	  for (QkqkModel qkqkModel:sscyr.getQkqkList()){
			                  WsDsrQkDO wsDsrQkDO = new WsDsrQkDO(qkqkModel);
			                  wsDsrQkDO.setAjxh(ajxh);
			                  wsDsrQkDO.setDsrbh(dsrbh);
			                  wsDsrQkDO.setQkbh(maxQkbh);
			                  s.save(wsDsrQkDO);
			                  maxQkbh++;
			                  i++;
			              }
			        }
			        s.save(wsDsrDO);
			        dsrbh++;
			        i++;
				}
				
				if(i>50){
					s.flush();
					s.clear();
				}
			}
			tx.commit();
			s.close();
		}
	}
}
