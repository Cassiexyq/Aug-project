package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;

/**
 * WsXspjjgfzDOId entity. @author MyEclipse Persistence Tools
 */
public class WsXspjjgfzDOId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer fzbh;

	// Constructors

	/** default constructor */
	public WsXspjjgfzDOId() {
	}

	/** full constructor */
	public WsXspjjgfzDOId(Integer ajxh, Integer fzbh) {
		this.ajxh = ajxh;
		this.fzbh = fzbh;
	}

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "FZBH", nullable = false)
	public Integer getFzbh() {
		return fzbh;
	}

	public void setFzbh(Integer fzbh) {
		this.fzbh = fzbh;
	}
	
	public boolean equals(Object other) {
		if ((this == other))
			return true;
		if ((other == null))
			return false;
		if (!(other instanceof WsXspjjgfzDOId))
			return false;
		WsXspjjgfzDOId castOther = (WsXspjjgfzDOId) other;

		return ((this.getAjxh() == castOther.getAjxh()) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((this.getFzbh() == castOther.getFzbh()) || (this
						.getFzbh() != null && castOther.getFzbh() != null && this
						.getFzbh().equals(castOther.getFzbh())));
	}

	public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getFzbh() == null ? 0 : this.getFzbh().hashCode());
		return result;
	}

}