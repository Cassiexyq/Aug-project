package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.List;
import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.PubLaAyDao;
import nju.software.cpwsqwjs.data.dao.WsajjbxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjxxbDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.WsajjbxxService;
import nju.software.cpwsqwjs.service.datamodel.WsajjbxxModel;
import nju.software.cpwsqwjs.service.model.PjjgnrModel;
import nju.software.cpwsqwjs.service.model.WsCpjgssfModel;
import nju.software.cpwsqwjs.service.model.WscpjgModel;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.service.model.WswwModel;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.util.MyBeanUtils;

public class WsajjbxxServiceImpl implements WsajjbxxService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static WsajjbxxbDao wsajjbxxbDao;
	
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsajjbxxbDao = (WsajjbxxbDao) appContext.getBean("wsajjbxxbDao");
	}
	
	@Override
	public WsajjbxxModel getAjjbxxModelByAh(String ah) {
		
		List<WsAjxxbDO> ajList = wsajjbxxbDao.findByAh(ah);
		if(ajList!=null && ajList.size()>0){
			WsAjxxbDO aj = ajList.get(0);
			WsajjbxxModel ajjbxxModel = new WsajjbxxModel();
			try {
				MyBeanUtils.copyBean2Bean(ajjbxxModel, aj);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ajjbxxModel;
		}else{
			return null;
		}
	}

	@Override
	public int addAjjbxx(WswsModel wswsModel) {
		// TODO Auto-generated method stub
		WsAjxxbDO ajxxbDO = new WsAjxxbDO(wswsModel);
		int ajxhMax = wsajjbxxbDao.getMaxAjxh();
		ajxxbDO.setAjxh(ajxhMax+1);
		return wsajjbxxbDao.addAjjbxxDo(ajxxbDO);
	}

	@Override
	public void fromCpjgModel(WsAjxxbDO wsAjxxbDO, WscpjgModel cpjgModel) {
		// TODO Auto-generated method stub
		if(cpjgModel.getSftcgxyy()!=null){
			wsAjxxbDO.setTcgxqyy(cpjgModel.getSftcgxyy());
		}
		if(cpjgModel.getJafs()!=null){
			wsAjxxbDO.setJafs(cpjgModel.getJafs());
		}
		if(cpjgModel.getKssz()!=null){
			wsAjxxbDO.setKssz(cpjgModel.getKssz());
		}
		if(cpjgModel.getSsqx()!=null){
			wsAjxxbDO.setSsqx(cpjgModel.getSsqx());
		}
		if(cpjgModel.getSstjcl()!=null){
			wsAjxxbDO.setSstjcl(cpjgModel.getSstjcl());
		}
		if(cpjgModel.getSffhcs()!=null){
			wsAjxxbDO.setSffhcs(cpjgModel.getSffhcs());
		}
		if(cpjgModel.getFhcsyy()!=null){
			wsAjxxbDO.setFhccyy(cpjgModel.getFhcsyy());
		}
		if(cpjgModel.getJabdze()!=null){
			wsAjxxbDO.setJazbd(cpjgModel.getJabdze());
		}
	}

	public void addFromWwModel(int ajxh,WswwModel wwModel){
		WsAjxxbDO ajxxDo = wsajjbxxbDao.getAjjbxxByAjxh(ajxh);
		if(ajxxDo!=null){
			if(wwModel.getWsrq()!=null){
				ajxxDo.setPjsj(wwModel.getWsrq());
			}
			if(wwModel.getYear()!=null){
				ajxxDo.setJand(wwModel.getYear());
			}
			if(wwModel.getMonth()!=null){
				ajxxDo.setJayf(wwModel.getMonth());
			}
			wsajjbxxbDao.addAjjbxxDo(ajxxDo);
		}
	}
	@Override
	public int addAjjbxxFromWsAndCpjg( WswsModel wswsModel, WscpjgModel cpjgModel,WswwModel wwModel) {
		// TODO Auto-generated method stub
		//����
		WsAjxxbDO ajxxbDO = new WsAjxxbDO(wswsModel);
//		�о����
		fromCpjgModel(ajxxbDO, cpjgModel);
		int ajxhMax = wsajjbxxbDao.getMaxAjxh();
		ajxxbDO.setAjxh(ajxhMax+1);
		//��β
		if(wwModel.getWsrq()!=null){
			ajxxbDO.setPjsj(wwModel.getWsrq());
		}
		if(wwModel.getYear()!=null){
			ajxxbDO.setJand(wwModel.getYear());
		}
		if(wwModel.getMonth()!=null){
			ajxxbDO.setJayf(wwModel.getMonth());
		}
		return wsajjbxxbDao.addAjjbxxDo(ajxxbDO);
	}

	@Override
	public int addFromXsWsAndPjjg( WswsModel wswsModel,XsPjjgModel pjjgModel,WswwModel wwModel) {
		// TODO Auto-generated method stub
		WsAjxxbDO ajxxbDO = new WsAjxxbDO(wswsModel);
		convertFromXspjjg(ajxxbDO, pjjgModel);
		int ajxhMax = wsajjbxxbDao.getMaxAjxh();
		ajxxbDO.setAjxh(ajxhMax+1);
		//��β
		if(wwModel.getWsrq()!=null){
			ajxxbDO.setPjsj(wwModel.getWsrq());
		}
		if(wwModel.getYear()!=null){
			ajxxbDO.setJand(wwModel.getYear());
		}
		if(wwModel.getMonth()!=null){
			ajxxbDO.setJayf(wwModel.getMonth());
		}
		return wsajjbxxbDao.addAjjbxxDo(ajxxbDO);
	}
	
	public void convertFromXspjjg(WsAjxxbDO wsAjxxbDO,XsPjjgModel cpjgModel){
		if(cpjgModel.getTcgxyy()!=null){
			wsAjxxbDO.setTcgxqyy(cpjgModel.getTcgxyy());
		}
		if(cpjgModel.getJafs()!=null){
			wsAjxxbDO.setJafs(cpjgModel.getJafs());
		}
		if(cpjgModel.getKssz()!=null){
			wsAjxxbDO.setKssz(cpjgModel.getKssz());
		}
		if(cpjgModel.getSsqx()!=null){
			wsAjxxbDO.setSsqx(cpjgModel.getSsqx());
		}
		if(cpjgModel.getSstjcl()!=null){
			wsAjxxbDO.setSstjcl(cpjgModel.getSstjcl());
		}
	}

	@Override
	public int getMaxAjxh() {
		// TODO Auto-generated method stub
		return   wsajjbxxbDao.getMaxAjxh();
	}
}
