package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBszjdDO;


public interface WsAjjbqkBszjdDao {
    public WsAjjbqkBszjdDO getByAjxh(int ajxh);
    public void save(WsAjjbqkBszjdDO wsAjjbqkBszjdDO);
    public int getMaxbh();
}
