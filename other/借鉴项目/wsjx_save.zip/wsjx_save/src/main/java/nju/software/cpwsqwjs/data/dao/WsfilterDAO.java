package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsfilterDO;

import java.util.List;

/**
 * Created by zhx on 2017/6/27.
 */
public interface WsfilterDAO {
    /**
     * �����洢�������
     * @param wsfilterDOS
     */
    public void addWsfilterList(List<WsfilterDO> wsfilterDOS);

    /**
     * �洢���������
     * @param wsfilterDO
     * @return
     */
    public String addWsfilter(WsfilterDO wsfilterDO);

    /**
     * �õ����ID
     * @return
     */
    public long getMaxId();

    public String save2(WsfilterDO wsfilterDO);
}
