package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfjxDO;

public interface WsXspjjgfjxDao {

	public int save(WsXspjjgfjxDO fix);
	public int getMaxfjxbhByAjxh(int ajxh);
	public void saveFjxList(List<WsXspjjgfjxDO> doList);
}
