package nju.software.cpwsqwjs.service.dataService;

import nju.software.cpwsqwjs.data.dataobject.WssxbDo;

public interface WssxbService {

	public int getMaxid();
	public void save(WssxbDo wssx);
}
