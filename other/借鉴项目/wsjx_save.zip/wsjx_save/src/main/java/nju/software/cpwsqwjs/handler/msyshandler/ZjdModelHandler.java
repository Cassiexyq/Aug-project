package nju.software.cpwsqwjs.handler.msyshandler;

import java.util.ArrayList;
import java.util.List;

public class ZjdModelHandler {
	public List jxZjdModellist(List<String> zjd) {
		List zjdmodellist=new ArrayList<>();
		for(int i=0;i<zjd.size();i++){
			String[] zjdlist=zjd.get(i).split(" ");
//			for(int j=0;j<zjdlist.length;j++){
//				System.out.println(zjdlist[j]);
//			}
		}
		return zjd;
	}
}
