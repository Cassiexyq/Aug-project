package nju.software.cpwsqwjs.util;

import java.util.StringTokenizer;


/**
 * ����������࣬���ڻ���ܰ������ʺ����г���Ӱ������仯
 * 
 * @author byron
 * 
 */
public class DmUtil {
	/**
	 * ��ȡ�ܰ������ʺ����г���Ӱ�����Ϣ��������
	 * 
	 * @param sjxx
	 * @param ajxzbh
	 * @param spcxbh
	 * @return
	 */
	public static String getLbbh(String sjxx, String ajxzbh, String spcxbh) {
		String lbbh = "";
		StringTokenizer tokenizer = new StringTokenizer(sjxx, ",");
		// boolean spcxbhWild = StringUtil.equals("*", spcxbh);
		String xzWildcard = "";
		String spWildcard = "";
		boolean xzWildJudge = false;
		boolean spWildJudge = false;
		if (StringUtil.equals("*", spcxbh)) // ��r number+*
			while (tokenizer.hasMoreTokens()) {
				String token = tokenizer.nextToken();
				xzWildcard = token.substring(0, 1);
				xzWildJudge = StringUtil.equals("*", xzWildcard);
				if (StringUtil.equals(xzWildJudge ? xzWildcard : ajxzbh,
						xzWildcard)) {
					lbbh = token.substring(2);
					break;
				}
			}
		else
			// ��rnumber+number
			while (tokenizer.hasMoreTokens()) {
				String token = tokenizer.nextToken();
				xzWildcard = token.substring(0, 1);
				xzWildJudge = StringUtil.equals("*", xzWildcard);
				spWildcard = token.substring(1, 2);
				spWildJudge = StringUtil.equals("*", spWildcard);
				String ajxzAndSpcx = spWildJudge ? xzWildcard
						: xzWildJudge ? spWildcard : token.substring(0, 2);
				if (StringUtil.equals(spWildJudge ? xzWildJudge ? xzWildcard
						: ajxzbh : xzWildJudge ? spcxbh : ajxzbh + spcxbh,
						ajxzAndSpcx)) {
					lbbh = token.substring(2);
					break;
				}
			}
		return lbbh;
	}

	/**
	 * ��ȡ���г��������
	 * 
	 * @param ajxz
	 * @return
	 */
	public static String getSpcxLbbhByAjxz(String ajxz) {
		String lbbh = "";

		if (ajxz != null && !"".equals(ajxz)) {
			if ("1".equals(ajxz)) {
				lbbh = "FBS0041-97";
			} else if ("2".equals(ajxz)) {
				lbbh = "FBS0081-97";
			} else if ("3".equals(ajxz)) {
				lbbh = "FBSSPCX-JJ";
			} else if ("4".equals(ajxz)) {
				lbbh = "FBS0081-97";
			} else if ("5".equals(ajxz)) {
				lbbh = "FBSSPCX-ZS";
			} else if ("6".equals(ajxz)) {
				lbbh = "FBS0111-97";
			} else if ("7".equals(ajxz)) {
				lbbh = "FBSSPCX-PC";
			} else if ("8".equals(ajxz)) {
				lbbh = "FBSSPCX-ZX";
			} else if ("9".equals(ajxz)) {
				lbbh = "FBSSPCX-SB";
			} else if ("A".equals(ajxz)) {
				lbbh = "FBSSPCX-QS";
			} else if ("B".equals(ajxz)) {
				lbbh = "FBS2015-SPCXB";
			}else if ("C".equals(ajxz)) {
				lbbh = "FBS2015-SPCXC";
			}else if ("D".equals(ajxz)) {
				lbbh = "FBS2015-SPCXD";
			}else if ("E".equals(ajxz)) {
				lbbh = "FBS2015-SPCXE";
			}else if ("Z".equals(ajxz)) {
				lbbh = "";
			}else if("F".equals(ajxz)){
				lbbh="FBS2015-SPCXF";
			}
		}

		return lbbh;
	}

	/**
	 * ��ȡ���г��������
	 * 
	 * @param ajxz
	 * @return
	 */
	public static String getSxkclyLbbhByAjxz(String ajxz) {
		String lbbh = "";
		if (ajxz != null && !"".equals(ajxz)) {
			if ("1".equals(ajxz)) {
//				lbbh = "FBS0072-97";
				lbbh = "USR610-03";
			} else if ("2".equals(ajxz)) {
				lbbh = "USR413-99";
			} else if ("6".equals(ajxz)) {
				lbbh = "USR413-99";
			} else if ("8".equals(ajxz)) {
				lbbh = "USR709-02";
			}
		}
		return lbbh;
	}
	
	public static String getSxzzlyLbbhByAjxz(String ajxz) {
		String lbbh = "";
		if (ajxz != null && !"".equals(ajxz)) {
			if ("1".equals(ajxz)) {
				lbbh = "FBS0072-97";
			} else if ("2".equals(ajxz)) {
				lbbh = "FBS0092-97";
			} else if ("6".equals(ajxz)) {
				lbbh = "FBS0126-97";
			} else if ("8".equals(ajxz)) {
				lbbh = "FBS0149-97";
			} else if ("7".equals(ajxz)) {
				lbbh = "FBS0092-97";
			} else if ("8".equals(ajxz)) {
				lbbh = "FBS0092-97";
			}
		}
		return lbbh;
	}
}
