package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.*;

/**
 * Created by zhx on 2017/6/27.
 */
@Entity
@Table(name = "WS_FILTER")
@IdClass(WsfilterDO.class)
public class WsfilterDO implements java.io.Serializable{
    /**
     * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
     */
    private static final long serialVersionUID = 1L;

    private long id;
    private String ah;//����
    private String ajmc;//��������
    private String spcx;//���г���
    private String fymc;//��Ժ����
    private String wsbt;//�������
    private String cprq;//��������
    private String fbrq;//��������
    private String zsfy;//����Ժ
    private String zsah;//���󰸺�
    private String spz;//���г�
    private String ay;//����
    private String byrw;//��Ժ��Ϊ
    private String zw;//����
    private String ft;//����

    public WsfilterDO() {
    }

    public WsfilterDO(String ah) {
        this.ah = ah;
    }

    public WsfilterDO(long id,String ah, String ajmc, String spcx, String fymc, String wsbt, String cprq, String fbrq, String zsfy, String zsah, String spz, String ay, String byrw, String zw, String ft) {
        this.id = id;
        this.ah = ah;
        this.ajmc = ajmc;
        this.spcx = spcx;
        this.fymc = fymc;
        this.wsbt = wsbt;
        this.cprq = cprq;
        this.fbrq = fbrq;
        this.zsfy = zsfy;
        this.zsah = zsah;
        this.spz = spz;
        this.ay = ay;
        this.byrw = byrw;
        this.zw = zw;
        this.ft = ft;
    }

    @Id
    @Column(name="ID")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "AH",nullable =false,length = 30)
    public String getAh() {
        return ah;
    }

    public void setAh(String ah) {
        this.ah = ah;
    }
    @Column(name="AJMC")
    public String getAjmc() {
        return ajmc;
    }

    public void setAjmc(String ajmc) {
        this.ajmc = ajmc;
    }
    @Column(name = "SPCX",length = 30)
    public String getSpcx() {
        return spcx;
    }

    public void setSpcx(String spcx) {
        this.spcx = spcx;
    }
    @Column(name = "FYMC",length = 30)
    public String getFymc() {
        return fymc;
    }

    public void setFymc(String fymc) {
        this.fymc = fymc;
    }
    @Column(name = "WSBT")
    public String getWsbt() {
        return wsbt;
    }

    public void setWsbt(String wsbt) {
        this.wsbt = wsbt;
    }
    @Column(name = "CPRQ",length = 20)
    public String getCprq() {
        return cprq;
    }

    public void setCprq(String cprq) {
        this.cprq = cprq;
    }
    @Column(name = "FBRQ",length = 20)
    public String getFbrq() {
        return fbrq;
    }

    public void setFbrq(String fbrq) {
        this.fbrq = fbrq;
    }
    @Column(name = "ZSFY",length = 30)
    public String getZsfy() {
        return zsfy;
    }

    public void setZsfy(String zsfy) {
        this.zsfy = zsfy;
    }
    @Column(name = "ZSAH",length = 30)
    public String getZsah() {
        return zsah;
    }

    public void setZsah(String zsah) {
        this.zsah = zsah;
    }
    @Column(name="SPZ",length = 10)
    public String getSpz() {
        return spz;
    }

    public void setSpz(String spz) {
        this.spz = spz;
    }
    @Column(name = "AY",length = 40)
    public String getAy() {
        return ay;
    }

    public void setAy(String ay) {
        this.ay = ay;
    }
    @Lob
    @Column(name = "BYRW",columnDefinition = "TEXT")
    public String getByrw() {
        return byrw;
    }

    public void setByrw(String byrw) {
        this.byrw = byrw;
    }
    @Lob
    @Column(name = "ZW",columnDefinition = "TEXT")
    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }
    @Lob
    @Column(name = "FT",columnDefinition = "TEXT")
    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }

}
