package nju.software.cpwsqwjs.service;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import nju.software.cpwsqwjs.service.model.SearchCondition;
import nju.software.cpwsqwjs.service.model.WsModel;
import org.apache.lucene.queryparser.classic.ParseException;
public interface WsService {
//	public byte[] getWsByWjm(String wjm);
	/**
	 * ������
	 * @return
	 */
	public int getWsCount();


	/**
	 * ��ѯ��ں���
	 */
	public List<WsModel> search(String keyword,String search_way,int page, int pageNum,HttpServletRequest request);

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByKeyword(String keyword,int page,int pageNum,HttpServletRequest request) throws IOException, ParseException;

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByZz(String keyword) throws IOException, ParseException;

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByWjm(String keyword) throws IOException, ParseException;

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByAjxh(String keyword) throws IOException, ParseException;

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByWsjbbh(String keyword) throws IOException, ParseException;

	/**
	 * ȫ�ļ���
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public List<WsModel> searchByWsnr(String keyword) throws IOException, ParseException;

	/**
	 * ��ȡ����Tokens
	 */
	public List<String> getTokens(String keyword);


	public List<WsModel> searchByCondition(SearchCondition condition) throws IOException;
	//����ɸѡ����������з�������������
	public List<WsModel> searchBySx(String keyword,List<String> fy,List<String> sjs,List<String> ajlxs,List<String> wjlxs,Date begin ,Date end,int page,int pageNum,HttpServletRequest request);
	//��ȡ��������
	public String convertToText(byte[] ws, String suffix);
}
