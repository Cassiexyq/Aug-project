package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WswwModel;

/**
 * WsSsjlCtrDO entity. @author MyEclipse Persistence Tools
 * ���ϼ�¼ ��ͥ�� ȱͥ����Ϣ
 */
@Entity
@Table(name = "WS_SSJL_CTR")
@IdClass(WsSsjlCtrDoId.class)
public class WsSsjlCtrDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer ctrbh;//��ͥ�˱��
	private String ctlx;//��ͥ����
	private String xm;//����
	private String sssf;//��������
	/** default constructor */
	public WsSsjlCtrDO() {
	}

	public WsSsjlCtrDO(Integer ajxh, Integer ctrbh, String ctlx, String xm,
			String sssf) {
		super();
		this.ajxh = ajxh;
		this.ctrbh = ctrbh;
		this.ctlx = ctlx;
		this.xm = xm;
		this.sssf = sssf;
	}

 
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	@Id
	@Column(name = "CTRBH", nullable = false)
	public Integer getCtrbh() {
		return ctrbh;
	}

	public void setCtrbh(Integer ctrbh) {
		this.ctrbh = ctrbh;
	}
	@Column(name = "CTLX", length = 10)
	public String getCtlx() {
		return ctlx;
	}

	public void setCtlx(String ctlx) {
		this.ctlx = ctlx;
	}
	@Column(name = "XM", length = 100)
	public String getXm() {
		return xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}
	@Column(name = "SSSF", length = 50)
	public String getSssf() {
		return sssf;
	}

	public void setSssf(String sssf) {
		this.sssf = sssf;
	}

	 
}