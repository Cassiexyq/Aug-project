package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsAjjbqkBszjdDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBszjdDO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;


public class WsAjjbqkBszjdDaoImpl extends HibernateDaoSupport implements WsAjjbqkBszjdDao {
    private static final Logger log = LoggerFactory.getLogger(WsAjjbqkBszjdDaoImpl.class);

    @Override
    public WsAjjbqkBszjdDO getByAjxh(int ajxh) {
        List<WsAjjbqkBszjdDO>list = findByProperty("AJXH",ajxh);
        if(list==null)
            return null;
        else if(list.size()==0)
            return null;

        return list.get(0);
    }

    public List findByProperty(String propertyName, Object value) {
        log.debug("finding WsAjjbqkBszjdDO with property: " + propertyName
                + ", value: " + value);
        try {
            String queryString = "from WsAjjbqkBszjdDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            log.error("find by property name failed", re);
            throw re;
        }
    }

    @Override
    public void save(WsAjjbqkBszjdDO wsAjjbqkBszjdDO) {
        log.debug("saving wsAjjbqkBszjdDO");
        try {
            getHibernateTemplate().saveOrUpdate(wsAjjbqkBszjdDO);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }

	@Override
	public int getMaxbh() {
		// TODO Auto-generated method stub
		String hql = "select max(bh) from WsAjjbqkBszjdDO";

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxAjxh = 0;
		if (query.uniqueResult() != null)
			maxAjxh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxAjxh;
	}
}
