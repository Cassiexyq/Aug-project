package nju.software.cpwsqwjs.test;

import nju.software.cpwsqwjs.util.ExportUtil;

import java.io.IOException;

/**
 * Created by zhx on 2017/6/29.
 */
public class Ftjx {
    public static void main(String[] args) throws IOException{
        String path = "/Users/zhx/Desktop/wsduty/����/ȫ��20170627������Ϣ(��).xlsx";
        ExportUtil.handleFt(path);
    }
}
