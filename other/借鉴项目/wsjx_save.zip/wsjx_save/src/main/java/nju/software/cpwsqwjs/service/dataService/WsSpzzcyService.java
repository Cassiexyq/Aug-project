package nju.software.cpwsqwjs.service.dataService;

import nju.software.cpwsqwjs.service.model.WswwModel;

public interface WsSpzzcyService {
	public void saveWwmodel(WswwModel model,int ajxh);

}
