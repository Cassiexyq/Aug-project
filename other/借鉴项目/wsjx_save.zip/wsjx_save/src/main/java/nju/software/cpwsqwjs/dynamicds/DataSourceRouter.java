package nju.software.cpwsqwjs.dynamicds;


public class DataSourceRouter {

	public static void routerTo(String fydm) {
		if (CustomerContextHolder.getCustomerType() == null
				|| !CustomerContextHolder.getCustomerType().equals(fydm)) {
			 System.out.println("����Դ�л�: " + DataSourceMap.getDataSourceKey(fydm));
			CustomerContextHolder.setCustomerType(DataSourceMap
					.getDataSourceKey(fydm));
		}
	}
}
