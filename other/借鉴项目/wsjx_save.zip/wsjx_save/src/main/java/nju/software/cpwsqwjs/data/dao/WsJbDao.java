package nju.software.cpwsqwjs.data.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.exception.BaseAppException;

import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


/**
 	* A data access object (DAO) providing persistence and search support for WsJbDO entities.
 			* Transaction control of the save(), update() and delete() operations 
		can directly support Spring container-managed transactions or they can be augmented	to handle user-managed Spring transactions. 
		Each of these methods provides additional information for how to configure it for the desired type of transaction control. 	
	 * @see software.tjspxt.data.dataobject.WsJbDO
  * @author MyEclipse Persistence Tools 
 */

public class WsJbDao extends HibernateDaoSupport  {
	     private static final Logger log = LoggerFactory.getLogger(WsJbDao.class);
		//property constants
	public static final String WSLB = "wslb";
	public static final String WSMC = "wsmc";
	public static final String ZFJ = "zfj";
	public static final String WSLBBH = "wslbbh";
	public static final String WSBH = "wsbh";
	public static final String WSYS = "wsys";
	public static final String WSJJ = "wsjj";
	public static final String ZZH = "zzh";
	public static final String WSWJM = "wswjm";
	public static final String WSAH = "wsah";
	public static final String WSZT = "wszt";
	public static final String SJJZ_FLAG = "sjjzFlag";



	protected void initDao() {
		//do nothing
	}
    
    public void save(WsJbDO transientInstance) {
        log.debug("saving WsJbDO instance");
        try {
            getHibernateTemplate().saveOrUpdate(transientInstance);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }
    }
    
	public void delete(WsJbDO persistentInstance) {
        log.debug("deleting WsJbDO instance");
        try {
            getHibernateTemplate().delete(persistentInstance);
            log.debug("delete successful");
        } catch (RuntimeException re) {
            log.error("delete failed", re);
            throw re;
        }
    }
    
    public WsJbDO findById( nju.software.cpwsqwjs.data.dataobject.WsJbDOId id) {
        log.debug("getting WsJbDO instance with id: " + id);
        try {
            WsJbDO instance = (WsJbDO) getHibernateTemplate()
                    .get("software.tjspxt.data.dataobject.WsJbDO", id);
            return instance;
        } catch (RuntimeException re) {
            log.error("get failed", re);
            throw re;
        }
    }
    
    
    public List<WsJbDO> findByExample(WsJbDO instance) {
        log.debug("finding WsJbDO instance by example");
        try {
            List<WsJbDO> results = (List<WsJbDO>) getHibernateTemplate().findByExample(instance); 
            log.debug("find by example successful, result size: " + results.size());
            return results;
        } catch (RuntimeException re) {
            log.error("find by example failed", re);
            throw re;
        }
    }    
    
    public List findByProperty(String propertyName, Object value) {
      log.debug("finding WsJbDO instance with property: " + propertyName
            + ", value: " + value);
      try {
         String queryString = "from WsJbDO as model where model." 
         						+ propertyName + "= ?";
		 return getHibernateTemplate().find(queryString, value);
      } catch (RuntimeException re) {
         log.error("find by property name failed", re);
         throw re;
      }
	}

	public List<WsJbDO> findByWslb(Object wslb
	) {
		return findByProperty(WSLB, wslb
		);
	}
	
	public List<WsJbDO> findByWsmc(Object wsmc
	) {
		return findByProperty(WSMC, wsmc
		);
	}
	
	public List<WsJbDO> findByZfj(Object zfj
	) {
		return findByProperty(ZFJ, zfj
		);
	}
	
	public List<WsJbDO> findByWslbbh(Object wslbbh
	) {
		return findByProperty(WSLBBH, wslbbh
		);
	}
	
	public List<WsJbDO> findByWsbh(Object wsbh
	) {
		return findByProperty(WSBH, wsbh
		);
	}
	
	public List<WsJbDO> findByWsys(Object wsys
	) {
		return findByProperty(WSYS, wsys
		);
	}
	
	public List<WsJbDO> findByWsjj(Object wsjj
	) {
		return findByProperty(WSJJ, wsjj
		);
	}
	
	public List<WsJbDO> findByZzh(Object zzh
	) {
		return findByProperty(ZZH, zzh
		);
	}
	
	public List<WsJbDO> findByWswjm(Object wswjm
	) {
		return findByProperty(WSWJM, wswjm
		);
	}
	
	public List<WsJbDO> findByWsah(Object wsah
	) {
		return findByProperty(WSAH, wsah
		);
	}
	
	public List<WsJbDO> findByWszt(Object wszt
	) {
		return findByProperty(WSZT, wszt
		);
	}
	
	public List<WsJbDO> findBySjjzFlag(Object sjjzFlag
	) {
		return findByProperty(SJJZ_FLAG, sjjzFlag
		);
	}
	

	public List findAll() {
		log.debug("finding all WsJbDO instances");
		try {
			String queryString = "from WsJbDO";
		 	return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}
	
    public WsJbDO merge(WsJbDO detachedInstance) {
        log.debug("merging WsJbDO instance");
        try {
            WsJbDO result = (WsJbDO) getHibernateTemplate()
                    .merge(detachedInstance);
            log.debug("merge successful");
            return result;
        } catch (RuntimeException re) {
            log.error("merge failed", re);
            throw re;
        }
    }

    public void attachDirty(WsJbDO instance) {
        log.debug("attaching dirty WsJbDO instance");
        try {
            getHibernateTemplate().saveOrUpdate(instance);
            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }
    
    public void attachClean(WsJbDO instance) {
        log.debug("attaching clean WsJbDO instance");
        try {
            getHibernateTemplate().lock(instance, LockMode.NONE);
            log.debug("attach successful");
        } catch (RuntimeException re) {
            log.error("attach failed", re);
            throw re;
        }
    }

	public static WsJbDao getFromApplicationContext(ApplicationContext ctx) {
    	return (WsJbDao) ctx.getBean("WsJbDODAO");
	}
	
	/**
	 * ���ָ��������ŵ�������Ϣ
	 * @param ajxh �������
	 * @return ������Ϣ
	 */
	public List<WsJbDO> getWsJbByAjxh(int ajxh)
	{
		String hql = "from WsJbDO where ajxh = " + ajxh + " and wslb <> '�״�����' order by scrq";
		List<WsJbDO> wsJbDOs = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled())
			log.info("getWsJbByAjxh by sql: " + hql);
		return wsJbDOs;
	}
	public WsJbDO getWsByAjxhAndBh(Integer ajxh,Integer wsjbbh){
		String hql = "from WsJbDO where ajxh = " + ajxh +"and wsjbbh = "+ wsjbbh;
		List<WsJbDO> wsJbDOs = getHibernateTemplate().find(hql);
		if(wsJbDOs.size()!=0){
			return wsJbDOs.get(0);
		}else{
			return new WsJbDO();
		}
	}
	public List<WsJbDO> getJaWsJbByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "from WsJbDO where ajxh = " + ajxh + " and wslb like '%����%' or wslb like '%֪ͨ%' or wslb like '%�о�%' or wslb like '%����%' or wslb like '%������%' and wszt <> '10'";
		List<WsJbDO> wsJbDOs = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled())
			log.info("getWsJbByAjxh by sql: " + hql);
		return wsJbDOs;
	}
	
	/**
	 * ͨ����������ŵõ�������������Ϣ(�˵�����Ժ��������������޿۳���¼)
	 * @param ajxh �������
	 * @return ƥ�䵽�İ���������Ϣ
	 */
	
	/**
	 * ͨ����������źͱ�ŵõ�������������Ϣ
	 * @param ajxh �������
	 * @param wsjbbh ������
	 * @return
	 */
	public WsJbDO getWsJbByAjxhAndBh(int ajxh , int wsjbbh)
	{
		String hql = "from WsJbDO where ajxh = " + ajxh + " and wsjbbh = " + wsjbbh;
		List<WsJbDO> wsJbDOs = getHibernateTemplate().find(hql);
		if(log.isInfoEnabled())
			log.info("getWsJbByAjxh by sql: " + hql);
		return wsJbDOs.size() == 0 ? null : wsJbDOs.get(0);
	}
	
	/**
	 * ���ָ��������ŵ��������ı��
	 * @param ajxh �������
	 * @return ����������
	 */
	public int getMaxBhByAjxh(int ajxh)
	{
		String hql = "select max(wsjbbh) from WsJbDO where ajxh = " + ajxh;
		
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null)
			maxbh = (Integer) query.uniqueResult();
		
		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		
		return maxbh;
	}
	
	/**
	 * ����������Ϣ
	 * @param WsJbDO ����������Ϣ
	 * @return
	 */
	public boolean update(WsJbDO wsJbDO)
	{
		try {
			if (wsJbDO == null) {
				throw new BaseAppException("���µĴ������Ϊ�գ�");
			} else {
				getHibernateTemplate().update(wsJbDO);
				if (log.isInfoEnabled()) {
					log.info("update a WsJbDO with ajxh = " + wsJbDO.getAjxh()
							+ ",jbbh = " + wsJbDO.getWsjbbh());
				}
			}
			// ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("���´������ʱ���ݿⷢ������");
		}
		
		return true;
	}
	
	public byte[] getWsContent(int ajxh,int wsbh){
		List<WsJbDO> origList =  getHibernateTemplate().find("from WsJbDO where wslb LIKE '%����%' AND ajxh = ? and wsjbbh=?", new Object[]{ajxh,wsbh});
		if(origList.isEmpty()){
			return null;
		}else{
			return origList.get(0).getWsnr();
		}
	}
	
	public String getYmclurlByAjxh(int ajxh){
		String sql = "select ymclurl from WsJbDO where ajxh = " + ajxh;
		String ymclurl = "";
		Session s = this.getSession();
		Query query = s.createQuery(sql);

		while (query.iterate()!=null)
			ymclurl = query.toString();
		
		//�ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return ymclurl;
	}
	
	public List<WsJbDO> getWsxxByAjxhs(String ajxhs) {
		String sql = "SELECT AJXH,WSJBBH,WSLB,WSMC,YMCLURL,WSLBBH,WSBH FROM PUB_WS_JB WHERE AJXH in ("
				+ ajxhs + ")";
		List<WsJbDO> wsxxList=new ArrayList<WsJbDO>();
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			cp = ((SessionFactoryImplementor) this
					.getSessionFactory()).getConnectionProvider();
			connection = cp.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				WsJbDO wsxxModel = new WsJbDO();
				wsxxModel.setAjxh(resultSet.getInt("AJXH"));
				wsxxModel.setWsjbbh(resultSet.getInt("WSJBBH"));
				wsxxModel.setWslb(resultSet.getString("WSLB"));
				wsxxModel.setWsmc(resultSet.getString("WSMC"));
				wsxxModel.setYmclurl(resultSet.getString("YMCLURL"));
				wsxxModel.setWslbbh(resultSet.getInt("WSLBBH"));
				wsxxModel.setWsbh(resultSet.getInt("WSBH"));
				wsxxList.add(wsxxModel);
			}
		} catch (SQLException e) {
			log.error("Wrong sql:" + sql, e);
		}finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����",e);
			}

		}
		if (log.isInfoEnabled()) {
			log.info("getAjxxByAjxhs by sql: " + sql);
		}
		return wsxxList;
	}

	public byte[] getWsContent(int ajxh, String typeEsc) {
		// TODO Auto-generated method stub
		List<WsJbDO> origList =  getHibernateTemplate().find("from WsJbDO where wslb ='"+typeEsc+"' AND ajxh = "+ajxh+" AND wsmc not like '%ԭ��%'");
		if(origList.isEmpty()){
			return null;
		}else{
			return origList.get(0).getWsnr();
		}
	}
	/**
	 * �жϰ����Ƿ��н᰸����
	 * ����з���true û�з���false
	 * @param ajxh
	 * @return
	 */
	public boolean SfyJawsByAjxh(int ajxh){
		String hql = "from WsJbDO where ajxh ="+ ajxh + "and sfjaws ='Y'";
		List<WsJbDO> wsJbDOList = getHibernateTemplate().find(hql);
		if(wsJbDOList == null){
			return false;
		}
		return !wsJbDOList.isEmpty();
	}
	
	public List<WsJbDO> getYrwsxxByAjxh(int ajxh){
//		String sql = "SELECT AJXH,WSJBBH,WSLB,WSMC,ZFJ,WSLBBH,WSBH,WSYS,WSJJ,ZZH,SCRQ,WSWJM,WSAH,WSZT,WSNR FROM PUB_WS_JB WHERE AJXH = "+ajxh+" AND (PUB_WS_JB.WSMC LIKE '%�о�%' OR PUB_WS_JB.WSMC LIKE '%�ö�%' OR PUB_WS_JB.WSMC LIKE '%����%')" ;
		String hql = "select new WsJbDO(ajxh,wsjbbh,wslb,wsmc,zfj,wslbbh,wsbh,wsys,wsjj,zzh,scrq,wswjm,wsah,wszt,wsnr) from WsJbDO where ajxh="+ajxh+" and (wsmc like '%�о�%' or wsmc like '%�ö�%' or wsmc LIKE '%����%')";
		List<WsJbDO> origList =  getHibernateTemplate().find(hql);
		if(origList.isEmpty()){
			return null;
		}else{
			return origList;
		}
		
	}

	@SuppressWarnings("unchecked")
	public List<WsJbDO> getWsxxByAjxhAndWslbbhAndWsbh(Integer ajxh,
			Integer wslbbh, Integer wsbh) {
		String sql = "from WsJbDO where ajxh = ? and wslbbh = ? and wsbh = ?";
		return getHibernateTemplate().find(sql, ajxh, wslbbh, wsbh);
	}

	
}