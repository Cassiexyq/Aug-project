package nju.software.cpwsqwjs.scanner;

import java.util.ArrayList;

import nju.software.cpwsqwjs.util.FcUtil;
import nju.software.cpwsqwjs.util.FileUtil;

/**
 * ���������ȡ����
 *  
 * @author WY
 *
 */
public class WsScanner {
	
	public static String scan(String path,String filename) throws Exception{
		String wsnr=null;
		if(filename.contains("txt")){
			wsnr=getWsnr(path,filename);
		}else if(filename.contains("doc")){
			wsnr=FileUtil.readDoc(path, filename);
		}else{
			System.out.println("�ļ���Ϊ��"+filename+"\n��Ч�ļ�");
		}
		return wsnr;
	}
	
	public static String getWsnr(String path,String filename){
		String wsnr="";
		ArrayList<String> content=new ArrayList<String>();
		ArrayList<String> wsnrlist=new ArrayList<String>();
		FileUtil fileUtil = new FileUtil();
		fileUtil.setS(path+"\\"+filename);
		content=fileUtil.readFromFile();
		for(int i=0;i<content.size();i++){
			ArrayList<String> str=(ArrayList<String>) FcUtil.getWholeToken(content.get(i));
			if(str.size()>0){
				wsnrlist.add(content.get(i));
			}
		}
		for(int i=0;i<wsnrlist.size()-1;i++){
			wsnr+=wsnrlist.get(i)+"\n";
		}
		wsnr+=wsnrlist.get(wsnrlist.size()-1);
		return wsnr;
	}
}
