package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Embeddable;


/**
 * ��������
 * WsJbVOId entity. @author MyEclipse Persistence Tools
 */
@Embeddable

public class WsJbDOId  implements java.io.Serializable {


    // Fields    

     private Integer ajxh;
     private Integer wsjbbh;


    // Constructors

    /** default constructor */
    public WsJbDOId() {
    }

    
    /** full constructor */
    public WsJbDOId(Integer ajxh, Integer wsjbbh) {
        this.ajxh = ajxh;
        this.wsjbbh = wsjbbh;
    }

   
    // Property accessors

    @Column(name="AJXH", nullable=false)

    public Integer getAjxh() {
        return this.ajxh;
    }
    
    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name="WSJBBH", nullable=false)

    public Integer getWsjbbh() {
        return this.wsjbbh;
    }
    
    public void setWsjbbh(Integer wsjbbh) {
        this.wsjbbh = wsjbbh;
    }
   



   public boolean equals(Object other) {
         if ( (this == other ) ) return true;
		 if ( (other == null ) ) return false;
		 if ( !(other instanceof WsJbDOId) ) return false;
		 WsJbDOId castOther = ( WsJbDOId ) other; 
         
		 return ( (this.getAjxh()==castOther.getAjxh()) || ( this.getAjxh()!=null && castOther.getAjxh()!=null && this.getAjxh().equals(castOther.getAjxh()) ) )
 && ( (this.getWsjbbh()==castOther.getWsjbbh()) || ( this.getWsjbbh()!=null && castOther.getWsjbbh()!=null && this.getWsjbbh().equals(castOther.getWsjbbh()) ) );
   }
   
   public int hashCode() {
         int result = 17;
         
         result = 37 * result + ( getAjxh() == null ? 0 : this.getAjxh().hashCode() );
         result = 37 * result + ( getWsjbbh() == null ? 0 : this.getWsjbbh().hashCode() );
         return result;
   }   





}