package nju.software.cpwsqwjs.data.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsajjbxxbDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjxxbDO;

public class WsajjbxxbDaoImpl extends HibernateDaoSupport implements WsajjbxxbDao {
	
	public static final String AH="ah";//����
	public static final String AJXZ = "ajxz";//��������
	public static final String SPCX = "spcx";//���г���
	public static final String WSMC = "wsmc";//��������
	public static final String WSZL = "wszl";//��������
	public static final String WSZZDQ = "wszzdw";//����������λ
	public static final String JBFY = "jbfy";//���취Ժ
	public static final String FYJB = "fyjb";//��Ժ����
	public static final String XZQHSH = "xzqhsh";//�������� ʡ
	public static final String XZQHS = "xzqhs";//�������� ��
	public static final String LAND = "land";//�������
	public static final String TCGXQYY = "tcgxqyy";//�Ƿ������ϽȨ����
	public static final String JAFS = "jafs";//�᰸��ʽ
	public static final String PJSJ = "pjsj";//�о�ʱ��
	public static final String JAND = "jand";//�᰸���
	public static final String JAYF ="jayf";//�᰸�·�
	public static final String KSSZ = "kssz";//��������
	public static final String SSQX = "ssqx";//��������
	public static final String SSTJCL = "sstjcl";//�����ύ����
	public static final String SFFHCS = "sffhcs";//�Ƿ񷢻�����
	public static final String FSCSYY = "fhccyy";//��������ԭ��
	public static final String JEZBD = "jazbd";//�᰸�ܱ��
	
	@Override
	public WsAjxxbDO getAjjbxxByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		try {
			WsAjxxbDO instance = (WsAjxxbDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsAjxxbDO", ajxh);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public WsAjxxbDO getAjjbxxByAh(String ah) {
		// TODO Auto-generated method stub
		try {
			WsAjxxbDO instance = (WsAjxxbDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsAjxxbDO", ah);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}
	
	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsAjxxbDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List<WsAjxxbDO> findByAh(String ah) {
		// TODO Auto-generated method stub
		return findByProperty("ah", ah);
	}
	
	public Integer getMaxAjxh() {
		String hql = "select max(ajxh) from WsAjxxbDO";

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxAjxh = 0;
		if (query.uniqueResult() != null)
			maxAjxh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxAjxh;
	}

	@Override
	public Integer addAjjbxxDo(WsAjxxbDO wsAjxxbDO) {
		// TODO Auto-generated method stub
		try {
			getHibernateTemplate().saveOrUpdate(wsAjxxbDO);
			return wsAjxxbDO.getAjxh();
		} catch (RuntimeException re) {
			throw re;
		}
	}
	

}
