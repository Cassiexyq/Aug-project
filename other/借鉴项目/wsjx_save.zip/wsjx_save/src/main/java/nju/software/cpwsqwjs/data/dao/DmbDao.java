package nju.software.cpwsqwjs.data.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.exception.BaseAppException;
import nju.software.cpwsqwjs.util.StringUtil;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;


/**
 * A data access object (DAO) providing persistence and search support for DmbDO
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see software.tjspxt.data.dataobject.DmbDO
 * @author MyEclipse Persistence Tools
 */

public class DmbDao extends HibernateDaoSupport {
	private static final Logger log = Logger.getLogger(DmbDao.class);

	// property constants
	public static final String DMMS = "dmms";
	public static final String XGDM = "xgdm";
	public static final String BZ = "bz";
	public static final String MODFLAG = "modflag";
	public static final String TRANSFLAG = "transflag";
	public static final String XSSX = "xssx";
	public static final String DQBS = "dqbs";
	public static final String FYBH = "fybh";
	public static final String FYSX = "fysx";
	public static final String FYLBDM = "fylbdm";
	public static final String XZQDMBH = "xzqdmbh";
	public static final String DMBBH = "dmbbh";
	public static final String SPBM = "spbm";
	public static final String BMZT = "bmzt";
	public static final String XGDM2 = "xgdm2";

	protected void initDao() {
		// do nothing
	}

	public void save(DmbDO transientInstance) {
		log.debug("saving DmbDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(DmbDO persistentInstance) {
		log.debug("deleting DmbDO instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public DmbDO findById(nju.software.cpwsqwjs.data.dataobject.DmbDOId id) {
		log.debug("getting DmbDO instance with id: " + id);
		try {
			DmbDO instance = (DmbDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.DmbDO", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<DmbDO> findByExample(DmbDO instance) {
		log.debug("finding DmbDO instance by example");
		try {
			List<DmbDO> results = (List<DmbDO>) getHibernateTemplate()
					.findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding DmbDO instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from DmbDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List<DmbDO> findByDmms(Object dmms) {
		return findByProperty(DMMS, dmms);
	}

	public List<DmbDO> findByXgdm(Object xgdm) {
		return findByProperty(XGDM, xgdm);
	}

	public List<DmbDO> findByBz(Object bz) {
		return findByProperty(BZ, bz);
	}

	public List<DmbDO> findByModflag(Object modflag) {
		return findByProperty(MODFLAG, modflag);
	}

	public List<DmbDO> findByTransflag(Object transflag) {
		return findByProperty(TRANSFLAG, transflag);
	}

	public List<DmbDO> findByXssx(Object xssx) {
		return findByProperty(XSSX, xssx);
	}

	public List<DmbDO> findByDqbs(Object dqbs) {
		return findByProperty(DQBS, dqbs);
	}

	public List<DmbDO> findByFybh(Object fybh) {
		return findByProperty(FYBH, fybh);
	}

	public List<DmbDO> findByFysx(Object fysx) {
		return findByProperty(FYSX, fysx);
	}

	public List<DmbDO> findByFylbdm(Object fylbdm) {
		return findByProperty(FYLBDM, fylbdm);
	}

	public List<DmbDO> findByXzqdmbh(Object xzqdmbh) {
		return findByProperty(XZQDMBH, xzqdmbh);
	}

	public List<DmbDO> findByDmbbh(Object dmbbh) {
		return findByProperty(DMBBH, dmbbh);
	}

	public List<DmbDO> findBySpbm(Object spbm) {
		return findByProperty(SPBM, spbm);
	}

	public List<DmbDO> findByBmzt(Object bmzt) {
		return findByProperty(BMZT, bmzt);
	}

	public List findAll() {
		log.debug("finding all DmbDO instances");
		try {
			String queryString = "from DmbDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public DmbDO merge(DmbDO detachedInstance) {
		log.debug("merging DmbDO instance");
		try {
			DmbDO result = (DmbDO) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(DmbDO instance) {
		log.debug("attaching dirty DmbDO instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(DmbDO instance) {
		log.debug("attaching clean DmbDO instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static DmbDao getFromApplicationContext(ApplicationContext ctx) {
		return (DmbDao) ctx.getBean("DmbDAO");
	}


	/**
	 * �õ�ĳһ�����б�
	 * 
	 * @return ����б�
	 */
	public List<DmbDO> getLblbFylbbh(String lbbh) {
		log.debug("finding all fy inofmation from DmbDO instances");
		try {
			String queryString = "from DmbDO where lbbh='" + lbbh
					+ "' and (dqbs='1' or dqbs is null)";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	/**
	 * ��������źͷ�Ժ��Ż�÷���Ҫ��Ĵ����б�
	 * 
	 * @param lbbh
	 *            �����
	 * @param fybh
	 *            ��Ժ���
	 * @return �����б�
	 */
	public List<DmbDO> getDmListByLbbh(String lbbh, Integer fybh) {
		String hql = "";
		if (fybh == null) {
			hql = "from DmbDO where lbbh = '"
					+ lbbh
					+ "' and fybh is null and (dqbs='1' or dqbs is null) order by dmbh";
		} else {
			hql = "from DmbDO where lbbh = '" + lbbh + "' and fybh = " + fybh
					+ " and (dqbs='1' or dqbs is null) order by dmbh";
		}

		if (log.isInfoEnabled()) {
			log.info("getDmListByLbbh by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	public List<DmbDO> getDmListByLbbhAndDmbhLike(String lbbh, String dmbh) {
		String hql = "";

		hql = "from DmbDO where lbbh like '" + lbbh + "' and dmbh like '"
				+ dmbh + "' order by dmbh";

		if (log.isInfoEnabled()) {
			log.info("getDmListByLbbh by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	public List<DmbDO> getDmList(int fybh) {
		String hql = "";
		if ((Integer) fybh == null) {
			hql = "from DmbDO where fybh is null and (dqbs='1' or dqbs is null)";
		} else {
			hql = "from DmbDO where fybh = " + fybh
					+ " and (dqbs='1' or dqbs is null)";
		}

		if (log.isInfoEnabled()) {
			log.info("getDmList by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	/**
	 * ���ݷ�Ժ��ŵõ���Ժ������Ϣ
	 * 
	 * @param fybh
	 *            ��Ժ���
	 * @return ��Ժ������Ϣ
	 */
	public DmbDO findFybyFybh(Integer fybh) {
		log.debug("finding fy all inofmation from DmbDO instances");
		try {
			String queryString = "from DmbDO where lbbh='FBZ0001-97' and (dqbs='1' or dqbs is null) and fybh="
					+ fybh + "";
			List<DmbDO> tempData = getHibernateTemplate().find(queryString);
			return tempData.isEmpty() ? null : tempData.get(0);
		} catch (RuntimeException re) {
			log.error("find failed", re);
			throw re;
		}
	}

	public DmbDO findXzqbyDmbbh(Integer dmbh) {
		log.debug("finding all xzq inofmation from DmbDO instances");
		try {
			String queryString = "from DmbDO where lbbh='GB2260-91' and (dqbs='1' or dqbs is null) and xzqdmbh="
					+ dmbh + "";
			List<DmbDO> tempData = getHibernateTemplate().find(queryString);
			return tempData.isEmpty() ? null : tempData.get(0);
		} catch (RuntimeException re) {
			log.error("find failed", re);
			throw re;
		}
	}

	/**
	 * ����fyserverice�Լ�xzqservice�����Ϣ
	 * 
	 * @param lbbh
	 *            �����
	 * @param dmbh
	 *            ������
	 * @return
	 */
	public DmbDO findFyXzqbyID(String lbbh, String dmbh) {
		log.debug("finding all fy inofmation from DmbDO instances");
		try {
			String queryString = "from DmbDO where (dqbs='1' or dqbs is null) and lbbh='"
					+ lbbh + "' and dmbh='" + dmbh + "'";
			List<DmbDO> tempData = getHibernateTemplate().find(queryString);
			return tempData.isEmpty() ? null : tempData.get(0);
		} catch (RuntimeException re) {
			log.error("find failed", re);
			throw re;
		}
	}

	/**
	 * ���ݷ�Ժ���õ���Ժ�����б�
	 * 
	 * @param fylbdm
	 *            ��Ժ������
	 * @return
	 */
	public List<DmbDO> getFyDmListByFylbdm(String fylbdm) {
		String hql = "from FydmbDO where lbbh='FBZ0001-97' and fylbdm='"
				+ fylbdm + "' and (dqbs='1' or dqbs is null)";

		List<DmbDO> fydmb = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getFyDmListByFylbdm by sql: " + hql);
		}
		return fydmb;
	}

	public List<DmbDO> getFydmByFydm(String fydm) {
		String hql = "from DmbDO where dmbh like '" + fydm + "'";
		List<DmbDO> fydmDoList = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getFydmByFydm by sql: " + hql);
		}
		return fydmDoList;
	}

	public List<DmbDO> getXzqByjb(String likeCon) {
		String hql = "from DmbDO where lbbh = 'GB2260-91'" + likeCon + "";
		List<DmbDO> fydmDoList = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getXzqByjb by sql: " + hql);
		}
		return fydmDoList;
	}

	/**
	 * ���ڻ�ò�����Ϣ(bmbservice)
	 * 
	 * @param lbbh
	 *            �����
	 * @param fybh
	 *            ��Ժ���
	 * @param dmms
	 *            �����������������ƣ�
	 * @return
	 */
	public DmbDO getdmbByFybhandDmms(String lbbh, Integer fybh, String dmms) {
		try {
			String hql = "from DmbDO where lbbh = '" + lbbh + "' and fybh="
					+ fybh + " and dmms='" + dmms + "'";
			List<DmbDO> tempData = getHibernateTemplate().find(hql);
			return tempData.isEmpty() ? null : tempData.get(0);
		} catch (RuntimeException re) {
			log.error("find failed", re);
			throw re;
		}
	}

	public List<DmbDO> getMoreDmbByFybhandDmms(String lbbh, Integer fybh,
			String dmms) {
		String hql;
		if (dmms != null) {
			hql = "from BmDO where bmmc like  '%" + dmms + "%' and fybh="
					+ fybh;
		} else {
			hql = "from BmDO where fybh=" + fybh;
		}
		if (log.isInfoEnabled()) {
			log.info("getMoHuBm(String,long) by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	/**
	 * ͨ����Ժ��Ż�ô����б���bmbserviceʹ�ã�
	 * 
	 * @param lbbh
	 *            �����
	 * @param fybh
	 *            ��Ժ���
	 * @return
	 */
	public List<DmbDO> getDmbbyFybh(String lbbh, Integer fybh) {
		String hql = "from DmbDO where lbbh = '" + lbbh + "' and fybh = "
				+ fybh + "";
		List<DmbDO> fydmDoList = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDmbbyFybh by sql: " + hql);
		}
		return fydmDoList;
	}

	/**
	 * ͨ����Ժ��Ż�ô����б���bmbserviceʹ�ã�
	 * 
	 * @param lbbh
	 *            �����
	 * @param fybh
	 *            ��Ժ���
	 * @param bz
	 *            ��ע
	 * @return �����б�
	 */
	public List<DmbDO> getDmbbyFybhAndBz(String lbbh, Integer fybh, String bz) {
		String hql = "from DmbDO where lbbh = '" + lbbh + "' and fybh = "
				+ fybh + " and bz = '" + bz + "'";
		List<DmbDO> fydmDoList = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDmbbyFybhAndBz by sql: " + hql);
		}
		return fydmDoList;
	}

	/**
	 * ͨ�������������������ƣ���ô����б���bmbserviceʹ�ã�
	 * 
	 * @param lbbh
	 *            �����
	 * @param dmms
	 *            ��������
	 * @return
	 */
	public List<DmbDO> getDmbbyDmms(String lbbh, String dmms) {
		String hql = "from DmbDO where lbbh = '" + lbbh + "' and dmms='" + dmms
				+ "'";
		List<DmbDO> fydmDoList = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDmbbyDmms by sql: " + hql);
		}
		return fydmDoList;
	}


	public DmbDO getDmByDmbbh(int dmbbh) {
		String hql = "from DmbDO where dmbbh=" + dmbbh;
		List<DmbDO> dmb = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDmByDmbbh by sql: " + hql);
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}

	/**
	 * �����ţ�����ţ���Ժ��Ż�ô����б�
	 * 
	 * @param dmbh
	 *            ������
	 * @param lbbh
	 *            �����
	 * @param fybh
	 *            ��Ժ���
	 * @return
	 */
	public DmbDO getDmByDmbhAndLbbh(String dmbh, String lbbh, int fybh) {
		List<DmbDO> dmb = new ArrayList<DmbDO>();
		try {
			String hql = "";
			if ((Integer) fybh == null) {
				hql = "from DmbDO where dmbh = '" + dmbh + "' and lbbh ='"
						+ lbbh
						+ "' and fybh is null and (dqbs='1' or dqbs is null)";
			} else {
				hql = "from DmbDO where dmbh = '" + dmbh + "' and lbbh ='"
						+ lbbh + "' and fybh = " + fybh
						+ " and (dqbs='1' or dqbs is null)";
			}

			dmb = getHibernateTemplate().find(hql);
			if (log.isInfoEnabled()) {
				log.info("getDmByDmbhAndLbbh by sql: " + hql);
			}
		} catch (Exception e) {
			String sql = "SELECT LBBH, DMBH, DMMS, XGDM, BZ FROM PUB_DMB WHERE DMBH = '"
					+ dmbh + "' and LBBH = '" + lbbh + "'";
			ConnectionProvider cp = null;
			Connection connection = null;
			Statement statement = null;
			ResultSet resultSet = null;
			dmb = new ArrayList<DmbDO>();
			try {
				cp = ((SessionFactoryImplementor) this.getSessionFactory())
						.getConnectionProvider();
				connection = cp.getConnection();
				statement = connection.createStatement();
				statement.executeQuery(sql);
				resultSet = statement.executeQuery(sql);

				int num = 0;
				while (resultSet.next()) {
					DmbDO dmbdo = new DmbDO();
					dmbdo.setLbbh(StringUtil.trim(resultSet.getString("LBBH")));
					dmbdo.setDmbh(StringUtil.trim(resultSet.getString("DMBH")));
					dmbdo.setDmms(StringUtil.trim(resultSet.getString("DMMS")));
					dmbdo.setXgdm(StringUtil.trim(resultSet.getString("XGDM")));
					dmbdo.setBz(StringUtil.trim(resultSet.getString("BZ")));
					dmb.add(dmbdo);
					num++;
				}
			} catch (SQLException ex) {
				String errstr = "�����ִ��sql������" + sql;
				throw new BaseAppException(errstr);
			} finally {
				try {
					if (resultSet != null)
						resultSet.close();
					if (statement != null)
						statement.close();
					if (cp != null)
						cp.closeConnection(connection);
				} catch (SQLException e1) {
					log.error("�ر����ݿ����ӳ�����", e1);
					e1.printStackTrace();
				}

			}
		}

		if (dmb.size() > 1) {
			String errstr = "���������lbbh��" + lbbh + " dmbh:" + dmbh + " ������"
					+ dmb.size() + "����¼���Զ����ص�һ����";
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}

	public DmbDO getDmByLbbhAndDmbhAndXgdm(String lbbh, String dmbh,
			String xgdm, int fybh) {
		String hql = "";
		if ((Integer) fybh == null) {
			hql = "from DmbDO where dmbh = '" + dmbh + "' and lbbh ='" + lbbh
					+ "' and xgdm = '" + xgdm
					+ "' and fybh is null and (dqbs='1' or dqbs is null)";
		} else {
			hql = "from DmbDO where dmbh = '" + dmbh + "' and lbbh ='" + lbbh
					+ "' and xgdm = '" + xgdm + "' and fybh = " + fybh
					+ " and (dqbs='1' or dqbs is null)";
		}

		List<DmbDO> dmb = getHibernateTemplate().find(hql);
		if (log.isInfoEnabled()) {
			log.info("getDmByLbbhAndDmbhAndXgdm by sql: " + hql);
		}
		return dmb.isEmpty() ? null : dmb.get(0);
	}

	public List<DmbDO> getDmListByLbbh(String lbbh) {
		String hql = "from DmbDO where lbbh = '" + lbbh + "' ORDER BY dmms";
		if (log.isInfoEnabled()) {
			log.info("getDmLsByLbbh by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	public List<DmbDO> getDmgzListByLbbh() {
		String hql = "from DmbDO where lbbh = 'USR800-09' ORDER BY dmbh ASC";
		if (log.isInfoEnabled()) {
			log.info("getDmLsByLbbh by sql: " + hql);
		}
		return getHibernateTemplate().find(hql);
	}

	/**
	 * ����ID�õ�DMB����
	 * 
	 * @param lbbh
	 *            �����
	 * @param dmbh
	 *            ������
	 * @return ��ѯ�õ��Ĵ��������
	 */
	public DmbDO findById(String lbbh, String dmbh) {
		log.debug("finding all fy inofmation from DmbDO instances");
		try {
			String queryString = "from DmbDO where lbbh='" + lbbh
					+ "' and dmbh='" + dmbh + "'";
			List<DmbDO> tempData = getHibernateTemplate().find(queryString);
			return tempData.isEmpty() ? null : tempData.get(0);
		} catch (RuntimeException re) {
			log.error("find failed", re);
			throw re;
		}
	}

	public boolean update(DmbDO dmbDo) {
		try {
			if (dmbDo == null) {
				throw new BaseAppException("���µĴ������Ϊ�գ�");
			} else {
				getHibernateTemplate().update(dmbDo);
				if (log.isInfoEnabled()) {
					log.info("add a dmbObj with lbbh = " + dmbDo.getLbbh()
							+ ",dmbh = " + dmbDo.getDmbh() + ",bz = "
							+ dmbDo.getBz());
				}
			}
			// ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("���´������ʱ���ݿⷢ������");
		}

		return true;
	}

	public boolean add(DmbDO dmbDo) {
		try {
			if (dmbDo == null) {
				throw new BaseAppException("���ӵĴ������Ϊ�գ�");
			} else {
				getHibernateTemplate().evict(dmbDo);
				getHibernateTemplate().save(dmbDo);
				if (log.isInfoEnabled()) {
					log.info("add a dmbObj with lbbh = " + dmbDo.getLbbh()
							+ ",dmbh = " + dmbDo.getDmbh() + ",bz = "
							+ dmbDo.getBz());
				}
			}
			// ˢ��Session
			getSession().flush();
		} catch (Exception e) {
			throw new BaseAppException("���Ӵ������ʱ���ݿⷢ������");
		}

		return true;
	}

	public List<DmbDO> getTjFydmb() {
		// TODO Auto-generated method stub
		String hql = "from DmbDO where lbbh=? and dmbh like ?";
		@SuppressWarnings("unchecked")
		List<DmbDO> dmb = getHibernateTemplate().find(hql, "FBZ0001-97", "12%");
		if (dmb == null) {
			dmb = new ArrayList<DmbDO>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInTj by sql: " + hql);
		}
		return dmb;
	}

	public List<DmbDO> getSpt() {
		// String hql = "from DmbDO where lbbh=? and bz=?";
		String hql = "from DmbDO where lbbh = 'USR206-99' and bz = '����'";
		// List<DmbDO> dmb = getHibernateTemplate().find(hql,"USR206-99","����");
		@SuppressWarnings("unchecked")
		List<DmbDO> dmb = getHibernateTemplate().find(hql);
		if (dmb == null) {
			dmb = new ArrayList<DmbDO>();
		}
		if (log.isInfoEnabled()) {
			log.info("getDmInTj by sql: " + hql);
		}
		return dmb;
	}

	public DmbDO getDmbByLbbhLikeAndDmbh(String lbbh, String dmbh) {
		String hql = "from DmbDO where lbbh like ? and dmbh = ?";
		List<DmbDO> dmb = getHibernateTemplate().find(hql, lbbh, dmbh);
		if (dmb == null) {
			dmb = new ArrayList<DmbDO>();
		}

		return dmb.isEmpty() ? null : dmb.get(0);
	}

	/**
	 * ��������źʹ����Ż�ô�������
	 * 
	 * @param lbbh
	 * @param dmbh
	 * @return
	 */
	public DmbDO findByDmbhandLbbh(String lbbh, String dmbh) {
		String hql = "from DmbDO where lbbh='" + lbbh + "' and dmbh='" + dmbh
				+ "'";
		List<DmbDO> dmbDOs = new ArrayList<DmbDO>();
		dmbDOs = getHibernateTemplate().find(hql);
		return dmbDOs.size() == 0 ? new DmbDO() : dmbDOs.get(0);
	}

	/**
	 * ��������źʹ����źͱ�ע��ô�������
	 * @param lbbh
	 * @param dmbh
	 * @param bz
	 * @return
	 */
	public DmbDO findByDmbhandLbbhandBz(String lbbh, String dmbh, String bz) {
		String hql = "from DmbDO where lbbh='" + lbbh + "' and dmbh='" + dmbh
				+ "' and bz='" + bz + "'";
		List<DmbDO> dmbDOs = new ArrayList<DmbDO>();
		dmbDOs = getHibernateTemplate().find(hql);
		return dmbDOs.size() == 0 ? new DmbDO() : dmbDOs.get(0);
	}
}