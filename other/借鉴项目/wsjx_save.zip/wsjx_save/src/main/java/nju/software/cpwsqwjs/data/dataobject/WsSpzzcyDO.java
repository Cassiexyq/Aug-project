package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.model.WswwModel;

/**
 * WsSpzzcyDO entity. @author MyEclipse Persistence Tools
 * ������֯��Ա
 */
@Entity
@Table(name = "WS_SPZZCY")
@IdClass(WsSpzzcyDOId.class)
public class WsSpzzcyDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer cybh;//��Ա���
	private String sf;//����
	private String xm;//����
	/** default constructor */
	public WsSpzzcyDO() {
	}

	/** minimal constructor */
	public WsSpzzcyDO(Integer ajxh, Integer cybh) {
		this.ajxh = ajxh;
		this.cybh = cybh;
	}

	public WsSpzzcyDO(Integer ajxh, Integer cybh, String sf, String xm) {
		super();
		this.ajxh = ajxh;
		this.cybh = cybh;
		this.sf = sf;
		this.xm = xm;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "CYBH", nullable = false)
	public Integer getCybh() {
		return cybh;
	}

	public void setCybh(Integer cybh) {
		this.cybh = cybh;
	}
	@Column(name = "SF", length = 20)
	public String getSf() {
		return sf;
	}

	public void setSf(String sf) {
		this.sf = sf;
	}
	@Column(name = "XM", length = 50)
	public String getXm() {
		return xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}
}