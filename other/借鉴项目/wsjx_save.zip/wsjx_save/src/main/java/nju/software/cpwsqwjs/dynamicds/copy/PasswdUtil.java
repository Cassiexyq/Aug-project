package nju.software.cpwsqwjs.dynamicds.copy;

public class PasswdUtil {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Getpasswd oo = new Getpasswd();
		String result = oo.passwd("120224 219", "IL4T-9P48-FRIX-N364");
		System.out.println(result);
	}

}
