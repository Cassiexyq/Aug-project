package nju.software.cpwsqwjs.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * PubLaAy entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_LA_AY")
@IdClass(value=PubLaAyId.class)
public class PubLaAy implements java.io.Serializable {
	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = -5482205964270211414L;
	private Integer ajxh;
	private Integer laaybh;
	private String ay;
	private String laay;
	
	// Constructors

	/** default constructor */
	public PubLaAy() {
	}

	/** minimal constructor */
	public PubLaAy(Integer ajxh,Integer laaybh) {
		this.ajxh = ajxh;
		this.laaybh = laaybh;
	}

	/** full constructor */
	public PubLaAy(Integer ajxh,Integer laaybh, String ay, String laay) {
		this.ajxh = ajxh;
		this.laaybh = laaybh;
		this.ay = ay;
		this.laay = laay;
	}
	
	// Property accessors
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	
	@Id
	@Column(name = "LAAYBH", nullable = false)
	public Integer getLaaybh() {
		return this.laaybh;
	}

	public void setLaaybh(Integer laaybh) {
		this.laaybh = laaybh;
	}
	@Column(name = "AY", length = 10)
	public String getAy() {
		return this.ay;
	}

	public void setAy(String ay) {
		this.ay = ay;
	}

	@Column(name = "LAAY", length = 100)
	public String getLaay() {
		return this.laay;
	}

	public void setLaay(String laay) {
		this.laay = laay;
	}
}
