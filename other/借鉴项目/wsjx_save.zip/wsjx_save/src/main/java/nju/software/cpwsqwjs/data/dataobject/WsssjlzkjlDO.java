package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * WsssjlzkjlDO entity. @author MyEclipse Persistence Tools
 * ���ϼ�¼ ָ����Ϣ
 */
@Entity
@Table(name = "WS_SSJL_ZKJL")
@IdClass(WsssjlzkjlDOId.class)
public class WsssjlzkjlDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer zkjlbh;// ָ�ر��
	private String xgr;//�����
	/** default constructor */
	public WsssjlzkjlDO() {
	}

	/** minimal constructor */
	public WsssjlzkjlDO(Integer ajxh, Integer zkjlbh) {
		this.ajxh = ajxh;
		this.zkjlbh = zkjlbh;
	}

	public WsssjlzkjlDO(Integer ajxh, Integer zkbh, String xgr) {
		super();
		this.ajxh = ajxh;
		this.xgr = xgr;
	}

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}
	@Id
	@Column(name = "ZKJLBH", nullable = false)
	public Integer getZkjlbh() {
		return zkjlbh;
	}

	public void setZkjlbh(Integer zkjlbh) {
		this.zkjlbh = zkjlbh;
	}

	@Column(name = "XGR", length =255)
	public String getXgr() {
		return xgr;
	}

	public void setXgr(String xgr) {
		this.xgr = xgr;
	}
}