/**
 * 2014-5-18 10:07
 */
package nju.software.cpwsqwjs.service.dataConvertor;

import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrDwDO;
import nju.software.cpwsqwjs.data.dataobject.DsrGrDO;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrMspcFjxxDO;
import nju.software.cpwsqwjs.data.dataobject.DsrXpJgDO;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DmbModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;
import nju.software.cpwsqwjs.service.sp.DmbService;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.DateUtil;
import nju.software.cpwsqwjs.util.StringUtil;

import org.springframework.beans.BeanUtils;


/**
 * @author ruanhao
 *
 */
public class DsrConvertor {
	
//	public static DsrgrjhxxVO dsrgrVoTojhVo(DsrgrxxVO dsrgrxxVO) {
//		DsrgrjhxxVO dsrgrjhxxVO = new DsrgrjhxxVO();
//		if (dsrgrxxVO != null) {
//			BeanUtils.copyProperties(dsrgrxxVO, dsrgrjhxxVO);
//		}
//		return dsrgrjhxxVO;
//	}
//	
//	public static DsrgrjbxxVO dsrgrVoTojbVo(DsrgrxxVO dsrgrxxVO) {
//		DsrgrjbxxVO dsrgrjbxxVO = new DsrgrjbxxVO();
//		if (dsrgrxxVO != null) {
//			BeanUtils.copyProperties(dsrgrxxVO, dsrgrjbxxVO);
//		}
//		return dsrgrjbxxVO;
//	}
//	
//	public static DsrgrpcxxVO dsrgrVoTopcVo(DsrgrxxVO dsrgrxxVO) {
//		DsrgrpcxxVO dsrgrpcxxVO = new DsrgrpcxxVO();
//		if (dsrgrxxVO != null) {
//			BeanUtils.copyProperties(dsrgrxxVO, dsrgrpcxxVO);
//		}
//		return dsrgrpcxxVO;
//	}
//	
//	public static DsrdwjhxxVO dsrdwVoTojhVo(DsrdwxxVO dsrdwxxVO) {
//		DsrdwjhxxVO dsrdwjhxxVO = new DsrdwjhxxVO();
//		if (dsrdwxxVO != null) {
//			BeanUtils.copyProperties(dsrdwxxVO, dsrdwjhxxVO);
//		}
//		return dsrdwjhxxVO;
//	}
//	
//	public static DsrdwjbxxVO dsrdwVoTojbVo(DsrdwxxVO dsrdwxxVO) {
//		DsrdwjbxxVO dsrdwjbxxVO = new DsrdwjbxxVO();
//		if (dsrdwxxVO != null) {
//			BeanUtils.copyProperties(dsrdwxxVO, dsrdwjbxxVO);
//		}
//		return dsrdwjbxxVO;
//	}
//	
//	public static DsrdwpcxxVO dsrdwVoTopcVo(DsrdwxxVO dsrdwxxVO) {
//		DsrdwpcxxVO dsrdwpcxxVO = new DsrdwpcxxVO();
//		if (dsrdwxxVO != null) {
//			BeanUtils.copyProperties(dsrdwxxVO, dsrdwpcxxVO);
//		}
//		return dsrdwpcxxVO;
//	}
//	
//	public static DsrdwpocxxVO dsrdwVoTopocVo(DsrdwxxVO dsrdwxxVO) {
//		DsrdwpocxxVO dsrdwpocxxVO = new DsrdwpocxxVO();
//		if (dsrdwxxVO != null) {
//			BeanUtils.copyProperties(dsrdwxxVO, dsrdwpocxxVO);
//		}
//		return dsrdwpocxxVO;
//	}
//	
//	public static DsrjgjhxxVO dsrjgVoTojhVo(DsrjgxxVO dsrjgxxVO) {
//		DsrjgjhxxVO dsrjgjhxxVO = new DsrjgjhxxVO();
//		if (dsrjgxxVO != null) {
//			BeanUtils.copyProperties(dsrjgxxVO, dsrjgjhxxVO);
//		}
//		return dsrjgjhxxVO;
//	}
//	
//	public static DsrjgpcxxVO dsrjgVoTopcVo(DsrjgxxVO dsrjgxxVO) {
//		DsrjgpcxxVO dsrjgpcxxVO = new DsrjgpcxxVO();
//		if (dsrjgxxVO != null) {
//			BeanUtils.copyProperties(dsrjgxxVO, dsrjgpcxxVO);
//		}
//		return dsrjgpcxxVO;
//	}
//	
//	public static DsrjgpocxxVO dsrjgVoTopocVo(DsrjgxxVO dsrjgxxVO) {
//		DsrjgpocxxVO dsrjgpocxxVO = new DsrjgpocxxVO();
//		if (dsrjgxxVO != null) {
//			BeanUtils.copyProperties(dsrjgxxVO, dsrjgpocxxVO);
//		}
//		return dsrjgpocxxVO;
//	}
//
//
//
//	public static DsrgrxxVO dsrgrModelToVo(DsrgrxxModel dsrgrModel) {
//		DsrgrxxVO dsrgrVO = new DsrgrxxVO();
//		if (dsrgrModel != null) {
//			dsrgrVO.setBh(dsrgrModel.getDsrbh());
//			BeanUtils.copyProperties(dsrgrModel, dsrgrVO);
//		}
//		return dsrgrVO;
//	}
//	
//	public static DsrdwxxVO dsrdwModelToVo(DsrdwxxModel dsrdwxxModel) {
//		DsrdwxxVO dsrdwxxVO = new DsrdwxxVO();
//		if (dsrdwxxModel != null) {
//			dsrdwxxVO.setBh(dsrdwxxModel.getDsrbh());
//			BeanUtils.copyProperties(dsrdwxxModel, dsrdwxxVO);
//		}
//		return dsrdwxxVO;
//	}
//	
//	public static DsrjgxxVO dsrjgModelToVo(DsrjgxxModel dsrjgxxModel) {
//		DsrjgxxVO dsrjgxxVO = new DsrjgxxVO();
//		if (dsrjgxxModel != null) {
//			dsrjgxxVO.setBh(dsrjgxxModel.getDsrbh());
//			BeanUtils.copyProperties(dsrjgxxModel, dsrjgxxVO);
//		}
//		return dsrjgxxVO;
//	}
//	
//	public static DsrgrxxModel dsrgrVoToModel(DsrgrxxVO dsrgrVO) {
//		DsrgrxxModel dsrgrModel = new DsrgrxxModel();
//		if (dsrgrVO != null) {
//			BeanUtils.copyProperties(dsrgrVO, dsrgrModel);
//		}
//		return dsrgrModel;
//	}
//	
//	public static DsrdwxxModel dsrdwVoToModel(DsrdwxxVO dsrdwxxVO) {
//		DsrdwxxModel dsrdwxxModel = new DsrdwxxModel();
//		if (dsrdwxxVO != null) {
//			BeanUtils.copyProperties(dsrdwxxVO, dsrdwxxModel);
//		}
//		return dsrdwxxModel;
//	}
//	
//	public static DsrjgxxModel dsrjgVoToModel(DsrjgxxVO dsrjgxxVO) {
//		DsrjgxxModel dsrjgxxModel = new DsrjgxxModel();
//		if (dsrjgxxVO != null) {
//			BeanUtils.copyProperties(dsrjgxxVO, dsrjgxxModel);
//		}
//		return dsrjgxxModel;
//	}
//	
//	public static DsrGrDO dsrgrModelToDsrgrDO(DsrgrxxModel dsrgrModel, DsrGrDO dsrGrDO) {
//		if (dsrGrDO == null) {
//			dsrGrDO = new DsrGrDO();
//		}
//		if (dsrgrModel != null) {
//			dsrGrDO.setAjxh((int)dsrgrModel.getAjxh());
//			dsrGrDO.setDsrbh((int)dsrgrModel.getDsrbh());
//			dsrGrDO.setXm(dsrgrModel.getXm());
//			dsrGrDO.setXb(dsrgrModel.getXb());
//			if (!StringUtil.isBlank(dsrgrModel.getCsnyr())) {
//				dsrGrDO.setCsnyr(DateUtil.parse(dsrgrModel.getCsnyr(), DateUtil.webFormat));
//			}
//			dsrGrDO.setMz(dsrgrModel.getMz());
//			dsrGrDO.setSsgj(dsrgrModel.getSsgj());
//			dsrGrDO.setWhcd(dsrgrModel.getWhcd());
//			dsrGrDO.setZzmm(dsrgrModel.getZzmm());
//			dsrGrDO.setJb(dsrgrModel.getJb());
//			dsrGrDO.setJg(dsrgrModel.getJg());
//			dsrGrDO.setSf(dsrgrModel.getSf());
//			dsrGrDO.setZjlb(dsrgrModel.getZjlb());
//			dsrGrDO.setSfzhm(dsrgrModel.getSfzhm());
//			dsrGrDO.setYb(dsrgrModel.getYb());
//			dsrGrDO.setDh(dsrgrModel.getDh());
//			dsrGrDO.setZwzy(dsrgrModel.getZwzy());
//			dsrGrDO.setGzdw(dsrgrModel.getGzdw());
//			dsrGrDO.setDz(dsrgrModel.getDz());
//			dsrGrDO.setZzd(dsrgrModel.getZzd());
//		}
//		return dsrGrDO;
//	}
//	
//	public static DsrDwDO dsrdwModelToDsrdwDO(DsrdwxxModel dsrdwxxModel, DsrDwDO dsrDwDO) {
//		if (dsrDwDO == null) {
//			dsrDwDO = new DsrDwDO();
//		}
//		if (dsrdwxxModel != null) {
//			dsrDwDO.setAjxh((int)dsrdwxxModel.getAjxh());
//			dsrDwDO.setDsrbh((int)dsrdwxxModel.getDsrbh());
//			dsrDwDO.setDwmc(dsrdwxxModel.getDwmc());
//			dsrDwDO.setDz(dsrdwxxModel.getDz());
//			dsrDwDO.setDh(dsrdwxxModel.getDh());
//			dsrDwDO.setYb(dsrdwxxModel.getYb());
//			dsrDwDO.setFrxz(dsrdwxxModel.getFrxz());
//			dsrDwDO.setFddbrxm(dsrdwxxModel.getFddbrxm());
//			dsrDwDO.setDbrzw(dsrdwxxModel.getDbrzw());
//			dsrDwDO.setGyqygm(dsrdwxxModel.getGyqygm());
//			dsrDwDO.setLxdh(dsrdwxxModel.getLxdh());
//			dsrDwDO.setDjzlb(dsrdwxxModel.getDjzlb());
//			dsrDwDO.setDjzh(dsrdwxxModel.getDjzh());
//			dsrDwDO.setFddbrxb(dsrdwxxModel.getFddbrxb());
//			dsrDwDO.setJb(dsrdwxxModel.getJb());
//			dsrDwDO.setWhcd(dsrdwxxModel.getWhcd());
//			dsrDwDO.setZzmm(dsrdwxxModel.getZzmm());
//			if (!StringUtil.isBlank(dsrdwxxModel.getCsnyr())) {
//				dsrDwDO.setCsnyr(DateUtil.parse(dsrdwxxModel.getCsnyr(), DateUtil.webFormat));
//			}
//		}
//		return dsrDwDO;
//	}
//	
//	public static DsrXpJgDO dsrjgModelToDsrjgDO(DsrjgxxModel dsrjgxxModel, DsrXpJgDO dsrXpJgDO) {
//		if (dsrXpJgDO == null) {
//			dsrXpJgDO = new DsrXpJgDO();
//		}
//		if (dsrjgxxModel != null) {
//			dsrXpJgDO.setAjxh((int)dsrjgxxModel.getAjxh());
//			dsrXpJgDO.setDsrbh((int)dsrjgxxModel.getDsrbh());
//			
//			dsrXpJgDO.setJgmc(dsrjgxxModel.getJgmc());
//			dsrXpJgDO.setDz(dsrjgxxModel.getDz());
//			dsrXpJgDO.setFddbrxm(dsrjgxxModel.getFddbrxm());
//			dsrXpJgDO.setXzjgxz(dsrjgxxModel.getXzjgxz());
//			dsrXpJgDO.setYb(dsrjgxxModel.getYb());
//			dsrXpJgDO.setSffy(dsrjgxxModel.getSffy());
//			dsrXpJgDO.setSfpc(dsrjgxxModel.getSfpc());
//			dsrXpJgDO.setDh(dsrjgxxModel.getDh());
//			dsrXpJgDO.setDjzh(dsrjgxxModel.getDjzh());
//			dsrXpJgDO.setDjzlb(dsrjgxxModel.getDjzlb());
//		}
//		return dsrXpJgDO;
//	}
//	
//	public static DsrJbDO dsrgrModelToDsrjbDO(DsrgrxxModel dsrgrModel, DsrJbDO dsrJbDO) {
//		if (dsrJbDO == null) {
//			dsrJbDO = new DsrJbDO();
//		}
//		if (dsrgrModel != null) {
//			dsrJbDO.setAjxh((int)dsrgrModel.getAjxh());
//			dsrJbDO.setDsrbh((int)dsrgrModel.getDsrbh());
//			dsrJbDO.setDsrssdw(dsrgrModel.getDsrssdw());
//			dsrJbDO.setDsrlb(dsrgrModel.getDsrlb());
//			dsrJbDO.setDsrjc(dsrgrModel.getDsrjc());
//			dsrJbDO.setSfssdbr(dsrgrModel.getSfssdbr());
//			if (!StringUtil.isBlank(dsrgrModel.getHpje())) {
//				dsrJbDO.setHpje(Double.parseDouble(dsrgrModel.getHpje()));
//			}
//			if (!StringUtil.isBlank(dsrgrModel.getQqpcje())) {
//				dsrJbDO.setQqpcje(Double.parseDouble(dsrgrModel.getQqpcje()));
//			}
//		}
//		return dsrJbDO;
//	}
//	
//	public static DsrJbDO dsrdwModelToDsrjbDO(DsrdwxxModel dsrdwModel, DsrJbDO dsrJbDO) {
//		if (dsrJbDO == null) {
//			dsrJbDO = new DsrJbDO();
//		}
//		if (dsrdwModel != null) {
//			dsrJbDO.setAjxh((int)dsrdwModel.getAjxh());
//			dsrJbDO.setDsrbh((int)dsrdwModel.getDsrbh());
//			dsrJbDO.setDsrssdw(dsrdwModel.getDsrssdw());
//			dsrJbDO.setDsrlb(dsrdwModel.getDsrlb());
//			dsrJbDO.setDsrjc(dsrdwModel.getDsrjc());
//			dsrJbDO.setSfssdbr(dsrdwModel.getSfssdbr());
//			if (!StringUtil.isBlank(dsrdwModel.getHpje())) {
//				dsrJbDO.setHpje(Double.parseDouble(dsrdwModel.getHpje()));
//			}
//			if (!StringUtil.isBlank(dsrdwModel.getQqpcje())) {
//				dsrJbDO.setQqpcje(Double.parseDouble(dsrdwModel.getQqpcje()));
//			}
//		}
//		return dsrJbDO;
//	}
//	
//	public static DsrJbDO dsrjgModelToDsrjbDO(DsrjgxxModel dsrjgModel, DsrJbDO dsrJbDO) {
//		if (dsrJbDO == null) {
//			dsrJbDO = new DsrJbDO();
//		}
//		if (dsrjgModel != null) {
//			dsrJbDO.setAjxh((int)dsrjgModel.getAjxh());
//			dsrJbDO.setDsrbh((int)dsrjgModel.getDsrbh());
//			dsrJbDO.setDsrssdw(dsrjgModel.getDsrssdw());
//			dsrJbDO.setDsrlb(dsrjgModel.getDsrlb());
//			dsrJbDO.setDsrjc(dsrjgModel.getDsrjc());
//			dsrJbDO.setSfssdbr(dsrjgModel.getSfssdbr());
//			if (!StringUtil.isBlank(dsrjgModel.getHpje())) {
//				dsrJbDO.setHpje(Double.parseDouble(dsrjgModel.getHpje()));
//			}
//			if (!StringUtil.isBlank(dsrjgModel.getQqpcje())) {
//				dsrJbDO.setQqpcje(Double.parseDouble(dsrjgModel.getQqpcje()));
//			}
//		}
//		return dsrJbDO;
//	}
//	
//	public static DsrMspcFjxxDO dsrdwModelToDsrpocDO(DsrdwxxModel dsrdwModel, DsrMspcFjxxDO dsrMspcFjxxDO) {
//		if (dsrMspcFjxxDO == null) {
//			dsrMspcFjxxDO = new DsrMspcFjxxDO();
//		}
//		if (dsrdwModel != null) {
//			dsrMspcFjxxDO.setAjxh((int)dsrdwModel.getAjxh());
//			dsrMspcFjxxDO.setDsrbh((int)dsrdwModel.getDsrbh());
//			if (!StringUtil.isBlank(dsrdwModel.getZcze())) {
//				dsrMspcFjxxDO.setZcze(Double.parseDouble(dsrdwModel.getZcze()));
//			}
//			if (!StringUtil.isBlank(dsrdwModel.getZwze())) {
//				dsrMspcFjxxDO.setZwze(Double.parseDouble(dsrdwModel.getZwze()));
//			}
//			if (!StringUtil.isBlank(dsrdwModel.getYhzq())) {
//				dsrMspcFjxxDO.setYhzq(Double.parseDouble(dsrdwModel.getYhzq()));
//			}
//		}
//		return dsrMspcFjxxDO;
//	}
//	
//	public static DsrMspcFjxxDO dsrjgModelToDsrpocDO(DsrjgxxModel dsrjgModel, DsrMspcFjxxDO dsrMspcFjxxDO) {
//		if (dsrMspcFjxxDO == null) {
//			dsrMspcFjxxDO = new DsrMspcFjxxDO();
//		}
//		if (dsrjgModel != null) {
//			dsrMspcFjxxDO.setAjxh((int)dsrjgModel.getAjxh());
//			dsrMspcFjxxDO.setDsrbh((int)dsrjgModel.getDsrbh());
//			if (!StringUtil.isBlank(dsrjgModel.getZcze())) {
//				dsrMspcFjxxDO.setZcze(Double.parseDouble(dsrjgModel.getZcze()));
//			}
//			if (!StringUtil.isBlank(dsrjgModel.getZwze())) {
//				dsrMspcFjxxDO.setZwze(Double.parseDouble(dsrjgModel.getZwze()));
//			}
//			if (!StringUtil.isBlank(dsrjgModel.getYhzq())) {
//				dsrMspcFjxxDO.setYhzq(Double.parseDouble(dsrjgModel.getYhzq()));
//			}
//		}
//		return dsrMspcFjxxDO;
//	}

	public static List<DsrgrxxModel> dsrgrDoListToModelList(List<DsrGrDO> dsrGrDOs, List<DsrJbDO> dsrJbDOs,DmbDao dmbDao,XxxService xxxSerrvice ,AjjbxxModel ajModel) {
		List<DsrgrxxModel> dsrgrModels = new ArrayList<DsrgrxxModel>();
		String ssdw_lbbh = xxxSerrvice.getLbbhOld("dsrssdw", "DSR_JB", ajModel);//���ϵ�λ
		String xb_lbbh = xxxSerrvice.getLbbhOld("xb", "DSR_GR", ajModel);//�Ա�
		String whcd_lbbh = xxxSerrvice.getLbbhOld("whcd", "DSR_GR", ajModel);//����������
		String mz_lbbh = xxxSerrvice.getLbbhOld("mz", "DSR_GR", ajModel);//����
		String zjlb_lbbh = xxxSerrvice.getLbbhOld("zjlb", "DSR_GR", ajModel);//֤�����
		String gj_lbbh = xxxSerrvice.getLbbhOld("ssgj", "DSR_GR", ajModel);//�Ļ��̶�
		String zzmm_lbbh = xxxSerrvice.getLbbhOld("zzmm", "DSR_GR", ajModel);//������ò
		for (DsrJbDO dsrJbDO : dsrJbDOs) {
			if(!StringUtil.equals(dsrJbDO.getDsrlb(), "1")){
				continue;
			}
			for (DsrGrDO dsrGrDO : dsrGrDOs) {
				if (equalsDsrgrDOAndDsrjbDO(dsrGrDO, dsrJbDO)) {
					DsrgrxxModel dsrgrModel = new DsrgrxxModel();
					dsrgrModel.setAjxh(dsrJbDO.getAjxh());
					dsrgrModel.setDsrbh(dsrJbDO.getDsrbh());
					//���������ϵ�λ
					DmbDO ssdw_dm = dmbDao.findById(ssdw_lbbh, StringUtil.trim(dsrJbDO.getDsrssdw()));
					if(ssdw_dm!=null && !StringUtil.isBlank(ssdw_dm.getDmms())){
						dsrgrModel.setDsrssdw(ssdw_dm.getDmms());
					}
					
					dsrgrModel.setDsrlb(StringUtil.trim(dsrJbDO.getDsrlb()));
					dsrgrModel.setSfssdbr(StringUtil.trim(dsrJbDO.getSfssdbr()));
					dsrgrModel.setDsrjc(StringUtil.trim(dsrJbDO.getDsrjc()));
					if (dsrJbDO.getHpje() != null) {
						dsrgrModel.setHpje(dsrJbDO.getHpje() + "");
					}
					if (dsrJbDO.getQqpcje() != null) {
						dsrgrModel.setQqpcje(dsrJbDO.getQqpcje() + "");
					}
					
					dsrgrModel.setXm(StringUtil.trim(dsrGrDO.getXm()));
//					�Ա�
					DmbDO xb_dm = dmbDao.findById(xb_lbbh, StringUtil.trim(dsrGrDO.getXb()));
					if(xb_dm!=null && !StringUtil.isBlank(xb_dm.getDmms())){
						dsrgrModel.setXb(xb_dm.getDmms());
					}
//					����������
					dsrgrModel.setCsnyr(DateUtil.format(dsrGrDO.getCsnyr(), DateUtil.webFormat));
//					����
					DmbDO mz_dm = dmbDao.findById(mz_lbbh, StringUtil.trim(dsrGrDO.getMz()));
					if(mz_dm!=null && !StringUtil.isBlank(mz_dm.getDmms())){
						dsrgrModel.setMz(mz_dm.getDmms());
					}
//					��������
					DmbDO gj_dm = dmbDao.findById(gj_lbbh,StringUtil.trim(dsrGrDO.getSsgj()));
					if(gj_dm!=null && !StringUtil.isBlank(gj_dm.getDmms())){
						dsrgrModel.setSsgj(gj_dm.getDmms());
					}
//					�Ļ��̶�
					DmbDO whcd_dm = dmbDao.findById(whcd_lbbh,StringUtil.trim(dsrGrDO.getWhcd()));
					if(whcd_dm!=null && !StringUtil.isBlank(whcd_dm.getDmms())){
						dsrgrModel.setWhcd(whcd_dm.getDmms());
					}
//					������ò
					DmbDO zzmm_dm = dmbDao.findById(zzmm_lbbh,StringUtil.trim(dsrGrDO.getZzmm()));
					if(zzmm_dm!=null && !StringUtil.isBlank(zzmm_dm.getDmms())){
						dsrgrModel.setZzmm(zzmm_dm.getDmms());
					}
					dsrgrModel.setSf(StringUtil.trim(dsrGrDO.getSf()));
					dsrgrModel.setJb(StringUtil.trim(dsrGrDO.getJb()));
					dsrgrModel.setJg(StringUtil.trim(dsrGrDO.getJg()));
//					֤�����
					DmbDO zjlb_dm = dmbDao.findById(zjlb_lbbh, StringUtil.trim(dsrGrDO.getZjlb()));
					if(zjlb_dm!=null && !StringUtil.isBlank(zjlb_dm.getDmms())){
						dsrgrModel.setZjlb(zjlb_dm.getDmms());
					}
					dsrgrModel.setSfzhm(StringUtil.trim(dsrGrDO.getSfzhm()));
					dsrgrModel.setYb(StringUtil.trim(dsrGrDO.getYb()));
					dsrgrModel.setDh(StringUtil.trim(dsrGrDO.getDh()));
					dsrgrModel.setZwzy(StringUtil.trim(dsrGrDO.getZwzy()));
					dsrgrModel.setGzdw(StringUtil.trim(dsrGrDO.getGzdw()));
					dsrgrModel.setDz(StringUtil.trim(dsrGrDO.getDz()));
					dsrgrModel.setZzd(StringUtil.trim(dsrGrDO.getZzd()));
					
					dsrgrModels.add(dsrgrModel);
				}
				
			}
			
		}
		
		return dsrgrModels;
	}
	
	public static List<DsrdwxxModel> dsrdwDoListToModelList(List<DsrDwDO> dsrDwDOs, List<DsrJbDO> dsrJbDOs, List<DsrMspcFjxxDO> dsrMspcFjxxDOs,
			DmbDao dmbDao,XxxService xxxSerrvice,AjjbxxModel ajModel) {
		List<DsrdwxxModel> dsrdwModels = new ArrayList<DsrdwxxModel>();
		String ssdw_lbbh = xxxSerrvice.getLbbhOld("dsrssdw", "DSR_JB", ajModel);//���ϵ�λ
		for (DsrJbDO dsrJbDO : dsrJbDOs) {
			if(!StringUtil.equals(dsrJbDO.getDsrlb(), "2")){
				continue;
			}
			for (DsrDwDO dsrDwDO : dsrDwDOs) {
				if (equalsDsrdwDOAndDsrjbDO(dsrDwDO, dsrJbDO)) {
					DsrdwxxModel dsrdwModel = new DsrdwxxModel();
					dsrdwModel.setAjxh(dsrJbDO.getAjxh());
					dsrdwModel.setDsrbh(dsrJbDO.getDsrbh());
//					���ϵ�λ
					DmbDO ssdw_dm = dmbDao.findById(ssdw_lbbh, StringUtil.trim(dsrJbDO.getDsrssdw()));
					if(ssdw_dm!=null && !StringUtil.isBlank(ssdw_dm.getDmms())){
						dsrdwModel.setDsrssdw(ssdw_dm.getDmms());
					}
					dsrdwModel.setDsrlb(StringUtil.trim(dsrJbDO.getDsrlb()));
					dsrdwModel.setSfssdbr(StringUtil.trim(dsrJbDO.getSfssdbr()));
					dsrdwModel.setDsrjc(StringUtil.trim(dsrJbDO.getDsrjc()));
					if (dsrJbDO.getHpje() != null) {
						dsrdwModel.setHpje(dsrJbDO.getHpje() + "");
					}
					if (dsrJbDO.getQqpcje() != null) {
						dsrdwModel.setQqpcje(dsrJbDO.getQqpcje() + "");
					}
					
					dsrdwModel.setDwmc(StringUtil.trim(dsrDwDO.getDwmc()));
					dsrdwModel.setYb(StringUtil.trim(dsrDwDO.getYb()));
					dsrdwModel.setDh(StringUtil.trim(dsrDwDO.getDh()));
					dsrdwModel.setDz(StringUtil.trim(dsrDwDO.getDz()));
					dsrdwModel.setFrxz(StringUtil.trim(dsrDwDO.getFrxz()));
					dsrdwModel.setFddbrxm(StringUtil.trim(dsrDwDO.getFddbrxm()));
					dsrdwModel.setGyqygm(StringUtil.trim(dsrDwDO.getGyqygm()));
					dsrdwModel.setDbrzw(StringUtil.trim(dsrDwDO.getDbrzw()));
					
					dsrdwModel.setLxdh(StringUtil.trim(dsrDwDO.getLxdh()));
					dsrdwModel.setDjzlb(StringUtil.trim(dsrDwDO.getDjzlb()));
					dsrdwModel.setDjzh(StringUtil.trim(dsrDwDO.getDjzh()));
					dsrdwModel.setFddbrxb(StringUtil.trim(dsrDwDO.getFddbrxb()));
					dsrdwModel.setJb(StringUtil.trim(dsrDwDO.getJb()));
					dsrdwModel.setWhcd(StringUtil.trim(dsrDwDO.getWhcd()));
					dsrdwModel.setZzmm(StringUtil.trim(dsrDwDO.getZzmm()));
					dsrdwModel.setCsnyr(DateUtil.format(dsrDwDO.getCsnyr(), DateUtil.webFormat));

					
					for (DsrMspcFjxxDO dsrMspcFjxxDO : dsrMspcFjxxDOs) {
						if (equalsDsrpocDOAndDsrjbDO(dsrMspcFjxxDO, dsrJbDO)) {
							if (dsrMspcFjxxDO.getZcze() != null) {
								dsrdwModel.setZcze(dsrMspcFjxxDO.getZcze() + "");
							}
							if (dsrMspcFjxxDO.getZwze() != null) {
								dsrdwModel.setZwze(dsrMspcFjxxDO.getZwze() + "");
							}
							if (dsrMspcFjxxDO.getYhzq() != null) {
								dsrdwModel.setYhzq(dsrMspcFjxxDO.getYhzq() + "");
							}
						}
					}
					
					dsrdwModels.add(dsrdwModel);
				}
			}
			
		}
		
		return dsrdwModels;
	}
//	
	public static List<DsrjgxxModel> dsrjgDoListToModelList(List<DsrXpJgDO> dsrXpJgDOs, List<DsrJbDO> dsrJbDOs, List<DsrMspcFjxxDO> dsrMspcFjxxDOs,
			DmbDao dmbDao,XxxService xxxSerrvice,AjjbxxModel ajModel) {
		List<DsrjgxxModel> dsrjgModels = new ArrayList<DsrjgxxModel>();
		String ssdw_lbbh = xxxSerrvice.getLbbhOld("dsrssdw", "DSR_JB", ajModel);//���ϵ�λ
		for (DsrJbDO dsrJbDO : dsrJbDOs) {
			if(!StringUtil.equals(dsrJbDO.getDsrlb(), "3")){
				continue;
			}
			for (DsrXpJgDO dsrXpJgDO : dsrXpJgDOs) {
				if (equalsDsrjgDOAndDsrjbDO(dsrXpJgDO, dsrJbDO)) {
					DsrjgxxModel dsrjgModel = new DsrjgxxModel();
					dsrjgModel.setAjxh(dsrJbDO.getAjxh());
					dsrjgModel.setDsrbh(dsrJbDO.getDsrbh());
//					���ϵ�λ
					DmbDO ssdw_dm = dmbDao.findById(ssdw_lbbh, StringUtil.trim(dsrJbDO.getDsrssdw()));
					if(ssdw_dm!=null && !StringUtil.isBlank(ssdw_dm.getDmms())){
						dsrjgModel.setDsrssdw(ssdw_dm.getDmms());
					}
					dsrjgModel.setDsrlb(StringUtil.trim(dsrJbDO.getDsrlb()));
					dsrjgModel.setSfssdbr(StringUtil.trim(dsrJbDO.getSfssdbr()));
					dsrjgModel.setDsrjc(StringUtil.trim(dsrJbDO.getDsrjc()));
					if (dsrJbDO.getHpje() != null) {
						dsrjgModel.setHpje(dsrJbDO.getHpje() + "");
					}
					if (dsrJbDO.getQqpcje() != null) {
						dsrjgModel.setQqpcje(dsrJbDO.getQqpcje() + "");
					}
					
					dsrjgModel.setJgmc(StringUtil.trim(dsrXpJgDO.getJgmc()));
					dsrjgModel.setDz(StringUtil.trim(dsrXpJgDO.getDz()));
					dsrjgModel.setFddbrxm(StringUtil.trim(dsrXpJgDO.getFddbrxm()));
					dsrjgModel.setXzjgxz(StringUtil.trim(dsrXpJgDO.getXzjgxz()));
					dsrjgModel.setSffy(StringUtil.trim(dsrXpJgDO.getSffy()));
					dsrjgModel.setSfpc(StringUtil.trim(dsrXpJgDO.getSfpc()));
					dsrjgModel.setDh(StringUtil.trim(dsrXpJgDO.getDh()));
					dsrjgModel.setYb(StringUtil.trim(dsrXpJgDO.getYb()));
					dsrjgModel.setDjzlb(StringUtil.trim(dsrXpJgDO.getDjzlb()));
					dsrjgModel.setDjzh(StringUtil.trim(dsrXpJgDO.getDjzh()));

					for (DsrMspcFjxxDO dsrMspcFjxxDO : dsrMspcFjxxDOs) {
						if (equalsDsrpocDOAndDsrjbDO(dsrMspcFjxxDO, dsrJbDO)) {
							if (dsrMspcFjxxDO.getZcze() != null) {
								dsrjgModel.setZcze(dsrMspcFjxxDO.getZcze() + "");
							}
							if (dsrMspcFjxxDO.getZwze() != null) {
								dsrjgModel.setZwze(dsrMspcFjxxDO.getZwze() + "");
							}
							if (dsrMspcFjxxDO.getYhzq() != null) {
								dsrjgModel.setYhzq(dsrMspcFjxxDO.getYhzq() + "");
							}
						}
					}
					dsrjgModels.add(dsrjgModel);
				}
			}
		}
		
		return dsrjgModels;
	}
//	
	public static boolean equalsDsrgrDOAndDsrjbDO(DsrGrDO dsrGrDO,
			DsrJbDO dsrJbDO) {
		if (dsrGrDO != null && dsrJbDO != null) {
			if (dsrGrDO.getAjxh().equals(dsrJbDO.getAjxh())
					&& dsrGrDO.getDsrbh().equals(dsrJbDO.getDsrbh()))
				return true;
			else
				return false;
		} else
			return true;
	}
//	
	public static boolean equalsDsrdwDOAndDsrjbDO(DsrDwDO dsrDwDO,
			DsrJbDO dsrJbDO) {
		if (dsrDwDO != null && dsrJbDO != null) {
			if (dsrDwDO.getAjxh().equals(dsrJbDO.getAjxh())
					&& dsrDwDO.getDsrbh().equals(dsrJbDO.getDsrbh()))
				return true;
			else
				return false;
		} else
			return true;
	}
//	
	public static boolean equalsDsrjgDOAndDsrjbDO(DsrXpJgDO dsrXpJgDO,
			DsrJbDO dsrJbDO) {
		if (dsrXpJgDO != null && dsrJbDO != null) {
			if (dsrXpJgDO.getAjxh().equals(dsrJbDO.getAjxh())
					&& dsrXpJgDO.getDsrbh().equals(dsrJbDO.getDsrbh()))
				return true;
			else
				return false;
		} else
			return true;
	}
//	
	public static boolean equalsDsrpocDOAndDsrjbDO(DsrMspcFjxxDO dsrMspcFjxxDO,
			DsrJbDO dsrJbDO) {
		if (dsrMspcFjxxDO != null && dsrJbDO != null) {
			if (dsrMspcFjxxDO.getAjxh().equals(dsrJbDO.getAjxh())
					&& dsrMspcFjxxDO.getDsrbh().equals(dsrJbDO.getDsrbh()))
				return true;
			else
				return false;
		} else
			return true;
	}
//	
//	public static DsrpcsqxxVO dsrpcsqModelToVo(DsrpcsqxxModel dsrpcsqxxModel) {
//		DsrpcsqxxVO dsrpcsqxxVO = new DsrpcsqxxVO();
//		if (dsrpcsqxxModel != null) {
//			BeanUtils.copyProperties(dsrpcsqxxModel, dsrpcsqxxVO);
//			dsrpcsqxxVO.setBh(Long.parseLong(dsrpcsqxxModel.getDsrbh()));
//		}
//		return dsrpcsqxxVO;
//	}
//	
//	public static DsrpcsqxxModel dsrpcsqVoToModel(DsrpcsqxxVO dsrpcsqxxVO) {
//		DsrpcsqxxModel dsrpcsqxxModel = new DsrpcsqxxModel();
//		if (dsrpcsqxxVO != null) {
//			BeanUtils.copyProperties(dsrpcsqxxVO, dsrpcsqxxModel);
//		}
//		return dsrpcsqxxModel;
//	}
//	
//	public static DsrPcsqxgxxDO dsrpcsqModelToDo(DsrpcsqxxModel dsrpcsqxxModel, DsrPcsqxgxxDO dsrPcsqxgxxDO) {
//		if (dsrPcsqxgxxDO == null) {
//			dsrPcsqxgxxDO = new DsrPcsqxgxxDO();
//		}
//		if (dsrpcsqxxModel != null) {
//			dsrPcsqxgxxDO.setAjxh(Integer.parseInt(dsrpcsqxxModel.getAjxh() + ""));
//			dsrPcsqxgxxDO.setDsrbh(Integer.parseInt(dsrpcsqxxModel.getDsrbh() + ""));
//			dsrPcsqxgxxDO.setSqpcly(dsrpcsqxxModel.getSqpcly());
//			dsrPcsqxgxxDO.setSqpcqq(dsrpcsqxxModel.getSqpcqq());
//			dsrPcsqxgxxDO.setQqpcje(Double.parseDouble(dsrpcsqxxModel.getQqpcje()));
//			dsrPcsqxgxxDO.setSqqrqk(dsrpcsqxxModel.getSqqrqk());
//			dsrPcsqxgxxDO.setPcywjgqrqk(dsrpcsqxxModel.getPcywjgqrqk());
//			dsrPcsqxgxxDO.setPcywjgqrflyj(dsrpcsqxxModel.getPcywjgqrflyj());
//			dsrPcsqxgxxDO.setPcywjgjdqk(dsrpcsqxxModel.getPcywjgjdqk());
//			dsrPcsqxgxxDO.setPcywjgjdflyj(dsrpcsqxxModel.getPcywjgjdflyj());
//			dsrPcsqxgxxDO.setPcywjgsfpc(dsrpcsqxxModel.getPcywjgsfpc());
//			dsrPcsqxgxxDO.setPcywjgpcje(Double.parseDouble(dsrpcsqxxModel.getPcywjgpcje()));
//			
//		}
//		return dsrPcsqxgxxDO;
//	}
//	
//	public static DsrpcsqxxModel dsrpcsqDoToModel(DsrPcsqxgxxDO dsrPcsqxgxxDO) {
//		DsrpcsqxxModel dsrpcsqxxModel = new DsrpcsqxxModel();
//		if (dsrPcsqxgxxDO != null) {
//			dsrpcsqxxModel.setAjxh(dsrPcsqxgxxDO.getAjxh());
//			dsrpcsqxxModel.setDsrbh(dsrPcsqxgxxDO.getDsrbh() + "");
//			dsrpcsqxxModel.setSqpcly(StringUtil.trim(dsrPcsqxgxxDO.getSqpcly()));
//			dsrpcsqxxModel.setSqpcqq(StringUtil.trim(dsrPcsqxgxxDO.getSqpcqq()));
//			if (dsrPcsqxgxxDO.getQqpcje() != null) {
//				dsrpcsqxxModel.setQqpcje(dsrPcsqxgxxDO.getQqpcje() + "");
//			}
//			dsrpcsqxxModel.setSqqrqk(StringUtil.trim(dsrPcsqxgxxDO.getSqqrqk()));
//			dsrpcsqxxModel.setPcywjgqrqk(StringUtil.trim(dsrPcsqxgxxDO.getPcywjgqrqk()));
//			dsrpcsqxxModel.setPcywjgqrflyj(StringUtil.trim(dsrPcsqxgxxDO.getPcywjgqrflyj()));
//			dsrpcsqxxModel.setPcywjgjdqk(StringUtil.trim(dsrPcsqxgxxDO.getPcywjgjdqk()));
//			dsrpcsqxxModel.setPcywjgjdflyj(StringUtil.trim(dsrPcsqxgxxDO.getPcywjgjdflyj()));
//			dsrpcsqxxModel.setPcywjgsfpc(StringUtil.trim(dsrPcsqxgxxDO.getPcywjgsfpc()));
//			if (dsrPcsqxgxxDO.getPcywjgpcje() != null) {
//				dsrpcsqxxModel.setPcywjgpcje(dsrPcsqxgxxDO.getPcywjgpcje() + "");
//			}
//		}
//		return dsrpcsqxxModel;
//	}
//	
//	public static List<DsrpcsqxxModel> dsrpcsqDoListToModelList(List<DsrPcsqxgxxDO> dsrPcsqxgxxDOs) {
//		List<DsrpcsqxxModel> dsrpcsqxxModels = new ArrayList<DsrpcsqxxModel>();
//		if (dsrPcsqxgxxDOs != null) {
//			for (DsrPcsqxgxxDO dsrPcsqxgxxDO : dsrPcsqxgxxDOs) {
//				DsrpcsqxxModel dsrpcsqxxModel = dsrpcsqDoToModel(dsrPcsqxgxxDO);
//				dsrpcsqxxModels.add(dsrpcsqxxModel);
//			}
//		}
//		return dsrpcsqxxModels;
//	}
}
