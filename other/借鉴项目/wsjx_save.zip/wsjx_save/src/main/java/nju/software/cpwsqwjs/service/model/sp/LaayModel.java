/**
 * 2014-5-26 14:43
 */
package nju.software.cpwsqwjs.service.model.sp;

import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.LaAyDO;
import nju.software.cpwsqwjs.util.StringUtil;

public class LaayModel {

	long ajxh;
	long bh;//��ţ�ͬһ��������1����
	String ay;//���а��ɱ��
	String laay;//��������
	public long getAjxh() {
		return ajxh;
	}
	public void setAjxh(long ajxh) {
		this.ajxh = ajxh;
	}
	public long getBh() {
		return bh;
	}
	public void setBh(long bh) {
		this.bh = bh;
	}
	public String getAy() {
		return ay;
	}
	public void setAy(String ay) {
		this.ay = ay;
	}
	public String getLaay() {
		return laay;
	}
	public void setLaay(String laay) {
		this.laay = laay;
	}
	public static List<LaayModel> laayDoListToModelList(List<LaAyDO> laAyDOs) {
		List<LaayModel> laayModels = new ArrayList<LaayModel>();
		if (laAyDOs != null) {
			for (LaAyDO laAyDO : laAyDOs) {
				LaayModel laayModel = laayDoToModel(laAyDO);
				laayModels.add(laayModel);
			}
		}
		
		return laayModels;
	}	
	
	public static LaayModel laayDoToModel(LaAyDO laAyDO) {
		LaayModel laayModel = new LaayModel();
		if (laAyDO != null) {
			laayModel.setAjxh(laAyDO.getAjxh().longValue());
			laayModel.setBh(laAyDO.getLaaybh().longValue());
			laayModel.setAy(StringUtil.trim(laAyDO.getAy()));
			laayModel.setLaay(StringUtil.trim(laAyDO.getLaay()));
		}
		
		return laayModel;
	}
}
