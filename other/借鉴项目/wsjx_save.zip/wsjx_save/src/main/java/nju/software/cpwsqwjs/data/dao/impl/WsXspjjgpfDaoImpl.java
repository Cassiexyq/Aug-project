package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsXspjjgpfDao;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDO;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDOId;

public class WsXspjjgpfDaoImpl  extends HibernateDaoSupport implements WsXspjjgpfDao{

	@Override
	public int save(WsXspjjgpfDO pf) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(pf);
			return pf.getPfbh();
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public int getMaxPfbhByAjxhAndFzbh(int ajxh, int fzbh) {
		// TODO Auto-generated method stub
		String hql = "select max(pfbh) from WsXspjjgpfDO where ajxh="+ajxh+" and fzbh="+fzbh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxbh = 0;
		if (query.uniqueResult() != null) {
			maxbh =  (int) query.uniqueResult();
		}
		// �ͷ����ݿ�����
		this.releaseSession(s);
		return  maxbh;
	}

	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsXspjjgpfDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public WsXspjjgpfDO finfById(WsXspjjgpfDOId id) {
		// TODO Auto-generated method stub
		try{
			WsXspjjgpfDO instance = (WsXspjjgpfDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsXspjjgpfDO", id);
			return instance;
		} catch(RuntimeException e){
			throw e;
		}
	}
}
