package nju.software.cpwsqwjs.service.model;

import nju.software.cpwsqwjs.data.dataobject.FydmDO;

public class FydmModel {

	private String fydm;//��Ժ����
	private String cjm;//�㼶��
	private String fymc;//��Ժ����
	private String sm;//˵��
	private String sjfymc;//�ϼ���Ժ����
	
	
	public FydmModel() {
		super();
	}
	public FydmModel(String fydm, String cjm, String fymc, String sm,
			String sjfymc) {
		super();
		this.fydm = fydm;
		this.cjm = cjm;
		this.fymc = fymc;
		this.sm = sm;
		this.sjfymc = sjfymc;
	}
	
	public FydmModel(String fydm, String cjm, String fymc) {
		super();
		this.fydm = fydm;
		this.cjm = cjm;
		this.fymc = fymc;
	}
	public String getFydm() {
		return fydm;
	}
	public void setFydm(String fydm) {
		this.fydm = fydm;
	}
	public String getCjm() {
		return cjm;
	}
	public void setCjm(String cjm) {
		this.cjm = cjm;
	}
	public String getFymc() {
		return fymc;
	}
	public void setFymc(String fymc) {
		this.fymc = fymc;
	}
	public String getSm() {
		return sm;
	}
	public void setSm(String sm) {
		this.sm = sm;
	}
	public String getSjfymc() {
		return sjfymc;
	}
	public void setSjfymc(String sjfymc) {
		this.sjfymc = sjfymc;
	}
	
	public FydmModel(FydmDO model){
		if(model!=null){
			 
		
		if(model.getFydm()!=null){
			this.setFydm(model.getFydm());
		}
		if(model.getCjm()!=null){
			this.setCjm(model.getCjm());
		}
		if(model.getFymc()!=null){
			this.setFymc(model.getFymc());
		}
		if(model.getSjfymc()!=null){
			this.setSjfymc(model.getSjfymc());
		}
		if(model.getSm()!=null){
			this.setSm(model.getSm());
		}
	}
	}
}
