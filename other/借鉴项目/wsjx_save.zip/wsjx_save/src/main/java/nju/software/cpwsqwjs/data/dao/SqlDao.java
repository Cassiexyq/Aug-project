package nju.software.cpwsqwjs.data.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.exception.BaseAppException;

import org.apache.log4j.Logger;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SqlDao extends HibernateDaoSupport {

	private static final Logger log = Logger.getLogger(SqlDao.class);

	public List<List<String>> callSql(String sql) {
		List<List<String>> result = new ArrayList<List<String>>();

		ConnectionProvider cp = null;
		Connection connection = null;
		List<String> metaResult = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();
			connection = cp.getConnection();

			statement = connection.prepareStatement(sql);

			resultSet = statement.executeQuery();

			int columnCount = resultSet.getMetaData().getColumnCount();
			while (resultSet.next()) {
				metaResult = new ArrayList<String>();
				for (int i = 1; i <= columnCount; i++) {
					metaResult.add(resultSet.getString(i));
				}
				result.add(metaResult);
			}

		} catch (SQLException e1) {
			System.out.println("����ϵͳ�쳣 " + sql);
			throw new BaseAppException(
					statement == null ? "PreparedStatement cstmt==null"
							: statement.toString(), e1);
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
				if (statement != null)
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);

			}

		}
		return result;
	}
	public void excuteSql(String sql){
		ConnectionProvider cp = null;
		Connection connection = null;
		Statement statement = null;
		
		try {
			cp = ((SessionFactoryImplementor) this.getSessionFactory())
					.getConnectionProvider();
			connection = cp.getConnection();

			statement = connection.createStatement();

		    statement.execute(sql);

			
		} catch (SQLException e1) {
			System.out.println("����ϵͳ�쳣 " + sql);
			throw new BaseAppException(
					statement == null ? "PreparedStatement cstmt==null"
							: statement.toString(), e1);
		} finally {
			try {
		
	
			
					statement.close();
				if (cp != null)
					cp.closeConnection(connection);
			} catch (SQLException e) {
				log.error("�ر����ݿ����ӳ�����", e);

			}

		}
	}
}
