package nju.software.cpwsqwjs.service.model.convert;

import java.util.ArrayList;
import java.util.List;

import nju.software.cpwsqwjs.service.model.WsModel;
import nju.software.cpwsqwjs.util.Constant;
import nju.software.cpwsqwjs.util.DateUtil;

import org.apache.lucene.document.Document;
public class WsModelConvert {

	public static WsModel documentToModel(Document doc){
		WsModel model=new WsModel();
		model.setAjxh(Integer.parseInt(doc.get("ajxh")));
		model.setWsjbbh(Integer.parseInt(doc.get("wsjbbh")));
		model.setWslb(doc.get("wslb"));
		model.setWsmc(doc.get("wsmc"));
		model.setZzh(doc.get("zz"));
		model.setScrq(DateUtil.parse(doc.get("scrq"), DateUtil.webFormat));
		model.setWswjm(doc.get("wswjm"));
		String wsnr=doc.get("wsnr");
		if(doc.get("ajlx")!=null)
		model.setAjlx(doc.get("ajlx").trim());
		else
			model.setAjlx("");
		if(doc.get("sj")!=null)
		model.setSjlx(doc.get("sj").trim());
		else{
			model.setSjlx("");
		}
		model.setFy(doc.get("fy"));
		String str=wsnr;
		str=str.replaceAll(" ", "");
		str=str.replaceAll("\r", "");
		str=str.replaceAll("\n", "");
		/*if(wsnr.length()>Constant.WsnrLength){
			wsnr=wsnr.substring(0, Constant.WsnrLength)+"...";
		}*/
		model.setWsnr(str);
		return model;
	}
	
	public static List<WsModel> documentsToModels(List<Document> docs){
		List<WsModel> models=new ArrayList<WsModel>();
		for(Document doc:docs){
			models.add(documentToModel(doc));
		}
		return models;
	}
}
