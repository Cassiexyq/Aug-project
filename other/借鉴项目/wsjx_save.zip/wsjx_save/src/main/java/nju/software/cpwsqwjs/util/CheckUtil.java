package nju.software.cpwsqwjs.util;

import java.util.Date;

import nju.software.cpwsqwjs.service.TestMethodService;
import nju.software.cpwsqwjs.service.impl.TestMethodServiceImpl;

public class CheckUtil {
	
	/**
	 * �ж������ڵ��Ƿ���ȫ���
	 * @param ws
	 * @param db
	 * @param jdmc
	 * @return
	 */
	
	public int checkUtil_equals(String ws, String db,String jdmc)
	{
		
		if(ws == null && db == null)
		{
			return 1;
		}

		else if(ws == null&& db != null)
		{
			return 2;
		}

		else if(ws != null && db == null)
		{
			return 3;
		}

		else if(ws.equals(db))
		{
			return 4;
		}
		else
		{
			return 5;
		}

	}
	
	/**
	 * �ж������ڵ��Ƿ���а�����ϵ
	 * @param ws
	 * @param db
	 * @param jdmc
	 * @return
	 */
	public int checkUtil_contains(String ws, String db,String jdmc)
	{
		
		if(ws == null && db == null)
		{
			return 1;
		}

		else if(ws == null&& db != null)
		{
			return 2;
		}

		else if(ws != null && db == null)
		{
			return 3;
		}

		else if(ws.contains(db) || db.contains(ws))
		{
			return 4;
		}
		else
		{
			return 5;
		}

	}
	
	/**
	 * �ж������ڵ��Ƿ�����
	 * @param ws
	 * @param db
	 * @param jdmc
	 * @return
	 */
	
	public int checkUtil_similar(String ws, String db,String jdmc)
	{
		TestMethodService testmethod = new TestMethodServiceImpl();
		
		if(ws == null && db == null)
		{
			return 1;
		}

		else if(ws == null&& db != null)
		{
			return 2;
		}

		else if(ws != null && db == null)
		{
			return 3;
		}

		else if(testmethod.judgeNode_3(ws, db))
		{
			return 4;
		}
		else
		{
			return 5;
		}

	}
	
	public int checkDate_equals(String ws, String db )
	{
		if(ws == null && db == null)
		{
			return 1;
		}

		if(ws == null&& db != null)
		{
			return 2;
		}

		if(ws != null && db == null)
		{
			return 3;
		}
		Date wsDate = DateUtil.parse(ws, DateUtil.chineseDtFormat);
		Date spDate = DateUtil.parse(db, DateUtil.newFormat);
		if(DateUtil.getDiffDays(wsDate, spDate)==0)
		{
			return 4;
		}
		return 5;
	}
}
