 package nju.software.cpwsqwjs.data.dao.impl;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.SsRzbDao;
import nju.software.cpwsqwjs.data.dataobject.SsRzbDO;

public class SsRzbDaoImpl extends HibernateDaoSupport implements SsRzbDao {
	private static Logger log = Logger.getLogger(SsRzbDaoImpl.class);

	public void addSsRzb(SsRzbDO s) {
		try {
			if (s == null) {
				throw new Exception("������־������Ϊ�գ�");
			} else {
				int id = getMaxId() + 1;
				s.setId(id);
				getHibernateTemplate().evict(s);
				getHibernateTemplate().save(s);
			}
			// ˢ��Session
			getSession().flush();
		} catch (Exception e) {

			e.printStackTrace();
		}

	}


	public int getMaxId() {
		String sql = "select max(id) from SsRzbDO";

		Integer maxxh = new Integer(0);
		try {
			Session s = this.getSession();
			Query query = s.createQuery(sql);

			if (query.uniqueResult() != null)
				maxxh = (Integer) query.uniqueResult();
			this.releaseSession(s);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Failed to get the max xh of SsRzbDO", e);
		}
		return maxxh;

	}


	
}
