package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsDsrQkDao;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQkDO;
import nju.software.cpwsqwjs.data.dataobject.WsDsrQkDOId;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by zhx on 2017/1/5.
 */
public class WsDsrQkDaoImpl extends HibernateDaoSupport implements WsDsrQkDao {

    @Override
    public WsDsrQkDO findByID(WsDsrQkDOId id) {
        try {
            WsDsrQkDO instance = (WsDsrQkDO) getHibernateTemplate().get(
                    "nju.software.cpwsqwjs.data.dataobject.WsDsrQkDO", id);
            return instance;
        } catch (RuntimeException re) {
            throw re;
        }
    }

    @Override
    public int getMaxQkbhByAjxh(int ajxh) {
        String hql="select max(qkbh) from  WsDsrQkDO where ajxh="+ajxh;
        Session s = this.getSession();
        Query query = s.createQuery(hql);

        int qkbhMax=0;
        if (query.uniqueResult()!=null){
            qkbhMax=(int)query.uniqueResult();
        }
        this.releaseSession(s);
        return qkbhMax;
    }

    @Override
    public List<WsDsrQkDO> getDsrQzcsByAjxhDsrxh(int ajxh, int dsrbh) {
        return null;
    }

    @Override
    public WsDsrQkDO getDsrQzcsByQkbh(int ajxh, int qkbh) {
        return null;
    }

    @Override
    public int save(WsDsrQkDO wsDsrQkDO) {
        try{
            getHibernateTemplate().saveOrUpdate(wsDsrQkDO);
            return wsDsrQkDO.getQkbh();
        }catch (RuntimeException re){
            throw re;
        }
    }
}
