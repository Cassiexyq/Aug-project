package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsfilterDAO;
import nju.software.cpwsqwjs.data.dataobject.WsfilterDO;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by zhx on 2017/6/27.
 */
public class WsfilterDAOImpl extends HibernateDaoSupport implements WsfilterDAO {
    @Override
    public void addWsfilterList(List<WsfilterDO> wsfilterDOS) {
        Session s = this.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        for (WsfilterDO wsfilterDO:wsfilterDOS){
            s.saveOrUpdate(wsfilterDO);
        }
        tx.commit();
        s.close();
    }

    @Override
    public String addWsfilter(WsfilterDO wsfilterDO) {
        try {
            getHibernateTemplate().save(wsfilterDO);
            return wsfilterDO.getAh();
        }catch (RuntimeException re){
            re.printStackTrace();
        }
        return null;
    }
    @Override
    public String save2(WsfilterDO wsfilterDO){
        Session s = this.getSessionFactory().openSession();
        Transaction tx = s.beginTransaction();
        s.save(wsfilterDO);
        tx.commit();
        s.close();
        return null;
    }

    @Override
    public long getMaxId() {
        String hql = "select max(id) from WsfilterDO";

        Session s = this.getSession();
        Query query = s.createQuery(hql);

        long maxid = 0;
        if (query.uniqueResult() != null)
            maxid = (Long) query.uniqueResult();

        // �ͷ����ݿ����ӣ�����
        this.releaseSession(s);
        return maxid;
    }
}
