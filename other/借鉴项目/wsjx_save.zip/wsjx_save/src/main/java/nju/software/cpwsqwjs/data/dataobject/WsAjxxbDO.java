package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import nju.software.cpwsqwjs.service.datamodel.WsajjbxxModel;
import nju.software.cpwsqwjs.service.model.WscpjgModel;
import nju.software.cpwsqwjs.service.model.WswsModel;

import com.sun.accessibility.internal.resources.accessibility;

/**
 * AjjbDO entity. @author MyEclipse Persistence Tools
 * ����������Ϣ
 */
@Entity
@Table(name = "WS_AJJBXXB")
public class WsAjxxbDO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private Integer ajxh;//�������
	private String ah;//����
	private String ajxz;//��������
	private String spcx;//���г���
	private String wsmc;//��������
	private String wszl;//��������
	private String wszzdw;//����������λ
	private String jbfy;//���취Ժ
	private String fyjb;//��Ժ����
	private String xzqhsh;//�������� ʡ
	private String xzqhs;//�������� ��
	private String land;//�������
	private String tcgxqyy;//�Ƿ������ϽȨ����
	private String jafs;//�᰸��ʽ
	private String pjsj;//�о�ʱ��
	private String jand;//�᰸���
	private String jayf;//�᰸�·�
	private String kssz;//��������
	private String ssqx;//��������
	private String sstjcl;//�����ύ����
	private String sffhcs;//�Ƿ񷢻�����
	private String fhccyy;//��������ԭ��
	private String jazbd;//�᰸�ܱ��

	// Constructors

	/** default constructor */
	public WsAjxxbDO() {
	}

	/** minimal constructor */
	public WsAjxxbDO(Integer ajxh) {
		this.ajxh = ajxh;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", unique = true, nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "AJXZ", length = 10)
	public String getAjxz() {
		return this.ajxz;
	}

	public void setAjxz(String ajxz) {
		this.ajxz = ajxz;
	}

	@Column(name = "SPCX", length = 10)
	public String getSpcx() {
		return this.spcx;
	}

	public void setSpcx(String spcx) {
		this.spcx = spcx;
	}
	@Column(name = "AH", length = 40)
	public String getAh() {
		return ah;
	}

	public void setAh(String ah) {
		this.ah = ah;
	}
	@Column(name = "WSMC", length = 50)
	public String getWsmc() {
		return wsmc;
	}

	public void setWsmc(String wsmc) {
		this.wsmc = wsmc;
	}
	@Column(name = "WSZL", length = 30)
	public String getWszl() {
		return wszl;
	}

	public void setWszl(String wszl) {
		this.wszl = wszl;
	}
	@Column(name = "WSZZDW", length = 30)
	public String getWszzdw() {
		return wszzdw;
	}

	public void setWszzdw(String wszzdw) {
		this.wszzdw = wszzdw;
	}
	@Column(name = "JBFY", length = 30)
	public String getJbfy() {
		return jbfy;
	}

	public void setJbfy(String jbfy) {
		this.jbfy = jbfy;
	}
	@Column(name = "FYJB", length = 10)
	public String getFyjb() {
		return fyjb;
	}

	public void setFyjb(String fyjb) {
		this.fyjb = fyjb;
	}
	@Column(name = "XZQHSH", length = 10)
	public String getXzqhsh() {
		return xzqhsh;
	}

	public void setXzqhsh(String xzqhsh) {
		this.xzqhsh = xzqhsh;
	}
	@Column(name = "XZQHS", length = 20)
	public String getXzqhs() {
		return xzqhs;
	}

	public void setXzqhs(String xzqhs) {
		this.xzqhs = xzqhs;
	}
	@Column(name = "LAND", length = 10)
	public String getLand() {
		return land;
	}

	public void setLand(String land) {
		this.land = land;
	}
	@Column(name = "TCGXQYY", length = 10)
	public String getTcgxqyy() {
		return tcgxqyy;
	}

	public void setTcgxqyy(String tcgxqyy) {
		this.tcgxqyy = tcgxqyy;
	}
	@Column(name = "JAFS", length = 30)
	public String getJafs() {
		return jafs;
	}

	public void setJafs(String jafs) {
		this.jafs = jafs;
	}
	@Column(name = "PJSJ", length = 50)
	public String getPjsj() {
		return pjsj;
	}

	public void setPjsj(String pjsj) {
		this.pjsj = pjsj;
	}
	@Column(name = "JAND", length = 10)
	public String getJand() {
		return jand;
	}

	public void setJand(String jand) {
		this.jand = jand;
	}
	@Column(name = "JAYF", length = 10)
	public String getJayf() {
		return jayf;
	}

	public void setJayf(String jayf) {
		this.jayf = jayf;
	}
	@Column(name = "KSSZ", length = 20)
	public String getKssz() {
		return kssz;
	}

	public void setKssz(String kssz) {
		this.kssz = kssz;
	}
	@Column(name = "SSQX", length = 10)
	public String getSsqx() {
		return ssqx;
	}

	public void setSsqx(String ssqx) {
		this.ssqx = ssqx;
	}
	@Column(name = "SSTJCL", length = 100)
	public String getSstjcl() {
		return sstjcl;
	}

	public void setSstjcl(String sstjcl) {
		this.sstjcl = sstjcl;
	}
	@Column(name = "SFFHCS", length = 2)
	public String getSffhcs() {
		return sffhcs;
	}

	public void setSffhcs(String sffhcs) {
		this.sffhcs = sffhcs;
	}
	@Column(name = "FHCSYY", length = 20)
	public String getFhccyy() {
		return fhccyy;
	}

	public void setFhccyy(String fhccyy) {
		this.fhccyy = fhccyy;
	}
	@Column(name = "JAZBD", length = 50)
	public String getJazbd() {
		return jazbd;
	}

	public void setJazbd(String jazbd) {
		this.jazbd = jazbd;
	}
	
	/**
	 * ��������������Ϣʱ��ʹ������
	 * @param model
	 */
	public WsAjxxbDO(WswsModel wsModel){
		if(wsModel.getAh()!=null){
			this.ah = wsModel.getAh();
		}
		if(wsModel.getJbfy()!=null){
			this.jbfy = wsModel.getJbfy();
		}
		if(wsModel.getWsmc()!=null){
			this.wsmc = wsModel.getWsmc();
		}
		if(wsModel.getLand()!=null){
			this.land = wsModel.getLand();
		}
		if(wsModel.getWszzdw()!=null){
			this.wszzdw = wsModel.getWszzdw();
		}
		if(wsModel.getFyjb()!=null){
			this.fyjb= wsModel.getFyjb();
		}
		if(wsModel.getXzqhProv()!=null){
			this.xzqhsh = wsModel.getXzqhProv();
		}
		if(wsModel.getXzqhCity()!=null){
			this.xzqhs = wsModel.getXzqhCity();
		}
		if(wsModel.getWszl()!=null){
			this.wszl = wsModel.getWszl();
		}
		if(wsModel.getAjxz()!=null){
			this.ajxz = wsModel.getAjxz();
		}
		if(wsModel.getSpcx()!=null){
			this.spcx = wsModel.getSpcx();
		}
	}

}