package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkCmssdDO;

public interface WsAjjbqkCmssdDao {
    public WsAjjbqkCmssdDO getByAjxh(int ajxh);
    public void save(WsAjjbqkCmssdDO wsAjjbqkCmssdDO);

    public int getMaxbh();
}
