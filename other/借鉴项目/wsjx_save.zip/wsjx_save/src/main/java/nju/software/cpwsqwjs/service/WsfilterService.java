package nju.software.cpwsqwjs.service;

import nju.software.cpwsqwjs.service.model.WsfilterModel;

/**
 * Created by zhx on 2017/6/27.
 */
public interface WsfilterService {
    /**
     * ����
     * @param wsfilterModel
     */
    public void saveWsfilter(WsfilterModel wsfilterModel);

}
