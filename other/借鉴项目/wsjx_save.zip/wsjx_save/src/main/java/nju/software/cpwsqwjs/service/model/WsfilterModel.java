package nju.software.cpwsqwjs.service.model;

/**
 * Created by zhx on 2017/6/27.
 */
public class WsfilterModel {
    private String ah;//����
    private String ajmc;//��������
    private String spcx;//���г���
    private String fymc;//��Ժ����
    private String wsbt;//�������
    private String cprq;//��������
    private String fbrq;//��������
    private String zsfy;//����Ժ
    private String zsah;//���󰸺�
    private String spz;//���г�
    private String ay;//����
    private String byrw;//��Ժ��Ϊ
    private String zw;//����
    private String ft;//����

    public WsfilterModel() {
    }

    public WsfilterModel(String ah, String ajmc, String spcx, String fymc, String wsbt, String cprq, String fbrq, String zsfy, String zsah, String spz, String ay, String byrw, String zw, String ft) {
        this.ah = ah;
        this.ajmc = ajmc;
        this.spcx = spcx;
        this.fymc = fymc;
        this.wsbt = wsbt;
        this.cprq = cprq;
        this.fbrq = fbrq;
        this.zsfy = zsfy;
        this.zsah = zsah;
        this.spz = spz;
        this.ay = ay;
        this.byrw = byrw;
        this.zw = zw;
        this.ft = ft;
    }

    public String getAh() {
        return ah;
    }

    public void setAh(String ah) {
        this.ah = ah;
    }

    public String getAjmc() {
        return ajmc;
    }

    public void setAjmc(String ajmc) {
        this.ajmc = ajmc;
    }

    public String getSpcx() {
        return spcx;
    }

    public void setSpcx(String spcx) {
        this.spcx = spcx;
    }

    public String getFymc() {
        return fymc;
    }

    public void setFymc(String fymc) {
        this.fymc = fymc;
    }

    public String getWsbt() {
        return wsbt;
    }

    public void setWsbt(String wsbt) {
        this.wsbt = wsbt;
    }

    public String getCprq() {
        return cprq;
    }

    public void setCprq(String cprq) {
        this.cprq = cprq;
    }

    public String getFbrq() {
        return fbrq;
    }

    public void setFbrq(String fbrq) {
        this.fbrq = fbrq;
    }

    public String getZsfy() {
        return zsfy;
    }

    public void setZsfy(String zsfy) {
        this.zsfy = zsfy;
    }

    public String getZsah() {
        return zsah;
    }

    public void setZsah(String zsah) {
        this.zsah = zsah;
    }

    public String getSpz() {
        return spz;
    }

    public void setSpz(String spz) {
        this.spz = spz;
    }

    public String getAy() {
        return ay;
    }

    public void setAy(String ay) {
        this.ay = ay;
    }

    public String getByrw() {
        return byrw;
    }

    public void setByrw(String byrw) {
        this.byrw = byrw;
    }

    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }
}
