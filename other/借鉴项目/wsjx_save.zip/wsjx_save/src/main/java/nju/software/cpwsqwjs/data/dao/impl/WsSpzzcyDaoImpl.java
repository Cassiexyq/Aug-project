package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsSpzzcyDao;
import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDO;
import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDOId;
import nju.software.cpwsqwjs.data.dataobject.WsXspjjgfzDO;

public class WsSpzzcyDaoImpl extends HibernateDaoSupport implements WsSpzzcyDao{
	private static final Logger log = Logger.getLogger(WsSpzzcyDaoImpl.class);
	@Override
	public void save(WsSpzzcyDO spzzcy) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(spzzcy);
		}catch(Exception e){
			throw e;
		}
	}

	@Override
	public WsSpzzcyDO findByID(WsSpzzcyDOId id) {
		// TODO Auto-generated method stub
		try {
			WsSpzzcyDO instance = (WsSpzzcyDO) getHibernateTemplate().get(
					"nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDO", id);
			return instance;
		} catch (RuntimeException re) {
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from WsSpzzcyDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}
	
	@Override
	public List<WsSpzzcyDO> findByAjxh(int ajxh) {
		// TODO Auto-generated method stub
		return findByProperty("ajxh", ajxh);
	}

}
