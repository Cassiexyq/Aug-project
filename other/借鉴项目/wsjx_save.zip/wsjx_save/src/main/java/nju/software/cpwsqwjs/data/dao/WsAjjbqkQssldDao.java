package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkQssldDO;

public interface WsAjjbqkQssldDao {
    public WsAjjbqkQssldDO getByAjxh(int ajxh);
    public void save(WsAjjbqkQssldDO wsAjjbqkQssldDO);
    public int getMaxbh();
}
