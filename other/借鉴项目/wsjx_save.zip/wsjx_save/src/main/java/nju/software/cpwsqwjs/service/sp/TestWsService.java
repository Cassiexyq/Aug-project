package nju.software.cpwsqwjs.service.sp;

import java.util.List;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.ValidateModel;
import nju.software.cpwsqwjs.service.model.sp.WsJbModel;

public interface TestWsService {
	
	public List<ValidateModel> testWs(WswsModel wswsModel,AjjbxxModel ajjbxxModel,WsJbModel wsjbModel,List<ValidateModel> vmodellist);

}
