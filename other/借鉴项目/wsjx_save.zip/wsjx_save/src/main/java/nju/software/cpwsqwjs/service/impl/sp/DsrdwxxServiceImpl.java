/**
 * 2014-5-18
 */
package nju.software.cpwsqwjs.service.impl.sp;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.DsrDwDao;
import nju.software.cpwsqwjs.data.dao.DsrJbDao;
import nju.software.cpwsqwjs.data.dao.DsrMspcFjxxDao;
import nju.software.cpwsqwjs.data.dao.XxxglDao;
import nju.software.cpwsqwjs.data.dataobject.DsrDwDO;
import nju.software.cpwsqwjs.data.dataobject.DsrDwDOId;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrMspcFjxxDO;
import nju.software.cpwsqwjs.service.dataConvertor.DsrConvertor;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;
import nju.software.cpwsqwjs.service.sp.DsrdwxxService;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.StringUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.googlecode.ehcache.annotations.Cacheable;
import com.googlecode.ehcache.annotations.TriggersRemove;
@Service
public class DsrdwxxServiceImpl implements DsrdwxxService {

	private   DsrDwDao dsrDwDao;
	private   DsrJbDao dsrJbDao;
	private   DsrMspcFjxxDao dsrMspcFjxxDao;
	private   XxxService xxxSerrvice;
	private   DmbDao dmbDao;
	
	/*private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static DsrDwDao dsrDwDao;
	private static DsrJbDao dsrJbDao;
	private static DsrMspcFjxxDao dsrMspcFjxxDao;
	private static XxxService xxxSerrvice;
	private static DmbDao dmbDao;
	static {
		dmbDao = (DmbDao) appContext.getBean("dmbDao");
		dsrDwDao = (DsrDwDao) appContext.getBean("dsrDwDao");
		dsrJbDao = (DsrJbDao) appContext.getBean("dsrJbDao");
		dsrMspcFjxxDao = (DsrMspcFjxxDao) appContext.getBean("dsrMspcFjxxDao");
		xxxSerrvice = new XxxServiceImpl();
	}*/
 


	public List<DsrdwxxModel> getDsrdwxxByAjxh(long ajxh,AjjbxxModel ajModel) {
		// TODO Auto-generated method stub
		List<DsrDwDO> dsrDwDOs = dsrDwDao.findByProperty("ajxh", (int)ajxh);
		List<DsrJbDO> dsrJbDOs = dsrJbDao.findByProperty("ajxh", (int)ajxh);
		List<DsrMspcFjxxDO> dsrMspcFjxxDOs = dsrMspcFjxxDao.findByProperty("ajxh", (int)ajxh);
		List<DsrdwxxModel> dsrdwModels = DsrConvertor.dsrdwDoListToModelList(dsrDwDOs, dsrJbDOs, dsrMspcFjxxDOs,dmbDao,xxxSerrvice,ajModel);
		return dsrdwModels;
	}


	public void setDsrDwDao(DsrDwDao dsrDwDao) {
		this.dsrDwDao = dsrDwDao;
	}


	public void setDsrJbDao(DsrJbDao dsrJbDao) {
		this.dsrJbDao = dsrJbDao;
	}


	public void setDsrMspcFjxxDao(DsrMspcFjxxDao dsrMspcFjxxDao) {
		this.dsrMspcFjxxDao = dsrMspcFjxxDao;
	}


	public void setXxxSerrvice(XxxService xxxSerrvice) {
		this.xxxSerrvice = xxxSerrvice;
	}


	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}


	@Override
	public boolean updateDsrdw(long ajxh, int dsrbh, String zd, String zdz) {
		// TODO Auto-generated method stub
		DsrDwDOId id = new DsrDwDOId((int)ajxh, dsrbh);
		DsrDwDO dsr = dsrDwDao.findById(id);
		if(dsr==null){
			return false;
		}
		if(StringUtil.equals(zd, "DZ")){
			dsr.setDz(zdz);
			dsrDwDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "FDDBRXM")){
			dsr.setFddbrxm(zdz);
			dsrDwDao.save(dsr);
			return true;
		}
		return false;
	}

}
