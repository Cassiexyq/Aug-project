package nju.software.cpwsqwjs.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.service.WsCqModel;
import nju.software.cpwsqwjs.service.model.*;
import nju.software.cpwsqwjs.test.Xzws2015;

import nju.software.cpwsqwjs.test.XzwsService2015;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;

public class ExportUtil {
	public static HashMap<String,String> hashMap = new HashMap<>();
	public static int count = 0;

	public static void handleFt(String filePath) throws IOException{
		File f = new File(filePath);
		InputStream inputStream = new FileInputStream(f);
		XSSFWorkbook xssfWorkbook = new XSSFWorkbook(inputStream);
		XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0);
		XzwsService2015 xzwsService2015 = new XzwsService2015();
		Xzws2015 model = new Xzws2015();
		for (int rowNum = 1;rowNum <= xssfSheet.getLastRowNum();rowNum++) {
			System.out.println(rowNum);
			XSSFRow row = xssfSheet.getRow(rowNum);
			if (row.getCell(13) != null) {
				String ajjbqk = row.getCell(13).getStringCellValue();
				String ajjbqk_ft = xzwsService2015.getFt(ajjbqk, model);
				row.createCell(14).setCellValue(ajjbqk_ft);
			}
			if (row.getCell(15) != null) {
				String cpfxgc = row.getCell(15).getStringCellValue();
				String cpfxgc_ft = xzwsService2015.getFt(cpfxgc, model);
				row.createCell(16).setCellValue(cpfxgc_ft);
			}
		}
		try{
			FileOutputStream fout = new FileOutputStream(filePath);
			xssfWorkbook.write(fout);
			fout.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void wsXsd(String filePath,String textPath) throws IOException{
		//ȡ�����ƶ��ı�
		FileUtil fileUtil = new FileUtil();
		fileUtil.setS(textPath);
		ArrayList<String> textlist = fileUtil.readFromFileuft8();
		HashMap<String,String> ajXsdList = new HashMap<>();
		for (String text: textlist) {
			String[] tlist = text.split("��");
			if (tlist.length>1){
				ajXsdList.put(tlist[0].trim(),tlist[1].trim());
			}else {
				ajXsdList.put(tlist[0].trim(),"");
			}
		}
		File f = new File(filePath);
		InputStream inputStream = new FileInputStream(f);
//		if (filePath.endsWith(".xlsx")){
//			XSSFWorkbook xssfSheets = new XSSFWorkbook(inputStream);
//			XSSFSheet xssfSheet = xssfSheets.getSheetAt(0);
//		}else{
		HSSFWorkbook  xssfWorkbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet1 = xssfWorkbook.getSheetAt(0);
		System.out.println("��������"+sheet1.getLastRowNum());
		//}
//		//���xlsx
//		XSSFWorkbook wb = new XSSFWorkbook();
//		XSSFSheet sheet = wb.createSheet("table");
//		XSSFCellStyle style = wb.createCellStyle();
//		style.setAlignment(XSSFCellStyle.ALIGN_CENTER);

		for (int rowNum =2;rowNum<=sheet1.getLastRowNum();rowNum++){
			HSSFRow row = sheet1.getRow(rowNum);
			if (row!=null){
				HSSFCell ahCell = row.getCell(0);
				String ahStr = ahCell.getStringCellValue().trim();
				if (hashMap.containsKey(ahStr)){
					System.out.println(ahStr);
					sheet1.removeRow(row);
				}
				hashMap.put(ahStr,ahStr);
//				HSSFCell byrwCell = row.getCell(11);
//				String byrwStr = byrwCell.getStringCellValue().trim();
//				Xzws2015 xzws2015 = new Xzws2015();
//				xzws2015.setByrw(byrwStr);
//				xzws2015.setAh(ahStr);
				//byrwTxt(xzws2015,"/Users/zhx/Desktop/wsduty/��Ժ��Ϊtxt-С��300��/");
				if (ajXsdList.containsKey(ahStr)&&ajXsdList.get(ahStr)!=""){
					//System.out.println(ajXsdList.get(ahStr));
					row.createCell(14).setCellValue(ajXsdList.get(ahStr));
				}
			}
		}

		try{
			FileOutputStream fout = new FileOutputStream(filePath);
			xssfWorkbook.write(fout);
			fout.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void exportNew2(Map<String,Xzws2015> map, String filePath, String outPath) throws IOException {
		File f = new File(filePath);
		InputStream inputStream = new FileInputStream(f);
		HSSFWorkbook  xssfWorkbook = new  HSSFWorkbook(inputStream);
		//  XSSFSheet xssfSheet = xssfWorkbook.getSheetAt(0); //�����.xlsx�ļ�ʹ�����
		HSSFSheet sheet1 = xssfWorkbook.getSheetAt(0);

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("table");
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);

		for (int rowNum = 2,toRowNum = 2; rowNum <= sheet1.getLastRowNum(); rowNum++) {


			HSSFRow row = sheet1.getRow(rowNum);
			if (row != null) {

				HSSFCell ah = row.getCell(1);
				HSSFCell wsmc1 = row.getCell(2);
				HSSFCell wsmc2 = row.getCell(5);
				String ahStr = ah.getStringCellValue().trim();
				String wsmc1Str = wsmc1.getStringCellValue().trim();
				String wsmc2Str = wsmc2.getStringCellValue().trim();
//				if( wsmc1Str.contains("�̱�����")
//						|| wsmc2Str.contains("�̱�����")){
//					continue;
//				}

				HSSFRow rowNew = sheet.createRow(toRowNum++);
				for(int i=0;i<8;i++){
					rowNew.createCell(i).setCellValue(row.getCell(i).getStringCellValue());
				}

				Xzws2015 model = map.get(ahStr);

				if(model!=null){
					//�����Ժ��Ϊtxt
//					String path = "/Users/zhx/Desktop/wsduty/��Ժ��Ϊtxt-С��300��/";
//					byrwTxt(model,path);
					//System.out.println(ahStr);

					if(!StringUtil.isBlank(model.getZsfy()) ){
						rowNew.createCell(8).setCellValue(model.getZsfy());
					}else{
						rowNew.createCell(8).setCellValue("");
					}
					if(!StringUtil.isBlank(model.getZsah()) ){
						rowNew.createCell(9).setCellValue(model.getZsah());
					}else{
						rowNew.createCell(9).setCellValue("");
					}
					if(  !StringUtil.isBlank(model.getSpz()) ){
						rowNew.createCell(10).setCellValue(model.getSpz());
					}else{
						rowNew.createCell(10).setCellValue("");
					}
					if(  !StringUtil.isBlank(model.getAy()) ){
						rowNew.createCell(11).setCellValue(model.getAy());
					}else{
						rowNew.createCell(11).setCellValue("");
					}
					if(  !StringUtil.isBlank(model.getByrw()) ){
						rowNew.createCell(12).setCellValue(model.getByrw());
					}else{
						rowNew.createCell(12).setCellValue("");
					}
					if(  !StringUtil.isBlank(model.getZw()) ){
						rowNew.createCell(13).setCellValue(model.getZw());
					}else{
						rowNew.createCell(13).setCellValue("");
					}
					if(  !StringUtil.isBlank(model.getFt()) ){
						rowNew.createCell(14).setCellValue(model.getFt());
					}else{
						rowNew.createCell(14).setCellValue("");
					}
				}
			}
		}
		try{
			FileOutputStream fout = new FileOutputStream(outPath);
			wb.write(fout);
			fout.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void byrwTxt(Xzws2015 model,String filepath){
		String byrw = model.getByrw();
		List<String> byrwlist = new ArrayList<>();
		if (byrw!=null && byrw.length()<310 && byrw.length()>0){
			byrwlist.add(byrw);
			//System.out.println(byrw);
			String ah = model.getAh();
			String path = filepath + ah;
			FileUtil.writeToFile(byrwlist,path);
		}
	}

	public static void export(List<XzzsWsjxModel> models,String outputPath){
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("table");
		HSSFRow row = sheet.createRow(0);
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);


		HSSFCell cell = row.createCell(0);
		cell.setCellValue("��������");
		cell.setCellStyle(style);

		cell = row.createCell(1);
		cell.setCellValue("����");
		cell.setCellStyle(style);

		cell = row.createCell(2);
		cell.setCellValue("����");
		cell.setCellStyle(style);

		cell = row.createCell(3);
		cell.setCellValue("������");
		cell.setCellStyle(style);

		cell = row.createCell(4);
		cell.setCellValue("��������");
		cell.setCellStyle(style);

		cell = row.createCell(5);
		cell.setCellValue("������������");
		cell.setCellStyle(style);

		cell = row.createCell(6);
		cell.setCellValue("����Ժ����");
		cell.setCellStyle(style);

		cell = row.createCell(7);
		cell.setCellValue("����Ժ��Ϊ");
		cell.setCellStyle(style);

		cell = row.createCell(8);
		cell.setCellValue("��Ժ��Ϊ");
		cell.setCellStyle(style);

		cell = row.createCell(9);
		cell.setCellValue("���з�������");
		cell.setCellStyle(style);

		cell = row.createCell(10);
		cell.setCellValue("���н��");
		cell.setCellStyle(style);

		for(int i=0;i<models.size();i++){
			XzzsWsjxModel model = models.get(i);
			row = sheet.createRow(i+1);
			if(model.getWs()!=null && !StringUtil.isBlank(model.getWs().getWszl()) ){
				row.createCell(0).setCellValue(model.getWs().getWszl());
			}else{
				row.createCell(0).setCellValue("");
			}
			if(model.getWs()!=null&& !StringUtil.isBlank(model.getWs().getAh()) ){
				row.createCell(1).setCellValue(model.getWs().getAh());
			}else{
				row.createCell(1).setCellValue("");
			}
			if(model.getSsjl()!=null&& !StringUtil.isBlank(model.getSsjl().getAy()) ){
				row.createCell(2).setCellValue(model.getSsjl().getAy());
			}else{
				row.createCell(2).setCellValue("");
			}
			row.createCell(3).setCellValue(getSscyrByssdw(model, "������"));
			row.createCell(4).setCellValue(getSscyrByssdw(model, "��������"));
			if(model.getAjjbqk()!=null && !StringUtil.isBlank( model.getAjjbqk().getZssqqq())){
				row.createCell(5).setCellValue(model.getAjjbqk().getZssqqq());
			}else{
				row.createCell(5).setCellValue("");
			}
			if(model.getAjjbqk()!=null && !StringUtil.isBlank( model.getAjjbqk().getEsfycm())){
				row.createCell(6).setCellValue(model.getAjjbqk().getEsfycm());
			}else{
				row.createCell(6).setCellValue("");
			}
			if(model.getAjjbqk()!=null && !StringUtil.isBlank( model.getAjjbqk().getEsfyrw())){
				row.createCell(7).setCellValue(model.getAjjbqk().getEsfyrw());
			}else{
				row.createCell(7).setCellValue("");
			}
			if(model.getWsfdModel()!=null && !StringUtil.isBlank( model.getWsfdModel().getCpfxgc())){
				row.createCell(8).setCellValue(model.getWsfdModel().getCpfxgc());
			}else{
				row.createCell(8).setCellValue("");
			}

			row.createCell(9).setCellValue(getFltk(model));
			row.createCell(10).setCellValue(getCpjg(model));
		}

		try{
			FileOutputStream fout = new FileOutputStream(outputPath);
			wb.write(fout);
			fout.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static String getSscyrByssdw(XzzsWsjxModel model,String ssdw){
		if(model.getSscyr()!=null &&model.getSscyr().size()>0 ){
			StringBuilder res= new StringBuilder();
			for(WssscyrModel sscyr:model.getSscyr()){
				if(StringUtil.contains(sscyr.getSsdw(), ssdw)){
					res.append(sscyr.getSscyr()+";");
				}
			}
			String res1 = res.toString();
			if(res1.length()>0){
				res1 = res1.substring(0, res1.length()-1);
			}
			return res1;
		}else{
			return "";
		}
	}

	public static String getFltk(XzzsWsjxModel model){
		StringBuilder sb = new StringBuilder();
		String ftStr = "";
		if(model.getCpfxgc()!=null && model.getCpfxgc().getFtModellist()!=null){
			for(WscpfxgcFtModel ft:model.getCpfxgc().getFtModellist()){
				sb.append(ft.getFlftmc()+",");
				if(ft.getFtMap()!=null){
					for(String key:ft.getFtMap().keySet()){
						sb.append("��"+key+"��");
						if(!ft.getFtMap().get(key).equals("û�п�Ŀ")){
							sb.append("��"+ft.getFtMap().get(key)+"��;");
						}
					}
				}
			}
			ftStr = sb.toString();
			if(ftStr.endsWith(",")){
				ftStr = ftStr.substring(0, ftStr.length()-1);
			}
		}
		return ftStr;
	}

	public static String getCpjg(XzzsWsjxModel model){
		StringBuilder sb = new StringBuilder();
		String res = "";
		if(model.getPjjg()!=null && model.getPjjg().getCpjgnr()!=null){
			for(String s:model.getPjjg().getCpjgnr()){
				sb.append(s);
			}
			res = sb.toString();
		}
		return res;
	}

	public static void exportTraffic(List<WsCqModel> models, String outpath){
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("table");
		for (int i = 0; i < 27; i++) {
			sheet.setColumnWidth(i,15*256);
		}
		sheet.setColumnWidth(2,20*256);
		sheet.setColumnWidth(3,20*256);
		sheet.setColumnWidth(4,25*256);
		sheet.setColumnWidth(24,35*256);
		sheet.setColumnWidth(26,20*256);
		HSSFRow row = sheet.createRow(1);
		HSSFRow mainHeadRow = sheet.createRow(0);
		HSSFCellStyle style = wb.createCellStyle();
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		String[] rowHead = {"��������","����","��ǿ�ձ��չ�˾(���ϵ�λ)","��ҵ������(���ϵ�λ)",
				"��ͨ�¹�ԭ���߳����Ͻ��",
				"�Ƿ����ϸ��",
				"�¹�����","�¹�ʱ��", "�¹ʵص�",
				"������������","������������","���������϶����",
				"ʵ�ʾ�ס��", "ְҵ", "�������", "����" ,"��ؼ���", "ʵ��֧�����",
				"���ܺ��˵������⸶",
				"�Ƿ�Ͷ��", "Ͷ������", "�Ƿ��ڱ�������",
				"�����Ƿ�ɿ�",
				"�¹����α���",
				"ͬʱ������Ȩ���뱣�չ�˾���⳥˳���Ƿ���ȷ",
				"�⳥",
				"����������е����������"
		};
		String[] rowMainHead = {"������","ԭ���߳ƶ�-���������","�����ƶ�","������ʵ��-�¹�","���������������","�ܺ������","����","���Ŷ����","���з�������","�о����"};
		Integer[] rowMainHeadNum = {2,4,5,6,9,12,19,22,23,24};
		HashMap<Integer,String> rowMainHeadMap = new HashMap<>();
		for (int i = 0; i < rowMainHead.length; i++) {
			rowMainHeadMap.put(rowMainHeadNum[i],rowMainHead[i]);
		}
		for (int i = 0,j=0; i < rowHead.length; i++) {
			HSSFCell cell = row.createCell(i);
			cell.setCellValue(rowHead[i]);
			cell.setCellStyle(style);
			if (rowMainHeadMap.containsKey(i)){
				creatCell(mainHeadRow,i,rowMainHead[j++],style);
			}
		}


		for (int i = 0,rowNum = 1; i <models.size() ; i++) {
			WsCqModel model = models.get(i);
			row = sheet.createRow(++rowNum);
			if(model.getFilename()!=null){
				row.createCell(0).setCellValue(model.getFilename());
			}else{
				row.createCell(0).setCellValue("");
			}
			if(model.getWs()!=null&& !StringUtil.isBlank(model.getWs().getAh()) ){
				row.createCell(1).setCellValue(model.getWs().getAh());
			}else{
				row.createCell(1).setCellValue("");
			}
//			row.createCell(2).setCellValue(getSscyrBySssf(model,"��ǿ��"));
//			row.createCell(3).setCellValue(getSscyrBySssf(model,"��ҵ������"));
			row.createCell(2).setCellValue("δ����");
			row.createCell(3).setCellValue("δ����");
			row.createCell(4).setCellValue(getSsje(model));
			row.createCell(5).setCellValue("δ����");
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSgxq()!=null){
				row.createCell(6).setCellValue(model.getAjjbqk().getSgxq());
			}else{
				row.createCell(6).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSgsj()!=null){
				row.createCell(7).setCellValue(model.getAjjbqk().getSgsj());
			}else{
				row.createCell(7).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSgdd()!=null){
				row.createCell(8).setCellValue(model.getAjjbqk().getSgdd());
			}else{
				row.createCell(8).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getJdcsyr()!=null){
				row.createCell(9).setCellValue(model.getAjjbqk().getJdcsyr());
			}else{
				row.createCell(9).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getJdcglr()!=null){
				row.createCell(10).setCellValue(model.getAjjbqk().getJdcglr());
			}else{
				row.createCell(10).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getGajgrdyj()!=null){
				row.createCell(11).setCellValue(model.getAjjbqk().getGajgrdyj());
			}else{
				row.createCell(11).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getShrjzd()!=null){
				row.createCell(12).setCellValue(model.getAjjbqk().getShrjzd());
			}else{
				row.createCell(12).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getShrzy()!=null){
				row.createCell(13).setCellValue(model.getAjjbqk().getShrzy());
			}else{
				row.createCell(13).setCellValue("");
			}
			row.createCell(14).setCellValue("δ����");
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getShangQing()!=null){
				row.createCell(15).setCellValue(model.getAjjbqk().getShangQing());
			}else{
				row.createCell(15).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getIdentifyContent()!=null){
				row.createCell(16).setCellValue(model.getAjjbqk().getIdentifyContent());//��ؼ���
			}else{
				row.createCell(16).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getRealPay()!=null){
				row.createCell(17).setCellValue(model.getAjjbqk().getRealPay());
			}else{
				row.createCell(17).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSfxqpf()!=null){
				row.createCell(18).setCellValue(model.getAjjbqk().getSfxqpf());
			}else{
				row.createCell(18).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSftb()!=null){
				row.createCell(19).setCellValue(model.getAjjbqk().getSftb());
			}else{
				row.createCell(19).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getTbxz()!=null){
				row.createCell(20).setCellValue(model.getAjjbqk().getTbxz());
			}else{
				row.createCell(20).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getSfzbxqn()!=null){
				row.createCell(21).setCellValue(model.getAjjbqk().getSfzbxqn());
			}else{
				row.createCell(21).setCellValue("");
			}
			if (model.getAjjbqk()!=null&&model.getAjjbqk().getJdsfkk()!=null){
				row.createCell(22).setCellValue(model.getAjjbqk().getJdsfkk());
			}else{
				row.createCell(22).setCellValue("");
			}
			row.createCell(23).setCellValue("");
			if (model.getPjjg()!=null&&model.getPjjg().getPcsxsfzq()!=null){
				row.createCell(24).setCellValue(model.getPjjg().getPcsxsfzq());
			}else{
				row.createCell(24).setCellValue("");
			}
			row.createCell(25).setCellValue(getSsje(model));
			row.createCell(26).setCellValue("δ����");//�������û����
		}

		try{
			FileOutputStream fout = new FileOutputStream(outpath);
			wb.write(fout);
			fout.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static String getSscyrBySssf(WsCqModel model,String sssf){
		if(model.getSscyr()!=null &&model.getSscyr().size()>0 ){
			StringBuilder res= new StringBuilder();
			for(WssscyrModel sscyr:model.getSscyr()){
				if(StringUtil.contains(sscyr.getSssf(), sssf)){
					res.append(sscyr.getSscyr()+";");
				}
			}
			String res1 = res.toString();
			if(res1.length()>0){
				res1 = res1.substring(0, res1.length()-1);
			}
			return res1;
		}else{
			return "";
		}
	}

	public static String getSsje(WsCqModel model){
		if (model.getAjjbqk()!=null && model.getAjjbqk().getSsqqjeList()!=null&&model.getAjjbqk().getSsqqjeList().size()>0){
			StringBuilder res = new StringBuilder();
			for (PjjeModel je:model.getAjjbqk().getSsqqjeList()){
				if (!StringUtil.isBlank(je.getValue())){
					res.append("���Ͻ�"+je.getValue()+"��");
				}
				if(je.getCategorys()!=null && je.getCategorys().size()>0){
					res.append("������ࣺ");
					for(String lx:je.getCategorys()){
						res.append(lx+"��");
					}
					res.deleteCharAt(res.lastIndexOf("��"));
					res.append("��");
				}
				if (!StringUtil.isBlank(je.getJsfs())){
					res.append("���㷽ʽ:"+je.getJsfs()+"��");
				}
				if (!StringUtil.isBlank(je.getKssj())){
					res.append("��ʼʱ��:"+je.getKssj()+"��");
				}
				if (!StringUtil.isBlank(je.getJssj())){
					res.append("����ʱ��:"+je.getJssj()+"��");
				}
			}
			String res1 = res.toString();
			if(res1.length()>0){
				res1 = res1.substring(0, res1.length()-1);
			}
			return res1;
		}else{
			return "";
		}
	}

	public static String getPCInfo(WsCqModel wsCqModel){
		if (wsCqModel.getPjjg()!=null&&wsCqModel.getPjjg().getPjjgList()!=null&&wsCqModel.getPjjg().getPjjgList().size()>0){
			StringBuilder res = new StringBuilder();
			for (PjjgnrModel pjjgnrModel : wsCqModel.getPjjg().getPjjgList()) {
				if (pjjgnrModel.getPjjeList() != null
						&& pjjgnrModel.getPjjeList().size() > 0){
					for (PjjeModel jemodel : pjjgnrModel.getPjjeList()) {
						if (jemodel != null
								&& !StringUtil.isBlank(jemodel
								.getValue())){
							res.append("��"+jemodel.getValue()+"��");
						}
						if (jemodel.getCategorys() != null
								&& jemodel.getCategorys().size() > 0){
							for (String s : jemodel.getCategorys()) {
								if (!StringUtil.isBlank(s)){
									res.append("������ࣺ"+s+"��");
								}
							}
						}
						res.deleteCharAt(res.lastIndexOf("��"));
						res.append("��");
					}

				}
			}
			String res1 = res.toString();
			if(res1.length()>0){
				res1 = res1.substring(0, res1.length()-1);
			}
			return res1;
		}
		return "";

	}

	public static void creatCell(HSSFRow row,int cellNum,String value,HSSFCellStyle style){
		HSSFCell cell = row.createCell(cellNum);
		cell.setCellValue(value);
		cell.setCellStyle(style);
	}
	
}
