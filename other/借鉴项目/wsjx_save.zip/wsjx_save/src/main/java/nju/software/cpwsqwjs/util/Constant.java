package nju.software.cpwsqwjs.util;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;


import org.wltea.analyzer.lucene.IKAnalyzer;

import com.chenlb.mmseg4j.analysis.ComplexAnalyzer;

public class Constant {

	public static long OneDayTime=86400000;
	public static long OneHourTime=3600000;
	
	public static String ProjectName="cpwsqwjs";
	public static final String cl="E://cpws"; 
	public static String IndexPath=cl+"//index";//�����ļ�
	public static String WsFilePath="resources/ws/";//�����ļ����Ŀ¼
	public static String beginPath=cl+"/config/begin.ini";
	public static String endPath=cl+"/config/end.ini";
	public static String totalPath=cl+"/config/total.ini";
	
	public static String IndexConfigPath=cl+"/config/indexConfig.ini";//�����ļ����������¸�������ʱ��
	public static String IndexLog=cl+"/config/log.ini";
//	public static Version LuceneVersion=Version.LUCENE_5_1_0;
	
	public static int WsnrLength=130;
	public static Analyzer Analyzer=new  IKAnalyzer();
	
	
	public final static String QuanWen="search_qw";
	
	public final static String ZuoZhe="search_zz";
	public final static String WenjianMing="search_wjm";
	public final static String AnJianXuHao="search_ajxh";
	public final static String WenShuJiBiaoBianHao="search_wsjbbh";
	public final static String WenShuNeiRong="search_wsnr";
	
	public static int SearchLength=1000;
	public static int SingleSearchLength=500;
	
	public final static String Index_Ajxh="ajxh";
	public final static String Index_Zz="zz";
	public final static String Index_Wsnr="wsnr";
	public final static String Index_Wsjbbh="wsjbbh";
	public final static String Index_Scrq="scrq";
	public final static String Index_Wswjm="wswjm";
	public final static String Index_Wsmc="wsmc";
	public final static String Index_Wslb="wslb";
	public final static String Index_Sj="sj";
	public final static String Index_Wjlx="wjlx";
	public final static String Index_Ajlx="ajlx";
	public final static String Index_Fy="fy";
	public final static String Index_Scrqsz="scrqsz";
	public final static String Index_Laay="laay";
	//������Ϊ�����������
	public final static int diff=5;
//	//����������request��Ĭ�ϱ����ʽ��windowsΪgbk��linuxΪiso-8859-1
//	public final static String rquestCode="iso-8859-1";
//	//ת���ɽ����ı���,windows��utf-8,linux��GBK
//	public final static String destinateCode="gbk";
	/*public enum SearchWay{
		search_qw,search_zz,search_wjm,search_ajxh,search_wsjbbh,search_wsnr
	}*/

	
}
