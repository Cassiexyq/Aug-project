package nju.software.cpwsqwjs.data.dataobject;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "PUB_QWJS_SSRZB")
public class SsRzbDO implements Serializable {

	private int id;
	private String type;
	private String gjc;
	private String ckwjm;
	private Date sj;

	@Id
	@Column(name = "ID", unique = true, nullable = false)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "TYPE")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	@Column(name = "GJC")
	public String getGjc() {
		return gjc;
	}

	public void setGjc(String gjc) {
		this.gjc = gjc;
	}

	@Column(name = "CKWJM")
	public String getCkwjm() {
		return ckwjm;
	}

	public void setCkwjm(String ckwjm) {
		this.ckwjm = ckwjm;
	}

	@Column(name = "SJ")
	public Date getSj() {
		return sj;
	}

	public void setSj(Date sj) {
		this.sj = sj;
	}

}
