package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * WsJbDO entity. @author MyEclipse Persistence Tools
 * ���з������� �������
 */
@Entity
@Table(name = "WS_CPFXGC_LXQJ")
@IdClass(WsCpfxgcLxqjDOId.class)
public class WsCpfxgcLxqjDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;//�������
	private Integer lxqjbh;//������ڱ��
	private String lxqjzl;//�����������
	private String xgr;//�����
	private String qj;//���
	private String lxzl;//��������

	/** default constructor */
	public WsCpfxgcLxqjDO() {
	}

	/** minimal constructor */
	public WsCpfxgcLxqjDO(Integer ajxh, Integer lxqjbh) {
		this.ajxh = ajxh;
		this.lxqjbh = lxqjbh;
	}

	public WsCpfxgcLxqjDO(Integer ajxh, Integer lxqjbh, String lxqjzl,
			String xgr, String qj,String lxzl) {
		super();
		this.ajxh = ajxh;
		this.lxqjbh = lxqjbh;
		this.lxqjzl = lxqjzl;
		this.xgr = xgr;
		this.qj = qj;
		this.lxzl = lxzl;
	}


	

	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "LXQJBH", nullable = false)
	public Integer getLxqjbh() {
		return lxqjbh;
	}

	public void setLxqjbh(Integer lxqjbh) {
		this.lxqjbh = lxqjbh;
	}
	@Column(name = "LXQJZL", length = 255)
	public String getLxqjzl() {
		return lxqjzl;
	}

	public void setLxqjzl(String lxqjzl) {
		this.lxqjzl = lxqjzl;
	}
	
	@Column(name = "XGR", length = 255)
	public String getXgr() {
		return xgr;
	}

	public void setXgr(String xgr) {
		this.xgr = xgr;
	}
	@Column(name = "QJ", length = 200)
	public String getQj() {
		return qj;
	}

	public void setQj(String qj) {
		this.qj = qj;
	}
	@Column(name = "LXZL", length = 20)
	public String getLxzl() {
		return lxzl;
	}

	public void setLxzl(String lxzl) {
		this.lxzl = lxzl;
	}
	
}