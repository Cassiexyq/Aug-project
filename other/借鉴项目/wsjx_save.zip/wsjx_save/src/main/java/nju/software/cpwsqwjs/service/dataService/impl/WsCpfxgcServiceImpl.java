package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.Map;

import nju.software.cpwsqwjs.data.dao.WsCpfxgcDao;
import nju.software.cpwsqwjs.data.dao.WsCpfxgcFlftDao;
import nju.software.cpwsqwjs.data.dao.WsCpfxgcLxqjDao;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcDO;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcFlftDO;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcLxqjDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.dynamicds.copy.DataSourceEnum;
import nju.software.cpwsqwjs.service.dataService.WsCpfxgcService;
import nju.software.cpwsqwjs.service.model.WscpfxgcFdlxModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcFtModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcModel;
import nju.software.cpwsqwjs.service.model.WscpfxgcZdlxModel;
import nju.software.cpwsqwjs.util.StringUtil;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class WsCpfxgcServiceImpl implements WsCpfxgcService {

	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");
	
	private static WsCpfxgcDao wsCpfxgcDao;
	private static WsCpfxgcFlftDao wsCpfxgcFlftDao;
	private static WsCpfxgcLxqjDao wsCpfxgcLxqjDao;
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsCpfxgcDao = (WsCpfxgcDao) appContext.getBean("wsCpfxgcDao");
		wsCpfxgcFlftDao = (WsCpfxgcFlftDao) appContext.getBean("wsCpfxgcFlftDao");
		wsCpfxgcLxqjDao = (WsCpfxgcLxqjDao) appContext.getBean("wsCpfxgcLxqjDao");
	}
	@Override
	public int saveCpfxgc(WscpfxgcModel wscpfxgcModel, int ajxh) {
		// TODO Auto-generated method stub
		WsCpfxgcDO cpfxgcDO = new WsCpfxgcDO(wscpfxgcModel);
		cpfxgcDO.setAjxh(ajxh);
		//���ɷ���
		if(wscpfxgcModel.getFtModellist()!=null && !wscpfxgcModel.getFtModellist().isEmpty()){
			int maxFtbh = wsCpfxgcFlftDao.getMaxFtbhByajxh(ajxh)+1;
			for(WscpfxgcFtModel ftModel : wscpfxgcModel.getFtModellist()){
				saveFlft(ftModel , ajxh , maxFtbh);
				maxFtbh++;
			}
		}
		//�����������
		if(wscpfxgcModel.getFdlxModel()!=null){
			int maxLxqjbh = wsCpfxgcLxqjDao.getMaxLxqjbhByAjxh(ajxh);
			for(WscpfxgcFdlxModel fdlx : wscpfxgcModel.getFdlxModel()){
				saveFdLxqj(fdlx , "��������" , ajxh , maxLxqjbh);
				maxLxqjbh++;
			}
		}
		//�ö��������
		if(wscpfxgcModel.getZdlxModel()!=null){
			int maxLxqjbh = wsCpfxgcLxqjDao.getMaxLxqjbhByAjxh(ajxh);
			for(WscpfxgcZdlxModel zdlx : wscpfxgcModel.getZdlxModel()){
				saveZdLxqj(zdlx , "�ö�����" , ajxh , maxLxqjbh);
				maxLxqjbh++;
			}
		}
		return wsCpfxgcDao.saveCpfxgcDO(cpfxgcDO);
	}

	@Override
	public void saveFlft(WscpfxgcFtModel model, int ajxh, int ftbh) {
		// TODO Auto-generated method stub
		if(model.getFlftmc()!=null && !model.getFlftmc().isEmpty()){
			WsCpfxgcFlftDO flftDO = new WsCpfxgcFlftDO();
			flftDO.setAjxh(ajxh);
			flftDO.setFtbh(ftbh);
			flftDO.setFtmc(model.getFlftmc());
			if(model.getFtMap()!=null && !model.getFtMap().isEmpty()){
				String tk = "";
				for(Map.Entry<String, String> entry : model.getFtMap().entrySet()){
					if(entry.getKey()!=null){
						//�����������
						if(entry.getValue()!=null){
							tk = tk + "��" + entry.getKey() + "��" + entry.getValue() + ";";
						}
						//ֻ����Ŀû�п�Ŀ
						else{
							tk = tk + "��" + entry.getKey() + "��;"; 
						}
					}
				}
				if(tk.endsWith(";")){
					tk = tk.substring(0,tk.length()-1);
				}
				if(!StringUtil.isBlank(tk)){
					flftDO.setTk(tk);
				}
			}
			wsCpfxgcFlftDao.saveFlft(flftDO);
		}


	}

	@Override
	public void saveFdLxqj(WscpfxgcFdlxModel fdlxModel, String lxlx, int ajxh,
			int lxqjBh) {
		// TODO Auto-generated method stub
		if(fdlxModel.getQj()!=null){
			WsCpfxgcLxqjDO lxqjDO = new WsCpfxgcLxqjDO();
			lxqjDO.setQj(fdlxModel.getQj());
			if(fdlxModel.getLxqjlb()!=null && !fdlxModel.getLxqjlb().isEmpty()){
				lxqjDO.setAjxh(ajxh);
				lxqjDO.setLxqjbh(lxqjBh);
				lxqjDO.setLxzl(lxlx);
				String lxqjzl = "";
				for(String str : fdlxModel.getLxqjlb()){
					lxqjzl = lxqjzl + str + ";";
				}
				if(lxqjzl.endsWith(";")){
					lxqjzl = lxqjzl.substring(0,lxqjzl.length()-1);
				}
				if(!StringUtil.isBlank(lxqjzl)){
					lxqjDO.setLxqjzl(lxqjzl);
				}
				if(fdlxModel.getXgr()!=null &&  !fdlxModel.getXgr().isEmpty()){
					String xgs_str = "";
					for(String xgr : fdlxModel.getXgr()){
						xgs_str = xgs_str+xgr+";";
					}
					if(xgs_str.endsWith(";")){
						xgs_str = xgs_str.substring(0, xgs_str.length()-1);
					}
					if(!StringUtil.isBlank(xgs_str)){
						lxqjDO.setXgr(xgs_str);
					}
				}
				wsCpfxgcLxqjDao.save(lxqjDO);
			}
			
		}
	}

	@Override
	public void saveZdLxqj(WscpfxgcZdlxModel zdlxModel, String lxlx, int ajxh,
			int lxqjBh) {
		// TODO Auto-generated method stub
		if(zdlxModel.getQj()!=null){
			WsCpfxgcLxqjDO lxqjDO = new WsCpfxgcLxqjDO();
			lxqjDO.setQj(zdlxModel.getQj());
			if(zdlxModel.getLxqjlb()!=null && !zdlxModel.getLxqjlb().isEmpty()){
				lxqjDO.setAjxh(ajxh);
				lxqjDO.setLxqjbh(lxqjBh);
				lxqjDO.setLxzl(lxlx);
				String lxqjzl = "";
				for(String str : zdlxModel.getLxqjlb()){
					lxqjzl = lxqjzl + str + ";";
				}
				if(lxqjzl.endsWith(";")){
					lxqjzl = lxqjzl.substring(0,lxqjzl.length()-1);
				}
				if(!StringUtil.isBlank(lxqjzl)){
					lxqjDO.setLxqjzl(lxqjzl);
				}
				if(zdlxModel.getXgr()!=null &&  !zdlxModel.getXgr().isEmpty()){
					String xgs_str = "";
					for(String xgr : zdlxModel.getXgr()){
						xgs_str = xgs_str+xgr+";";
					}
					if(xgs_str.endsWith(";")){
						xgs_str = xgs_str.substring(0, xgs_str.length()-1);
					}
					if(!StringUtil.isBlank(xgs_str)){
						lxqjDO.setXgr(xgs_str);
					}
				}
				wsCpfxgcLxqjDao.save(lxqjDO);
			}
			
		}
	}

	@Override
	public void saveCpfxgcBatch(WscpfxgcModel wscpfxgcModel, int ajxh) {
		// TODO Auto-generated method stub
		wsCpfxgcDao.save(ajxh,wscpfxgcModel);
	}

}
