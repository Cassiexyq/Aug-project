package nju.software.cpwsqwjs.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.handler.mseshandler.WsModelHandler;
import nju.software.cpwsqwjs.service.impl.sp.AjjbxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrdwxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrgrxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.DsrjgxxServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.TestDsrServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.TestWsServiceImpl;
import nju.software.cpwsqwjs.service.impl.sp.WsJbServiceImpl;
import nju.software.cpwsqwjs.service.model.ModelList;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;
import nju.software.cpwsqwjs.service.model.sp.ValidateModel;
import nju.software.cpwsqwjs.service.model.sp.WsJbModel;
import nju.software.cpwsqwjs.service.sp.Ajjbxxservice;
import nju.software.cpwsqwjs.service.sp.DsrdwxxService;
import nju.software.cpwsqwjs.service.sp.DsrgrxxService;
import nju.software.cpwsqwjs.service.sp.DsrjgxxService;
import nju.software.cpwsqwjs.service.sp.TestDsrService;
import nju.software.cpwsqwjs.service.sp.TestWsService;
import nju.software.cpwsqwjs.service.sp.WsJbService;
import nju.software.cpwsqwjs.util.FcUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.vo.JYResult;


/**
 * ������� ������������
 * 
 * 
 */
@Controller
@RequestMapping(value="/")
public class WsjxController {
	@Autowired
	private Ajjbxxservice ajjbxxservice ;
	@Autowired
	private WsJbService wsJbService;
	@Autowired
	private	DsrgrxxService dsrgrxxservice ;
	@Autowired
	private DsrdwxxService dsrdwxxservice ;
	@Autowired
	private DsrjgxxService dsrjgxxservice ;
	public void setAjjbxxservice(Ajjbxxservice ajjbxxservice) {
		this.ajjbxxservice = ajjbxxservice;
	}
	
	public void setWsJbService(WsJbService wsJbService) {
		this.wsJbService = wsJbService;
	}

	public void setDsrgrxxservice(DsrgrxxService dsrgrxxservice) {
		this.dsrgrxxservice = dsrgrxxservice;
	}

	public void setDsrdwxxservice(DsrdwxxService dsrdwxxservice) {
		this.dsrdwxxservice = dsrdwxxservice;
	}

	public void setDsrjgxxservice(DsrjgxxService dsrjgxxservice) {
		this.dsrjgxxservice = dsrjgxxservice;
	}

	public static String format(String qw){
		char[]ws=qw.toCharArray();		
		int index=0;
		for(int i=0;i<ws.length;i++){
			int temp=ws[i];
			if(temp==32){
				if(i-index>5){
					ws[i]=10;
				}
				index=i;
			}

		}
		return String.valueOf(ws);
	}
	public static String  getWsnr(String path,String filename){
		String wsnr="";
		ArrayList<String> content=new ArrayList<String>();
		ArrayList<String> wsnrlist=new ArrayList<String>();
		FileUtil fileUtil = new FileUtil();
		fileUtil.setS(path+"\\"+filename);
		content=fileUtil.readFromFile();
		for(int i=0;i<content.size();i++){
			ArrayList<String> str=(ArrayList<String>) FcUtil.getWholeToken(content.get(i));
			if(str.size()>0){
				wsnrlist.add(content.get(i));
			}
		}
		for(int i=0;i<wsnrlist.size()-1;i++){
			wsnr+=wsnrlist.get(i)+"\n";
		}
		wsnr+=wsnrlist.get(wsnrlist.size()-1);
		return wsnr;
	}
	public static String fileSelection(String path,String filename) throws Exception{
		String wsnr=null;
		String str = filename.substring(filename.lastIndexOf(".")+1);
		if(str.contains("txt")){
			wsnr=getWsnr(path,filename);
		}else if(str.contains("doc")||str.contains("docx")||str.contains("DOC")){
			wsnr=FileUtil.readDoc(path, filename);
		}else if(str.contains("RTF")||str.contains("rtf") ){
			wsnr=FileUtil.readRtf(path, filename);
		}else{
			System.out.println("�ļ���Ϊ��"+filename+"\n��Ч�ļ�");
		}
		return wsnr;
	}
	public static void main(String[] args) throws Exception {
		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());

		long ajxh = 45808;
		WsJbService wsJbService = new WsJbServiceImpl();
		Ajjbxxservice ajjbxxservice = new AjjbxxServiceImpl();
		DsrgrxxService dsrgrxxservice = new DsrgrxxServiceImpl();
		DsrdwxxService dsrdwxxservice = new DsrdwxxServiceImpl();
		DsrjgxxService dsrjgxxservice = new DsrjgxxServiceImpl();
		
		
		WsJbModel wsJbModel = wsJbService.getJaWsJbxxByAjxh(ajxh);
		AjjbxxModel ajjbxxModel = ajjbxxservice.getWsAjjbxxByAjxh(ajxh);
		List<DsrgrxxModel> dsrgrxxModellist = dsrgrxxservice.getDsrgrxxByAjxh(ajxh, ajjbxxModel);
		List<DsrdwxxModel> dsrdwxxModellist = dsrdwxxservice.getDsrdwxxByAjxh(ajxh, ajjbxxModel);
		List<DsrjgxxModel> dsrjgxxModellist = dsrjgxxservice.getDsrjgxxByAjxh(ajxh, ajjbxxModel);
		
		byte[] wsnr = wsJbModel.getWsnr();
		String wsmc = wsJbModel.getWswjm();
		String wsnrStr = POIUtil.getContent(wsnr, wsmc);
		System.out.println(wsnrStr);
		WsjxDispatcher wsjxDis = new WsjxDispatcher();
		WsAnalyse wsAnalyse = new WsAnalyse(wsmc,wsnrStr);
		WswsModel wswsModel=new WswsModel();
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		ModelList modellist = new ModelList();
		String ajlx = wswsModel.getAjlx();
		if(StringUtil.contains(ajlx, "���¶���")){
			modellist = wsjxDis.jxMses(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxMsys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxXzys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxXsys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "��������")){
			modellist = wsjxDis.jxXzes(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "���¶���")){
			modellist = wsjxDis.jxXses(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "��������")){
			modellist = wsjxDis.jxXzes(wsAnalyse,wsnrStr);
		}
		/**
		 * У�����ײ���
		 */
		TestWsService testWs = new TestWsServiceImpl();
		List<ValidateModel> vmodellist_ws = new ArrayList<ValidateModel>();		
		vmodellist_ws = testWs.testWs(modellist.getWswsModel(),ajjbxxModel,wsJbModel,vmodellist_ws);
		printwsResult(vmodellist_ws);
		
		/**
		 * У�鵱���˲���
		 */
		TestDsrService testDsr = new TestDsrServiceImpl();
		List<List<ValidateModel>> vmodellist_dsr = new ArrayList<List<ValidateModel>>();
		vmodellist_dsr = testDsr.testDsr(modellist.getWssscyrModellist(), dsrgrxxModellist, dsrdwxxModellist, dsrjgxxModellist, vmodellist_dsr);
		printdsrResult(vmodellist_dsr);
	}
	
	@RequestMapping(value="/jyxt/*")
	public String toJYXT() {
		return "jyxt";
	}
	
	@ResponseBody
	@RequestMapping(value="/getJYResult")
	public JYResult getJYResult(long ajxh) throws Exception {
		System.out.println(ajxh);
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());

//		WsJbService wsJbService = new WsJbServiceImpl();
//		Ajjbxxservice ajjbxxservice = new AjjbxxServiceImpl();
//		DsrgrxxService dsrgrxxservice = new DsrgrxxServiceImpl();
//		DsrdwxxService dsrdwxxservice = new DsrdwxxServiceImpl();
//		DsrjgxxService dsrjgxxservice = new DsrjgxxServiceImpl();
		
		
		WsJbModel wsJbModel = wsJbService.getJaWsJbxxByAjxh(ajxh);
		AjjbxxModel ajjbxxModel = ajjbxxservice.getWsAjjbxxByAjxh(ajxh);
		List<DsrgrxxModel> dsrgrxxModellist = dsrgrxxservice.getDsrgrxxByAjxh(ajxh, ajjbxxModel);
		List<DsrdwxxModel> dsrdwxxModellist = dsrdwxxservice.getDsrdwxxByAjxh(ajxh, ajjbxxModel);
		List<DsrjgxxModel> dsrjgxxModellist = dsrjgxxservice.getDsrjgxxByAjxh(ajxh, ajjbxxModel);
		
		byte[] wsnr = wsJbModel.getWsnr();
		String wsmc = wsJbModel.getWswjm();
		String wsnrStr = POIUtil.getContent(wsnr, wsmc);
		System.out.println(wsnrStr);
		WsjxDispatcher wsjxDis = new WsjxDispatcher();
		WsAnalyse wsAnalyse = new WsAnalyse(wsmc,wsnrStr);
		WswsModel wswsModel=new WswsModel();
		if(wsAnalyse.getWs()!=null){
			wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
		}
		ModelList modellist = new ModelList();
		String ajlx = wswsModel.getAjlx();
		if(StringUtil.contains(ajlx, "���¶���")){
			modellist = wsjxDis.jxMses(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxMsys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxXzys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "����һ��")){
			modellist = wsjxDis.jxXsys(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "��������")){
			modellist = wsjxDis.jxXzes(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "���¶���")){
			modellist = wsjxDis.jxXses(wsAnalyse,wsnrStr);
		}else if(StringUtil.contains(ajlx, "��������")){
			modellist = wsjxDis.jxXzes(wsAnalyse,wsnrStr);
		}
		/**
		 * У�����ײ���
		 */
		TestWsService testWs = new TestWsServiceImpl();
		List<ValidateModel> vmodellist_ws = new ArrayList<ValidateModel>();		
		vmodellist_ws = testWs.testWs(modellist.getWswsModel(),ajjbxxModel,wsJbModel,vmodellist_ws);
		printwsResult(vmodellist_ws);
		
		/**
		 * У�鵱���˲���
		 */
		TestDsrService testDsr = new TestDsrServiceImpl();
		List<List<ValidateModel>> vmodellist_dsr = new ArrayList<List<ValidateModel>>();
		vmodellist_dsr = testDsr.testDsr(modellist.getWssscyrModellist(), dsrgrxxModellist, dsrdwxxModellist, dsrjgxxModellist, vmodellist_dsr);
		printdsrResult(vmodellist_dsr);
		
		JYResult result = new JYResult();
		result.setWsResult(vmodellist_ws);
		result.setDsrResult(vmodellist_dsr);
		return result;
	}
	
	public static void printwsResult(List<ValidateModel> vmodellist)
	{
		System.out.println("�ڵ�����\t\t�����������\t\t���ݿ���ȡ����\t\tУ����");
		for(int i = 0; i<vmodellist.size(); i++)
		{
			ValidateModel vmodel = vmodellist.get(i);
			System.out.println(vmodel.getJdmc()+"\t\t"+vmodel.getData_jx()+"\t\t"+vmodel.getData_db()+"\t\t"+vmodel.getJyjg());
		}
	}
	
	public static void printdsrResult(List<List<ValidateModel>> vmodellist_dsr)
	{
		System.out.println(vmodellist_dsr.size());
		for (int j = 0; j < vmodellist_dsr.size(); j++)
		{
			List<ValidateModel> vmodellist = vmodellist_dsr.get(j);
			System.out.println("�����ˡ�" + vmodellist.get(0).getData_jx() + "����У������");
			System.out.println("�ڵ�����\t\t�����������\t\t���ݿ���ȡ����\t\tУ����");
			for(int i = 0; i<vmodellist.size(); i++)
			{
				ValidateModel vmodel = vmodellist.get(i);
				System.out.println(vmodel.getJdmc()+"\t\t"+vmodel.getData_jx()+"\t\t"+vmodel.getData_db()+"\t\t"+vmodel.getJyjg());
			}
		}
		
	}
}