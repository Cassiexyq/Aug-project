/**
 * 2014-5-17 15��05
 */
package nju.software.cpwsqwjs.service.model.sp;

/**
 * @author ruanhao
 *
 */
public class DsrgrxxModel {
	long ajxh;
	long dsrbh;
	String grlb;
	
	String dsrssdw;//���ϵ�λ
	String dsrlb;
	String sfssdbr;
	String dsrjc;
	String hpje;
	String qqpcje;
	
	String xm;//����
	String xb;//�Ա�
	String csnyr;//����������
	String mz;//����
	String whcd;//�Ļ��̶�
	String ssgj;//��������
	String jb;
	String zzmm;//������ò
	String sf;
	String jg;
	String zjlb;//֤�����
	String sfzhm;//����֤����
	String yb;
	String dh;
	String zwzy;
	String gzdw;
	String dz;//��ַ
	String zzd;
	public long getAjxh() {
		return ajxh;
	}
	public void setAjxh(long ajxh) {
		this.ajxh = ajxh;
	}
	public long getDsrbh() {
		return dsrbh;
	}
	public void setDsrbh(long dsrbh) {
		this.dsrbh = dsrbh;
	}
	public String getDsrssdw() {
		return dsrssdw;
	}
	public void setDsrssdw(String dsrssdw) {
		this.dsrssdw = dsrssdw;
	}
	public String getDsrlb() {
		return dsrlb;
	}
	public void setDsrlb(String dsrlb) {
		this.dsrlb = dsrlb;
	}
	public String getSfssdbr() {
		return sfssdbr;
	}
	public void setSfssdbr(String sfssdbr) {
		this.sfssdbr = sfssdbr;
	}
	public String getDsrjc() {
		return dsrjc;
	}
	public void setDsrjc(String dsrjc) {
		this.dsrjc = dsrjc;
	}
	public String getXm() {
		return xm;
	}
	public void setXm(String xm) {
		this.xm = xm;
	}
	public String getXb() {
		return xb;
	}
	public void setXb(String xb) {
		this.xb = xb;
	}
	public String getCsnyr() {
		return csnyr;
	}
	public void setCsnyr(String csnyr) {
		this.csnyr = csnyr;
	}
	public String getMz() {
		return mz;
	}
	public void setMz(String mz) {
		this.mz = mz;
	}
	public String getSsgj() {
		return ssgj;
	}
	public void setSsgj(String ssgj) {
		this.ssgj = ssgj;
	}
	public String getZjlb() {
		return zjlb;
	}
	public void setZjlb(String zjlb) {
		this.zjlb = zjlb;
	}
	public String getSfzhm() {
		return sfzhm;
	}
	public void setSfzhm(String sfzhm) {
		this.sfzhm = sfzhm;
	}
	public String getYb() {
		return yb;
	}
	public void setYb(String yb) {
		this.yb = yb;
	}
	public String getDh() {
		return dh;
	}
	public void setDh(String dh) {
		this.dh = dh;
	}
	public String getZwzy() {
		return zwzy;
	}
	public void setZwzy(String zwzy) {
		this.zwzy = zwzy;
	}
	public String getGzdw() {
		return gzdw;
	}
	public void setGzdw(String gzdw) {
		this.gzdw = gzdw;
	}
	public String getDz() {
		return dz;
	}
	public void setDz(String dz) {
		this.dz = dz;
	}
	public String getZzd() {
		return zzd;
	}
	public void setZzd(String zzd) {
		this.zzd = zzd;
	}
	public String getGrlb() {
		return grlb;
	}
	public void setGrlb(String grlb) {
		this.grlb = grlb;
	}
	public String getHpje() {
		return hpje;
	}
	public void setHpje(String hpje) {
		this.hpje = hpje;
	}
	public String getQqpcje() {
		return qqpcje;
	}
	public void setQqpcje(String qqpcje) {
		this.qqpcje = qqpcje;
	}
	public String getWhcd() {
		return whcd;
	}
	public void setWhcd(String whcd) {
		this.whcd = whcd;
	}
	public String getJb() {
		return jb;
	}
	public void setJb(String jb) {
		this.jb = jb;
	}
	public String getZzmm() {
		return zzmm;
	}
	public void setZzmm(String zzmm) {
		this.zzmm = zzmm;
	}
	public String getSf() {
		return sf;
	}
	public void setSf(String sf) {
		this.sf = sf;
	}
	public String getJg() {
		return jg;
	}
	public void setJg(String jg) {
		this.jg = jg;
	}
	
	
}
