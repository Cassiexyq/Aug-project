package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkmsxzDO;

public interface WsAjjbqkmsxzDao {
    public WsAjjbqkmsxzDO getWsAjjbqkmsxzByAjxh(int ajxh);

    public void save(WsAjjbqkmsxzDO wsAjjbqkmsxzDO);
}
