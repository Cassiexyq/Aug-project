package nju.software.cpwsqwjs.data.dao.impl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.WsCpfxgcFlftDao;
import nju.software.cpwsqwjs.data.dataobject.WsCpfxgcFlftDO;

public class WsCpfxgcFlftDaoImpl extends HibernateDaoSupport implements WsCpfxgcFlftDao{

	@Override
	public int getMaxFtbhByajxh(int ajxh) {
		// TODO Auto-generated method stub
		String hql = "select max(ftbh) from WsCpfxgcFlftDO where ajxh="+ajxh;
		Session s = this.getSession();
		Query query = s.createQuery(hql);
		
		int maxbh = 0;
		if(query.uniqueResult()!=null){
			maxbh = (int) query.uniqueResult();
		}
		this.releaseSession(s);
		return maxbh;
	}

	@Override
	public int saveFlft(WsCpfxgcFlftDO flftDO) {
		// TODO Auto-generated method stub
		try{
			getHibernateTemplate().saveOrUpdate(flftDO);
			return flftDO.getFtbh();	
		}catch(RuntimeException re){
			throw re;
		}
	}

}
