package nju.software.cpwsqwjs.handler.xseshandler;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import nju.software.cpwsqwjs.service.model.WsxszjdModel;
public class XsesZjdModelHandler {
	public List<WsxszjdModel> jxWsxszjdModel(List<String> bssldlist) {
		List<WsxszjdModel> wsxszjdmodellist=new ArrayList<WsxszjdModel>();
		int[] bssldindex=new int[bssldlist.size()];
		List<Integer> zjfzindex=new ArrayList<Integer>();
		for(int i=0;i<bssldlist.size();i++){
			String ajnr=bssldlist.get(i);
			String temp=ajnr;
			if(ajnr.length()>30)
				temp=ajnr.substring(0,30);
			if(likeZjd(temp)&&(issurplus(temp)==-1)){
				bssldindex[i]=-1;
			}else if(issurplus(temp)>-1){
				bssldindex[i]=issurplus(temp);
			}
		}
		boolean isZjfzpre=true;
		for(int i=0;i<bssldlist.size();i++){
			if(bssldindex[i]>0){
				int tmp=bssldindex[i];
				int tmppre=i;
				int tmpend=i;
				int newtmp=i;
				for(int j=i+1;j<bssldlist.size();j++){
					if(bssldindex[j]<tmp&&bssldindex[j]>0){
						newtmp=j;
						break;
					}
					else if(bssldindex[j]>tmp){
						tmp=bssldindex[j];
						tmpend=j;
					}
				}
				int id=bssldindex[tmppre];
				for(int j=tmppre;j<tmpend;j++){
					if(bssldindex[j]>0)
						id=bssldindex[j];
					else if(bssldindex[j]<=0)
						bssldindex[j]=id;
				}
				i=newtmp;
			}
		}
		for(int i=0;i<bssldlist.size();i++){
			if(bssldindex[i]==0){
				if(isZjfzpre){
					zjfzindex.add(i);
					isZjfzpre=false;
				}
			}else {
				isZjfzpre=true;
			}
		}
		zjfzindex.add(bssldlist.size()-1);
		for(int i=0;i<zjfzindex.size()-1;i++){
			WsxszjdModel zjdmodel=new WsxszjdModel();
			String rdss="";
			List<String> zjjl=new ArrayList<String>();
			String zjjltemp="";
			int temp=0;
			int zjjlpre=0;
			for(int j=zjfzindex.get(i);j<zjfzindex.get(i+1);j++){
				if(bssldindex[j]==0)
					rdss+=bssldlist.get(j)+" ";
				else break;
			}
			for(int j=zjfzindex.get(i);j<zjfzindex.get(i+1);j++){
				if(bssldindex[j]!=0){
					temp=bssldindex[j];
					zjjlpre=j;
					zjjltemp=bssldlist.get(j);
					break;
				}
			}		
			for(int j=zjjlpre+1;j<zjfzindex.get(i+1);j++){
				if(bssldindex[j]!=temp){
					zjjl.add(zjjltemp);
					zjjltemp=bssldlist.get(j);
					temp=bssldindex[j];
				}else{
					zjjltemp+=bssldlist.get(j)+" ";
				}				
			}
			zjjl.add(zjjltemp);
			zjdmodel.setRdss(rdss);
			zjdmodel.setZjjl(zjjl);
			wsxszjdmodellist.add(zjdmodel);
		}
		return wsxszjdmodellist;
	}
	public boolean likeZjd(String content){
		boolean b=false;
		if(content.contains("֤��")||content.contains("֤��")||content.contains("��֤")
				||content.contains("֤��")||content.contains("֤ʵ")||content.contains("֤��")
				||content.contains("��֤")||content.contains("��֤")){
			b=true;
		}
		return b;
	}
	public boolean isZjd(String content){
		boolean b=false;
		if(content.contains("��ͥ����֤")||content.contains("�������")||content.contains("���Բ���")
				||content.contains("����֤��")||content.contains("��ͥ��֤")||content.contains("���Բ���")
				||content.contains("�ھ�Ϊƾ")||content.contains("������֤"))
			b=true;
		if(content.length()>=50)
			content=content.substring(0,50);
		if(content.contains("֤��:")||content.contains("֤�ݣ�")||content.contains("֤�����£�")
				||content.contains("֤������:")
				){
			b=true;
		}
		return b;
	}
	public static boolean isFzsurplus(String content){
		boolean b=false;
		String rexNu="[һ�����������߰˾�ʮ]";
		Pattern patternNu=Pattern.compile(rexNu);
		if(content.length()>=3)
			content=content.substring(0,3);
		Matcher matcherNu=patternNu.matcher(content);
		if(matcherNu.find()&&(content.contains(".")||content.contains("��")||content.contains("��")||
				content.contains("("))){
			b=true;
		}
		return b;
	}
	public static int issurplus(String content){
		int b=-1;
		String rexNu="\\d{1,2}";
		Pattern patternNu=Pattern.compile(rexNu);
		if(content.length()>=3)
			content=content.substring(0,3);
		Matcher matcherNu=patternNu.matcher(content);
		if(matcherNu.find()&&(content.contains(".")||content.contains("��")||content.contains("��"))){
			b=Integer.parseInt(matcherNu.group(0));
		}
		return b;
	}	
}
