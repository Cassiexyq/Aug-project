package nju.software.cpwsqwjs.service.dataService.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import nju.software.cpwsqwjs.data.dao.WsSpzzcyDao;
import nju.software.cpwsqwjs.data.dao.WsXspjjgfjxDao;
import nju.software.cpwsqwjs.data.dao.WsXspjjgfzDao;
import nju.software.cpwsqwjs.data.dao.WsXspjjgpfDao;
import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDO;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.service.dataService.WsSpzzcyService;
import nju.software.cpwsqwjs.service.model.WswwModel;

public class WsSpzzcyServiceImpl implements WsSpzzcyService{
	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static WsSpzzcyDao wsSpzzcyDao;
	static {
//		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		wsSpzzcyDao = (WsSpzzcyDao) appContext.getBean("wsSpzzcyDao");
	}
	
	
	@Override
	public void saveWwmodel(WswwModel model,int ajxh) {
		// TODO Auto-generated method stub
		if(model.getSpzzcyMap()!=null){
			 Map<String, String> spzzcyMap = model.getSpzzcyMap();
			 int cybh=1;
			 for(Map.Entry<String, String> entry:spzzcyMap.entrySet()){
				 WsSpzzcyDO spzzcyDO = new WsSpzzcyDO();
				 if(entry.getKey()!=null){
					 spzzcyDO.setXm(entry.getKey());
				 }
				 if(entry.getValue()!=null){
					 spzzcyDO.setSf(entry.getValue());
				 }
				 spzzcyDO.setAjxh(ajxh);
				 spzzcyDO.setCybh(cybh);
				 cybh= cybh+1;
				 wsSpzzcyDao.save(spzzcyDO);
			 }
		}
	}

}
