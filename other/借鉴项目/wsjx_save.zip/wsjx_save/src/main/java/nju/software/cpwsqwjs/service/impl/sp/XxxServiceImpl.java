package nju.software.cpwsqwjs.service.impl.sp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.XxxglDao;
import nju.software.cpwsqwjs.data.dataobject.DmbDO;
import nju.software.cpwsqwjs.data.dataobject.XxxglDO;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.DmUtil;
import nju.software.cpwsqwjs.util.StringUtil;
import nju.software.cpwsqwjs.util.XzajUtil;
@Service
public class XxxServiceImpl implements XxxService{
	private   DmbDao dmbDao;
	private   XxxglDao xxxglDao;
	
//	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
//			"applicationContext.xml", "applicationContextDataSource.xml");
//
//	private static DmbDao dmbDao;
//	private static XxxglDao xxxglDao;
//	static {
//		dmbDao = (DmbDao) appContext.getBean("dmbDao");
//		xxxglDao = (XxxglDao) appContext.getBean("xxxglDao");
//	}
	
	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}
	public void setXxxglDao(XxxglDao xxxglDao) {
		this.xxxglDao = xxxglDao;
	}
	@Override
	public String getLbbhNew(String xxxjc, String szb,AjjbxxModel ajModel) {
		// TODO Auto-generated method stub
		String ajxz = StringUtil.trim(ajModel.getAjxz());
		String spcx = StringUtil.trim(ajModel.getSpcx());
		String spcxdz = StringUtil.trim(ajModel.getSpcxdz());
		String spcxlbbh = "";
		if (ajxz != null) {
			spcxlbbh = DmUtil.getSpcxLbbhByAjxz(ajxz); 
		}
		String lbbhxgdm = ajxz+spcx+spcxdz;
		DmbDO spcxDm = dmbDao.findById(spcxlbbh, spcx); 
		if(!(spcxDm.getXgdm2()!=null && !StringUtil.isBlank(spcxDm.getXgdm2()))){//������С��
			lbbhxgdm = ajxz+spcx+"0";
		}
		XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao(xxxjc, szb);
		String sjxx = xxx.getSjxx2016();
		sjxx = XzajUtil.getLbbhNew(sjxx, lbbhxgdm);
		
		return sjxx;
	}
	@Override
	public String getLbbhOld(String xxxjc, String szb, AjjbxxModel ajModel) {
		// TODO Auto-generated method stub
		String ajxz = StringUtil.trim(ajModel.getAjxz());
		String spcx = StringUtil.trim(ajModel.getSpcx());
		if (ajxz.startsWith("0")) {
			ajxz = ajxz.substring(1);
		}
		if (spcx.startsWith("0")) {
			spcx = spcx.substring(1);
		}
		XxxglDO xxx = xxxglDao.getXxxByXxxmcAndDao(xxxjc, szb);
		String lbbh = xxx.getSjxx();
		if (xxx.getSjxx().contains(",")) {
			lbbh = XzajUtil.getLbbhByColumn(ajxz, spcx,lbbh);
		}
		return lbbh;
	}

}
