package nju.software.cpwsqwjs.data.dao;

import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDO;
import nju.software.cpwsqwjs.data.dataobject.WsSpzzcyDOId;

public interface WsSpzzcyDao {
	
	public void save(WsSpzzcyDO spzzcy);

	public WsSpzzcyDO findByID(WsSpzzcyDOId id);
	
	public List<WsSpzzcyDO> findByAjxh(int ajxh);
}
