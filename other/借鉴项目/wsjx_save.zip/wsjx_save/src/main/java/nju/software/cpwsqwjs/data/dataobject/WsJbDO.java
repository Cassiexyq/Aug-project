package nju.software.cpwsqwjs.data.dataobject;

import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;


/**
 * WsJbVO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name="PUB_WS_JB")
@IdClass(WsJbDOId.class)
public class WsJbDO  implements java.io.Serializable {


    // Fields    

     private Integer ajxh;
     private Integer wsjbbh;
    
     private String wslb;
     private String wsmc;
     private String zfj;
     private Integer wslbbh;
     private Integer wsbh;
     private Integer wsys;
     private String wsjj;
     private String zzh;
     private Date scrq;
     private String wswjm;
     private String wsah;
     private String wszt;
     private byte[] wsnr;
     private String sjjzFlag;
     private String wsurl;
     private String sfjaws;
     private String ymclurl;
     private String thyy;


    // Constructors

    /** default constructor */
    public WsJbDO() {
    }

	/** minimal constructor */
    public WsJbDO(Integer ajxh, Integer wsjbbh) {
        this.ajxh = ajxh;
        this.wsjbbh = wsjbbh;
    }
    
    /** full constructor */
    public WsJbDO(Integer ajxh, Integer wsjbbh, String wslb, String wsmc, String zfj, Integer wslbbh, Integer wsbh, Integer wsys, String wsjj, String zzh, Date scrq, String wswjm, String wsah, String wszt, byte[] wsnr, String sjjzFlag,String sfjaws,String ymclurl) {
        this.ajxh = ajxh;
        this.wsjbbh = wsjbbh;
        this.wslb = wslb;
        this.wsmc = wsmc;
        this.zfj = zfj;
        this.wslbbh = wslbbh;
        this.wsbh = wsbh;
        this.wsys = wsys;
        this.wsjj = wsjj;
        this.zzh = zzh;
        this.scrq = scrq;
        this.wswjm = wswjm;
        this.wsah = wsah;
        this.wszt = wszt;
        this.wsnr = wsnr;
        this.sjjzFlag = sjjzFlag;
        this.sfjaws = sfjaws;
        this.ymclurl = ymclurl;
    }
    public WsJbDO(Integer ajxh, Integer wsjbbh, String wslb, String wsmc, String zfj, Integer wslbbh, Integer wsbh, Integer wsys, String wsjj, String zzh, Date scrq, String wswjm, String wsah, String wszt, byte[] wsnr) {
        this.ajxh = ajxh;
        this.wsjbbh = wsjbbh;
        this.wslb = wslb;
        this.wsmc = wsmc;
        this.zfj = zfj;
        this.wslbbh = wslbbh;
        this.wsbh = wsbh;
        this.wsys = wsys;
        this.wsjj = wsjj;
        this.zzh = zzh;
        this.scrq = scrq;
        this.wswjm = wswjm;
        this.wsah = wsah;
        this.wszt = wszt;
        this.wsnr = wsnr;
    }
   
    // Property accessors
    @Id
    @Column(name="AJXH", nullable=false)
    public Integer getAjxh() {
        return this.ajxh;
    }
    
    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Id
    @Column(name="WSJBBH", nullable=false)

    public Integer getWsjbbh() {
        return this.wsjbbh;
    }
    
    public void setWsjbbh(Integer wsjbbh) {
        this.wsjbbh = wsjbbh;
    }
    
    @Column(name="WSLB", length=50)

    public String getWslb() {
        return this.wslb;
    }
    
    public void setWslb(String wslb) {
        this.wslb = wslb;
    }
    
    @Column(name="WSMC")

    public String getWsmc() {
        return this.wsmc;
    }
    
    public void setWsmc(String wsmc) {
        this.wsmc = wsmc;
    }
    
    @Column(name="ZFJ", length=10)

    public String getZfj() {
        return this.zfj;
    }
    
    public void setZfj(String zfj) {
        this.zfj = zfj;
    }
    
    @Column(name="WSLBBH")

    public Integer getWslbbh() {
        return this.wslbbh;
    }
    
    public void setWslbbh(Integer wslbbh) {
        this.wslbbh = wslbbh;
    }
    
    @Column(name="WSBH")

    public Integer getWsbh() {
        return this.wsbh;
    }
    
    public void setWsbh(Integer wsbh) {
        this.wsbh = wsbh;
    }
    
    @Column(name="WSYS")

    public Integer getWsys() {
        return this.wsys;
    }
    
    public void setWsys(Integer wsys) {
        this.wsys = wsys;
    }
    
    @Column(name="WSJJ", length=250)

    public String getWsjj() {
        return this.wsjj;
    }
    
    public void setWsjj(String wsjj) {
        this.wsjj = wsjj;
    }
    
    @Column(name="ZZH", length=50)

    public String getZzh() {
        return this.zzh;
    }
    
    public void setZzh(String zzh) {
        this.zzh = zzh;
    }
    
    @Column(name="SCRQ", length=23)

    public Date getScrq() {
        return this.scrq;
    }
    
    public void setScrq(Date scrq) {
        this.scrq = scrq;
    }
    
    @Column(name="WSWJM")

    public String getWswjm() {
        return this.wswjm;
    }
    
    public void setWswjm(String wswjm) {
        this.wswjm = wswjm;
    }
    
    @Column(name="WSAH")

    public String getWsah() {
        return this.wsah;
    }
    
    public void setWsah(String wsah) {
        this.wsah = wsah;
    }
    
    @Column(name="WSZT", length=1)

    public String getWszt() {
        return this.wszt;
    }
    
    public void setWszt(String wszt) {
        this.wszt = wszt;
    }
    
    @Column(name="WSNR")

    public byte[] getWsnr() {
        return this.wsnr;
    }
    
    public void setWsnr(byte[] wsnr) {
        this.wsnr = wsnr;
    }
    
    @Column(name="SJJZ_FLAG", length=1)

    public String getSjjzFlag() {
        return this.sjjzFlag;
    }
    
    public void setSjjzFlag(String sjjzFlag) {
        this.sjjzFlag = sjjzFlag;
    }

    @Column(name="WSURL", length=100)
	public String getWsurl() {
		return wsurl;
	}

	public void setWsurl(String wsurl) {
		this.wsurl = wsurl;
	}

	@Column(name="SFJAWS", length=2)
	public String getSfjaws() {
		return sfjaws;
	}

	public void setSfjaws(String sfjaws) {
		this.sfjaws = sfjaws;
	}

	@Column(name="YMCLURL", length=200)
	public String getYmclurl() {
		return ymclurl;
	}

	public void setYmclurl(String ymclurl) {
		this.ymclurl = ymclurl;
	}
	@Column(name="THYY", length=100)
	public String getThyy() {
		return thyy;
	}

	public void setThyy(String thyy) {
		this.thyy = thyy;
	}







}