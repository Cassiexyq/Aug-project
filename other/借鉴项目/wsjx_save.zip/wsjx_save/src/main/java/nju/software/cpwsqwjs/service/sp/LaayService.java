package nju.software.cpwsqwjs.service.sp;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.LaayModel;


public interface LaayService {
	
	public List<LaayModel> getLaayByAjxh(long ajxh);

}
