/**
 * 2014-5-18
 */
package nju.software.cpwsqwjs.service.impl.sp;

import java.util.List;

import nju.software.cpwsqwjs.data.dao.DmbDao;
import nju.software.cpwsqwjs.data.dao.DsrJbDao;
import nju.software.cpwsqwjs.data.dao.DsrMspcFjxxDao;
import nju.software.cpwsqwjs.data.dao.DsrXpJgDao;
import nju.software.cpwsqwjs.data.dataobject.DsrJbDO;
import nju.software.cpwsqwjs.data.dataobject.DsrMspcFjxxDO;
import nju.software.cpwsqwjs.data.dataobject.DsrXpJgDO;
import nju.software.cpwsqwjs.data.dataobject.DsrXpJgDOId;
import nju.software.cpwsqwjs.service.dataConvertor.DsrConvertor;
import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;
import nju.software.cpwsqwjs.service.sp.DsrjgxxService;
import nju.software.cpwsqwjs.service.sp.XxxService;
import nju.software.cpwsqwjs.util.StringUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
@Service
public class DsrjgxxServiceImpl implements DsrjgxxService {
	private   DsrXpJgDao dsrXpJgDao;
	private   DsrJbDao dsrJbDao;
	private   DsrMspcFjxxDao dsrMspcFjxxDao;
	private   XxxService xxxSerrvice;
	private   DmbDao dmbDao;
	
	/*private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
			"applicationContext.xml", "applicationContextDataSource.xml");

	private static DsrXpJgDao dsrXpJgDao;
	private static DsrJbDao dsrJbDao;
	private static DsrMspcFjxxDao dsrMspcFjxxDao;
	private static XxxService xxxSerrvice;
	private static DmbDao dmbDao;
	static {
		dsrXpJgDao = (DsrXpJgDao) appContext.getBean("dsrXpJgDao");
		dsrJbDao = (DsrJbDao) appContext.getBean("dsrJbDao");
		dsrMspcFjxxDao = (DsrMspcFjxxDao) appContext.getBean("dsrMspcFjxxDao");
		xxxSerrvice = new XxxServiceImpl();
		dmbDao = (DmbDao) appContext.getBean("dmbDao");
	}*/

	public void setDsrXpJgDao(DsrXpJgDao dsrXpJgDao) {
		this.dsrXpJgDao = dsrXpJgDao;
	}

	public void setDsrJbDao(DsrJbDao dsrJbDao) {
		this.dsrJbDao = dsrJbDao;
	}

	public void setDsrMspcFjxxDao(DsrMspcFjxxDao dsrMspcFjxxDao) {
		this.dsrMspcFjxxDao = dsrMspcFjxxDao;
	}

	public void setXxxSerrvice(XxxService xxxSerrvice) {
		this.xxxSerrvice = xxxSerrvice;
	}

	public void setDmbDao(DmbDao dmbDao) {
		this.dmbDao = dmbDao;
	}

	public List<DsrjgxxModel> getDsrjgxxByAjxh(long ajxh,AjjbxxModel aj) {
		// TODO Auto-generated method stub
		List<DsrXpJgDO> dsrJgDOs = dsrXpJgDao.findByProperty("ajxh", (int)ajxh);
		List<DsrJbDO> dsrJbDOs = dsrJbDao.findByProperty("ajxh", (int)ajxh);
		List<DsrMspcFjxxDO> dsrMspcFjxxDOs = dsrMspcFjxxDao.findByProperty("ajxh", (int)ajxh);
		List<DsrjgxxModel> dsrjgModels = DsrConvertor.dsrjgDoListToModelList(dsrJgDOs, dsrJbDOs, dsrMspcFjxxDOs,dmbDao,xxxSerrvice,aj);
		return dsrjgModels;
	}

	@Override
	public boolean updateDsrdw(long ajxh, int dsrbh, String zd, String zdz) {
		// TODO Auto-generated method stub
		DsrXpJgDOId id = new DsrXpJgDOId((int)ajxh, dsrbh);
		DsrXpJgDO dsr = dsrXpJgDao.findById(id);
		if(dsr==null)
			return false;
		if(StringUtil.equals(zd, "DZ")){
			dsr.setDz(zdz);
			dsrXpJgDao.save(dsr);
			return true;
		}
		if(StringUtil.equals(zd, "FDDBRXM")){
			dsr.setFddbrxm(zdz);
			dsrXpJgDao.save(dsr);
			return true;
		}
		return false;
	}

}
