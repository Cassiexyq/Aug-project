package nju.software.cpwsqwjs.service.model;

import java.util.List;

import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;

public class ModelList {
	private WswsModel wswsModel;
	private List<WssscyrModel> wssscyrModellist;
	private WsssjlModel wsssjlModel;
	private WsajjbqkModel wsajjbqkModel;
	private List<WsxszjdModel> wsxszjdModellist;
	private WscpfxgcModel wscpfxgcModel;
	private XsPjjgModel wsxspjjgModel;
	private WscpjgModel wscpjgModel;
	private WswwModel wswwModel;
	private WsfjModel wsflModel;
	public WswsModel getWswsModel() {
		return wswsModel;
	}
	public void setWswsModel(WswsModel wswsModel) {
		this.wswsModel = wswsModel;
	}

	public List<WssscyrModel> getWssscyrModellist() {
		return wssscyrModellist;
	}
	public void setWssscyrModellist(List<WssscyrModel> wssscyrModellist) {
		this.wssscyrModellist = wssscyrModellist;
	}
	public WsssjlModel getWsssjlModel() {
		return wsssjlModel;
	}
	public void setWsssjlModel(WsssjlModel wsssjlModel) {
		this.wsssjlModel = wsssjlModel;
	}
	public WsajjbqkModel getWsajjbqkModel() {
		return wsajjbqkModel;
	}
	public void setWsajjbqkModel(WsajjbqkModel wsajjbqkModel) {
		this.wsajjbqkModel = wsajjbqkModel;
	}
	public WscpfxgcModel getWscpfxgcModel() {
		return wscpfxgcModel;
	}
	public void setWscpfxgcModel(WscpfxgcModel wscpfxgcModel) {
		this.wscpfxgcModel = wscpfxgcModel;
	}
	public WscpjgModel getWscpjgModel() {
		return wscpjgModel;
	}
	public void setWscpjgModel(WscpjgModel wscpjgModel) {
		this.wscpjgModel = wscpjgModel;
	}
	public WswwModel getWswwModel() {
		return wswwModel;
	}
	public void setWswwModel(WswwModel wswwModel) {
		this.wswwModel = wswwModel;
	}
	public WsfjModel getWsflModel() {
		return wsflModel;
	}
	public void setWsflModel(WsfjModel wsflModel) {
		this.wsflModel = wsflModel;
	}
	public XsPjjgModel getWsxspjjgModel() {
		return wsxspjjgModel;
	}
	public void setWsxspjjgModel(XsPjjgModel wsxspjjgModel) {
		this.wsxspjjgModel = wsxspjjgModel;
	}
	public List<WsxszjdModel> getWsxszjdModellist() {
		return wsxszjdModellist;
	}
	public void setWsxszjdModellist(List<WsxszjdModel> wsxszjdModellist) {
		this.wsxszjdModellist = wsxszjdModellist;
	}

	
}
