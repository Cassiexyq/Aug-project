package nju.software.cpwsqwjs.service.sp;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.SpryxxModel;

public interface SpryService {

	public List<SpryxxModel> getSpryxxByAjxh(long ajxh);
}
