package nju.software.cpwsqwjs.service.sp;

import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;

public interface XxxService {

//	public String getXxx(String String lbbh);
	public String getLbbhNew(String xxxjc,String szb,AjjbxxModel ajModel);
	
	public String getLbbhOld(String xxxjc,String szb,AjjbxxModel ajModel);
}
