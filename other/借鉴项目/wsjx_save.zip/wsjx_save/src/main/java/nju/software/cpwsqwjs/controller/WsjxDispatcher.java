package nju.software.cpwsqwjs.controller;
import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.handler.mseshandler.*;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSSscyrModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MSYSSsjlModelHandler;
import nju.software.cpwsqwjs.handler.msyshandler.MsysAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XSESCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XSESSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XsesAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XsesPjjgHandler;
import nju.software.cpwsqwjs.handler.xseshandler.XsesZjdModelHandler;
import nju.software.cpwsqwjs.handler.xsyshandler.*;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESSscyrModelHandler;
import nju.software.cpwsqwjs.handler.xzeshandler.XZESSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xzeshandler.XzesAjjbqkModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSCpfxgcModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSscyrModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XZYSSsjlModelHandler;
import nju.software.cpwsqwjs.handler.xzyshandler.XzysAjjbqkModelHandler;
import nju.software.cpwsqwjs.service.model.*;
import nju.software.cpwsqwjs.service.model.xs.XsPjjgModel;
import nju.software.cpwsqwjs.util.AjlxEnum;


import org.jdom.JDOMException;

import java.io.IOException;
import java.util.List;
public class WsjxDispatcher {

	private XsesPjjgHandler xsesPjjgHandler;

	/**
	 * �������¶�������
	 */
	public  ModelList jxMses(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{

		ModelList modellist = new ModelList();

		if(wsAnalyse.getWs()!=null)
		{
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);		
		}

		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new SscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getSsjl());
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new SsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new CpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			WscpjgModel wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,modellist.getWssscyrModellist(),AjlxEnum.MSES);
			modellist.setWscpjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk()!=null)
		{
			WsajjbqkModel wsajjbqkModel = new AjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		return modellist;
	}

	/**
	 * ��������һ������
	 */
	public  ModelList jxMsys(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{

		ModelList modellist = new ModelList();

		if(wsAnalyse.getWs()!=null)
		{
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);		
		}

		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new MSYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getSsjl(),wsnr,wsAnalyse);
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new MSYSSsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new MSYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			WscpjgModel wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,modellist.getWssscyrModellist(),AjlxEnum.MSYS);
			modellist.setWscpjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk()!=null)
		{
			WsajjbqkModel wsajjbqkModel = new MsysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk(),modellist.getWssscyrModellist());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		return modellist;
	}

	/**
	 * ��������һ������
	 */
	public  ModelList jxXzys(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{

		ModelList modellist = new ModelList();

		if(wsAnalyse.getWs()!=null)
		{
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);		
		}

		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new XZYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new XZYSSsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new XZYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			WscpjgModel wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,modellist.getWssscyrModellist(),AjlxEnum.XZYS);
			modellist.setWscpjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk()!=null)
		{
			WsajjbqkModel wsajjbqkModel = new XzysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		return modellist;
	}
	
	/**
	 * ��������һ������
	 */
	public  ModelList jxXsys(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{
		
		ModelList modellist = new ModelList();
		
		if(wsAnalyse.getWs()!=null){
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);	
		}
		
		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new XSYSSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl(),wsAnalyse.getWsnr());
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new XSYSSsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new XSYSCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc(),modellist.getWssscyrModellist()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			XsPjjgModel wscpjgModel = new XSYSPjjgHandler().jxXspjjgModel(wsAnalyse, modellist.getWssscyrModellist(), AjlxEnum.XSYS);
			modellist.setWsxspjjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk() != null)
		{
			WsajjbqkModel wsajjbqkModel = new XsysAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(modellist.getWsajjbqkModel().getBssld() != null)
		{
			List<WsxszjdModel>  zjdModellist= new XsysZjdModelHandler().jxWsxszjdModel(modellist.getWsajjbqkModel().getBssld());
			modellist.setWsxszjdModellist(zjdModellist);
		}
		
		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		
		return modellist;
	}
	/**
	 * ����������������
	 */
	public ModelList jxXzes(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{

		ModelList modellist = new ModelList();

		if(wsAnalyse.getWs()!=null)
		{
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);		
		}

		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new XZESSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new XZESSsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new XZESCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			WscpjgModel wscpjgModel = new CpjgModelHandler().jxWscpjgModel(wsAnalyse,modellist.getWssscyrModellist(),AjlxEnum.XZES);
			modellist.setWscpjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk()!=null)
		{
			WsajjbqkModel wsajjbqkModel = new XzesAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		
		return modellist;

	}
	/**
	 * �������¶�������
	 */
	public  ModelList jxXses(WsAnalyse wsAnalyse,String wsnr) throws IOException, JDOMException{

		ModelList modellist = new ModelList();
		
		if(wsAnalyse.getWs()!=null){
			WswsModel wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			modellist.setWswsModel(wswsModel);	
		}
		
		if(wsAnalyse.getSscyr()!=null)
		{
			List<WssscyrModel> wssscyrModellist = new XZESSscyrModelHandler().jxWssscyrModelList(wsAnalyse.getSscyr(),wsAnalyse.getAjjbqk(),wsAnalyse.getSsjl());
			modellist.setWssscyrModellist(wssscyrModellist);
		}

		if(wsAnalyse.getSsjl()!=null)
		{
			WsssjlModel wsssjlModel = new XSESSsjlModelHandler().jxWsssjlModel(modellist.getWssscyrModellist(),wsAnalyse.getSsjl());
			modellist.setWsssjlModel(wsssjlModel);
		}

		if(wsAnalyse.getCpfxgc()!=null)
		{
			WscpfxgcModel wscpfxgcModel = new XSESCpfxgcModelHandler().jxWscpfxgcModel(wsAnalyse.getCpfxgc(),modellist.getWssscyrModellist()); 
			modellist.setWscpfxgcModel(wscpfxgcModel);
		}

		if(wsAnalyse.getCpjg()!=null)
		{
			XsPjjgModel wscpjgModel = xsesPjjgHandler.jxXspjjgModel(wsAnalyse,modellist.getWssscyrModellist(),AjlxEnum.XSES);
			modellist.setWsxspjjgModel(wscpjgModel);
		}

		if(wsAnalyse.getAjjbqk() != null)
		{
			WsajjbqkModel wsajjbqkModel = new XsesAjjbqkModelHandler().jxWsajjbqkModel(wsAnalyse.getAjjbqk());
			modellist.setWsajjbqkModel(wsajjbqkModel);
		}

		if(modellist.getWsajjbqkModel().getBssld() != null)
		{
			List<WsxszjdModel>  zjdModellist= new XsesZjdModelHandler().jxWsxszjdModel(modellist.getWsajjbqkModel().getBssld());
			modellist.setWsxszjdModellist(zjdModellist);
		}
		
		if(wsAnalyse.getWw()!=null)
		{
			WswwModel wswwModel = new WwModelHandler().jxWswwModel(wsAnalyse.getWw());
			modellist.setWswwModel(wswwModel);
		}
		
		return modellist;
	}


}
