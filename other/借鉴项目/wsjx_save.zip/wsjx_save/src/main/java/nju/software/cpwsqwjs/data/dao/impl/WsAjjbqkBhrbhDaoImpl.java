package nju.software.cpwsqwjs.data.dao.impl;

import nju.software.cpwsqwjs.data.dao.WsAjjbqkBhrbhDao;
import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBhrbhDO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.util.List;

/**
 * Created by mdw on 2017/1/5.
 */

public class WsAjjbqkBhrbhDaoImpl extends HibernateDaoSupport implements WsAjjbqkBhrbhDao {
    private static final Logger log = LoggerFactory.getLogger(WsAjjbqkBhrbhDaoImpl.class);
    @Override
    public WsAjjbqkBhrbhDO getByAjxh(int ajxh) {
        List<WsAjjbqkBhrbhDO>list = findByProperty("AJXH",ajxh);
        if(list==null)
            return null;
        else if(list.size()==0)
            return null;

        return list.get(0);
    }
    public List findByProperty(String propertyName, Object value) {
        log.debug("finding WsAjjbqkBhrbhDO with property: " + propertyName
                + ", value: " + value);
        try {
            String queryString = "from WsAjjbqkBhrbhDO as model where model."
                    + propertyName + "= ?";
            return getHibernateTemplate().find(queryString, value);
        } catch (RuntimeException re) {
            log.error("find by property name failed", re);
            throw re;
        }
    }

    @Override
    public void save(WsAjjbqkBhrbhDO wsAjjbqkBhrbhDO) {
        log.debug("saving wsAjjbqkBhrbhDO");
        try {
            getHibernateTemplate().saveOrUpdate(wsAjjbqkBhrbhDO);
            log.debug("save successful");
        } catch (RuntimeException re) {
            log.error("save failed", re);
            throw re;
        }

    }
	@Override
	public int getMaxbh() {
		// TODO Auto-generated method stub
	    String hql = "select max(bh) from WsAjjbqkBhrbhDO";

		Session s = this.getSession();
		Query query = s.createQuery(hql);

		int maxAjxh = 0;
		if (query.uniqueResult() != null)
			maxAjxh = (Integer) query.uniqueResult();

		// �ͷ����ݿ����ӣ�����
		this.releaseSession(s);
		return maxAjxh;
	}
}
