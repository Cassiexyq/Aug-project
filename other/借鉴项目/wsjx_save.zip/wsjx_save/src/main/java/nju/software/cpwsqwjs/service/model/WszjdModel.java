package nju.software.cpwsqwjs.service.model;

public class WszjdModel {
	private String zjxx;
	private String zjzl;
}
