package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsssjlzkjlDO;

public interface WsssjlZkjlDao {
	
	public void save(WsssjlzkjlDO zkjlDo);
	
	public int getMaxZkjlbhByajxh(int ajxh);

}
