package nju.software.cpwsqwjs.data.dataobject;

import nju.software.cpwsqwjs.service.model.AydmModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;

import javax.persistence.*;

/**
 * AydmbDO entity. @author MyEclipse Persistence Tools
 * ���ɴ����
 */
@Entity
@Table(name = "AYDMB") 
public class AydmbDO implements java.io.Serializable {
	/**
	 * ���л�ʱΪ�˱��ְ汾�ļ����ԣ����ڰ汾����ʱ�����л��Ա��ֶ����Ψһ��
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private String aydmbh;//���ɴ�����
	private String aymc;//��������
	private String sjdm;//�ϼ�����
	private String sjmc;//�ϼ�����
	private String sm;//˵��
	private Integer ayjb;//���ɼ���

	/** default constructor */
	public AydmbDO() {
	}
	
	public AydmbDO(String aydmbh, String aymc, String sjdm, String sm) {
		super();
		this.aydmbh = aydmbh;
		this.aymc = aymc;
		this.sjdm = sjdm;
		this.sm = sm;
	}
	
	@Id
	@Column(name = "AYDMBH", nullable = false)
	public String getAydmbh() {
		return aydmbh;
	}

	public void setAydmbh(String aydmbh) {
		this.aydmbh = aydmbh;
	}
	
	@Column(name = "AYMC" )
	public String getAymc() {
		return aymc;
	}

	public void setAymc(String aymc) {
		this.aymc = aymc;
	}
	@Column(name = "SJDM" )
	public String getSjdm() {
		return sjdm;
	}

	public void setSjdm(String sjdm) {
		this.sjdm = sjdm;
	}

	@Column(name = "SM", length = 100)
	public String getSm() {
		return sm;
	}


	public void setSm(String sm) {
		this.sm = sm;
	}
	@Column(name = "SJMC" )
	public String getSjmc() {
		return sjmc;
	}
	
	public void setSjmc(String sjmc) {
		this.sjmc = sjmc;
	}
	@Column(name = "AYJB" )
	public Integer getAyjb() {
		return ayjb;
	}

	public void setAyjb(Integer ayjb) {
		this.ayjb = ayjb;
	}

	public AydmbDO(AydmModel aydm){
		if(aydm!=null){
			if(aydm.getAydmbh()!=null){
				this.setAydmbh(aydm.getAydmbh());
			}
			if(aydm.getAymc()!=null){
				this.setAymc(aydm.getAymc());
			}
			if(aydm.getSjdm()!=null){
				this.setSjdm(aydm.getSjdm());
			}
			if(aydm.getSjmc()!=null){
				this.setSjmc(aydm.getSjmc());
			}
			if(aydm.getSm()!=null){
				this.setSm(aydm.getSm());
			}
			if(aydm.getAyjb()!=null){
				this.setAyjb(aydm.getAyjb());
			}
		}
	}

}