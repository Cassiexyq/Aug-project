package nju.software.cpwsqwjs.service.dataService;

import java.util.HashMap;
import java.util.List;

import nju.software.cpwsqwjs.data.dataobject.WssxbDo;
import nju.software.cpwsqwjs.service.model.AydmModel;

public interface AydmService {

	public List<AydmModel> getAllAy();
	
	public boolean save(AydmModel model);
	
	public AydmModel getAydm(String property,String value);
	
	public AydmModel getAydmBySjdm(String value);
	public AydmModel getAydmByAydmbh(String value);
	
	public HashMap<String, AydmModel> getAll();
	
	public void setAyjb(AydmModel model, HashMap<String, AydmModel> map);
	
	public WssxbDo setAy(WssxbDo wssx,String aydm,HashMap<String, AydmModel> map);
}
