package nju.software.cpwsqwjs.data.dao;


import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkBhrbhDO;

public interface WsAjjbqkBhrbhDao {
    public WsAjjbqkBhrbhDO getByAjxh(int ajxh);
    public void save(WsAjjbqkBhrbhDO wsAjjbqkBhrbhDO);
    public int getMaxbh();
}
