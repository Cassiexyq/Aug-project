package nju.software.cpwsqwjs.service.model;

/**
 * ���鸽��model
 * @author lr12
 *
 */
public class WsfjModel {

}
