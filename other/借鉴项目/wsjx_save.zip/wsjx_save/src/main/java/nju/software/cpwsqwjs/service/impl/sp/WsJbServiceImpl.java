package nju.software.cpwsqwjs.service.impl.sp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import nju.software.cpwsqwjs.data.dao.AjjbDao;
import nju.software.cpwsqwjs.data.dao.WsJbDao;
import nju.software.cpwsqwjs.data.dataobject.WsJbDO;
import nju.software.cpwsqwjs.service.model.sp.WsJbModel;
import nju.software.cpwsqwjs.service.sp.WsJbService;
import nju.software.cpwsqwjs.util.StringUtil;

@Service
public class WsJbServiceImpl implements WsJbService {
	
//	private static ApplicationContext appContext = new ClassPathXmlApplicationContext(
//			"applicationContext.xml", "applicationContextDataSource.xml");
//
//	private static WsJbDao wsJbDao;
//	static {
//		wsJbDao = (WsJbDao) appContext.getBean("wsJbDao");
//	}
	private  WsJbDao wsJbDao;
	
	public void setWsJbDao(WsJbDao wsJbDao) {
		this.wsJbDao = wsJbDao;
	}

	public List<WsJbModel> getWsJbxxByAjxh(long ajxh) {
		// TODO Auto-generated method stub
		List<WsJbDO> wsJbDOs = wsJbDao.getWsJbByAjxh((int)ajxh);
		return WsJbModel.convertDOsToModels(wsJbDOs);
	}
	
	public WsJbModel getWsJbxxByAjxhAndBh(long ajxh, long bh) {
		// TODO Auto-generated method stub
		WsJbDO wsJbDO = wsJbDao.getWsJbByAjxhAndBh((int)ajxh, (int)bh);
		return wsJbDO == null ? null : new WsJbModel(wsJbDO);
	}

	public boolean sfyJawsByAjxh(Long ajxh) {
		if(ajxh == null) return false;
		return wsJbDao.SfyJawsByAjxh(ajxh.intValue());
	}

	@Override
	public WsJbModel getJaWsJbxxByAjxh(long ajxh) {
		// TODO Auto-generated method stub
		List<WsJbDO> wsJbDOs = wsJbDao.getWsJbByAjxh((int)ajxh);
		if(wsJbDOs!=null && wsJbDOs.size()>0){
			for(WsJbDO wsjb:wsJbDOs){
				if(StringUtil.equals(wsjb.getSfjaws(), "Y")){
					WsJbModel wsJbModel = new WsJbModel(wsjb);
					return wsJbModel;
				}
			}
		}
		return null;
	}



}
