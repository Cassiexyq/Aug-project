package nju.software.cpwsqwjs.service.datamodel;

import javax.persistence.Column;
import javax.persistence.Id;
/**
 * ����������Ϣģ��
 * @author Admin
 *
 */
public class WsajjbxxModel {
	 
	// Fields
	private Integer ajxh;//�������
	private String ah;//����
	private String ajxz;//��������
	private String spcx;//���г���
	private String wsmc;//��������
	private String wszl;//��������
	private String wszzdw;//����������λ
	private String jbfy;//���취Ժ
	private String fyjb;//��Ժ����
	private String xzqhsh;//�������� ʡ
	private String xzqhs;//�������� ��
	private String land;//�������
	private String tcgxqyy;//�Ƿ������ϽȨ����
	private String jafs;//�᰸��ʽ
	private String pjsj;//�о�ʱ��
	private String jand;//�᰸���
	private String jayf;//�᰸�·�
	private String kssz;//��������
	private String ssqx;//��������
	private String sstjcl;//�����ύ����
	private String sffhcs;//�Ƿ񷢻�����
	private String fhccyy;//��������ԭ��
	private String jazbd;//�᰸�ܱ��

	// Constructors

	/** default constructor */
	public WsajjbxxModel() {
	}

	// Property accessors
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	public String getAjxz() {
		return this.ajxz;
	}

	public void setAjxz(String ajxz) {
		this.ajxz = ajxz;
	}

	public String getSpcx() {
		return this.spcx;
	}

	public void setSpcx(String spcx) {
		this.spcx = spcx;
	}
	public String getAh() {
		return ah;
	}

	public void setAh(String ah) {
		this.ah = ah;
	}
	public String getWsmc() {
		return wsmc;
	}

	public void setWsmc(String wsmc) {
		this.wsmc = wsmc;
	}
	public String getWszl() {
		return wszl;
	}

	public void setWszl(String wszl) {
		this.wszl = wszl;
	}
	public String getWszzdw() {
		return wszzdw;
	}

	public void setWszzdw(String wszzdw) {
		this.wszzdw = wszzdw;
	}
	public String getJbfy() {
		return jbfy;
	}

	public void setJbfy(String jbfy) {
		this.jbfy = jbfy;
	}
	public String getFyjb() {
		return fyjb;
	}

	public void setFyjb(String fyjb) {
		this.fyjb = fyjb;
	}
	public String getXzqhsh() {
		return xzqhsh;
	}

	public void setXzqhsh(String xzqhsh) {
		this.xzqhsh = xzqhsh;
	}
	public String getXzqhs() {
		return xzqhs;
	}

	public void setXzqhs(String xzqhs) {
		this.xzqhs = xzqhs;
	}
	public String getLand() {
		return land;
	}

	public void setLand(String land) {
		this.land = land;
	}
	public String getTcgxqyy() {
		return tcgxqyy;
	}

	public void setTcgxqyy(String tcgxqyy) {
		this.tcgxqyy = tcgxqyy;
	}
	public String getJafs() {
		return jafs;
	}

	public void setJafs(String jafs) {
		this.jafs = jafs;
	}
	public String getPjsj() {
		return pjsj;
	}

	public void setPjsj(String pjsj) {
		this.pjsj = pjsj;
	}
	public String getJand() {
		return jand;
	}

	public void setJand(String jand) {
		this.jand = jand;
	}
	public String getJayf() {
		return jayf;
	}

	public void setJayf(String jayf) {
		this.jayf = jayf;
	}
	public String getKssz() {
		return kssz;
	}

	public void setKssz(String kssz) {
		this.kssz = kssz;
	}
	public String getSsqx() {
		return ssqx;
	}

	public void setSsqx(String ssqx) {
		this.ssqx = ssqx;
	}
	public String getSstjcl() {
		return sstjcl;
	}

	public void setSstjcl(String sstjcl) {
		this.sstjcl = sstjcl;
	}
	public String getSffhcs() {
		return sffhcs;
	}

	public void setSffhcs(String sffhcs) {
		this.sffhcs = sffhcs;
	}
	public String getFhccyy() {
		return fhccyy;
	}

	public void setFhccyy(String fhccyy) {
		this.fhccyy = fhccyy;
	}
	public String getJazbd() {
		return jazbd;
	}

	public void setJazbd(String jazbd) {
		this.jazbd = jazbd;
	}
	

}
