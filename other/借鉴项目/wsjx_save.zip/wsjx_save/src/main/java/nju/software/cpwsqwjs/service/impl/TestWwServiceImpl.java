package nju.software.cpwsqwjs.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.xpath.axes.HasPositionalPredChecker;
import org.jdom.Element;
import org.xml.sax.SAXException;

import nju.software.cpwsqwjs.service.TestWwService;
import nju.software.cpwsqwjs.service.model.TestModel;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.service.model.WswwModel;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.XMLReader;

public class TestWwServiceImpl implements TestWwService{

	@Override
	public TestModel testSpryxm(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
//		����������Ա����list
		ArrayList<String> contentlist=xr.getXMLNodelist(inputpath+"\\"+filename, node[1]);
		int index=0;
		boolean flag = true;
		if(!contentlist.get(0).equals("��")&&wswwModel!=null && wswwModel.getSpzzcyMap()!=null){
			HashMap<String , String> spzzcyMap = wswwModel.getSpzzcyMap();
			for(String content:contentlist){
				if(!spzzcyMap.containsKey(content)){
					flag = false;
					break;
				}
			}
		}
		if(flag){
			testModel.setCoNum(testModel.getCoNum()+1);
		}else{
			System.out.println("����:"+contentlist);
		}
		return testModel;
	}

	@Override
	public TestModel testSpryjs(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
//		����������Ա����list
		ArrayList<String> contentlist=xr.getXMLNodelist(inputpath+"\\"+filename, node[1]);
		boolean flag = true;
		String s = "";
		if(!contentlist.get(0).equals("��")&&wswwModel!=null && wswwModel.getSpzzcyMap()!=null){
			HashMap<String , String> spzzcyMap = wswwModel.getSpzzcyMap();
			for(String content:contentlist){
				if(!spzzcyMap.containsValue(content)){
					flag = false;
					break;
				}
			}
		}
		if(flag){
			testModel.setCoNum(testModel.getCoNum()+1);
		}else{
			System.out.println("����:"+contentlist);
		}
		return testModel;
	}

	@Override
	public TestModel testCpsj(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		// TODO Auto-generated method stub
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
		String content=xr.getXMLNode(inputpath+"\\"+filename, node[1]);
        if(wswwModel!=null){
        	String cprq = wswwModel.getWsrq();
        	if(cprq!=null && ts.judgeNode_1(cprq, content)){
        		testModel.setCoNum(testModel.getCoNum()+1);
        	}else{
        		System.out.println("����ʱ�� "+cprq+"   "+content);		
//    			FileUtil.fileCopy(inputpath, filename, specialpath+"cpsjspecial", filename);
        	}
        }
		return testModel;
	}

	@Override
	public TestModel testJand(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		// TODO Auto-generated method stub
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
		String content=xr.getXMLNode(inputpath+"\\"+filename, node[1]);
        if(wswwModel!=null){
        	String year = wswwModel.getYear();
        	if(year!=null && ts.judgeNode_1(year, content)){
        		testModel.setCoNum(testModel.getCoNum()+1);
        	}else{
        		System.out.println("�᰸��� "+year+"   "+content);		
//    			FileUtil.fileCopy(inputpath, filename, specialpath+"yearspecial", filename);
        	}
        }
		return testModel;
	}

	@Override
	public TestModel testJanyr(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		// TODO Auto-generated method stub
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
		String content=xr.getXMLNode(inputpath+"\\"+filename, node[1]);
        if(wswwModel!=null){
        	String cprq = wswwModel.getWsrq();
        	if(cprq!=null && ts.judgeNode_1(cprq, content)){
        		testModel.setCoNum(testModel.getCoNum()+1);
        	}else{
        		System.out.println("�᰸������ "+cprq+"   "+content);		
//    			FileUtil.fileCopy(inputpath, filename, specialpath+"janyrspecial", filename);
        	}
        }
		return testModel;
	}

	@Override
	public TestModel testJany(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		// TODO Auto-generated method stub
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
		String content=xr.getXMLNode(inputpath+"\\"+filename, node[1]);
        if(wswwModel!=null){
        	String cprq = wswwModel.getYearAndMonth();
        	if(cprq!=null && ts.judgeNode_1(cprq, content)){
        		testModel.setCoNum(testModel.getCoNum()+1);
        	}else{
        		System.out.println("����ʱ�� "+cprq+"   "+content);		
//    			FileUtil.fileCopy(inputpath, filename, specialpath+"janyspecial", filename);
        	}
        }
		return testModel;
	}

	@Override
	public TestModel testJay(TestModel testModel, WswwModel wswwModel,
			String inputpath, String filename, String specialpath, String[] node)
			throws XPathExpressionException, ParserConfigurationException,
			SAXException, IOException {
		// TODO Auto-generated method stub
		XMLReader xr=new XMLReader();
		TestMethodServiceImpl ts=new TestMethodServiceImpl();
		String content=xr.getXMLNode(inputpath+"\\"+filename, node[1]);
        if(wswwModel!=null){
        	String cprq = wswwModel.getMonth();
        	if(cprq!=null &&ts.judgeNode_1(cprq, content)){
        		testModel.setCoNum(testModel.getCoNum()+1);
        	}else{
        		System.out.println("����ʱ�� "+cprq+"   "+content);		
//    			FileUtil.fileCopy(inputpath, filename, specialpath+"Monthpecial", filename);
        	}
        }
		return testModel;
	}
}
