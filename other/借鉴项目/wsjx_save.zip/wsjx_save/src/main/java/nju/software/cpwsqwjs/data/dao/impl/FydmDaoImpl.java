package nju.software.cpwsqwjs.data.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import nju.software.cpwsqwjs.data.dao.FydmDao;
import nju.software.cpwsqwjs.data.dataobject.FydmDO;
import nju.software.cpwsqwjs.exception.BaseAppException;

public class FydmDaoImpl extends HibernateDaoSupport implements FydmDao{

	@Override
	public boolean save(FydmDO fydm) {
		 try{
	            getHibernateTemplate().saveOrUpdate(fydm);
        }catch (RuntimeException re){
            throw re;
        }
		 return true;
	}

	@Override
	public FydmDO findByFymc(String fymc) {
		// TODO Auto-generated method stub
		try {
			String queryString = "from FydmDO as model where model.fymc = '"+fymc+"'";
			return (FydmDO) getHibernateTemplate().find(queryString).get(0);
		} catch (RuntimeException re) {
			throw re;
		}
//		List<FydmDO> list = findByProperty("FYMC", fymc);
//		if(list.size()>0){
//			return list.get(0);
//		}else{
//			return null;
//		}
	}
	
	public List findByProperty(String propertyName, Object value) {
		try {
			String queryString = "from FydmDO as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public List<FydmDO> getAll() {
		// TODO Auto-generated method stub
		try {
			String queryString = "from FydmDO";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			throw re;
		}
	}

	@Override
	public FydmDO findByCjm(String cjm) {
		// TODO Auto-generated method stub
		List<FydmDO> list = findByProperty("cjm", cjm);
		if(list.size()>0){
			return list.get(0);
		}else{
			return null;
		}
	}

}
