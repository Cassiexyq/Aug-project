package nju.software.cpwsqwjs.main;

import java.io.File;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.business.WsManager;
import nju.software.cpwsqwjs.handler.mseshandler.WsModelHandler;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.util.FcUtil;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.StringUtil;


/**
 * ���ݽ��� ������������
 * 
 * @author lr12
 * 
 */
public class WsjxWordTxt1 {
	private static final Logger log = LoggerFactory.getLogger(WsjxWordTxt1.class);
	public static String format(String qw){
		char[]ws=qw.toCharArray();		
		int index=0;
		for(int i=0;i<ws.length;i++){
			int temp=ws[i];
			if(temp==32){
				if(i-index>5){
					ws[i]=10;
				}
				index=i;
			}

		}
		return String.valueOf(ws);
	}
	public static String  getWsnr(String path,String filename){
		String wsnr="";
		ArrayList<String> content=new ArrayList<String>();
		ArrayList<String> wsnrlist=new ArrayList<String>();
		FileUtil fileUtil = new FileUtil();
		FcUtil fcUtil=new FcUtil();
		fileUtil.setS(path+"\\"+filename);
		content=fileUtil.readFromFile();
		for(int i=0;i<content.size();i++){
			ArrayList<String> str=(ArrayList<String>) FcUtil.getWholeToken(content.get(i));
			if(str.size()>0){
				wsnrlist.add(content.get(i));
			}
		}
		for(int i=0;i<wsnrlist.size()-1;i++){
			wsnr+=wsnrlist.get(i)+"\n";
		}
		wsnr+=wsnrlist.get(wsnrlist.size()-1);
		return wsnr;
	}
	public static String fileSelection(String path,String filename) throws Exception{
		String wsnr=null;
		String str = filename.substring(filename.lastIndexOf(".")+1);
		if(str.contains("txt")){
			wsnr=getWsnr(path,filename);
		}else if(str.contains("doc")||str.contains("docx")||str.contains("DOC")){
			wsnr=FileUtil.readDoc(path, filename);
		}else if(str.contains("RTF")||str.contains("rtf") ){
			wsnr=FileUtil.readRtf(path, filename);
		}else{
			System.out.println("�ļ���Ϊ��"+filename+"\n��Ч�ļ�");
		}
		return wsnr;
	}
	public static void main(String[] args) throws Exception {
        String  inputpath="C:\\Users\\Admin\\Desktop\\���½�ͨ�о��� - 2015&2016\\test";
		String outputpath="C:\\Users\\Admin\\Desktop\\���½�ͨ�о��� - 2015&2016";
		String  specialpath="C:\\Users\\Admin\\Desktop\\���½�ͨ�о��� - 2015&2016";
		File file=new File(inputpath);
		String filename[];
		filename=file.list();
		WsManager wsManager = new WsManager();
		for(int j=0;j<filename.length;j++)
		{
			log.info(filename[j]);
				try{
					System.out.println(filename[j]);
					String wsnr=fileSelection(inputpath,filename[j]);
					WsAnalyse wsAnalyse = new WsAnalyse(filename[j],wsnr);
					WswsModel wswsModel=new WswsModel();
					if(wsAnalyse.getWs()!=null){
						wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
					}
					String ajlx = wswsModel.getAjlx();
					if(StringUtil.contains(ajlx, "���¶���")){
						wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
					}else if(StringUtil.contains(ajlx, "����һ��")){
						wsManager.jxMsys(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
					}else if(StringUtil.contains(ajlx, "����һ��")){
						wsManager.jxXzys(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
					}else if(StringUtil.contains(ajlx, "��������")){
						wsManager.jxXzes(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
					}else if(StringUtil.contains(ajlx, "����һ��")){
						wsManager.jxXsys(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
					}else if(StringUtil.contains(ajlx, "���¶���")){
						wsManager.jxXses(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
					}else if(StringUtil.contains(ajlx, "����")){
						wsManager.jxXses(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
					}else if(StringUtil.contains(ajlx, "����")){
						wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
					}else if(StringUtil.contains(ajlx, "����")){
						wsManager.jxXzes(wsAnalyse, wsnr, inputpath, outputpath, filename[j]);
					}else{
						wsManager.jxMses(wsAnalyse,wsnr,inputpath,outputpath,filename[j]);
					}
				}catch(Exception e){
					e.printStackTrace();
					log.error("�޷�����",e);
					FileUtil.fileCopy(inputpath, filename[j], specialpath,  filename[j]);
				}
		}
		 
	}
}