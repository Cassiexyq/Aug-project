package nju.software.cpwsqwjs.service.sp;

import java.util.List;
import nju.software.cpwsqwjs.service.model.WssscyrModel;
import nju.software.cpwsqwjs.service.model.sp.DsrdwxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrjgxxModel;
import nju.software.cpwsqwjs.service.model.sp.ValidateModel;

public interface TestDsrService {

	public List<List<ValidateModel>> testDsr(List<WssscyrModel> wssscyrModellist,List<DsrgrxxModel> dsrgrxxmodellist,
			List<DsrdwxxModel> dsrdwxxmodellist, List<DsrjgxxModel> dsrjgxxModellist,List<List<ValidateModel>> vmodellist_dsr);

}
