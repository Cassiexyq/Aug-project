/**
 * 2014-5-17 15��05
 */
package nju.software.cpwsqwjs.service.sp;

import java.util.List;

import nju.software.cpwsqwjs.service.model.sp.AjjbxxModel;
import nju.software.cpwsqwjs.service.model.sp.DsrgrxxModel;

public interface DsrgrxxService {

	/**
	 * ������и��˵�����
	 * @param ajxh
	 * @return
	 */
	public List<DsrgrxxModel> getDsrgrxxByAjxh(long ajxh,AjjbxxModel ajModel);
	/**
	 * ���µ��������ϵ�λ
	 * @param ajxh
	 * @param dsrbh
	 * @param ssdw
	 * @return
	 */
	public boolean updateDsrssdw(int ajxh,int dsrbh, String ssdw);
	
	/**
	 * ���µ�����
	 * @param ajxh
	 * @param dsrbh
	 * @param zd
	 * @param zdz
	 * @return
	 */
	public boolean updateGrdsr(int ajxh,int dsrbh,String zd,String zdz);
}
