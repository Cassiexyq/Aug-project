package nju.software.cpwsqwjs.test;

import java.io.IOException;
import java.util.List;

import org.jdom.JDOMException;

import nju.software.cpwsqwjs.business.WsAnalyse;
import nju.software.cpwsqwjs.business.WsManager;
import nju.software.cpwsqwjs.data.dao.PubLaAyDao;
import nju.software.cpwsqwjs.data.dao.SqlDao;
import nju.software.cpwsqwjs.data.dao.impl.PubLaAyDaoImpl;
import nju.software.cpwsqwjs.data.dataobject.PubLaAy;
import nju.software.cpwsqwjs.dynamicds.DataSourceEnum;
import nju.software.cpwsqwjs.dynamicds.DataSourceRouter;
import nju.software.cpwsqwjs.handler.mseshandler.WsModelHandler;
import nju.software.cpwsqwjs.service.Ayservice;
import nju.software.cpwsqwjs.service.dataService.WsajjbxxService;
import nju.software.cpwsqwjs.service.dataService.impl.WsajjbxxServiceImpl;
import nju.software.cpwsqwjs.service.datamodel.WsajjbxxModel;
import nju.software.cpwsqwjs.service.impl.AyserviceImpl;
import nju.software.cpwsqwjs.service.impl.sp.WsJbServiceImpl;
import nju.software.cpwsqwjs.service.model.WswsModel;
import nju.software.cpwsqwjs.service.model.sp.WsJbModel;
import nju.software.cpwsqwjs.service.sp.WsJbService;
import nju.software.cpwsqwjs.util.FileUtil;
import nju.software.cpwsqwjs.util.POIUtil;
import nju.software.cpwsqwjs.util.StringUtil;

public class Test2 {

	public static void main(String[] args) throws IOException, JDOMException{
		DataSourceRouter.routerTo(DataSourceEnum.TJGY.getFydm());
		WsJbService wsJbService = new WsJbServiceImpl();
		WsJbModel wsJbModel = wsJbService.getJaWsJbxxByAjxh(47402);
		byte[] wsnr = wsJbModel.getWsnr();
		String wsmc = wsJbModel.getWswjm();
		String wsnrStr = POIUtil.getContent(wsnr, wsmc);
		System.out.println(wsnrStr);
		String  inputpath="C:\\Users\\Admin\\Desktop\\���½�ͨ�о��� - 2015&2016\\test";
		String outputpath="C:\\Users\\Admin\\Desktop\\1";
		String  specialpath="C:\\Users\\Admin\\Desktop\\";
			WsManager wsManager = new WsManager();
			WsAnalyse wsAnalyse = new WsAnalyse(wsmc,wsnrStr);
			WswsModel wswsModel=new WswsModel();
			if(wsAnalyse.getWs()!=null){
				wswsModel = new WsModelHandler().jxWswsModel(wsAnalyse.getWs());
			}
			String ajlx = wswsModel.getAjlx();
			if(StringUtil.contains(ajlx, "���¶���")){
				wsManager.jxMses(wsAnalyse,wsnrStr,inputpath,outputpath,wsmc);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxMsys(wsAnalyse,wsnrStr,inputpath,outputpath,wsmc);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxXzys(wsAnalyse,wsnrStr,inputpath,outputpath,wsmc);
			}else if(StringUtil.contains(ajlx, "����һ��")){
				wsManager.jxXsys(wsAnalyse, wsnrStr, inputpath, outputpath, wsmc);
			}else if(StringUtil.contains(ajlx, "��������")){
				wsManager.jxXzes(wsAnalyse, wsnrStr, inputpath, outputpath, wsmc);
			}else if(StringUtil.contains(ajlx, "���¶���")){
				wsManager.jxXses(wsAnalyse, wsnrStr, inputpath, outputpath, wsmc);
			}else if(StringUtil.contains(ajlx, "��������")){
				wsManager.jxMses(wsAnalyse, wsnrStr, inputpath, outputpath, wsmc);
			}
		
	}
}
