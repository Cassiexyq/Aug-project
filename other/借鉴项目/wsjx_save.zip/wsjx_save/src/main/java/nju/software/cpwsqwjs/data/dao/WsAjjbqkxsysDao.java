package nju.software.cpwsqwjs.data.dao;

import nju.software.cpwsqwjs.data.dataobject.WsAjjbqkxsysDO;


public interface WsAjjbqkxsysDao {
    public WsAjjbqkxsysDO getByAjxh(int ajxh);

    public void save(WsAjjbqkxsysDO wsAjjbqkxsysDO);
}
