var ajxh = window.location.pathname.substr(11);

var app = new Vue({
    el: '#app',
    data() {
        return {
            wsResult: [],
            dsrResult: [],
            activeItem: {},
            downloading: true
        }
    },
    methods: {
        checkItem (item) {
            this.activeItem = item;
        },
        handleUpdate () {
            console.log('回填');
            //TO DO
            $.post('http://localhost:8080/wsjx/ht', 
                {
                    ajxh: ajxh,
                    jdmc: this.activeItem.jdmc,
                    jdbz: this.activeItem.jdbz,
                    wszd: this.activeItem.data_jx
                }, (res, status) => {
                    console.log(res);
                    if (res) {
                        alert("回填成功");
                        window.location.reload();
                    } else {
                        alert("回填失败");
                        $('#modal').modal('hide');
                    }
                })
        }
    },
    created () {
        console.log('created');
        $.get('http://localhost:8080/wsjx/getJYResult?ajxh='+ajxh, (res, status) => {
            console.log(res);
            console.log(status);
            this.wsResult = res.wsResult;
            this.dsrResult = res.dsrResult;
            this.downloading = false;
        });
    }
})