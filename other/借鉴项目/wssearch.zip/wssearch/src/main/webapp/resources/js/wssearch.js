/**
 * Created by zhx on 2017/6/30.
 */
(function(argument){
    var form = document.querySelector("#search-form");
    
    form.addEventListener("submit",function (e) {
        e.preventDefault();
        var data = getData(form);
        sendSearchCondition(data).then(handleResponse);
    })

    function sendSearchCondition(data){
        var xhr = new XMLHttpRequest();
        var dataJson = JSON.stringify(data);
        return new Promise(function (resolve,reject) {
            xhr.open("post","search.aj",true);
            xhr.setRequestHeader('Content-Type','application/json');
            xhr.send(dataJson);
            xhr.onreadystatechange = function(){
                if (xhr.readyState === 4){
                    if(xhr.status>=200&&xhr.status<300||xhr.status === 304){
                        resolve(xhr.response);
                    }else {
                        reject(new Error(this.statusText));
                    }
                }
            }
        });
    }

    /**
     * �����ش���response
     */
    function handleResponse(data){
        data = JSON.parse(data);
        var htmlTemplate = [];
         data.forEach(function (item) {
            var str = `<td>${item.ah}</td><td>${item.ajmc}</td><td>${item.spcx}</td><td>${item.fymc}</td><td>${item.cprq}</td><td>${item.fbrq}</td><td>${item.zsfy}</td>
<td>${item.zsah}</td><td>${item.spz}</td><td>${item.ay}</td><td><div>${item.byrw}</div></td><td><div>${item.zw}</div></td><td><div>${item.ft}</div></td>`;
            htmlTemplate.push('<tr>'+str+'</tr>');
        });
         var lines = 10;//ÿҳ����
         var totalPages = Math.ceil(htmlTemplate.length/lines);
         var tableContain = document.querySelector(".case-list-table tbody");
         tableContain.innerHTML = totalPages>1?arr2html(htmlTemplate,0,20):arr2html(htmlTemplate,0,htmlTemplate.length);
         argument.pagination({
            totalPages:totalPages,
            container:".pagination",
             callback:cb.bind(null,tableContain,htmlTemplate)
         });
    }
    function cb(tableContain,data,lines,curPages,totalPages){
        var start = lines*(curPages-1);
        var end = lines*(curPages);
        tableContain.innerHTML = (curPages===totalPages)?arr2html(data,start,data.length):arr2html(data,start,end);
    }
    
    function getData(form) {
        var data= {};
        var inputs = Array.prototype.slice.call(form.querySelectorAll("input"));
        var textareas = Array.prototype.slice.call(form.querySelectorAll("textarea"));
        inputs.forEach(function (item) {
            data[item.name] = item.value;
        })
        textareas.forEach(function (item) {
            data[item.name] = item.value;
        })
        return data;
    }

    function arr2html(arr,start,end){
        var htmlstr = ''
        if(arr instanceof Array){
            for(let i=start;i<end;i++){
                htmlstr+=arr[i];
            }
        }
        return htmlstr;
    }

})(window);
