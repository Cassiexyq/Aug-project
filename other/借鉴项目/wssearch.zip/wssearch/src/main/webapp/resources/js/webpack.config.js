const path = require("path");

var OUTPUT_PATH = path.resolve(__dirname,'dist');


module.exports = {
	entry:["babel-polyfill","./pagination.js","./wssearch.js"],
	output:{
		path:OUTPUT_PATH,
		filename:'bundle.js',
		chunkFilename: '[name].[chunkhash:5].min.js',
		publicPath: '/'
	},
	module:{
		rules:[{
			test:/\.(js|jsx)$/,
			exclude:/^node_modules$/,
			loader:"babel-loader"
		}]
	}
	
}