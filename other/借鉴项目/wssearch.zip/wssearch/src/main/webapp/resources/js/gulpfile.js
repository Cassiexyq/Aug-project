var gulp = require('gulp');
var concat = require('gulp-concat');
var babel = require('gulp-babel');

gulp.task('default',function(){
	return gulp.src(['./pagination.js','./wssearch.js'])
	.pipe(babel())
	.pipe(concat("bundle.js"))
	.pipe(gulp.dest("build"));
})