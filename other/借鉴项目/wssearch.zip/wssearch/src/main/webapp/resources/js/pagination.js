(function(argument) {
    // body...
    var $ = function(selector){
        var nodeList = document.querySelectorAll(selector);
        if (nodeList.length === 1) {
            return nodeList[0];
        }else if(nodeList.length === 0){
            return [];
        }else {
            return nodeList;
        }
    }


    //分页：options totalPages 总页数 curpages当前页数
    class Pagination{

        constructor(options){
            this.totalPages = parseInt(options.totalPages || 1,10);
            this.curPages = parseInt(options.curPages || 1,10);
            this.container = $(options.container);
            this.callback = options.callback || function() {};
            this.init(this.curPages,this.totalPages);
            this._bindPages();
        }

        init(curPages,totalPages){
            this.refresh(curPages,totalPages);
            this.pages = Array.prototype.slice.call(this.container.querySelectorAll("li"));
        }

        _bindPages(){
            this.container.onclick = (e)=>{
                var parentElement = e.target.parentElement;
                if (!parentElement.classList.contains("active")&&!parentElement.classList.contains("disabled")) {
                    this.switchTo(e.target.getAttribute("data-page"));
                    this.callback(this.curPages,this.totalPages);

                }
            }
        }

        switchTo(page){
            if (page === '<') {
                this.refresh(--this.curPages,this.totalPages);
            }else if (page === '>') {
                this.refresh(++this.curPages,this.totalPages);
            }else if (page === '...') {
                return;
            }else{
                this.curPages = parseInt(page,10);
                this.refresh(this.curPages,this.totalPages);
            }
        }

        refresh(curPages,totalPages){
            if (curPages===null || totalPages===null)  return ;
            if (curPages<0 || totalPages <=0) return;
            if (curPages > totalPages) return;
            var htmlTemplates = [];
            var url = "javascript:void(0)";
            var endDistance = totalPages - curPages + 1 ;
            var maxLen = 9;
            if (totalPages<=8) {
                //生成页数码
                htmlTemplates = this.pageLoop(1,totalPages,url,htmlTemplates,curPages);
            }else{
                if (curPages<=3) {
                    htmlTemplates = this.pageLoop(1,5,url,htmlTemplates,curPages);
                    htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                    htmlTemplates = this.pageLoop(totalPages-1,totalPages,url,htmlTemplates,curPages);
                }else if (endDistance<=3) {
                    htmlTemplates = this.pageLoop(1,2,url,htmlTemplates,curPages);
                    htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                    htmlTemplates = this.pageLoop(totalPages-4,totalPages,url,htmlTemplates,curPages);
                }else {
                    if (totalPages<=maxLen) {
                        htmlTemplates = this.pageLoop(1,totalPages,url,htmlTemplates,curPages);
                    }else{
                        if (curPages<=5) {
                            htmlTemplates = this.pageLoop(1,curPages+1,url,htmlTemplates,curPages);
                            htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                            htmlTemplates = this.pageLoop(totalPages-1,totalPages,url,htmlTemplates,curPages);
                        }
                        else if (endDistance<=5) {
                            htmlTemplates = this.pageLoop(1,2,url,htmlTemplates,curPages);
                            htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                            htmlTemplates = this.pageLoop(curPages-1,totalPages,url,htmlTemplates,curPages);
                        }
                        else {
                            htmlTemplates = this.pageLoop(1,2,url,htmlTemplates,curPages);
                            htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                            htmlTemplates = this.pageLoop(curPages-1,curPages+1,url,htmlTemplates,curPages);
                            htmlTemplates.push(this.pageTemplates("...",url,"disabled"));
                            htmlTemplates= this.pageLoop(totalPages-1,totalPages,url,htmlTemplates,curPages);
                        }
                    }
                }
            }
            //生成上一页下一页箭头
            var prevClass = curPages === 1 ? "disabled" : "";
            var nextClass = curPages === totalPages ? "disabled" : "";
            htmlTemplates.unshift(this.pageTemplates("&lt;",url,prevClass));
            htmlTemplates.push(this.pageTemplates("&gt;",url,nextClass));
            var html = htmlTemplates.reduce((prev,cur)=>{return prev+cur});
            this.container.innerHTML = html;
        }

        pageTemplates(pages,url,className){
            var classProp = "";
            if (className) {
                classProp = "class="+className
            }
            return `<li ${classProp}><a href=${url} data-page=${pages}>${pages}</a></li>`;
        }

        pageLoop(start,end,url,templatesArray,curPages){
            for (var i = start; i <=end; i++) {
                var pageItem = i === parseInt(curPages,10) ? this.pageTemplates(i,url,"active"):this.pageTemplates(i,url);
                templatesArray.push(pageItem);
            }
            return templatesArray;
        }

    }

    // var pagination = new Pagination({
    //     totalPages:13,
    //     container:".pagination"
    // });
    argument.pagination = function(options){
        return new Pagination(options);
    };

})(window);
