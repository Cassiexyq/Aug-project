package software.wspc.web.filter;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import software.wspc.service.model.UserContextModel;
import software.wspc.util.StringUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by 28619 on 2017/6/12.
 */
public class AccessInterceptor extends HandlerInterceptorAdapter {

    private static final Logger log = Logger.getLogger(AccessInterceptor.class);

//    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,Object Handler) throws Exception{
//        String requestURI = request.getRequestURI();
//        String toLogin = request.getRequestURL().toString();
//        String doName = request.getServletPath();
//        if (StringUtil.contains(doName,"WEB-INF")){
//            return true;
//        }
//        String cannotAccess = toLogin.substring(0,
//                toLogin.length() - doName.length())
//                + "/login.do";
//        UserContextModel userContextModel = (UserContextModel)request.getSession().getAttribute("userContext");
//        if (userContextModel ==null){
//            if (requestURI.endsWith("/login.do")){
//                return true;
//            }else {
//                log.warn("错误的访问页面。requestURI:" + requestURI);
//                response.sendRedirect(cannotAccess);
//                return false;
//            }
//        }else {
//            return true;
//        }
//    }

}
