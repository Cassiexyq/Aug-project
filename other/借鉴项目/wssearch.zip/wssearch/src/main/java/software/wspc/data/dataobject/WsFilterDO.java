package software.wspc.data.dataobject;

import javax.persistence.*;

/**
 * Created by zhx on 2017/6/29.
 */
@Entity
@Table(name = "WS_FILTER", schema = "jsgy_manager", catalog = "JUDGE")
public class WsFilterDO {
    private int id;
    private String ah;
    private String ajmc;
    private String ay;
    private String byrw;
    private String cprq;
    private String fbrq;
    private String ft;
    private String fymc;
    private String spcx;
    private String spz;
    private String wsbt;
    private String zsah;
    private String zsfy;
    private String zw;

    @Id
    @Column(name = "ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "AH")
    public String getAh() {
        return ah;
    }

    public void setAh(String ah) {
        this.ah = ah;
    }

    @Basic
    @Column(name = "AJMC")
    public String getAjmc() {
        return ajmc;
    }

    public void setAjmc(String ajmc) {
        this.ajmc = ajmc;
    }

    @Basic
    @Column(name = "AY")
    public String getAy() {
        return ay;
    }

    public void setAy(String ay) {
        this.ay = ay;
    }

    @Basic
    @Column(name = "BYRW")
    public String getByrw() {
        return byrw;
    }

    public void setByrw(String byrw) {
        this.byrw = byrw;
    }

    @Basic
    @Column(name = "CPRQ")
    public String getCprq() {
        return cprq;
    }

    public void setCprq(String cprq) {
        this.cprq = cprq;
    }

    @Basic
    @Column(name = "FBRQ")
    public String getFbrq() {
        return fbrq;
    }

    public void setFbrq(String fbrq) {
        this.fbrq = fbrq;
    }

    @Basic
    @Column(name = "FT")
    public String getFt() {
        return ft;
    }

    public void setFt(String ft) {
        this.ft = ft;
    }

    @Basic
    @Column(name = "FYMC")
    public String getFymc() {
        return fymc;
    }

    public void setFymc(String fymc) {
        this.fymc = fymc;
    }

    @Basic
    @Column(name = "SPCX")
    public String getSpcx() {
        return spcx;
    }

    public void setSpcx(String spcx) {
        this.spcx = spcx;
    }

    @Basic
    @Column(name = "SPZ")
    public String getSpz() {
        return spz;
    }

    public void setSpz(String spz) {
        this.spz = spz;
    }

    @Basic
    @Column(name = "WSBT")
    public String getWsbt() {
        return wsbt;
    }

    public void setWsbt(String wsbt) {
        this.wsbt = wsbt;
    }

    @Basic
    @Column(name = "ZSAH")
    public String getZsah() {
        return zsah;
    }

    public void setZsah(String zsah) {
        this.zsah = zsah;
    }

    @Basic
    @Column(name = "ZSFY")
    public String getZsfy() {
        return zsfy;
    }

    public void setZsfy(String zsfy) {
        this.zsfy = zsfy;
    }

    @Basic
    @Column(name = "ZW")
    public String getZw() {
        return zw;
    }

    public void setZw(String zw) {
        this.zw = zw;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WsFilterDO that = (WsFilterDO) o;

        if (id != that.id) return false;
        if (ah != null ? !ah.equals(that.ah) : that.ah != null) return false;
        if (ajmc != null ? !ajmc.equals(that.ajmc) : that.ajmc != null) return false;
        if (ay != null ? !ay.equals(that.ay) : that.ay != null) return false;
        if (byrw != null ? !byrw.equals(that.byrw) : that.byrw != null) return false;
        if (cprq != null ? !cprq.equals(that.cprq) : that.cprq != null) return false;
        if (fbrq != null ? !fbrq.equals(that.fbrq) : that.fbrq != null) return false;
        if (ft != null ? !ft.equals(that.ft) : that.ft != null) return false;
        if (fymc != null ? !fymc.equals(that.fymc) : that.fymc != null) return false;
        if (spcx != null ? !spcx.equals(that.spcx) : that.spcx != null) return false;
        if (spz != null ? !spz.equals(that.spz) : that.spz != null) return false;
        if (wsbt != null ? !wsbt.equals(that.wsbt) : that.wsbt != null) return false;
        if (zsah != null ? !zsah.equals(that.zsah) : that.zsah != null) return false;
        if (zsfy != null ? !zsfy.equals(that.zsfy) : that.zsfy != null) return false;
        if (zw != null ? !zw.equals(that.zw) : that.zw != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + (ah != null ? ah.hashCode() : 0);
        result = 31 * result + (ajmc != null ? ajmc.hashCode() : 0);
        result = 31 * result + (ay != null ? ay.hashCode() : 0);
        result = 31 * result + (byrw != null ? byrw.hashCode() : 0);
        result = 31 * result + (cprq != null ? cprq.hashCode() : 0);
        result = 31 * result + (fbrq != null ? fbrq.hashCode() : 0);
        result = 31 * result + (ft != null ? ft.hashCode() : 0);
        result = 31 * result + (fymc != null ? fymc.hashCode() : 0);
        result = 31 * result + (spcx != null ? spcx.hashCode() : 0);
        result = 31 * result + (spz != null ? spz.hashCode() : 0);
        result = 31 * result + (wsbt != null ? wsbt.hashCode() : 0);
        result = 31 * result + (zsah != null ? zsah.hashCode() : 0);
        result = 31 * result + (zsfy != null ? zsfy.hashCode() : 0);
        result = 31 * result + (zw != null ? zw.hashCode() : 0);
        return result;
    }
}
