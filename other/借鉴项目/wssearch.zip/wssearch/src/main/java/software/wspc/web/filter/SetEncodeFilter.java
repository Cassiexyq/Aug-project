package software.wspc.web.filter;


import javax.servlet.*;
import java.io.IOException;

/**
 * Created by 28619 on 2017/6/12.
 */
public class SetEncodeFilter implements Filter {

    protected FilterConfig filterConfig = null;

    protected String defaultEncoding = null;

    public void init(FilterConfig arg0) throws ServletException {
        this.filterConfig = arg0;
        this.defaultEncoding = filterConfig.getInitParameter("encoding");
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        request.setCharacterEncoding("utf-8");
        chain.doFilter(request, response);
    }

    public void destroy() {
        this.defaultEncoding = null;
        this.filterConfig = null;
    }
}