package software.wspc.data.dao;

import org.springframework.stereotype.Repository;
import software.wspc.biz.vo.SearchConditionVO;
import software.wspc.data.dao.base.BaseDao;
import software.wspc.data.dataobject.WsFilterDO;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhx on 2017/6/29.
 */
@Repository
public class WsfilterDao extends BaseDao<WsFilterDO> {
    public WsFilterDO findByID(int id){
        String hql = "from WsFilterDO where id="+id;
        List<WsFilterDO> list = getHibernateTemplate().find(hql);
        return list!=null&&list.size()!=0?list.get(0):null;
    }

    public List<WsFilterDO> findBySearchCondition(SearchConditionVO searchConditionVO){
        //ȡ�ò�ѯ�����в�Ϊ�յ�ֵ
        ArrayList<String> conditionsSql = new ArrayList<>();
        Field[] fields = searchConditionVO.getClass().getDeclaredFields();//��ȡʵ������������ԣ�����Field����
        for (Field field: fields) {
            String name = field.getName();
            String type = field.getGenericType().toString();
            String getName = name.substring(0,1).toUpperCase()+name.substring(1);
            try {
                Method method = searchConditionVO.getClass().getMethod("get"+getName);
                if (type.equals("class java.lang.String")){
                    String value = (String)method.invoke(searchConditionVO);
                    if (value!=null){
                        conditionsSql.add(name+" LIKE "+"'%"+value+"%'");
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        String conditions = "";
        for (int i=0;i<conditionsSql.size();i++) {
            if (i==0){
                conditions = conditions + " where " + conditionsSql.get(i);
                continue;
            }
            conditions = conditions + " AND " + conditionsSql.get(i);
        }
        String hql = "from WsFilterDO"+conditions;
        List<WsFilterDO> wsFilterDOS = getHibernateTemplate().find(hql);
        return wsFilterDOS;
    }
}
