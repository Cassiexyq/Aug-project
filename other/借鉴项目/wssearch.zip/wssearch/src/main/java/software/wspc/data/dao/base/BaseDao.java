package software.wspc.data.dao.base;

import org.hibernate.SessionFactory;
import org.hibernate.connection.ConnectionProvider;
import org.hibernate.engine.SessionFactoryImplementor;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import javax.annotation.Resource;
import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

/**
 * Created by 28619 on 2017/6/12.
 */
public class BaseDao<T> extends HibernateDaoSupport {
    /**
     * ע��SessionFactory
     *
     * @param sessionFactory
     */
    @Resource
    public void setMySessioinFactory(SessionFactory sessionFactory) {
        super.setSessionFactory(sessionFactory);
    }

    /**
     * ����dataobject
     * @param entity
     */
    public void save(T entity){
        getHibernateTemplate().save(entity);
    }

    /**
     * ����id����
     * @param id
     * @return
     */
    public T getById(Serializable id){
        try{
            return getHibernateTemplate().get(this.getGenerics(),id);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * �����������ƺ�����ֵ����
     *
     * @param name  ������
     * @param value ����ֵ
     * @return
     */
    public List<T> findByProperty(String name, Object value) {
        String doname = this.getGenerics().getSimpleName();
        try {
            String hql = "from " + doname + " where " + name + " = ? ";
            return getHibernateTemplate().find(hql, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.<T>emptyList();
    }
    /**
     * ��ȡ��������
     *
     * @return
     */
    protected Class<T> getGenerics() {
        Type type = ((ParameterizedType) this.getClass().getGenericSuperclass()).getActualTypeArguments()[0];
        Class<T> clazz = (Class<T>) type;
        return clazz;
    }

    /**
     * ִ��sql
     * @param sql
     * @param params ֻ��String��Short��Integer��Long��Float��Double��Date����
     * @return
     */
    protected int executeSql(String sql, Object[] params) {
        ConnectionProvider cp = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            cp = ((SessionFactoryImplementor) this.getSessionFactory()).getConnectionProvider();
            connection = cp.getConnection();
            statement = connection.prepareStatement(sql);
            if (params != null)
                for (int i = 1; i < params.length+1; i++) {
                    Object param = params[i-1];
                    if(param instanceof String) statement.setString(i, (String) param);
                    else if(param instanceof Short) statement.setShort(i, (Short) param);
                    else if(param instanceof Integer) statement.setInt(i, (Integer) param);
                    else if(param instanceof Long) statement.setLong(i, (Long) param);
                    else if(param instanceof Float) statement.setFloat(i, (Float) param);
                    else if(param instanceof Double) statement.setDouble(i, (Double) param);
                    else if(param instanceof java.util.Date) statement.setTimestamp(i, new java.sql.Timestamp(((java.util.Date) param).getTime()));
                    else{
                        throw new RuntimeException("��ƥ������");
                    }
                }
            return statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            try {
                if (statement != null)
                    statement.close();
                if (cp != null)
                    cp.closeConnection(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
