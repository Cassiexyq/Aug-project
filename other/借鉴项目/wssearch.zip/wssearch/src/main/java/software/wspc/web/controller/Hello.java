package software.wspc.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import software.wspc.data.dao.WsfilterDao;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;

/**
 * Created by 28619 on 2017/6/12.
 */
@Controller
public class Hello {

    @Resource
    WsfilterDao wsFilterDao;
    @RequestMapping(value = "hello.aj",method = RequestMethod.GET)
    public String hello(HttpServletRequest request,HttpServletResponse response,ModelMap map) throws UnsupportedEncodingException {
        return "wssearch";

    }
}
