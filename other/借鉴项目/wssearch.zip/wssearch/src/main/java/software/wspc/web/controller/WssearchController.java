package software.wspc.web.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import software.wspc.biz.vo.SearchConditionVO;
import software.wspc.data.dao.WsfilterDao;
import software.wspc.data.dataobject.WsFilterDO;

import javax.annotation.Resource;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.List;

/**
 * Created by zhx on 2017/6/30.
 */
@Controller
public class WssearchController {
    @Resource
    WsfilterDao wsFilterDao;
    @RequestMapping(value = "search.aj",method = RequestMethod.POST)
    public void search(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) throws IOException{
//        BufferedReader br = new BufferedReader(new InputStreamReader((ServletInputStream) request.getInputStream(),"utf-8"));
//        StringBuffer sb = new StringBuffer("");
//        String temp;
//        while ((temp = br.readLine()) != null) {
//            sb.append(temp);
//        }
//        br.close();
//        String params = sb.toString();
        ObjectMapper objectMapper = new ObjectMapper();
        SearchConditionVO searchConditionVO = objectMapper.readValue(request.getInputStream(),SearchConditionVO.class);
        List<WsFilterDO> wsFilterDOS = wsFilterDao.findBySearchCondition(searchConditionVO);
        response.addHeader("Content-Type","application/json;charset=utf-8");
        response.setCharacterEncoding("UTF-8");
        PrintWriter pw = response.getWriter();
        pw.write(objectMapper.writeValueAsString(wsFilterDOS));
        pw.flush();
        pw.close();
    }
}
