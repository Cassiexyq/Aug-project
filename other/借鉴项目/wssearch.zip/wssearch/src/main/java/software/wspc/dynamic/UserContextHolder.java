package software.wspc.dynamic;

/**
 * Created by 28619 on 2017/6/12.
 */
public class UserContextHolder<T> {
    private static final ThreadLocal UserContextHolder = new ThreadLocal();
    public T getUserContext(){
        return (T)UserContextHolder.get();
    }
    public void setUserContext(T user){
        this.UserContextHolder.set(user);
    }
    public static void clearCustomerType() {
        UserContextHolder.remove();
    }
}
