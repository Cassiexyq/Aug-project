package software.wspc.service.model;

/**
 * Created by zhx on 2017/6/14.
 */
public class UserContextModel {
    /**
     * 法院名称
     */
    private String fymc;
    /**
     * 法院代码
     */
    private String fydm;
    /**
     * 用户名
     */
    private String username;
    /**
     * 密码
     */
    private String password;

    public String getFymc() {
        return fymc;
    }

    public void setFymc(String fymc) {
        this.fymc = fymc;
    }

    public String getFydm() {
        return fydm;
    }

    public void setFydm(String fydm) {
        this.fydm = fydm;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserContextModel(String fymc, String fydm, String username, String password) {
        this.fymc = fymc;
        this.fydm = fydm;
        this.username = username;
        this.password = password;
    }

    public UserContextModel() {
    }

    public UserContextModel(String fymc, String username, String password) {
        this.fymc = fymc;
        this.username = username;
        this.password = password;
    }
}
