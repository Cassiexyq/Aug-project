package software.wspc.web.controller;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by zhx on 2017/6/13.
 */
@Controller
public class LoginController {

    private static Logger logger=Logger.getLogger(LoginController.class);


    @RequestMapping(value = "login.do",method = RequestMethod.GET)
    public String showLogin(HttpServletRequest request, HttpServletResponse response,ModelMap map){
        return "wssearch";
    }


}
